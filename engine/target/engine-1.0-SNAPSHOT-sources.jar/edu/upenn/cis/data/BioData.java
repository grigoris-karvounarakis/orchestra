package edu.upenn.cis.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.upenn.cis.orchestra.datamodel.AbstractRelation;
import edu.upenn.cis.orchestra.datamodel.ForeignKey;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.StringType;
import edu.upenn.cis.orchestra.p2pqp.Null;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;

public class BioData {
	public static <S extends AbstractRelation> Map<String,S> createSchemas(CreateSchema<S> cs) {
		Map<String,S> schemas = new HashMap<String,S>();

		try {
			S species = cs.createSchema("SPECIES");
			species.addCol("speciesId", new IntType(false));
			species.addCol("genus", new StringType(false,true,20));
			species.addCol("species", new StringType(false,true,20));
			species.setPrimaryKey(Collections.singleton("speciesId"));
			cs.finalize(species);
			schemas.put(species.getName(), species);

			S db1 = cs.createSchema("DB1");
			db1.addCol("pName", new StringType(false,false,8));
			db1.addCol("speciesId", new IntType(false));
			db1.addCol("desc", new StringType(false,true,75));
			db1.setPrimaryKey(Collections.singleton("pName"));
			db1.addForeignKey(new ForeignKey("DB1_fk", db1, Collections.singletonList("speciesId"), species, Collections.singletonList("speciesId")));
			cs.finalize(db1);
			schemas.put(db1.getName(), db1);

			S db1todb2 = cs.createSchema("DB1toDB2");
			db1todb2.addCol("pName", new StringType(false,false,8));
			db1todb2.addCol("pId", new IntType(false));
			db1todb2.setPrimaryKey(Arrays.asList("pName", "pId"));
			db1todb2.addForeignKey(new ForeignKey("DB1toDB2_fk", db1todb2, Collections.singletonList("pName"), db1, Collections.singletonList("pName")));
			cs.finalize(db1todb2);
			schemas.put(db1todb2.getName(), db1todb2);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return schemas;
	}

	public static Map<String,QpSchema> createQpSchemas(int firstRelId) {
		Map<String,Set<String>> hashCols = new HashMap<String,Set<String>>();
		hashCols.put("SPECIES", Collections.singleton("speciesId"));
		hashCols.put("DB1", Collections.singleton("pName"));
		hashCols.put("DB1toDB2", Collections.singleton("pName"));
		return createSchemas(new CreateQpSchema(firstRelId,hashCols));
	}

	public final Iterator<QpTuple<Null>> speciesIt, db1It, db1todb2It;
	public final QpSchema db1Schema, db1todb2Schema, speciesSchema;
	
	public BioData(Map<String,QpSchema> schemas, int numProts, int numSpecies, int protsPerRef) {
		List<QpTuple<Null>> prots = new ArrayList<QpTuple<Null>>(numProts);
		List<QpTuple<Null>> species = new ArrayList<QpTuple<Null>>(numSpecies);
		List<QpTuple<Null>> refs = new ArrayList<QpTuple<Null>>(numProts / protsPerRef);

		
		db1Schema = schemas.get("DB1");
		db1todb2Schema = schemas.get("DB1toDB2");
		speciesSchema = schemas.get("SPECIES");
		
		if (db1Schema == null || db1todb2Schema == null || speciesSchema == null) {
			throw new IllegalArgumentException("Schemas must include DB1, DB1toDB2, and SPECIES");
		}
		try {
			StringBuilder sb = new StringBuilder();
			int db2Id = 0;
			int count = 0;
			for (int i = 0; i < numProts; ++i) {
				sb.setLength(0);
				int speciesNum = i % numSpecies;
				sb.append(i);
				while (sb.length() < 8) {
					sb.append('A');
				}
				String nameStr = sb.toString();
				String desc = "Description #" + i;
				QpTuple<Null> t = new QpTuple<Null>(db1Schema, false, 0, new Object[] {nameStr, speciesNum, desc});
				prots.add(t);
				++count;
				
				if (count == protsPerRef) {
					t = new QpTuple<Null>(db1todb2Schema, false, 0, new Object[] {nameStr, db2Id++});
					refs.add(t);
					count = 0;
				}
			}
			
			for (int i = 0; i < numSpecies; ++i) {
				species.add(new QpTuple<Null>(speciesSchema, false, 0, new Object[] {i, "Genus " + i, "Species " + i}));
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		
		speciesIt = species.iterator();
		db1It = prots.iterator();
		db1todb2It = refs.iterator();
	}
}

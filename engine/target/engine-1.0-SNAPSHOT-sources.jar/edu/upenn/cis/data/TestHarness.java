package edu.upenn.cis.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Appender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.experlog.zql.ParseException;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;

import edu.upenn.cis.orchestra.datamodel.Type;
import edu.upenn.cis.orchestra.datamodel.AbstractTuple.TupleFactory;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.optimization.Location;
import edu.upenn.cis.orchestra.optimization.Optimizer;
import edu.upenn.cis.orchestra.optimization.P2PQPQueryPlanGenerator;
import edu.upenn.cis.orchestra.optimization.QpSchemaFactory;
import edu.upenn.cis.orchestra.optimization.Query;
import edu.upenn.cis.orchestra.optimization.RelationTypes;
import edu.upenn.cis.orchestra.optimization.Query.SyntaxError;
import edu.upenn.cis.orchestra.optimization.QueryPlanGenerator.CreatedQP;
import edu.upenn.cis.orchestra.optimization.Type.TypeError;
import edu.upenn.cis.orchestra.p2pqp.CombineCalibrations;
import edu.upenn.cis.orchestra.p2pqp.DHTService;
import edu.upenn.cis.orchestra.p2pqp.Id;
import edu.upenn.cis.orchestra.p2pqp.IndexService;
import edu.upenn.cis.orchestra.p2pqp.Null;
import edu.upenn.cis.orchestra.p2pqp.PastryNodeFactory;
import edu.upenn.cis.orchestra.p2pqp.QpApplication;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QueryCoordinator;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.Router;
import edu.upenn.cis.orchestra.p2pqp.DHTService.DHTException;
import edu.upenn.cis.orchestra.p2pqp.QueryCoordinator.QueryFailure;
import edu.upenn.cis.orchestra.p2pqp.TupleStore.TupleStoreException;
import edu.upenn.cis.orchestra.p2pqp.plan.QueryPlan;
import edu.upenn.cis.orchestra.p2pqp.plan.QueryPlanWithSchemas;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.Holder;

public class TestHarness {
	static boolean showStats = false;

	private static Map<String,QpSchema> bioSchemas;

	public static void main(String args[]) {
		bioSchemas = Collections.unmodifiableMap(BioData.createQpSchemas(50));
		getTpchSchemas();
		URL xmlLoc = TestHarness.class.getResource("info.xml");
		DOMConfigurator.configure(xmlLoc);
		Level level = Logger.getRootLogger().getLevel();

		int dbCacheSizeMb = 128;

		boolean writeable = false;
		boolean interactive = false;
		int pastryPort = 7000;
		InetSocketAddress bootNode = null;
		CombineCalibrations cc = null;
		int qpPort = 8000;
		File envDir = null;
		String rootDir = "";

		int replicationFactor = 1;

		int maxSendRate = -1;

		List<Properties> props = new ArrayList<Properties>();
		for (int i = 0; i < args.length; ++i) {
			String arg = args[i];

			if (arg.equals("-w")) {
				writeable = true;
			} else if (arg.equals("-i")) {
				interactive = true;
			} else if (arg.equals("-r")) {
				rootDir = args[++i];
				if (rootDir.charAt(rootDir.length() - 1) != File.separatorChar) {
					rootDir += File.separatorChar;
				}
			} else if (arg.equals("-rf")) {
				String rfString = args[++i];
				try {
					replicationFactor = Integer.parseInt(rfString);
					if (replicationFactor < 0 || replicationFactor % 2 != 1) {
						System.err.println("Invalid replication factor (must be odd): " + rfString);
						System.exit(-1);
					}
				} catch (NumberFormatException ex) {
					System.err.println("Invalid replication factor: " + rfString);
					ex.printStackTrace();
					System.exit(-1);
				}
			} else if (arg.equals("-p")) {
				pastryPort = Integer.parseInt(args[++i]);
			} else if (arg.equals("-qp")) {
				qpPort = Integer.parseInt(args[++i]);
			} else if (arg.equals("-bn")) {
				String bnString = args[++i];
				try {
					bootNode = getAddress(bnString);
				} catch (Exception ex) {
					System.err.println("Invalid boot node: " + bnString);
					ex.printStackTrace();
					System.exit(-1);
				}
			} else if (arg.equals("-env")) {
				envDir = new File(rootDir + args[++i]);
				if (! envDir.exists()) {
					System.err.println("Couldn't open environment directory: " + rootDir + args[i]);
					System.exit(-1);
				}
			} else if (arg.equals("-tpch")) {
				String tpchDir = rootDir + args[++i];
				if (! new File(tpchDir).exists()) {
					System.err.println("Couldn't find TPCH directory: " + tpchDir);
					System.exit(-1);
				}
				TPCH.tpchDir = tpchDir;
			} else if (arg.equals("-calib")) {
				File calibFile = new File(rootDir + args[++i]);
				if (! calibFile.exists()) {
					System.err.println("Could not find calibration file " + calibFile);
					System.exit(-1);
				}
				try {
					ObjectInputStream ois = new ObjectInputStream(new FileInputStream(calibFile));
					cc = (CombineCalibrations) ois.readObject();
					ois.close();
				} catch (Exception ex) {
					System.err.println("Could not read calibration file " + calibFile);
					ex.printStackTrace();
					System.exit(-1);
				}
			} else if (arg.equals("-cache")) {
				dbCacheSizeMb = Integer.parseInt(args[++i]);
			} else if (arg.equals("-sendRate")) {
				try {
					maxSendRate = Integer.parseInt(args[++i]);
				} catch (NumberFormatException nfe) {
					System.err.println("Invalid send rate: " + args[i]);
					nfe.printStackTrace();
					System.exit(-1);
				}
			} else {
				File f = new File(rootDir + args[i]);
				try {
					Properties p = new Properties();
					p.load(new FileInputStream(f));
					props.add(p);
				} catch (FileNotFoundException ex) {
					System.err.println("Couldn't find node description file: " + args[i]);
					System.exit(-1);
				} catch (IOException ex) {
					System.err.println("Error loading node description file " + args[i]);
					ex.printStackTrace();
					System.exit(-1);
				}
			}
		}

		if (envDir == null) {
			System.err.println("Must specify environment directory");
			System.exit(-1);
		}

		EnvironmentConfig ec = new EnvironmentConfig();
		ec.setReadOnly(! writeable);
		ec.setAllowCreate(writeable);
		ec.setCacheSize(((long)dbCacheSizeMb) * 1024 * 1024);

		File scratchDir = new File(rootDir + "scratch");
		if (scratchDir.exists()) {
			for (File f : scratchDir.listFiles()) {
				f.delete();
			}
		} else {
			scratchDir.mkdir();
		}


		List<TestHarness> nodes = new ArrayList<TestHarness>(props.size());
		Environment e;
		try {
			e = new Environment(envDir, ec);
		} catch (DatabaseException ex) {
			System.err.println("Error creating BerkeleyDB environment");
			ex.printStackTrace();
			System.exit(-1);
			return;
		}
		System.out.println("Opened BerkeleyDB environment");

		final DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		final DocumentBuilder builder;
		try {
			builder = builderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException ex) {
			ex.printStackTrace();
			System.exit(-1);
			return;
		}

		try {
			int count = 0;
			for (Properties p : props) {
				System.out.println("Starting node #" + count);
				TestHarness th;
				try {
					th = new TestHarness(p, bootNode, qpPort + count, pastryPort + count, scratchDir, "node-" + count, e, count, cc, replicationFactor, maxSendRate);
				} catch (Exception ex) {
					System.err.println("Error creating node #" + count);
					ex.printStackTrace();
					System.exit(-1);
					return;
				}
				nodes.add(th);
				if (bootNode == null) {
					bootNode = th.pastryAddr;
				}
				++count;
			}

			Map<String,QpSchema> knownSchemas = new HashMap<String,QpSchema>();
			knownSchemas.putAll(getTpchSchemas());
			knownSchemas.putAll(TPCH.querySchemas);
			knownSchemas.putAll(bioSchemas);

			QueryPlanWithSchemas plan = null;

			String[] commands = {"quit", "load [blocksize]", "plan filename", "execute [queryname]",
					"select ...", "query", "optimize [tpch query name]", "debug (off|info|all|log)",
					"stats (off|on)", "check [relationname]", "gc", "scans (sequential|parallel)",
					"scanPriority [1-10]", "blockSize [integer]", "timeout [ms]", "probe [nodeno]",
					"router", "updateRouter [all]", "schemas", "batch (off|on)", "ownerWait delayTimeMs", "recovery (on|off)",
					"killAfterStart nodeNo delayMs", "bioLoad prots species protsPerRef"};
			String[] descs = {"", "load TPCH data", "load plan from filename",
					"execute loaded plan and optionally check against known results for queryname",
					"execute supplied SQL query and show results",
					"execute prompted for SQL query and show results",
					"optimize TPCH query or prompted for SQL query and show plan",
					"set debugging level",
					"show or hide BerkeleyDB stats after query execution",
					"check verify distributed storage using index",
					"run the Java garbage collector", "set sequential or parallel scans",
					"set scan thread priority", "set scan blocksize", "set query timeout",
					"probe for a specific tuple in local storage (at the first local node unless otherwise specified)",
					"show routing table", "recompute routing table (for first or all ndoes)", "show all base relation schemas",
					"set ship operator batching off or on",
					"set time to wait for query dissemination",
					"set recovery mode on or off",
					"kill the specified node after a query starts", "load bio data"};

			File shouldExit = new File(rootDir + "shouldExit");
			shouldExit.delete();


			if (interactive) {
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				for ( ; ; ) {
					Logger.getRootLogger().setLevel(Level.WARN);
					System.err.flush();
					System.out.print("> ");
					System.out.flush();

					String line = br.readLine();
					if (line.equals("q") || line.equals("quit") || line.equals("exit")) {
						break;
					} else if (line.startsWith("load")) {
						int blockSize = 500;
						String[] tokens = line.split("\\s+");
						if (tokens.length == 2) {
							try {
								blockSize = Integer.parseInt(tokens[1]);
							} catch (NumberFormatException nfe) {
								System.out.println("Usage: load [blocksize]");
								continue;
							}
						} else if (tokens.length != 1) {
							System.out.println("Usage: load [blocksize]");
							continue;
						}
						try {
							nodes.get(0).load(blockSize);
						} catch (DHTException ex) {
							ex.printStackTrace();
						}
					} else if (line.startsWith("blockSize")) {
						int blockSize = -1;
						String[] tokens = line.split("\\s+");
						if (tokens.length > 1) {
							try {
								blockSize = Integer.parseInt(tokens[1]);
							} catch (NumberFormatException nfe) {
								System.out.println("Usage: blockSize [blocksize]");
								continue;
							}
						}
						if (blockSize <= 0) {
							blockSize = 5000;
							System.out.println("Resetting blockSize to " + blockSize);
						}
						QueryExecution.blockSize = blockSize;
					} else if (line.startsWith("timeout")) {
						int timeout = -1;
						String[] tokens = line.split("\\s+");
						if (tokens.length > 1) {
							try {
								timeout = Integer.parseInt(tokens[1]);
							} catch (NumberFormatException nfe) {
								System.out.println("Usage: timeout [ms]");
								continue;
							}
						}
						if (timeout <= 0) {
							timeout = 10000;
							System.out.println("Resetting timeout to " + timeout);
						}
						QueryCoordinator.timeout = timeout;
					} else if (line.startsWith("scanPriority")) {
						int priority = -1;
						String[] tokens = line.split("\\s+");
						if (tokens.length > 1) {
							try {
								priority = Integer.parseInt(tokens[1]);
							} catch (NumberFormatException nfe) {
								System.out.println("Usage: scanPriority [1-10]");
								continue;
							}
						}
						if (priority < Thread.MIN_PRIORITY || priority > Thread.MAX_PRIORITY) {
							System.out.println("Resetting scanPriority to " + Thread.NORM_PRIORITY);
							priority = Thread.NORM_PRIORITY;
						}
						QueryExecution.scanThreadPriority = priority;
					} else if (line.startsWith("plan")) {
						int pos = 5;
						if (line.length() <= pos) {
							System.err.println("Must specify filename for plan");
							continue;
						}
						while (Character.isWhitespace(line.charAt(pos))) {
							++pos;
							if (pos >= line.length()) {
								break;
							}
						}
						if (pos >= line.length()) {
							System.err.println("Must specify filename for plan");
							continue;
						}
						String filename = line.substring(pos);
						FileInputStream fis;
						try {
							fis = new FileInputStream(rootDir + filename);
							Document document = builder.parse(fis);
							Element root = document.getDocumentElement();
							plan = QueryPlanWithSchemas.deserialize(root, knownSchemas);
							fis.close();
						} catch (IOException ioe) {
							System.err.println("Couldn't read plan file " + filename);
							continue;
						} catch (Exception ex) {
							ex.printStackTrace();
							continue;
						}
					} else if (line.toUpperCase().startsWith("SELECT")) {
						Logger.getRootLogger().setLevel(level);
						try {
							nodes.get(0).execute(line);
						} catch (Exception ex) {
							ex.printStackTrace();
						}
					} else if (line.startsWith("optimize")) {
						String[] tokens = line.split("\\s+");
						String query;
						if (tokens.length == 1) {
							System.out.println("Enter query: ");
							query = br.readLine();
						} else {
							query = TPCH.queries.get(tokens[1]);
							if (query == null) {
								System.err.println("TPCH Query '" + tokens[1] + "' is not known");
							}
						}
						if (query != null) {
							try {
								QueryPlanWithSchemas qpws = nodes.get(0).optimize(query,0);
								Document doc = builder.newDocument();
								Element el = doc.createElement("QueryPlanWithSchemas");
								doc.appendChild(el);
								qpws.serialize(doc, el, getTpchSchemas());
								DomUtils.write(doc, System.out);
							} catch (Exception ex) {
								ex.printStackTrace();
							}
						}
					} else if (line.startsWith("execute")) {
						if (plan == null) {
							System.err.println("Must specify plan first");
							continue;
						}
						String[] tokens = line.split("\\s+");
						Logger.getRootLogger().setLevel(level);
						try {
							if (tokens.length == 1) {
								nodes.get(0).execute(plan,null);
							} else {
								nodes.get(0).execute(plan,tokens[1]);
							}
						} catch (Exception ex) {
							ex.printStackTrace();
						}
					} else if (line.startsWith("query")) {
						System.out.println("Enter query: ");
						try {
							nodes.get(0).execute(br.readLine());
						} catch (Exception ex) {
							ex.printStackTrace();
						}
					} else if (line.startsWith("debug")) {
						String[] tokens = line.split("\\s+");
						String arg = "";
						if (tokens.length == 2) {
							arg = tokens[1];
						}

						Class<?> c = TestHarness.class;
						URL configLoc = null;
						if (arg.equals("off")) {
							configLoc = c.getResource("off.xml");
							System.out.println("Debugging info off");
						} else if (arg.equals("info")) {
							configLoc = c.getResource("info.xml");
							System.out.println("Showing some debugging info");
						} else if (arg.equals("all")) {
							configLoc = c.getResource("debug.xml");
							System.out.println("Showing more debugging info");
						} else if (arg.equals("log")) {
							configLoc = c.getResource("trace.xml");
							System.out.println("Showing more debugging info and logging all to a file");
						} else {
							System.out.println("debug (off|info|log)");
						}
						if (configLoc != null) {
							DOMConfigurator.configure(configLoc);
							level = Logger.getRootLogger().getLevel();
						}
					} else if (line.startsWith("stats")) {
						String[] tokens = line.split("\\s+");
						String arg = "";
						if (tokens.length == 2) {
							arg = tokens[1];
						}
						if (arg.equals("on")) {
							showStats = true;
						} else if (arg.equals("off")) {
							showStats = false;
						} else {
							System.out.println("stats (off|on)");
						}
					} else if (line.startsWith("check")) {
						Map<InetSocketAddress,Set<QpTuple<?>>> missing = new HashMap<InetSocketAddress,Set<QpTuple<?>>>();
						Collection<QpSchema> schemas = null;
						String[] tokens = line.split("\\s+");

						if (tokens.length == 2) {
							QpSchema schema = getTpchSchemas().get(tokens[1].toUpperCase());
							if (schema == null) {
								System.out.println("Unknown schema " + tokens[1].toUpperCase());
							} else {
								schemas = Collections.singleton(schema);
							}
						} else {
							schemas = getTpchSchemas().values();
						}
						if (schemas != null) {
							for (QpSchema schema : schemas) {
								if (schema.getLocation() != QpSchema.Location.STRIPED) {
									continue;
								}
								System.out.println("Checking " + schema.getName());
								Map<InetSocketAddress,Set<QpTuple<?>>> missingFromRel = nodes.get(0).app.findMissingTuples(schema.getName(), 0); 
								if (! missingFromRel.isEmpty()) {
									for (Map.Entry<InetSocketAddress,Set<QpTuple<?>>> me : missingFromRel.entrySet()) {
										if (me.getValue().isEmpty()) {
											continue;
										}
										Set<QpTuple<?>> alreadyMissing = missing.get(me.getKey());
										if (alreadyMissing == null) {
											missing.put(me.getKey(), me.getValue());
										} else {
											alreadyMissing.addAll(me.getValue());
										}
									}
								}
							}
							if (missing.isEmpty()) {
								System.out.println("All nodes have all the tuples they should");
							} else {
								for (Map.Entry<InetSocketAddress, Set<QpTuple<?>>> me : missing.entrySet()) {
									for (QpTuple<?> t : me.getValue()) {
										System.out.println(me.getKey() + " is missing " + t + " (" + t.getQPid() + ")");
									}
								}
							}
						}
					} else if (line.startsWith("gc")) {
						System.out.print("Garbage collecting...");
						System.out.flush();
						System.gc();
						System.out.println("done");
					} else if (line.startsWith("scans")) {
						String[] tokens = line.split("\\s+");
						String arg = "";
						if (tokens.length == 2) {
							arg = tokens[1];
						}

						if (arg.equalsIgnoreCase("sequential")) {
							QueryExecution.multipleScanThreads = false;
							System.out.println("Set sequential scans");
						} else {
							QueryExecution.multipleScanThreads = true;
							System.out.println("Set parallel scans");
						}
					} else if (line.startsWith("schemas")) {
						Document doc = builder.newDocument();
						Element el = doc.createElement("TpchSchemas");
						doc.appendChild(el);

						for (QpSchema schema : getTpchSchemas().values()) {
							Element schemaEl = schema.serialize(doc);	
							el.appendChild(schemaEl);
						}
						DomUtils.write(doc, System.out);
					} else if (line.startsWith("probe")) {
						String[] tokens = line.split("\\s+");
						int node = -1;
						if (tokens.length == 1) {
							node = 0;
						} else {
							try {
								node = Integer.parseInt(args[1]);
							} catch (NumberFormatException nfe) {
								System.out.println("Invalid node " + tokens[1]);
							}
							if (node >= nodes.size()) {
								System.out.println("Invalid node " + node);
								node = -1;
							}
						}
						QpApplication<?> app = null;
						if (node >= 0) {
							app = nodes.get(node).app;
						}
						QpSchema schema = null;
						if (app != null) {
							System.out.print("Enter table name: ");
							System.out.flush();
							String table = br.readLine();
							schema = app.getStore().getSchema(table.toUpperCase());
							if (schema == null) {
								System.out.println("Unknown table name: " + table);
							}
						}
						if (schema != null) {
							Object[] fields = new Object[schema.getNumCols()];
							QpTuple<?> key = null;
							if (key != null) {
								int numCols = schema.getNumCols();
								for (int i = 0; i < numCols; ++i) {
									if (! schema.getKeyColsSet().contains(i)) {
										continue;
									}
									Type t = schema.getColType(i);
									System.out.print("Enter a value for " + schema.getColName(i) + ": ");
									System.out.flush();
									String val = br.readLine();
									try {
										Object o = t.fromStringRep(val);
										fields[i]= o;
									} catch (Exception ex) {
										System.out.println("Invalid value for " + schema.getColName(i) + ": " + val);
										fields = null;
										break;
									}
								}
							}
							if (fields != null) {
								System.out.print("Enter epoch: ");
								System.out.flush();
								String epoch = br.readLine();
								try {
									int ep = Integer.parseInt(epoch);
									key = new QpTuple<Null>(schema, true, ep, fields);
								} catch (Exception ex) {
									System.out.println("Invalid epoch: " + epoch);
								}
							}
							if (key != null) {
								try {
									QpTuple<?> t = app.getStore().getTuple(key, key.getEpoch());
									if (t == null) {
										System.out.println("No value found for " + key + " at epoch " + key.getEpoch());
									} else {
										System.out.println(t);
									}
								} catch (TupleStoreException tse) {
									tse.printStackTrace();
								}
							}
						}
					} else if (line.startsWith("router")) {
						boolean all = false;
						String[] tokens = line.split("\\s+");
						if (tokens.length >= 2 && tokens[1].equals("all")) {
							all = true;
						}
						for (int i = 0; i < (all ? nodes.size() : 1); ++i) {
							Router r = nodes.get(i).app.getRouter();
							System.out.println("Node " + i + " routing table (" + r.size() + " entries):\n" + r);
						}
					} else if (line.startsWith("updateRouter")) {
						boolean all = false;
						String[] tokens = line.split("\\s+");
						if (tokens.length >= 2 && tokens[1].equals("all")) {
							all = true;
						}
						try {
							if (all) {
								for (TestHarness th : nodes) {
									th.app.scheduleRoutingTableUpdate();
								}
								for (TestHarness th : nodes) {
									th.app.performRoutingTableUpdate();
								}
								System.out.println("Updated all routing tables");
							} else {
								nodes.get(0).app.performRoutingTableUpdate();
								System.out.println("Updated node 0 routing table");
							}
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						for (int i = 0; i < (all ? nodes.size() : 1); ++i) {
							Router r = nodes.get(i).app.getRouter();
							System.out.println("Node " + i + " routing table (" + r.size() + " entries):\n" + r);
						}
					} else if (line.startsWith("index")) {
						String[] tokens = line.split("\\s+");
						if (tokens.length != 3) {
							System.out.println("Usage: index relationName epoch");
						} else {
							String relName = tokens[1];
							QpSchema rel = knownSchemas.get(relName.toUpperCase());
							int epoch = Integer.parseInt(tokens[2]);
							if (rel == null) {
								System.out.println("Relation " + relName + " is unknown");
							} else {
								final Holder<Boolean> done = new Holder<Boolean>(false);
								final Holder<Exception> ex = new Holder<Exception>(null);
								long startTime = System.nanoTime();
								nodes.get(0).app.getIndex().getTuplesInRelation(rel.relId, epoch, new IndexService.TupleSink() {
									int numPagesRemaining = -1;
									public synchronized void deliverTuples(QpTuple<?>[] contents) {
										if (numPagesRemaining < 0) {
											processException(new RuntimeException("NumPages < 0, totalNumTuplesIs is not being called"));
											return;
										}
										--numPagesRemaining;
										if (numPagesRemaining < 0) {
											processException(new RuntimeException("NumPages < 0, pages are being delivered multiple times"));
											return;
										}
										if (numPagesRemaining == 0) {
											synchronized (done) {
												done.value = true;
												done.notify();
											}
										}
									}

									public void processException(Exception e) {
										synchronized (done) {
											done.value = true;
											ex.value = e;
											done.notify();
										}
									}

									public void totalNumTuplesIs(int numTuples, int numPages) {
										numPagesRemaining = numPages;
									}
								});
								synchronized (done) {
									while (! done.value) {
										done.wait();
									}
								}
								long endTime = System.nanoTime();
								if (ex.value != null) {
									ex.value.printStackTrace();
								} else {
									System.out.println("Index retrieval time: " + ((endTime - startTime) / 1.0e9));
								}
							}
						}
					} else if (line.startsWith("batch")) {
						String[] tokens = line.split("\\s+");
						if (tokens.length != 2) {
							System.out.println("Usage: batch (on|off)");
						} else {
							if (tokens[1].equals("on")) {
								nodes.get(0).app.setShipBatching(true);
								System.out.println("Set batching on");
							} else if (tokens[1].equals("off")) {
								nodes.get(0).app.setShipBatching(false);
								System.out.println("Set batching off");
							} else {
								System.out.println("Usage: batch (on|off)");
							}
						}
					} else if (line.startsWith("ownerWait")) {
						String[] tokens = line.split("\\s+");
						if (tokens.length != 2) {
							System.out.println("Query dissemination time is " + QpApplication.QUERY_DISSEMINATION_TIME_MS + " ms");
							System.out.println("Usage: ownerWait delayTimeMs");
						} else {
							int delayTimeMs = Integer.parseInt(tokens[1]);
							QpApplication.QUERY_DISSEMINATION_TIME_MS = delayTimeMs;
						}
					} else if (line.startsWith("recovery")) {
						String[] tokens = line.split("\\s+");
						if (tokens.length != 2) {
							System.out.println("Recovery mode is " + (nodes.get(0).attemptRecovery ? "on" : "off"));
							System.out.println("Usage: recovery (on|off)");
						} else {
							if (tokens[1].equals("on")) {
								nodes.get(0).attemptRecovery = true;
								System.out.println("Set recovery on");
							} else if (tokens[1].equals("off")) {
								nodes.get(0).attemptRecovery = false;
								System.out.println("Set recovery off");
							} else {
								System.out.println("Usage: recovery (on|off)");
							}
						}
					} else if (line.startsWith("killAfterStart")) {
						String[] tokens = line.split("\\s+");
						if (tokens.length != 3) {
							System.out.println("Usage: killAfterStart nodeNo delayMs");
						} else {
							int nodeNo, delayMs;
							try {
								nodeNo = Integer.parseInt(tokens[1]);
								delayMs = Integer.parseInt(tokens[2]);
								if (nodeNo < 0 || nodeNo >= nodes.size()) {
									System.out.println("nodeNo must be between 0 and " + (nodes.size() - 1));
								} else {
									nodes.get(nodeNo).app.dieAfterNextQuery(delayMs);
								}
								if (delayMs >= 0 && nodes.get(0).attemptRecovery == false) {
									System.out.println("Warning: recovery is not enabled");
								}

							} catch (NumberFormatException nfe) {
								System.out.println("Usage: killAfterStart nodeNo delayMs");
							}
						}
					} else if (line.startsWith("bioLoad")) {
						int blockSize = 500;
						int prots, species, protsPerRef;
						String[] tokens = line.split("\\s+");
						if (tokens.length == 4) {
							try {
								prots = Integer.parseInt(tokens[1]);
								species = Integer.parseInt(tokens[2]);
								protsPerRef = Integer.parseInt(tokens[3]);
							} catch (NumberFormatException nfe) {
								System.out.println("bioLoad prots species protsPerRef");
								continue;
							}
						} else {
							System.out.println("bioLoad prots species protsPerRef");
							continue;
						}
						try {
							BioData bd = new BioData(bioSchemas, prots, species, protsPerRef);
							nodes.get(0).load(bd.db1Schema, bd.db1It, blockSize);
							nodes.get(0).load(bd.db1todb2Schema, bd.db1todb2It, blockSize);
							nodes.get(0).load(bd.speciesSchema, bd.speciesIt, blockSize);
						} catch (DHTException ex) {
							ex.printStackTrace();
						}

					} else {
						int maxLength = 0;
						for (String s : commands) {
							if (s.length() > maxLength) {
								maxLength = s.length();
							}
						}
						String format = "%-" + (maxLength + 1) + "s%s\n";
						System.out.println("Commands:");
						for (int i = 0; i < commands.length; ++i) {
							System.out.format(format, commands[i], descs[i]);
						}
					}
				}
			} else {
				while (! shouldExit.exists()) {
					Thread.sleep(500);
				}
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (InterruptedException ex) {
		} finally {
			try {
				for (TestHarness th : nodes) {
					th.app.stop();
					th.pnf.cleanup();
				}
			} catch (Exception ex2) {
				ex2.printStackTrace();
			}

			try {
				Thread.sleep(1000);
			} catch (InterruptedException ex) {
			}

			try {
				e.close();
			} catch (DatabaseException de) {
				de.printStackTrace();
			}

			Enumeration<?> appenders = Logger.getRootLogger().getAllAppenders();
			while (appenders.hasMoreElements()) {
				((Appender) appenders.nextElement()).close();
			}
		}
	}

	private final Map<String,InetSocketAddress> namedNodes;
	private final Set<String> localNames;
	private final QpApplication<Null> app;
	private final CombineCalibrations cc;
	private final PastryNodeFactory pnf;
	final InetSocketAddress pastryAddr;
	private boolean attemptRecovery = false;

	private TestHarness(Properties p, InetSocketAddress bootAddr, int qpPort, int pastryPort, File scratchDir, String scratchPrefix, Environment e, int count, CombineCalibrations cc, int replicationFactor, int maxSendRate) throws Exception {
		String localNames = p.getProperty("localNames");
		if (localNames == null) {
			this.localNames = Collections.emptySet();
		} else {
			Set<String> names = new HashSet<String>();
			String namesList[] = localNames.split("\\|");
			names.addAll(Arrays.asList(namesList));
			names.remove("");
			this.localNames = Collections.unmodifiableSet(names);
		}
		this.cc = cc;
		Id nodeId;
		String namedNodes = p.getProperty("namedNodes");
		if (namedNodes == null) {
			this.namedNodes = Collections.emptyMap();
		} else {
			String[] entries = namedNodes.split("\\|");
			Map<String,InetSocketAddress> names = new HashMap<String,InetSocketAddress>(entries.length); 
			for (String entry : entries) {
				if (entry.length() == 0) {
					continue;
				}
				String[] parts = entry.split("@");
				if (parts.length != 2) {
					throw new RuntimeException("Named nodes format: node1@host:port|node2@host:port...");
				}
				InetSocketAddress addr = getAddress(parts[1]);
				names.put(parts[0], addr);
			}
			this.namedNodes = Collections.unmodifiableMap(names);
		}
		String nodeIdStr = p.getProperty("nodeId");
		if (nodeIdStr == null) {
			nodeId = null;
		} else {
			nodeId = Id.fromString(nodeIdStr);
		}
		InetAddress bindAddress;
		String bindAddressString = p.getProperty("bindAddr");
		if (bindAddressString == null) {
			bindAddress = InetAddress.getLocalHost();
		} else {
			bindAddress = InetAddress.getByName(bindAddressString);
		}
		InetSocketAddress bindPort = new InetSocketAddress(bindAddress, qpPort);


		pnf = new PastryNodeFactory(pastryPort, bootAddr, bindAddress);
		pastryAddr = new InetSocketAddress(bindAddress, pastryPort);

		app = new QpApplication<Null>(bindPort, nodeId, pnf, scratchDir, scratchPrefix, e, "store" + count, "index" + count, null, this.namedNodes, replicationFactor);
		app.waitUntilReady();
		for (String name : this.localNames) {
			app.addLocalName(name);
		}

		for (QpSchema s : getTpchSchemas().values()) {
			app.addTable(s, 0);
		}

		for (QpSchema s : bioSchemas.values()) {
			app.addTable(s, 0);
		}

		if (maxSendRate > 0) {
			app.setMaxSendRate(maxSendRate);
		}

		System.out.println("Created TestHarness node on port " + qpPort);

	}

	private Optimizer<Location,QueryPlan,Double,QpSchema> getOptimizer() throws IOException, ClassNotFoundException {
		int numNodes = app.getParticipants().size();
		P2PQPQueryPlanGenerator<QpSchema> qpg = new P2PQPQueryPlanGenerator<QpSchema>(numNodes, cc);
		RelationTypes<Location,QpSchema> rt = getTpchRT();
		Location.Factory lf = new Location.Factory(rt);
		return new Optimizer<Location,QueryPlan,Double,QpSchema>(1,true,rt,qpg,lf);		
	}

	private static InetSocketAddress getAddress(String addr) throws UnknownHostException, NumberFormatException {
		String[] addrParts = addr.split(":");
		if (addrParts.length != 2) {
			throw new RuntimeException("Node format: host.name:port");
		}
		int bootPort = Integer.parseInt(addrParts[1]);
		InetAddress host = InetAddress.getByName(addrParts[0]);
		return new InetSocketAddress(host, bootPort);
	}


	private static Map<String,QpSchema> schemas = null;

	private static Map<String,QpSchema> getTpchSchemas() {
		if (schemas != null) {
			return schemas;
		}

		schemas = Collections.unmodifiableMap(TPCH.createSchemas(new CreateQpSchema(hashCols)));
		return schemas;
	}

	private static RelationTypes<Location,QpSchema> rt;
	private static RelationTypes<Location,QpSchema> getTpchRT() throws IOException, ClassNotFoundException {
		if (rt != null) {
			return rt;
		}
		rt = TPCH.createRT(getTpchSchemas());
		return rt;
	}

	public static final Map<String,Set<String>> hashCols;

	static {
		Map<String,Set<String>> temp = new HashMap<String,Set<String>>();
		temp.put("PART", Collections.singleton("P_PARTKEY"));
		temp.put("SUPPLIER", Collections.singleton("S_SUPPKEY"));
		temp.put("PARTSUPP", Collections.singleton("PS_PARTKEY"));
		temp.put("CUSTOMER", Collections.singleton("C_CUSTKEY"));
		temp.put("SUPPLIER", Collections.singleton("S_SUPPKEY"));
		temp.put("ORDERS", Collections.singleton("O_ORDERKEY"));
		temp.put("LINEITEM", Collections.singleton("L_ORDERKEY"));
		// Nation and Region are replicated
		hashCols = Collections.unmodifiableMap(temp);
	}

	private void load(final QpSchema schema, Iterator<QpTuple<Null>> tuples, int sendBlockSize) throws IOException, InterruptedException, DHTException {
		if (schema.getLocation() == QpSchema.Location.REPLICATED) {
			List<QpTuple<Null>> all = new ArrayList<QpTuple<Null>>();
			while (tuples.hasNext()) {
				all.add(tuples.next());
			}
			app.publishReplicatedRelation(schema.relId,all);
			System.err.println("Published replicated relation " + schema.getName());
			return;
		}
		DHTService.TupleCountObserver tco = new DHTService.TupleCountObserver() {
			int lastPrint = 0;
			public void tuplesSentCountIs(int count) {
				if (count - lastPrint >= 100000) {
					System.err.println("Sent " + count + " " + schema.getName() + " tuples");
					lastPrint = count;
				}
			}
		};
		app.getDHT().addTuples(tuples, 0, sendBlockSize, tco);
		System.err.println("Sent all " + schema.getName() + " tuples");

		app.getDHT().finishEpochForRelation(schema.getName());
		System.err.println("Updated index for relation " + schema.getName());

	}

	private void load(final int sendBlockSize) throws IOException, DHTException, InterruptedException {
		final Map<String,QpSchema> schemas = getTpchSchemas();

		long startTime = System.currentTimeMillis();

		TupleFactory<QpSchema,QpTuple<Null>> tf = new TupleFactory<QpSchema, QpTuple<Null>>() {
			final Map<String,QpSchema> schemas = getTpchSchemas();
			public QpTuple<Null> createTuple(String relationName, Object... fields)
			throws ValueMismatchException {
				QpSchema s = schemas.get(relationName);
				return new QpTuple<Null>(s, false, 0, fields);
			}

			public QpSchema getSchema(String relationName) {
				return schemas.get(relationName);
			}

		};

		for (Map.Entry<String, QpSchema> me : schemas.entrySet()) {
			final String relation = me.getKey();
			Iterator<QpTuple<Null>> tuples = TPCH.readTuples(relation, tf);
			load(me.getValue(), tuples, sendBlockSize);
		}

		long endTime = System.currentTimeMillis();
		double loadTime = (endTime - startTime) / 1000.0;
		System.out.println("Loading took " + loadTime + " seconds");
	}

	static int queryId = 100;

	private QueryPlanWithSchemas optimize(String query, int queryId) throws TypeError, SyntaxError, ParseException, InterruptedException, IOException, ClassNotFoundException {
		Optimizer<Location,QueryPlan,Double,QpSchema> optimizer = getOptimizer();
		if (optimizer == null) {
			return null;
		}
		Query q = TPCH.getQuery(query);

		QpSchemaFactory qsf = new QpSchemaFactory(queryId);
		CreatedQP<QpSchema,QueryPlan,Double> cqp = optimizer.createQueryPlan(q, Location.CENTRALIZED, qsf);
		return new QueryPlanWithSchemas(cqp.qp, qsf.getCreatedSchemasByName(), cqp.cost);
	}

	private void execute(String query) throws Exception {
		int queryId = ++TestHarness.queryId;
		QueryPlanWithSchemas qpws = null;
		try {
			qpws = optimize(query,queryId);
		} catch (SyntaxError se) {
			se.printStackTrace();
			return;
		}
		if (qpws == null) {
			System.out.println("Optimization is not supported because no calibration information was supplied");
			return;
		}

		List<QpTuple<Null>> results = new ArrayList<QpTuple<Null>>();
		long startTime = System.nanoTime();
		app.beginQuery(queryId, 0, qpws, results, attemptRecovery);
		app.waitUntilDone(queryId);
		long endTime = System.nanoTime();
		app.endQuery(queryId);

		for (QpTuple<?> t : results) {
			System.out.println(t);
		}
		System.out.println("Execution time: " + ((endTime - startTime) / 1.0e9));
		System.out.println("Result size: " + results.size() + " tuples");
		if (showStats) {
			app.printStoreStats(System.out);
		}
	}

	private void execute(QueryPlanWithSchemas plan, String queryName) throws Exception {
		Set<QpTuple<?>> expected;
		if (queryName == null) {
			expected = null;
		} else {
			try {
				expected = TPCH.readTpchResults().get(queryName);
			} catch (IOException io) {
				System.err.println("Couldn't read TPCH results");
				io.printStackTrace();
				return;
			}
			if (expected == null) {
				System.err.println("Couldn't find results for query " + queryName);
				return;
			}
		}

		int queryId = ++TestHarness.queryId;
		List<QpTuple<Null>> results = new ArrayList<QpTuple<Null>>();
		long startTime = System.nanoTime();
		app.beginQuery(queryId, 0, plan, results, attemptRecovery);
		try {
			app.waitUntilDone(queryId);
		} catch (QueryFailure qf) {
			long endTime = System.nanoTime();
			System.out.println("Execution time: " + ((endTime - startTime) / 1.0e9) + " seconds");
			qf.printStackTrace();
			return;
		} catch (Exception e) {
			System.err.println("Caught unexpected exception");
			e.printStackTrace();
			return;
		}
		long endTime = System.nanoTime();
		app.endQuery(queryId);

		if (expected == null) {
			if (results.size() < 500) {
				for (QpTuple<?> t : results) {
					System.out.println(t);
				}
			}
		} else {
			Set<QpTuple<Null>> resultsSet = new HashSet<QpTuple<Null>>(results);
			if (resultsSet.equals(expected)) {
				System.out.println("Results match expected");
			} else {
				for (QpTuple<?> t : expected) {
					if (! resultsSet.contains(t)) {
						System.out.println("-" + t);
					}
				}
				for (QpTuple<?> t : results) {
					if (! expected.contains(t)) {
						System.out.println("+" + t);
					}
				}
			}
		}

		System.out.println("Result size: " + results.size() + " tuples");
		System.out.println("Execution time: " + ((endTime - startTime) / 1.0e9) + " seconds");

		if (showStats) {
			app.printStoreStats(System.out);
		}
	}
}

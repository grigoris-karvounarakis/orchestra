package edu.upenn.cis.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import edu.upenn.cis.orchestra.datamodel.AbstractRelation;
import edu.upenn.cis.orchestra.datamodel.AbstractTuple;
import edu.upenn.cis.orchestra.datamodel.Date;
import edu.upenn.cis.orchestra.datamodel.DateType;
import edu.upenn.cis.orchestra.datamodel.DoubleType;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.StringType;
import edu.upenn.cis.orchestra.datamodel.Type;
import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.optimization.Histogram;

public class HistogramGenerator {
	private static final int stringLength = 3;
	public static <S extends AbstractRelation> List<Histogram<?>> generateHistograms(S schema, int[] cols, Iterator<? extends AbstractTuple<S>> it, int numBuckets) {
		final int numCols = schema.getNumCols();
		List<List<Object>> values = new ArrayList<List<Object>>(numCols);
		for (int i = 0; i < numCols; ++i) {
			values.add(new ArrayList<Object>());
		}
		while (it.hasNext()) {
			AbstractTuple<?> t = it.next();
			for (int col : cols) {
				Object o = t.get(col);
				if (o != null) {
					if (o instanceof String) {
						values.get(col).add(Histogram.convertForHistogram(stringLength, (String) o));
					} else {
						values.get(col).add(o);
					}
				}
			}
		}
		List<Histogram<?>> retval = new ArrayList<Histogram<?>>(numCols);
		for (int col : cols) {
			final Type t = schema.getColType(col);
			retval.add(generateHistogram(t, values.get(col), numBuckets));
			values.set(col, null);
		}
		return retval;
	}

	private static Histogram<?> generateHistogram(final Type t, List<Object> data, int numBuckets) {
		Comparator<Object> comp = new Comparator<Object>() {
			public int compare(Object o1, Object o2) {
				try {
					return t.compareTwo(o1, o2);
				} catch (CompareMismatch e) {
					throw new RuntimeException(e);
				}
			}
		};
		Collections.sort(data, comp);
		final int size = data.size();

		List<Object> bucketEdges = new ArrayList<Object>(numBuckets + 1);
		List<Double> cards = new ArrayList<Double>(numBuckets), DVs = new ArrayList<Double>(numBuckets);
		if (size < numBuckets * 5) {
			bucketEdges.add(data.get(0));
			// Can just put one item into each bucket
			for (int pos = 0; pos < size; ++pos) {
				Object curr = data.get(pos);
				int count = 1;
				while (pos + 1 < size && curr.equals(data.get(pos + 1))) {
					++pos;
					++count;
				}
				if ((! bucketEdges.isEmpty()) && (! bucketEdges.get(bucketEdges.size() -1).equals(curr))) {
					bucketEdges.add(curr);
					cards.add(0.0);
					DVs.add(0.0);
				}
				cards.add((double) count);
				DVs.add(1.0);
				bucketEdges.add(getSuccessor(curr));
			}
		} else {
			// Build an equi-depth histogram
			int approxBucketSize = size / numBuckets;
			if (approxBucketSize == 0) {
				approxBucketSize = 1;
			}


			bucketEdges.add(data.get(0));
			int card = 0, DV = 1;
			Object last = null;
			for (int pos = 0; pos < size; ++pos) {
				Object curr = data.get(pos);
				if (card > approxBucketSize && (! last.equals(curr))) {
					bucketEdges.add(curr);
					cards.add((double) card);
					DVs.add((double) DV);
					card = 0;
					DV = 1;
					last = null;
				}
				card++;
				if (last != null && (! last.equals(curr))) {
					++DV;
				}
				last = curr;
			}
			bucketEdges.add(getSuccessor(last));
			cards.add((double) card);
			DVs.add((double) DV);
		}

		double[] cardsArray = new double[cards.size()], DVsArray = new double[DVs.size()];
		for (int i = 0; i < cardsArray.length; ++i) {
			cardsArray[i] = cards.get(i);
			DVsArray[i] = DVs.get(i);
		}

		if (t instanceof IntType) {
			List<Integer> intBE = new ArrayList<Integer>(bucketEdges.size());
			for (Object o : bucketEdges) {
				intBE.add((Integer) o);
			}
			return Histogram.createIntegerHistogram(intBE, cardsArray, DVsArray);
		} else if (t instanceof DoubleType) {
			List<Double> doubleBE = new ArrayList<Double>(bucketEdges.size());
			for (Object o : bucketEdges) {
				doubleBE.add((Double) o);
			}
			return Histogram.createDoubleHistogram(doubleBE, cardsArray, DVsArray);
		} else if (t instanceof DateType) {
			List<Date> dateBE = new ArrayList<Date>(bucketEdges.size());
			for (Object o : bucketEdges) {
				dateBE.add((Date) o);
			}
			return Histogram.createDateHistogram(dateBE, cardsArray, DVsArray);
		} else if (t instanceof StringType) {
			List<String> stringBE = new ArrayList<String>(bucketEdges.size());
			for (Object o : bucketEdges) {
				stringBE.add((String) o);
			}
			return Histogram.createStringHistogram(stringLength, stringBE, cardsArray, DVsArray);
		} else {
			throw new IllegalArgumentException("Don't know how to process type " + t);
		}
	}

	private static Object getSuccessor(Object o) {
		if (o instanceof Integer) {
			return ((Integer) o ) + 1;
		} else if (o instanceof Double) {
			return o;
		} else if (o instanceof Date) {
			return ((Date) o).tomorrow();
		} else if (o instanceof String) {
			return Histogram.getSuccessorForHistogram(stringLength, (String) o);
		} else {
			throw new IllegalArgumentException("Don't know how to process data of type " + o.getClass().getName());
		}
	}
}

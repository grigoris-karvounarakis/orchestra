package edu.upenn.cis.orchestra.p2pqp.plan;

public class DistributedLoc extends Location {
	private static final long serialVersionUID = 1L;
	private static final DistributedLoc instance = new DistributedLoc();
	
	public static DistributedLoc getInstance() {
		return instance;
	}
	
	private DistributedLoc() {
	}
	
	@Override
	public boolean equals(Object o) {
		return (o instanceof DistributedLoc);
	}

	public boolean isDistributed() {
		return true;
	}
}

package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;
import java.util.Collection;

import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class JoinInputHasFinished extends QpMessage implements QueryExecutionMessage {
	private static final long serialVersionUID = 1L;

	public final int[] leftOps, rightOps;
	private final int queryId;
	
	public JoinInputHasFinished(InetSocketAddress dest, int queryId, Collection<Integer> leftOps, Collection<Integer> rightOps) {
		super(dest);
		this.queryId = queryId;
		this.leftOps = new int[leftOps.size()];
		int pos = 0;
		for (int op : leftOps) {
			this.leftOps[pos++] = op;
		}
		this.rightOps = new int[rightOps.size()];
		pos = 0;
		for (int op : rightOps) {
			this.rightOps[pos++] = op;
		}
	}
	
	public int getQueryId() {
		return queryId;
	}

	public JoinInputHasFinished(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf,origin);
		leftOps = new int[buf.readInt()];
		for (int i = 0; i < leftOps.length; ++i) {
			leftOps[i] = buf.readInt();
		}
		rightOps = new int[buf.readInt()];
		for (int i = 0; i < rightOps.length; ++i) {
			rightOps[i] = buf.readInt();
		}
		queryId = buf.readInt();
	}

	@Override
	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(leftOps.length);
		for (int i = 0; i < leftOps.length; ++i) {
			buf.writeInt(leftOps[i]);
		}
		buf.writeInt(rightOps.length);
		for (int i = 0; i < rightOps.length; ++i) {
			buf.writeInt(rightOps[i]);
		}
		buf.writeInt(queryId);		
	}

}

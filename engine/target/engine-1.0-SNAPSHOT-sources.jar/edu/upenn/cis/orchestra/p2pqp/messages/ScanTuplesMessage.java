package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;

import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.IndexService.EpochNum;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;

public class ScanTuplesMessage extends QpMessage implements QueryExecutionMessage {
	private static final long serialVersionUID = 1L;
	private final int queryId;
	private final byte[] data;
	public final int operatorId;
	private final int epoch;
	private final int pageNum;
	public final int keySetNo;

	public ScanTuplesMessage(InetSocketAddress dest, int keySetNo, int queryId, int operatorId, byte[] data, int epoch, int pageNum) {
		super(dest);
		this.queryId = queryId;
		this.data = data;
		this.operatorId = operatorId;
		this.epoch = epoch;
		this.pageNum = pageNum;
		this.keySetNo = keySetNo;
	}

	public List<ByteArrayWrapper> getData() {
		byte[] data = this.data;
		List<ByteArrayWrapper> retval = new ArrayList<ByteArrayWrapper>();
		int pos = 0;
		while (pos < data.length) {
			int tupleLen = IntType.getValFromBytes(data, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			retval.add(new ByteArrayWrapper(data, pos, tupleLen));
			pos += tupleLen;
		}
		return retval;
	}

	public String toString() {
		return "ScanTuplesMessage";
	}

	@Override
	protected
	void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(queryId);
		buf.writeBytes(data);
		buf.writeInt(operatorId);
		buf.writeInt(epoch);
		buf.writeInt(pageNum);
		buf.writeInt(keySetNo);
	}

	public ScanTuplesMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		queryId = buf.readInt();
		data = buf.readBytes();
		operatorId = buf.readInt();
		epoch = buf.readInt();
		pageNum = buf.readInt();
		keySetNo = buf.readInt();
	}

	public int getQueryId() {
		return queryId;
	}
	
	public EpochNum getEpochNum() {
		return new EpochNum(epoch, pageNum);
	}
}

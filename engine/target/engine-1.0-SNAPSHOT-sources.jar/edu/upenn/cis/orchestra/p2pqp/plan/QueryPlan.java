package edu.upenn.cis.orchestra.p2pqp.plan;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.Filter;
import edu.upenn.cis.orchestra.p2pqp.FilterSerialization;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpSchema.Source;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.Pair;
import edu.upenn.cis.orchestra.util.XMLParseException;

public abstract class QueryPlan implements Serializable, Iterable<QueryPlan.QueryPlanAndDest> {
	public final String outputSchema;
	public final Location loc;
	public final int operatorId;
	public final Set<Integer> descendentOperators;
	public final boolean isReplicated;
	
	private double expectedCost = Double.NEGATIVE_INFINITY;
	private double expectedCard = Double.NEGATIVE_INFINITY;
	
	public QueryPlan(String outputSchema, Location loc, int operatorId, Set<Integer> descendentOperators, boolean isReplicated) {
		if (loc == null) {
			throw new NullPointerException();
		}
		this.outputSchema = outputSchema;
		this.loc = loc;
		this.operatorId = operatorId;
		this.descendentOperators = Collections.unmodifiableSet(new HashSet<Integer>(descendentOperators));
		this.isReplicated = isReplicated;
	}
	
	/**
	 * Initialize a QueryExecution object for the distributed components of
	 * a query
	 * 
	 * @param exec			The QueryExecution object to add things too
	 * @param parent		The parent operator of this node (which must be
	 * 						created before creating this node)
	 * @param dest			The destination of the output tuples in the
	 * 						parent operator
	 * @param allowRecovery TODO
	 * @param allowRecovery	Whether joins should allow recovery or not
	 * @throws Operator.OperatorCreationException
	 */
	public <M> void createDistributedExecution(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
	throws Operator.OperatorCreationException {
		Operator<M> o = null;
		if (loc.isDistributed()) {
			o = createOperator(exec, parent, dest, allowRecovery);
			exec.addOperator(o);
		}
		for (QueryPlanAndDest qpad : this) {
			qpad.qp.createDistributedExecution(exec, o, qpad.d, allowRecovery);
		}
	}

	/**
	 * Initialize a QueryExecution object for the components of
	 * a query that execute at the query's owner
	 * 
	 * @param exec			The QueryExecution object to add things too
	 * @param parent		The parent operator of this node (which must be
	 * 						created before creating this node)
	 * @param dest			The destination of the output tuples in the
	 * 						parent operator
	 * @param allowRecovery	Whether joins should allow recovery or not
	 * @throws Operator.OperatorCreationException
	 */
	public <M> void createCentralExecution(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
		throws Operator.OperatorCreationException {
		Operator<M> o = null;
		if (loc.isCentralized()) {
			o = createOperator(exec, parent, dest, allowRecovery);
			exec.addOperator(o);
		}
		for (QueryPlanAndDest qpad : this) {
			qpad.qp.createCentralExecution(exec,o, qpad.d, allowRecovery);
		}
	}
	
	/**
	 * Initialize a QueryExecution object for the components of
	 * a query that execute at a named node
	 * 
	 * @param name			Node name
	 * @param exec			The QueryExecution object to add things too
	 * @param parent		The parent operator of this node (which must be
	 * 						created before creating this node)
	 * @param dest			The destination of the output tuples in the
	 * 						parent operator
	 * @param allowRecovery	Whether joins should allow recovery or not
	 * @throws Operator.OperatorCreationException
	 */
	public <M> void createNamedExecution(String name, QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
		throws Operator.OperatorCreationException {
		Operator<M> o = null;
		if (loc.isNamed() && loc.getName().equals(name)) {
			o = createOperator(exec, parent, dest, allowRecovery);
			exec.addOperator(o);
		}
		for (QueryPlanAndDest qpad : this) {
			qpad.qp.createNamedExecution(name, exec, o, qpad.d, allowRecovery);
		}
	}
	
	abstract <M> Operator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException;

	protected class QueryPlanAndDest {
		final QueryPlan qp;
		final WhichChild d;
		
		QueryPlanAndDest(QueryPlan qp, WhichChild d) {
			this.qp = qp;
			this.d = d;
		}
	}
	
	public final void getDistributedScans(List<RelationAndFilter> scans, QpSchema.Source schemas) {
		List<QueryPlan> nodes = new ArrayList<QueryPlan>();
		this.getOperatorsOfType(nodes, ProbeScanNode.class);
		
		for (QueryPlan qp : nodes) {
			ProbeScanNode psn = (ProbeScanNode) qp;
			Filter<? super QpTuple<?>> keyColsFilter = FilterSerialization.fromBytes(schemas.getSchema(psn.outputSchema), psn.keyColsBytes);
			scans.add(new RelationAndFilter(psn.operatorId, psn.outputSchema, keyColsFilter));
		}

		nodes.clear();
		this.getOperatorsOfType(nodes, DistributedScanNode.class);
		
		for (QueryPlan qp : nodes) {
			DistributedScanNode dsn = (DistributedScanNode) qp;
			Filter<? super QpTuple<?>> keyColsFilter = FilterSerialization.fromBytes(schemas.getSchema(dsn.outputSchema), dsn.keyColsBytes);
			scans.add(new RelationAndFilter(dsn.operatorId, dsn.outputSchema, keyColsFilter));
		}

	}

	public final void getBlockingOperatorDependents(Map<Integer,Set<Integer>> deps) {
		List<QueryPlan> nodes = new ArrayList<QueryPlan>();
		this.getOperatorsOfType(nodes, AggregateNode.class, LocalTableScanNode.class, IndexScanNode.class, FixpointNode.class);
		
		for (QueryPlan qp : nodes) {
			deps.put(qp.operatorId, Collections.unmodifiableSet(qp.descendentOperators));
		}
	}
	
	public final void getJoinOperatorDependents(Map<Integer,Pair<Set<Integer>,Set<Integer>>> deps) {
		List<QueryPlan> nodes = new ArrayList<QueryPlan>();
		this.getOperatorsOfType(nodes, PipelinedJoinNode.class);
		
		for (QueryPlan qp : nodes) {
			PipelinedJoinNode pjn = (PipelinedJoinNode) qp;
			HashSet<Integer> left = new HashSet<Integer>(pjn.left.descendentOperators);
			left.add(pjn.left.operatorId);
			HashSet<Integer> right = new HashSet<Integer>(pjn.right.descendentOperators);
			right.add(pjn.right.operatorId);
			deps.put(qp.operatorId, new Pair<Set<Integer>,Set<Integer>>(left,right));
		}
	}
	
	public static class RelationAndFilter {
		public final int operatorId;
		public final String relation;
		public final Filter<? super QpTuple<?>> keyFilter;
		
		RelationAndFilter(int operatorId, String relation, Filter<? super QpTuple<?>> keyFilter) {
			this.relation = relation;
			this.keyFilter = keyFilter;
			this.operatorId = operatorId;
		}
	}
		
	public abstract boolean equals(Object o);
	
	public final Element serialize(Document doc, Map<String,QpSchema> schemas) {
		String tag = findTag.get(getClass());
		if (tag == null) {
			throw new IllegalStateException("Don't know how to serialize " + this.getClass().getName());
		}
		Element el = doc.createElement(tag);
		serialize(doc,el,schemas);
		
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2);
		if (expectedCost >= 0.0) {
			el.setAttribute("expectedCost", df.format(expectedCost));
		}
		
		if (expectedCard >= 0.0) {
			el.setAttribute("expectedCard", df.format(expectedCard));
		}
		
		return el;
	}
	
	abstract void serialize(Document doc, Element el, Map<String,QpSchema> schemas);
	
	public static QueryPlan deserializePlan(Element field, Map<String,QpSchema> schemas) throws XMLParseException {
		return deserialize(field, schemas, new HashSet<Integer>());
	}
	
	static QueryPlan deserialize(Element field, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		Class<? extends QueryPlan> c = findClass.get(field.getTagName());
		if (c == null) {
			throw new XMLParseException("Cannot find class to deserialize query plan node", field);
		}
		try {
			Method m = c.getDeclaredMethod("deserialize", Element.class, Map.class, Set.class);
			if (m == null) {
				throw new XMLParseException("Could not find deserialization method for class " + c.getName());
			}
			Object o = m.invoke(null, field, schemas,alreadyIds);
			QueryPlan qp = (QueryPlan) o;
			
			if (! alreadyIds.add(qp.operatorId)) {
				throw new XMLParseException("Query plan contains multiple operators with ID " + qp.operatorId);
			}
			DecimalFormat df = new DecimalFormat();
			
			String expectedCostStr = field.getAttribute("expectedCost");
			if (expectedCostStr.length() > 0) {
				try {
					Number expectedCost = df.parse(expectedCostStr);
					qp.setCost(expectedCost.doubleValue());
				} catch (ParseException e) {
					throw new XMLParseException("Error parsing expected cost", e, field);
				}
			}

			String expectedCardStr = field.getAttribute("expectedCard");
			if (expectedCardStr.length() > 0) {
				try {
					Number expectedCard = df.parse(expectedCostStr);
					qp.setCard(expectedCard.doubleValue());
				} catch (ParseException e) {
					throw new XMLParseException("Error parsing expected card", e, field);
				}
			}			
			return qp;
		} catch (NoSuchMethodException e) {
			throw new XMLParseException("Could not find deserialize method for class " + c.getName(), field);
		} catch (IllegalAccessException e) {
			throw new XMLParseException("Error invoking deserialize method on class " + c.getName(), field);
		} catch (InvocationTargetException e) {
			if (e.getCause() instanceof XMLParseException) {
				throw (XMLParseException) e.getCause();
			} else {
				throw new XMLParseException("Error invoking deserialize method on class " + c.getName(), e.getCause());
			}
		}
	}
	
	private final static Map<Class<? extends QueryPlan>,String> findTag = new HashMap<Class<? extends QueryPlan>,String>();
	private final static Map<String,Class<? extends QueryPlan>> findClass = new HashMap<String,Class<? extends QueryPlan>>();

	private static void addClass(String tag, Class<? extends QueryPlan> c) {
		findTag.put(c, tag);
		findClass.put(tag, c);
	}
	
	static {
		addClass("aggregate", AggregateNode.class);
		addClass("probeScan", ProbeScanNode.class);
		addClass("applyFilters", FilterNode.class);
		addClass("function", FunctionNode.class);
		addClass("pipelinedJoin", PipelinedJoinNode.class);
		addClass("fixpoint", FixpointNode.class);
		addClass("fixpointShip", FixpointShipNode.class);
		addClass("fixpointReceiver", FixpointReceiverNode.class);
		addClass("nonblockingAggregate", NonblockingAggregateNode.class);
		addClass("union", UnionNode.class);
		addClass("project", ProjectNode.class);
		addClass("streampipelinedJoin", StreamPipelinedJoinNode.class);
		addClass("probeJoin", ProbeJoinNode.class);
		addClass("ship", ShipNode.class);
		addClass("spool", SpoolNode.class);
		addClass("localTableScan", LocalTableScanNode.class);
		addClass("indexScan", IndexScanNode.class);
		addClass("distributedScan", DistributedScanNode.class);
	}
	
	final public void setCost(double cost) {
		if (expectedCost >= 0.0) {
			throw new IllegalArgumentException("Cost is already set to " + expectedCost);
		}
		expectedCost = cost;
	}
	
	final public void setCard(double card) {
		if (expectedCard >= 0.0) {
			throw new IllegalArgumentException("Expected cardinality is already set to " + expectedCard);
		}
		expectedCard = card;
	}
	
	final public double getCost() {
		return expectedCost;
	}
	
	static class QueryPlanData {
		final int operatorId;
		final Location loc;
		final String outputSchema;
		
		QueryPlanData(int operatorId, Location loc, String outputSchema) {
			this.operatorId = operatorId;
			this.loc = loc;
			this.outputSchema = outputSchema;
		}
	}
	
	void serializeHelper(Document doc, Element el, Map<String,QpSchema> schemas) {
		el.setAttribute("operatorId", Integer.toString(operatorId));
		if (loc.isCentralized()) {
			el.setAttribute("centralized", Boolean.toString(true));
		} else if (loc.isDistributed()) {
			el.setAttribute("distributed", Boolean.toString(true));
		} else {
			el.setAttribute("location", loc.getName());
		}
		if (outputSchema != null) {
			el.setAttribute("outputSchema", outputSchema);
		}
	}
	
	static QueryPlanData deserializeHelper(Element el) throws XMLParseException {
		Map<String,String> atts = DomUtils.getAttributes(el);
		String opIdString = atts.get("operatorId");
		if (opIdString == null) {
			throw new XMLParseException("Missing operatorId attribute", el);
		}
		int operatorId = Integer.parseInt(opIdString);
		
		Location loc = null;
		
		String centralizedString = atts.get("centralized");
		if (centralizedString != null) {
			boolean centralized = Boolean.parseBoolean(centralizedString);
			if (centralized) {
				loc = CentralizedLoc.getInstance();
			}
		}
		
		if (loc == null) {
			String distributedString = atts.get("distributed");
			if (distributedString != null) {
				boolean distributed = Boolean.parseBoolean(distributedString);
				if (distributed) {
					loc = DistributedLoc.getInstance();
				}
			}
		}
		
		if (loc == null) {
			String namedLoc = atts.get("location");
			if (namedLoc == null) {
				throw new XMLParseException("Need either location attribute or centralized or distributed to be set to true", el);
			}
			loc = new NamedLoc(namedLoc);
		}
		String outputSchema = atts.get("outputSchema");
		// Output schema may sometimes be null (e.g. when storing tuples somewhere
		return new QueryPlanData(operatorId, loc, outputSchema);
	}
	
	static String getAttribute(Element el, String attName) throws XMLParseException {
		String attVal = el.getAttribute(attName);
		if (attVal.length() == 0) {
			throw new XMLParseException("Missing " + attName + " attribute", el);
		}
		return attVal;
	}
	
	public void getOperatorsOfType(Collection<QueryPlan> operators, Class<?>... classes) {
		for (Class<?> c : classes) {
			if (c.isInstance(this)) {
				operators.add(this);
				break;
			}
		}
	}
	
	public void getOperators(Map<Integer,QueryPlan> operatorsMap) {
		operatorsMap.put(this.operatorId, this);
	}
	
	/**
	 * Get the all the join operator than feed into a rehash operator without
	 * going through another join
	 * 
	 * @param opsHashCols
	 * @param schemas
	 */
	public final void getRecoveryJoinOperators(Map<Integer, int[]> opsHashCols, Source schemas) {
		getRecoveryJoinOperators(opsHashCols, null, schemas, false);
	}
	
	abstract void getRecoveryJoinOperators(Map<Integer, int[]> opsHashCols, List<Integer> hashCols, Source schemas, boolean prevStatfulOperatorIsAgg);
}
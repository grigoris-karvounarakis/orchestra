package edu.upenn.cis.orchestra.p2pqp;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Bandwidth implements Serializable {
	private static final long serialVersionUID = 1L;
	// Bandwidth between the current node and the named node in bytes
	// per second
	public final Map<String,Double> namedNodeBandwidths;
	// Latency between the current node and the named node, in seconds
	public final Map<String,Double> namedNodeLatencies;
	// Bandwidth between the current node and the remote node with
	// the lowest bandwidth, in bytes per second
	public final double worstRemoteBandwidth;
	// Latency between the current node and the remote node with
	// the highestBandwidth, in seconds;
	public final double worstRemoteLatency;
	
	public Bandwidth(Map<String,Double> namedNodeBandwidths, Map<String,Double> namedNodeLatencies,
			double worstRemoteBandwidth,
			double worstRemoteLatency) {
		this.namedNodeBandwidths = Collections.unmodifiableMap(new HashMap<String,Double>(namedNodeBandwidths));
		this.namedNodeLatencies = Collections.unmodifiableMap(new HashMap<String,Double>(namedNodeLatencies));
		this.worstRemoteBandwidth = worstRemoteBandwidth;
		this.worstRemoteLatency = worstRemoteLatency;
	}
	
	public double getTransmissionTime(double numBytes) {
		return worstRemoteLatency + (numBytes / worstRemoteBandwidth);
	}
	
	public double getTransmissionTime(double numBytes, String location) {
		return namedNodeLatencies.get(location) + (numBytes / namedNodeBandwidths.get(location)); 
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Bandwidth: " + worstRemoteBandwidth + " " + namedNodeBandwidths + "\n");
		sb.append("Latency: " + worstRemoteLatency + " " + namedNodeLatencies);
		return sb.toString();
	}
}

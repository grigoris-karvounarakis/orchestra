package edu.upenn.cis.orchestra.p2pqp;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.KEY;
import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.STORE;

import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.log4j.Logger;

import com.sleepycat.je.Cursor;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
import com.sleepycat.je.OperationStatus;
import com.sleepycat.je.StatsConfig;

import edu.upenn.cis.orchestra.datamodel.AbstractTuple;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;
import edu.upenn.cis.orchestra.util.ConcurrentIndexedQueue;

/**
 * @author netaylor
 *
 * @param <M>
 */
class BDbTupleStore<M> implements TupleStore<M> {
	final int numLookupThreads = 3;
	final int numDeliverThreads = 3;
	int batchingCutoff = 10000;
	int batchingCheckIntervalMs = 500;
	private final Logger logger = Logger.getLogger(BDbTupleStore.class);
	private final boolean batching;
	private Environment e;
	private final String dbName;
	private final MetadataFactory<M> mdf;
	private final DatabaseConfig dc;
	private final Map<Integer,QpSchema> tables;
	private final Map<String,QpSchema> tableNames;

	private ThreadLocal<Database> dbHandles;
	private List<Database> openHandles;

	private List<Thread> startedThreads;
	private final ThreadGroup tg;

	private final boolean onlyBatch;

	BDbTupleStore(Environment e, String dbName, MetadataFactory<M> mdf) throws DatabaseException {
		this(e,dbName,null,mdf);
	}

	BDbTupleStore(Environment e, String dbName, ThreadGroup tg, MetadataFactory<M> mdf) throws DatabaseException {
		this(e,dbName,tg,mdf,false);
	}

	BDbTupleStore(Environment e, String dbName, ThreadGroup tg,  MetadataFactory<M> mdf, boolean onlyBatch) throws DatabaseException {
		this.e = e;
		this.onlyBatch = onlyBatch;
		dc = new DatabaseConfig();
		dc.setSortedDuplicates(false);
		dc.setAllowCreate(true);
		EnvironmentConfig ec = e.getConfig();
		dc.setReadOnly(ec.getReadOnly());

		// Open the database to create it, if necessary.
		Database db = e.openDatabase(null, dbName, dc);
		db.close();
		dc.setAllowCreate(false);

		tables = new HashMap<Integer,QpSchema>();
		tableNames = new HashMap<String,QpSchema>();
		this.dbName = dbName;
		this.mdf = mdf;

		dbHandles = new ThreadLocal<Database>();
		openHandles = new ArrayList<Database>();

		this.tg = tg;
		batching = (tg != null);
		startThreads();
	}

	private void startThreads() throws DatabaseException {
		if (tg == null) {
			startedThreads = Collections.emptyList();
			logger.info("Starting non-batching BDbTupleStore");
		} else {
			startedThreads = new ArrayList<Thread>(numLookupThreads + numDeliverThreads + 1);
			Thread t = new BatchingThread(tg);
			t.start();
			startedThreads.add(t);
			if (! onlyBatch) {
				for (int i = 0; i < numLookupThreads; ++i) {
					t = new LookupThread(tg,i);
					t.start();
					startedThreads.add(t);
				}
			}
			for (int i = 0; i < numDeliverThreads; ++i) {
				t = new BatchDeliverThread(tg,i);
				t.start();
				startedThreads.add(t);
			}
			logger.info("Starting batching BDbTupleStore with " + numLookupThreads + " lookup threads");
		}

	}

	private Database getDatabaseNoCatch() throws DatabaseException {
		Database db = dbHandles.get();
		if (db == null) {
			db = e.openDatabase(null, dbName, dc);
			dbHandles.set(db);
			synchronized (openHandles) {
				openHandles.add(db);
			}
		}
		return db;

	}

	private Database getDatabase() throws TupleStoreException {
		try {
			return getDatabaseNoCatch();
		} catch (DatabaseException de) {
			throw new TupleStoreException("Error opening database", de);
		}
	}

	public void close() throws TupleStoreException {
		try {
			for (Thread t : startedThreads) {
				t.interrupt();
				t.join();
			}

			synchronized (openHandles) {
				for (int i = 0; i < openHandles.size(); ++i) {
					Database db = openHandles.get(i);
					db.close();
				}
				openHandles.clear();
			}
			dbHandles = null;
		} catch (InterruptedException ie) {
			throw new TupleStoreException("Interrupted while stopping batching threads", ie);
		} catch (DatabaseException de) {
			throw new TupleStoreException("Couldn't close BerkeleyDB TupleStore", de);
		}
	}

	public void addTable(QpSchema ns) {
		int id = ns.relId;
		String name = ns.getName();
		synchronized (tables) {
			if (tables.containsKey(id)) {
				throw new IllegalArgumentException("Table with ID " + id + " is already in this TupleStore");
			}
			if (tableNames.containsKey(name)) {
				throw new IllegalArgumentException("Table with name " + name + " is already in this TupleStore");
			}
			tables.put(id, ns);
			tableNames.put(name, ns);
		}
	}

	public void dropTable(String name) throws TupleStoreException {
		QpSchema s = getSchema(name);
		int id = s.relId;

		clearTable(name);

		synchronized (tables) {
			tables.remove(id);
			tableNames.remove(name);
		}
	}

	public void clearTable(String name) throws TupleStoreException {
		QpSchema s = getSchema(name);
		int id = s.relId;

		Database db = getDatabase();
		try {
			byte[] idBytes = IntType.getBytes(id);
			Cursor c = db.openCursor(null, null);

			try {
				DatabaseEntry key = new DatabaseEntry(idBytes), value = new DatabaseEntry();
				OperationStatus os = c.getSearchKeyRange(key, value, null);

				ENTRY: while (os != OperationStatus.NOTFOUND) {
					byte[] currKey = key.getData();
					for (int i = 0; i < idBytes.length; ++i) {
						if (currKey[i] != idBytes[i]) {
							break ENTRY;
						}
					}
					c.delete();

					os = c.getNext(key, value, null);
				}
			} finally {
				c.close();
			}
		} catch (DatabaseException de) {
			throw new TupleStoreException("Error clearing table " + name, de);
		}
	}

	public Map<String, QpSchema> getTables() {
		synchronized (tables) {
			return new HashMap<String,QpSchema>(tableNames);
		}
	}

	public QpSchema getSchema(int tableId) {
		QpSchema result;
		synchronized (tables) {
			result = tables.get(tableId);
		}
		if (result == null) {
			throw new IllegalArgumentException("No table with ID " + tableId);
		}
		return result;
	}

	public QpSchema getSchema(String name) {
		QpSchema result;
		synchronized (tables) {
			result = tableNames.get(name);
		}
		if (result == null) {
			throw new IllegalArgumentException("No table with name " + name);
		}
		return result;
	}

	public TableScan beginScan(int relation, Operator<M> dest, WhichChild outputDest, Filter<? super QpTuple<?>> keyFilter, Filter<? super QpTuple<?>> fullFilter, Integer lastEpoch,
			int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt, boolean enableRecovery, int phaseNo) {
		return new TableScan(relation,dest,outputDest,keyFilter,fullFilter,lastEpoch,queryId,nodeId,operatorId,rt,enableRecovery, phaseNo);
	}

	public TableScan beginScan(String relation, Operator<M> dest, WhichChild outputDest, Filter<? super QpTuple<?>> keyFilter, Filter<? super QpTuple<?>> fullFilter, Integer lastEpoch,
			int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt, boolean enableRecovery, int phaseNo) {
		QpSchema s = getSchema(relation);
		return new TableScan(s.relId,dest,outputDest,keyFilter,fullFilter,lastEpoch,queryId,nodeId,operatorId,rt,enableRecovery, phaseNo);
	}

	private static byte[] getDbKey(int relId, ByteArrayWrapper serializedKey) {
		byte[] relIdBytes = IntType.getBytes(relId);
		byte[] retval = new byte[relIdBytes.length + serializedKey.length];
		System.arraycopy(relIdBytes, 0, retval, 0, relIdBytes.length);
		System.arraycopy(serializedKey.array, serializedKey.offset, retval, relIdBytes.length, serializedKey.length);
		return retval;
	}

	private static byte[] getDbKey(QpTuple<?> t) {
		byte[] tupleBytes = t.getKeyBytes();
		byte[] relId = IntType.getBytes(t.getSchema().relId);
		byte[] retval = new byte[relId.length + tupleBytes.length];
		System.arraycopy(relId, 0, retval, 0, relId.length);
		System.arraycopy(tupleBytes, 0, retval, relId.length, tupleBytes.length);
		return retval;
	}

	public class TableScan extends PullScanOperator<M> {
		private final Filter<? super QpTuple<?>> keyFilter;
		private final Filter<? super QpTuple<?>> fullFilter;
		private final Integer lastEpoch;
		private final int epochOffset;
		private Cursor c = null;
		private DatabaseEntry key = new DatabaseEntry(), value = new DatabaseEntry();
		private final byte[] searchKey;
		private boolean finished = false;
		private final QpTupleSet<Null> alreadyOutputKeys;
		private final QpSchema.Source tables;
		private final QpSchema schema;
		private volatile boolean interrupted = false;
		private final int phaseNo;

		private TableScan(final int relation, Operator<M> dest, WhichChild outputDest, Filter<? super QpTuple<?>> keyFilter, Filter<? super QpTuple<?>> fullFilter, Integer lastEpoch,
				int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt, boolean enableRecovery, int phaseNo) {
			super(dest,outputDest,queryId,nodeId,operatorId,rt,BDbTupleStore.this.mdf, enableRecovery);

			schema = getSchema(relation);
			tables = new QpSchema.SingleSource(schema);

			if (keyFilter != null && (! schema.getKeyColsSet().containsAll(keyFilter.getColumns()))) {
				throw new IllegalArgumentException("Key filter uses non-key columns");
			}
			this.keyFilter = keyFilter;
			this.fullFilter = fullFilter;
			this.lastEpoch = lastEpoch;
			byte[] relId = IntType.getBytes(relation);
			ByteBufferWriter searchKey = new ByteBufferWriter(relId, relId.length + IntType.bytesPerInt);
			epochOffset = searchKey.getCurrentLength();
			if (this.lastEpoch == null) {
				searchKey.addToBuffer(Integer.MAX_VALUE);
			} else {
				searchKey.addToBuffer(lastEpoch + 1);
			}

			this.searchKey = searchKey.getByteArray();
			alreadyOutputKeys = new QpTupleSet<Null>();
			this.phaseNo = phaseNo;
		}

		public synchronized boolean isFinished(int phaseNo) {
			return finished;
		}

		@Override
		public void scan(int blockSize, int phaseNo) {
			scan(blockSize, false, phaseNo);
		}

		@Override
		public void scanAll(int blockSize, int phaseNo) {
			scan(blockSize, true, phaseNo);
		}

		private synchronized void scan(int blockSize, boolean all, int phaseNo) {
			if (finished) {
				throw new RuntimeException("Scan has already finished");
			}
			if (phaseNo != this.phaseNo) {
				throw new IllegalArgumentException("Expected phase " + this.phaseNo + ", got phase " + phaseNo);
			}
			ArrayList<QpTuple<M>> block = new ArrayList<QpTuple<M>>(blockSize);
			List<ExecutionId> scannedIds = new ArrayList<ExecutionId>(blockSize);
			try {
				OperationStatus os;
				if (c == null)  {
					c = getDatabase().openCursor(null, null);
					key.setData(searchKey);
					c.getSearchKeyRange(key, value, null);
					os = c.getPrev(key, value, null);
				} else {
					os = c.getPrev(key, value, null);
				}

				ENTRY: while ((! interrupted) && os != OperationStatus.NOTFOUND) {
					byte[] currKey = key.getData();
					for (int i = 0; i < epochOffset; ++i) {
						// Make sure we're still reading the right relation
						if (currKey[i] != searchKey[i]) {
							finished = true;
							break ENTRY;
						}
					}

					byte[] keyBytes = key.getData();
					QpTuple<Null> k = QpTuple.fromBytes(KEY, schema, tables, null, keyBytes, IntType.bytesPerInt, keyBytes.length - IntType.bytesPerInt, null);
					if (keyFilter == null || keyFilter.eval(k)) {
						if (! alreadyOutputKeys.containsKey(k)) {
							alreadyOutputKeys.add(k);
							byte[] valueBytes = value.getData();
							if (valueBytes.length == 0) {
								// Tuple deleted
							} else {
								QpTuple<M> t = QpTuple.fromBytes(STORE, schema, tables, mdf, valueBytes, null);
								if (fullFilter == null || fullFilter.eval(t)) {
									t = t.changeId(getFreshId(phaseNo));
									block.add(t);
									scannedIds.add(t.getId());
									if (block.size() == blockSize) {
										this.tuplesAdded(scannedIds);
										sendTuples(block);
										block.clear();
										scannedIds.clear();
										if (! all) {
											break;
										}
									}
								}
							}
						}
					}

					os = c.getPrev(key, value, null);
				}

				if (os == OperationStatus.NOTFOUND || interrupted) {
					finished = true;
				}

				if (finished) {
					c.close();
					c = null;
				}

			} catch (Exception e) {
				this.reportException(e);
			}
			if (! scannedIds.isEmpty()) {
				tuplesAdded(scannedIds);
			}
			if (! block.isEmpty()) {
				sendTuples(block);
			}
		}

		protected void close() {
			try {
				if (c != null) {
					c.close();
					c = null;
				}
			} catch (DatabaseException de) {
				de.printStackTrace();
			}
		}

		@Override
		public void interrupt(int phaseNo) {
			if (phaseNo != this.phaseNo) {
				throw new IllegalArgumentException("Expected phase " + this.phaseNo + ", got phase " + phaseNo);
			}
			interrupted = true;
		}
	}

	public void deleteTuple(AbstractTuple<QpSchema> t, int epoch) throws TupleStoreException {
		Database db = getDatabase();
		deleteTuple(t, epoch, db);
	}

	private void deleteTuple(AbstractTuple<QpSchema> t, int epoch, Database db) throws TupleStoreException {
		QpTuple<?> newKey;
		if (t instanceof QpTuple) {
			newKey = ((QpTuple<?>) t).getKeyTuple(epoch);
		} else {
			newKey = new QpTuple<Null>(t, epoch, true);
		}
		DatabaseEntry key = new DatabaseEntry(getDbKey(newKey)), value = new DatabaseEntry(new byte[0]);
		try {
			db.putNoOverwrite(null, key, value);
		} catch (DatabaseException e) {
			throw new TupleStoreException("Error deleting tuple " + newKey + " at epoch " + epoch, e);
		}
	}

	public void deleteTuples(Collection<? extends AbstractTuple<QpSchema>> ts, int epoch) throws TupleStoreException {
		Database db = getDatabase();
		for (AbstractTuple<QpSchema> t : ts) {
			deleteTuple(t, epoch, db);
		}
	}

	public void deleteTuple(int relId, byte[] key) throws TupleStoreException {
		deleteTuple(relId, key, getDatabase());
	}

	public void deleteTuples(Map<Integer,? extends Collection<byte[]>> keys) throws TupleStoreException {
		Database db = getDatabase();

		for (Map.Entry<Integer, ? extends Collection<byte[]>> me : keys.entrySet()) {
			int relId = me.getKey();
			Collection<byte[]> keysForRel = me.getValue();
			for (byte[] key : keysForRel) {
				deleteTuple(relId, key, db);
			}
		}
	}

	private void deleteTuple(int relId, byte[] key, Database db) throws TupleStoreException {
		byte[] keyWithRel = new byte[IntType.bytesPerInt + key.length];
		System.arraycopy(IntType.getBytes(relId), 0, keyWithRel, 0, IntType.bytesPerInt);
		System.arraycopy(key, 0, keyWithRel, IntType.bytesPerInt, key.length);
		DatabaseEntry keyDE = new DatabaseEntry(keyWithRel), value = new DatabaseEntry(new byte[0]);
		try {
			OperationStatus os = db.putNoOverwrite(null, keyDE, value);
			if (os != OperationStatus.SUCCESS) {
				throw new DatabaseException("Data already present for key");
			}
		} catch (DatabaseException e) {
			QpTuple<?> keyTuple = QpTuple.fromBytes(KEY, getSchema(relId), this, key, null);
			throw new TupleStoreException("Error deleting tuple " + keyTuple + " at epoch " + keyTuple.getEpoch(), e);
		}
	}



	public ConstraintViolation addTuple(QpTuple<M> t) throws TupleStoreException {
		return addTuples(Collections.singletonList(t)).get(0);
	}

	public List<ConstraintViolation> addTuples(List<QpTuple<M>> ts) throws TupleStoreException {
		return addTuples(ts,null);
	}

	public List<ConstraintViolation> addTuples(List<QpTuple<M>> ts, List<byte[]> serialized) throws TupleStoreException {
		Database db = getDatabase();
		DatabaseEntry key = new DatabaseEntry(), value = new DatabaseEntry();
		List<ConstraintViolation> retval = new ArrayList<ConstraintViolation>(ts.size());
		Iterator<byte[]> serializedIt = serialized == null ? null : serialized.iterator();
		for (QpTuple<M> t : ts) {
			if ( ! tables.containsKey(t.getSchema().relId)) {
				throw new IllegalArgumentException("Trying to add tuple from relation " + t.getRelationName() + " to TupleStore for relations " + tables.keySet());
			}
			key.setData(getDbKey(t));
			if (serializedIt == null) {
				value.setData(t.getStoreBytes(mdf));
			} else {
				value.setData(serializedIt.next());
			}
			OperationStatus os;
			try {
				os = db.putNoOverwrite(null, key, value);
				if (os == OperationStatus.KEYEXIST) {
					db.get(null, key, value, null);
					QpTuple<?> old = QpTuple.fromBytes(STORE, t.getSchema(), this, null, value.getData(), null);
					retval.add(new ConstraintViolation("Key violation, old value: " + old, t));
				} else {
					retval.add(null);
				}
			} catch (DatabaseException e) {
				throw new TupleStoreException("Could not put tuple", e);
			}
		}
		return retval;
	}

	public QpTupleSet<M> getTuples(String relName, Filter<? super QpTuple<?>> f, int epoch, QpTupleSet<Null> discarded) throws TupleStoreException {
		QpSchema s = getSchema(relName);
		return getTuples(s.relId, f, epoch, discarded);
	}

	public QpTupleSet<M> getTuples(final int relId, Filter<? super QpTuple<?>> f, int epoch, QpTupleSet<Null> discarded) throws TupleStoreException {
		QpTupleSet<M> retval = new QpTupleSet<M>();
		QpTupleSet<Null> deleted = new QpTupleSet<Null>();

		QpSchema s = getSchema(relId);
		QpSchema.Source tables = new QpSchema.SingleSource(s);
		Database db = getDatabase();

		try {
			Cursor c = db.openCursor(null, null);
			try {
				byte[] tableId = IntType.getBytes(s.relId), epochBytes = IntType.getBytes(epoch + 1);
				byte[] searchKey = new byte[tableId.length + epochBytes.length];
				System.arraycopy(tableId, 0, searchKey, 0, tableId.length);
				System.arraycopy(epochBytes, 0, searchKey, tableId.length, epochBytes.length);
				DatabaseEntry key = new DatabaseEntry(searchKey), value = new DatabaseEntry();
				c.getSearchKeyRange(key, value, null);
				OperationStatus os = c.getPrev(key, value, null);
				TUPLE: while (os != OperationStatus.NOTFOUND) {
					byte[] k = key.getData(), v = value.getData();
					for (int i = 0; i < tableId.length; ++i) {
						if (k[i] != tableId[i]) {
							break TUPLE;
						}
					}
					QpTuple<Null> keyTuple = QpTuple.fromBytes(KEY, s, tables, null, k, IntType.bytesPerInt, k.length - IntType.bytesPerInt, null);
					if (! (deleted.containsKey(keyTuple) || retval.containsKey(keyTuple))) {
						if (v.length == 0) {
							// Tuple was deleted
							deleted.add(keyTuple);
						} else {
							QpTuple<M> t = QpTuple.fromBytes(STORE, s, tables, mdf, v, null);
							if (f == null || f.eval(t)) {
								retval.add(t);
							} else {
								if (discarded != null) {
									discarded.add(keyTuple);
								}
							}
						}
					}
					os = c.getPrev(key, value, null);
				}
			} finally {
				c.close();
			}
		} catch (DatabaseException e) {
			throw new TupleStoreException("Error retrieving tuples", e);
		} catch (Filter.FilterException fe) {
			throw new TupleStoreException("Error evaluating tuple condition", fe);
		}

		return retval;
	}

	public List<QpTuple<M>> getTuples(List<? extends AbstractTuple<QpSchema>> keys, int epoch) throws TupleStoreException {
		List<QpTuple<M>> retval = new ArrayList<QpTuple<M>>(keys.size());

		Database db = getDatabase();

		for (AbstractTuple<QpSchema> key : keys) {
			retval.add(getTuple(key, epoch, db));
		}

		return retval;
	}

	public QpTuple<M> getTuple(AbstractTuple<QpSchema> keyTuple, int epoch) throws TupleStoreException {
		return getTuple(keyTuple, epoch, getDatabase());
	}

	private QpTuple<M> getTuple(AbstractTuple<QpSchema> keyTuple, int epoch, Database db) throws TupleStoreException {
		QpTuple<?> keyQpTuple;
		if (keyTuple instanceof QpTuple) {
			keyQpTuple = ((QpTuple<?>) keyTuple).getKeyTuple(epoch);
		} else {
			keyQpTuple = new QpTuple<Null>(keyTuple, epoch, true);
		}
		DatabaseEntry key = new DatabaseEntry(), value = new DatabaseEntry();

		for (int currEpoch = epoch; currEpoch >= 0; --currEpoch) {
			keyQpTuple = keyQpTuple.changeEpoch(currEpoch);
			key.setData(getDbKey(keyQpTuple));
			OperationStatus os;
			try {
				os = db.get(null, key, value, null);
			} catch (DatabaseException e) {
				throw new TupleStoreException("Error retrieving data for key tuple " + keyTuple + " for epoch " + keyQpTuple.getEpoch(), e);
			}
			if (os == OperationStatus.SUCCESS) {
				byte[] valueBytes = value.getData();
				if (valueBytes.length > 0) {
					return QpTuple.fromBytes(STORE, keyTuple.getSchema(), this, mdf, valueBytes, null);
				} else {
					return null;
				}
			}
		}
		return null;
	}

	public QpTuple<M> getTupleByKey(QpTuple<?> key) throws TupleStoreException {
		return getTuple(getDbKey(key), key.getSchema(), getDatabase());
	}

	public List<QpTuple<M>> getTuplesByKey(List<QpTuple<?>> keys) throws TupleStoreException {
		List<QpTuple<M>> retval = new ArrayList<QpTuple<M>>(keys.size());
		Database db = getDatabase();
		for (QpTuple<?> key : keys) {
			retval.add(getTuple(getDbKey(key),key.getSchema(),db));
		}
		return retval;
	}

	/**
	 * Get a tuple from the store
	 * 
	 * @param keyTuple				A serialized version of the key, with the relation ID before the tuple
	 * @param schema				The schema
	 * @param db					The handle to use
	 * @return						The tuple with that key
	 * @throws TupleStoreException
	 */
	private QpTuple<M> getTuple(byte[] keyTuple, QpSchema schema, Database db) throws TupleStoreException {
		DatabaseEntry key = new DatabaseEntry(), value = new DatabaseEntry();
		key.setData(keyTuple);
		OperationStatus os;
		try {
			os = db.get(null, key, value, null);
		} catch (DatabaseException e) {
			QpTuple<?> t = QpTuple.fromBytes(KEY, schema, BDbTupleStore.this, mdf, keyTuple, IntType.bytesPerInt, keyTuple.length - IntType.bytesPerInt, null);
			throw new TupleStoreException("Couldn't retrieve data for key tuple " + t + " for epoch " + t.getEpoch(), e);
		}
		if (os == OperationStatus.SUCCESS) {
			byte[] valueBytes = value.getData();
			if (valueBytes.length > 0) {
				return QpTuple.fromBytes(STORE, schema, this, mdf, valueBytes, null);
			}
		}
		return null;
	}

	public synchronized void clear() throws TupleStoreException {
		try {
			for (Thread t : startedThreads) {
				t.interrupt();
				t.join();
			}

			sinks.clear();
			sinksForTuple.clear();
			waitingTuples.clear();
			tables.clear();
			tableNames.clear();

			dbHandles = new ThreadLocal<Database>();
			for (Database db : openHandles) {
				db.close();
			}
			openHandles.clear();
			e.truncateDatabase(null, dbName, false);
			startThreads();
		} catch (InterruptedException ie) {
			throw new TupleStoreException("Interrupted while clearing BerkleyDB store", ie);
		} catch (DatabaseException de) {
			throw new TupleStoreException("Error clearing BerkeleyDB database", de);
		}
	}

	public void printStats(PrintStream ps)
	throws TupleStoreException {
		try {
			StatsConfig config = new StatsConfig();
			config.setClear(true);
			ps.println("BerkeleyDB statistics:");
			ps.println(e.getStats(config));
		} catch (DatabaseException de) {
			throw new TupleStoreException("Error requesting statistics from BerkeleyDB", de);
		}
	}

	private int nextRequestId = Integer.MIN_VALUE;


	private Map<Integer,SinkAndCount> sinks = Collections.synchronizedMap(new HashMap<Integer,SinkAndCount>());
	private Map<ByteArrayWrapper,Set<Integer>> sinksForTuple = new HashMap<ByteArrayWrapper,Set<Integer>>();

	private class SinkAndCount {
		final TupleSink<M> ts;
		private int count;

		SinkAndCount(TupleSink<M> ts, int count) {
			this.ts = ts;
			this.count = count;
		}

		synchronized boolean decrement() {
			--count;
			return (count == 0);
		}

		synchronized boolean isDone() {
			return count <= 0;
		}
	}

	private static class WaitingKey {
		final byte[] keyWithRelId;
		final QpSchema schema;

		WaitingKey(QpSchema schema, ByteArrayWrapper ps) {
			this.schema = schema;
			keyWithRelId = getDbKey(schema.relId, ps);
		}

		WaitingKey(QpTuple<?> key) {
			schema = key.getSchema();
			keyWithRelId = getDbKey(key);
		}

		WaitingKey(byte[] data) {
			keyWithRelId = data;
			schema = null;
		}

		public int hashCode() {
			return Arrays.hashCode(keyWithRelId);
		}

		public boolean equals(Object o) {
			if (o == null || o.getClass() != this.getClass()) {
				return false;
			}
			return Arrays.equals(keyWithRelId, ((WaitingKey) o).keyWithRelId);
		}
	}

	private ConcurrentIndexedQueue<WaitingKey,Integer> waitingKeys = new ConcurrentIndexedQueue<WaitingKey,Integer>(
			new ConcurrentIndexedQueue.MetadataFactory<WaitingKey, Integer>() {
				public Integer getMetadata(WaitingKey element) {
					return element.schema.relId;
				}
			});

	private class TupleAndKey {
		final byte[] keyWithRelId;
		final QpSchema schema;
		final byte[] tuple;

		TupleAndKey(QpSchema schema, byte[] keyWithRelId, byte[] tuple) {
			this.keyWithRelId = keyWithRelId;
			this.tuple = tuple;
			this.schema = schema;
		}
	}

	private ConcurrentLinkedQueue<TupleAndKey> waitingTuples = new ConcurrentLinkedQueue<TupleAndKey>();
	private Map<Integer,Integer> pendingCount = new HashMap<Integer,Integer>();

	public void getTuples(Collection<QpTuple<?>> keys, TupleSink<M> ts) {
		Map<Integer,List<ByteArrayWrapper>> serializedKeys = new HashMap<Integer,List<ByteArrayWrapper>>();

		for (QpTuple<?> key : keys) {
			List<ByteArrayWrapper> pas = serializedKeys.get(key.getSchema().relId);
			if (pas == null) {
				pas = new ArrayList<ByteArrayWrapper>();
				serializedKeys.put(key.getSchema().relId, pas);
			}
			byte[] data = key.getKeyBytes();
			pas.add(new ByteArrayWrapper(data, 0, data.length));
		}

		for (Map.Entry<Integer, List<ByteArrayWrapper>> me : serializedKeys.entrySet()) {
			getTuples(me.getKey(), me.getValue(), ts);
		}
	}

	public void getTuples(int relId, Collection<ByteArrayWrapper> serializedKeys, TupleSink<M> ts) {
		final QpSchema schema = getSchema(relId);
		if (batching) {
			if (serializedKeys.isEmpty()) {
				throw new IllegalArgumentException("Should never request 0 keys");
			}
			int requestId;
			synchronized (this) {
				requestId = nextRequestId++;
			}
			SinkAndCount sac = new SinkAndCount(ts, serializedKeys.size());
			sinks.put(requestId, sac);


			List<WaitingKey> newWaitingKeys = new ArrayList<WaitingKey>(serializedKeys.size());
			for (ByteArrayWrapper serializedKey : serializedKeys) {
				newWaitingKeys.add(new WaitingKey(schema, serializedKey));
			}
			synchronized (pendingCount) {
				Integer count = pendingCount.get(relId);
				if (count == null) {
					count = serializedKeys.size();
				} else {
					count += serializedKeys.size();
				}
				pendingCount.put(relId, count);
			}
			synchronized (sinksForTuple) {
				for (WaitingKey wk : newWaitingKeys) {
					Set<Integer> sinks = sinksForTuple.get(wk.keyWithRelId);
					if (sinks == null) {
						sinks = new HashSet<Integer>();
						sinksForTuple.put(new ByteArrayWrapper(wk.keyWithRelId), sinks);
					}
					sinks.add(requestId);
				}
			}
			synchronized (waitingKeys) {
				boolean wasEmpty = waitingKeys.isEmpty();
				for (WaitingKey wk : newWaitingKeys) {
					waitingKeys.add(wk);
				}
				if (wasEmpty) {
					waitingKeys.notifyAll();
				}
			}
		} else {
			try {
				Database db = getDatabase();
				List<QpTuple<M>> results = new ArrayList<QpTuple<M>>(serializedKeys.size());

				for (ByteArrayWrapper serializedKey : serializedKeys) {
					QpTuple<M> t = getTuple(getDbKey(relId, serializedKey), schema, db);
					if (t != null) {
						results.add(t);
					}
				}

				ts.deliverTuples(results);
			} catch (TupleStoreException tse) {
				ts.processException(tse);
			}
		}
	}

	private class BatchingThread extends Thread {
		private final Database db;

		BatchingThread(ThreadGroup tg) throws DatabaseException {
			super(tg, "BDbTupleStore Batching Thread");
			db = getDatabaseNoCatch();
		}

		private volatile boolean interrupted = false;

		public void interrupt() {
			interrupted = true;
		}

		public boolean isInterrupted() {
			return interrupted;
		}


		public void run() {
			while (! isInterrupted()) {
				try {
					Thread.sleep(batchingCheckIntervalMs);
					int batchRel = -1;
					int waitingSize = -1;
					synchronized (pendingCount) {
						for (Map.Entry<Integer,Integer> me : pendingCount.entrySet()) {
							if (me.getValue() > waitingSize) {
								batchRel = me.getKey();
								waitingSize = me.getValue();
							}
						}
					}

					if (waitingSize < batchingCutoff) {
						continue;
					}

					waitingKeys.setSkipMetadata(batchRel);
					if (logger.isInfoEnabled()) {
						logger.info("Starting batch for " + waitingSize + " keys in relation " + getSchema(batchRel).getName());
					}

					byte[] relIdBytes = IntType.getBytes(batchRel);
					QpSchema schema = getSchema(batchRel);
					DatabaseEntry key = new DatabaseEntry(relIdBytes), value = new DatabaseEntry();

					int retrievedCount = 0;

					Cursor c = null;
					try {
						c = db.openCursor(null, null);
						OperationStatus os = c.getSearchKeyRange(key, value, null);

						int rowcount = 0;
						int printcount = 0;

						TUPLE: while (os != OperationStatus.NOTFOUND && (! isInterrupted())) {
							byte[] keyBytes = key.getData();
							for (int i = 0; i < relIdBytes.length; ++i) {
								if (relIdBytes[i] != keyBytes[i]) {
									// past the end of the batched relation
									break TUPLE;
								}
							}
							WaitingKey wk = new WaitingKey(keyBytes);
							if (waitingKeys.contains(wk)) {
								waitingTuples.add(new TupleAndKey(schema, keyBytes, value.getData()));
								waitingKeys.remove(wk);
								++retrievedCount;
							}
							os = c.getNext(key,value, null);

							++rowcount;
							++printcount;

							if (printcount == 50000) {
								printcount = 0;

								if (logger.isInfoEnabled()) {
									logger.info("Batch for " + getSchema(batchRel).getName() + " has read " + rowcount + " tuples and retrieved " + retrievedCount + " so far");
								}
							}
						}
					} finally {
						if (c != null) {
							c.close();
						}
					}

					if (logger.isInfoEnabled()) {
						logger.info("Finished batch for " + waitingSize + " keys in relation " +  getSchema(batchRel).getName() + " (actually retrieved " + retrievedCount + ")");
					}
					synchronized (waitingKeys) {
						waitingKeys.clearSkipMetadata();
						waitingKeys.notifyAll();
					}
				} catch (InterruptedException ie) {
					return;
				} catch (DatabaseException dbe) {
					logger.fatal("Error in tuple store batching thread", dbe);
					return;
				}
			}

		}
	}

	private void deliver(byte[] keyWithRelation, QpSchema schema, QpTuple<M> t, TupleStoreException tse) {
		QpTuple<?> key = null;
		Integer id;
		if (t == null) {
			key = QpTuple.fromBytes(KEY, schema, BDbTupleStore.this, mdf, keyWithRelation, IntType.bytesPerInt, keyWithRelation.length - IntType.bytesPerInt, null);
			id = key.getSchema().relId;
		} else {
			id = t.getSchema().relId;
		}
		synchronized (pendingCount) {
			Integer count = pendingCount.get(id);
			if (count != null) {
				--count;
				pendingCount.put(id, count);
			}
		}

		Set<Integer> sinkIds;
		synchronized (sinksForTuple) {
			sinkIds = sinksForTuple.remove(new ByteArrayWrapper(keyWithRelation));
			if (sinkIds == null) {
				if (key == null) {
					key = QpTuple.fromBytes(KEY, schema, BDbTupleStore.this, mdf, keyWithRelation, IntType.bytesPerInt, keyWithRelation.length - IntType.bytesPerInt, null);
				}
				logger.info("No sinks found for tuple " + key + " at epoch " + key.getEpoch());
				return;
			}
		}


		if (tse != null) {
			for (Integer sinkId : sinkIds) {
				SinkAndCount sink = sinks.remove(sinkId);
				if (sink == null) {
					continue;
				}
				sink.ts.processException(tse);
			}
			return;
		}

		if (t == null) {
			for (Integer sinkId : sinkIds) {
				SinkAndCount sink = sinks.get(sinkId);
				if (sink == null) {
					// Sink has been removed due to an exception, most likely
					continue;
				}

				if (sink.decrement()) {
					sink.ts.tupleNotFound(key);
					sinks.remove(sinkId);
				} else {
					sink.ts.tupleNotFound(key);
				}
			}
		} else {
			Collection<QpTuple<M>> c = Collections.singleton(t); 
			for (Integer sinkId : sinkIds) {
				SinkAndCount sink = sinks.get(sinkId);
				if (sink == null) {
					// Sink has been removed due to an exception, most likely
					continue;
				}

				if (sink.decrement()) {
					sink.ts.deliverTuples(c);
					sinks.remove(sinkId);
				} else {
					sink.ts.deliverTuples(c);
				}
			}
		}
	}

	private class BatchDeliverThread extends Thread {
		BatchDeliverThread(ThreadGroup tg, int num) {
			super(tg, "BDbTupleStore BatchDeliverThread #" + num);
		}

		public void run() {
			try {
				while (! isInterrupted()) {
					TupleAndKey tak = waitingTuples.poll();
					if (tak == null) {
						Thread.sleep(batchingCheckIntervalMs);
						continue;
					}
					QpTuple<M> tuple = QpTuple.fromBytes(STORE, tak.schema, BDbTupleStore.this, mdf, tak.tuple, null);
					deliver(tak.keyWithRelId, tak.schema, tuple, null);
				}
			} catch (InterruptedException ie) {
				return;
			}
		}

	}

	private class LookupThread extends Thread {
		private final Database db;
		private volatile boolean interrupted = false;
		private volatile boolean noRealInterrupts = false;

		LookupThread(ThreadGroup tg, int num) throws DatabaseException {
			super(tg, "BDbTupleStore Lookup Thread #" + num);
			db = getDatabaseNoCatch();
		}

		public void interrupt() {
			interrupted = true;
			if (! noRealInterrupts) {
				super.interrupt();
			}
		}

		public boolean isInterrupted() {
			return interrupted;
		}

		public void run() {
			try {
				while (! isInterrupted()) {
					WaitingKey wk = null;
					QpTuple<M> t = null;
					TupleStoreException tse = null;
					synchronized (waitingKeys) {
						while ((wk = waitingKeys.poll()) == null) {
							try {
								waitingKeys.wait();
							} catch (InterruptedException e) {
								return;
							}
						}
					}
					try {
						noRealInterrupts = true;
						t = getTuple(wk.keyWithRelId, wk.schema, db);
						noRealInterrupts = false;
					} catch (TupleStoreException e) {
						tse = e;
					}

					deliver(wk.keyWithRelId, wk.schema, t, tse);
				}
			} catch (Exception e) {
				logger.error("Error in " + this.getName(), e);
			}
		}
	}

	public PullScanOperator<M> beginScan(int relation, Set<ByteArrayWrapper> keys, Filter<? super QpTuple<?>> fullFilter, Operator<M> componentOf, int phaseNo) {
		return new SpecifiedKeyScan(relation, keys, fullFilter, componentOf, phaseNo);
	}

	private class SpecifiedKeyScan extends PullScanOperator<M> {
		final byte[] searchKey;
		Cursor c;
		DatabaseEntry key, value;
		boolean finished = false;
		private final QpSchema.Source tables;
		private final Set<ByteArrayWrapper> keys;
		private final Filter<? super QpTuple<?>> fullFilter;
		private final int keysSize;
		private int keysScanned = 0;
		private final QpSchema schema;
		private volatile boolean interrupted = false;
		private final int phaseNo;

		SpecifiedKeyScan(int relation, Set<ByteArrayWrapper> keys, Filter<? super QpTuple<?>> fullFilter, Operator<M> componentOf, int phaseNo) {
			super(componentOf);

			searchKey = IntType.getBytes(relation);
			schema = getSchema(relation);
			tables = new QpSchema.SingleSource(schema);
			this.keys = keys;
			this.fullFilter = fullFilter;
			keysSize = keys.size();
			this.phaseNo = phaseNo;
			logger.info("SpecifiedKeyScan " + this.operatorId + " in phase "  + phaseNo + " starting for  " + keys.size() + " keys");
		}

		@Override
		public synchronized boolean isFinished(int phaseNo) {
			return finished;
		}

		@Override
		public void scan(int blockSize, int phaseNo) {
			scan(blockSize, false, phaseNo);
		}

		@Override
		public void scanAll(int blockSize, int phaseNo) {
			scan(blockSize, true, phaseNo);
		}

		private synchronized void scan(int blockSize, boolean all, int phaseNo) {
			if (phaseNo != this.phaseNo) {
				throw new IllegalArgumentException("Expected phase " + this.phaseNo + ", got phase " + phaseNo);
			}
			try {
				if (finished) {
					throw new IllegalStateException("Scan has already finished");
				}
				OperationStatus os;
				if (c == null) {
					c = getDatabase().openCursor(null, null);
					key = new DatabaseEntry(searchKey);
					value = new DatabaseEntry();
					os = c.getSearchKeyRange(key, value, null);
				} else {
					os = c.getNext(key, value, null);
				}
				List<QpTuple<M>> block = new ArrayList<QpTuple<M>>(blockSize);
				List<ExecutionId> scannedIds = new ArrayList<ExecutionId>(blockSize);
				List<QpTuple<?>> scannedKeys = new ArrayList<QpTuple<?>>(blockSize);
				TUPLE: while ((! interrupted) && os != OperationStatus.NOTFOUND) {
					byte[] keyBytes = key.getData();
					for (int i = 0; i < searchKey.length; ++i) {
						if (searchKey[i] != keyBytes[i]) {
							finished = true;
							break TUPLE;
						}
					}

					ByteArrayWrapper baw = new ByteArrayWrapper(keyBytes, IntType.bytesPerInt, keyBytes.length - IntType.bytesPerInt);
					if (keys.remove(baw)) {
						++keysScanned;
						QpTuple<?> key = QpTuple.fromBytes(KEY, schema, tables, null, keyBytes, IntType.bytesPerInt, keyBytes.length - IntType.bytesPerInt, null);
						QpTuple<M> t = QpTuple.fromBytes(STORE, schema, tables, mdf, value.getData(), null);
						scannedKeys.add(key);
						if (fullFilter == null || fullFilter.eval(t)) {
							QpTuple<M> newT = t.changeId(getFreshId(phaseNo));
							block.add(newT);
							scannedIds.add(newT.getId());
						}
					}

					if (scannedKeys.size() == blockSize) {
						tuplesAdded(scannedIds);
						keysScanned(scannedKeys, phaseNo);
						scannedIds.clear();
						scannedKeys.clear();						
					}
					if (block.size() == blockSize) {
						tuplesAdded(scannedIds);
						keysScanned(scannedKeys, phaseNo);
						scannedIds.clear();
						scannedKeys.clear();
						sendTuples(block);
						block.clear();
						if (! all) {
							break TUPLE;
						}
					}
					if (keys.isEmpty()) {
						finished = true;
						break;
					}
					os = c.getNext(key, value, null);
				}
				if (! scannedIds.isEmpty()) {
					tuplesAdded(scannedIds);
				}
				if (! scannedKeys.isEmpty()) {
					keysScanned(scannedKeys, phaseNo);
				}
				if (! block.isEmpty()) {
					sendTuples(block);
				}
				if (os == OperationStatus.NOTFOUND || finished || interrupted) {
					finished = true;
					c.close();
					c = null;
					if (! keys.isEmpty()) {
						if (logger.isInfoEnabled()) {
							logger.info("SpecifiedKeyScan " + this.operatorId + " in phase "  + phaseNo + " missed " + keys.size() + " keys");
						}
						List<QpTuple<?>> missing = new ArrayList<QpTuple<?>>(keys.size());
						for (ByteArrayWrapper baw : keys) {
							QpTuple<?> key = QpTuple.fromBytes(KEY, schema, tables, null, baw.array, baw.offset, baw.length, null);
							missing.add(key);
						}
						reportMissing(missing, phaseNo);
					} else if (keysSize != keysScanned) {
						logger.error("SpecifiedKeyScan " + operatorId + " in phase "  + phaseNo + " was scanning for " + keysSize + " keys but read " + keysScanned);
					} else if (logger.isInfoEnabled()) {
						logger.info("SpecifiedKeyScan " + this.operatorId + " in phase "  + phaseNo + " found all " + keysScanned + " keys");
					}
				}
			} catch (Exception e) {
				if (c != null) {
					try {
						c.close();
						c = null;
					} catch (DatabaseException de) {
						logger.error("Error closing SpecifiedKeyScan cursor", de);
					}
				}
				finished = true;				
				reportException(e);
				return;
			}
		}

		protected void close() {
			try {
				if (c != null) {
					c.close();
					c = null;
				}
			} catch (DatabaseException de) {
				de.printStackTrace();
			}
		}

		public void interrupt(int phaseNo) {
			if (phaseNo != this.phaseNo) {
				throw new IllegalArgumentException("Expected phase " + this.phaseNo + ", got phase " + phaseNo);
			}
			interrupted = true;
		}

	}
}

package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.p2pqp.IndexService.EpochNum;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;

public class DistributedScanOperator<M> extends PullScanOperator<M> implements KeyReceiver {
	private final List<Set<ByteArrayWrapper>> toScan = new ArrayList<Set<ByteArrayWrapper>>();
	private final List<Set<EpochNum>> remainingPages = new ArrayList<Set<EpochNum>>();

	private final int relation;
	private final Filter<? super QpTuple<?>> fullFilter;
	private final QpApplication<M> app;

	private final Logger logger = Logger.getLogger(this.getClass());

	private final List<PullScanOperator<M>> storeScans = new ArrayList<PullScanOperator<M>>();
	private final Collection<EpochNum> pages;

	public DistributedScanOperator(int relation,
			QpApplication<M> app,
			Filter<? super QpTuple<?>> fullFilter,
					Operator<M> dest, WhichChild outputDest,
					int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt,
					MetadataFactory<M> mdf, boolean enableRecovery, Collection<EpochNum> pages) {
		super(dest, outputDest, queryId, nodeId, operatorId, rt, mdf, enableRecovery);

		this.pages = pages;
		this.relation = relation;
		this.fullFilter = fullFilter;
		this.app = app;
	}

	@Override
	public synchronized boolean isFinished(int phaseNo) {
		PullScanOperator<M> storeScan = storeScans.get(phaseNo);
		if (storeScan == null) {
			return false;
		} else {
			return storeScan.isFinished(phaseNo);
		}
	}

	@Override
	public void scan(int blockSize, int phaseNo) {
		scan(blockSize, false, phaseNo);
	}

	@Override
	public void scanAll(int blockSize, int phaseNo) {
		scan(blockSize, true, phaseNo);
	}

	private void scan(int blockSize, boolean all, int phaseNo) {
		synchronized (remainingPages) {
			ensureCapacityFor(phaseNo);
			try {
				while (! remainingPages.get(phaseNo).isEmpty()) {
					remainingPages.wait();
				}
			} catch (InterruptedException ie) {
				reportException(ie);
				return;
			}
		}

		PullScanOperator<M> ourStoreScan;
		synchronized (this) {
			ourStoreScan = storeScans.get(phaseNo);
			if (ourStoreScan == null) {
				if (logger.isInfoEnabled()) {
					logger.info("Constructed DistributedScanOperator " + DistributedScanOperator.this.operatorId + " on " + app.localAddr + " in phase " + phaseNo + " for " + toScan.get(phaseNo).size() + " keys");
				}
				ourStoreScan = app.store.beginScan(relation, toScan.get(phaseNo), fullFilter, this, phaseNo);
				storeScans.set(phaseNo, ourStoreScan);
			}
		}
		if (all) {
			ourStoreScan.scanAll(blockSize, phaseNo);
		} else {
			ourStoreScan.scan(blockSize, phaseNo);
		}
	}

	protected synchronized void close() {
		for (int i = 0; i < remainingPages.size(); ++i) {
			if (! remainingPages.get(i).isEmpty()) {
				logger.warn("DistributedScanOperator " + operatorId + " is still waiting for pages " + remainingPages.get(i));
			}
		}
		toScan.clear();
		remainingPages.clear();
		storeScans.clear();
	}

	private void ensureCapacityFor(int phaseNo) {
		while (remainingPages.size() <= phaseNo) {
			remainingPages.add(new HashSet<EpochNum>(pages));
		}
		while (toScan.size() <= phaseNo) {
			toScan.add(new HashSet<ByteArrayWrapper>());
		}
		while (storeScans.size() <= phaseNo) {
			storeScans.add(null);
		}
	}


	public void receiveKeys(int phaseNo, EpochNum page, Collection<ByteArrayWrapper> keys) {
		synchronized (remainingPages) {
			ensureCapacityFor(phaseNo);
			if (remainingPages.get(phaseNo).remove(page)) {
				toScan.get(phaseNo).addAll(keys);
			}
			if (remainingPages.get(phaseNo).isEmpty()) {
				remainingPages.notifyAll();
			}
		}
	}

	@Override
	public synchronized void interrupt(int phaseNo) {
		PullScanOperator<M> storeScan = storeScans.get(phaseNo);
		if (storeScan != null) {
			storeScan.interrupt(phaseNo);
		}
	}

	boolean canRescan() {
		return true;
	}
}

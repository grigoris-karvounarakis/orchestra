package edu.upenn.cis.orchestra.p2pqp.messages;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.STORE;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.MetadataFactory;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.TupleStore;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class ConstraintViolationMsg extends QpMessage {
	private static final long serialVersionUID = 1L;

	private final List<byte[]> tuplesBytes;
	private final int relId;
	public final List<TupleStore.ConstraintViolation> errors;

	public <M> ConstraintViolationMsg(InsertTuplesMessage itm, List<QpTuple<M>> tuples, MetadataFactory<M> mdf, List<TupleStore.ConstraintViolation> errors) {
		super(itm, false);
		
		if (tuples.isEmpty()) {
			throw new IllegalStateException("Should not being sending message about no tuples");
		}

		
		int relId = 0;
		boolean first = true;
		tuplesBytes = new ArrayList<byte[]>();
		for (QpTuple<M> t : tuples) {
			if (first) {
				first = false;
				relId = t.getSchema().relId;
			} else if (t.getSchema().relId != relId) {
				throw new IllegalArgumentException("All tuples must be from the same relation");
			}
			tuplesBytes.add(t.getStoreBytes(mdf));
		}
		this.relId = relId;

		this.errors = Collections.unmodifiableList(new ArrayList<TupleStore.ConstraintViolation>(errors));
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(relId);
		buf.writeInt(tuplesBytes.size());
		for (byte[] bytes : tuplesBytes) {
			buf.writeBytes(bytes);
		}
		buf.writeObject(errors);
	}

	@SuppressWarnings("unchecked")
	public ConstraintViolationMsg(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);

		this.relId = buf.readInt();
		
		int numTuples = buf.readInt();
		tuplesBytes = new ArrayList<byte[]>(numTuples);
		while (numTuples > 0) {
			tuplesBytes.add(buf.readBytes());
			--numTuples;
		}

		this.errors = (List<TupleStore.ConstraintViolation>) buf.readObject();
	}

	public <M> List<QpTuple<M>> getErrorTuples(QpSchema.Source schemas, MetadataFactory<M> mdf) {
		QpSchema schema = schemas.getSchema(relId);
		List<QpTuple<M>> retval = new ArrayList<QpTuple<M>>(tuplesBytes.size());
		for (byte[] tupleBytes : tuplesBytes) {
			retval.add(QpTuple.fromBytes(STORE, schema, schemas, mdf, tupleBytes, null));
		}
		return retval;
	}
}

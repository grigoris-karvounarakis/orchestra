package edu.upenn.cis.orchestra.p2pqp;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Map;

import rice.p2p.commonapi.Endpoint;
import rice.p2p.commonapi.Id;
import rice.p2p.commonapi.Message;
import rice.p2p.commonapi.RouteMessage;

import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;

public class SQpApplication<M> extends QpApplication<M> {

	int nodeID;
	int x_attr;
	int y_attr;
	public SQpApplication(Integer id, InetSocketAddress localAddr, NodeFactory nf, File scratchDir, String scratchPrefix, Environment env, String storeTableName, String indexTableName, MetadataFactory<M> mdf, Map<String,InetSocketAddress> allNames) throws IOException, DatabaseException
	{
		super(localAddr, nf, scratchDir, scratchPrefix, env, storeTableName, indexTableName, mdf, allNames);
		nodeID = id;
		
	}
	public void setX(int x)
	{
		x_attr = x;
	}
	public void setY(int y)
	{
		y_attr = y;
	}
	@Override
	public boolean forward(RouteMessage message) {
		
		if (logger.isInfoEnabled()) {
			// Inspect message and report...
				try {
					QpMessage m = (QpMessage) message.getMessage(endpoint.getDeserializer());
					if(!m.isReply())
						logger.info("Message ID,"+m.messageId+" Source, "+m.getOrigin() + " Current, "+this.getNodeId());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		}
		return true;
	}
	@Override
	public void deliver(Id id, Message message)
	{
		super.deliver(id, message);
		if (logger.isInfoEnabled()) {
			// Inspect message and report...
				try {
					QpMessage m = (QpMessage) message;
					if(!m.isReply())
						logger.info("Message ID,"+m.messageId+" Source, "+m.getOrigin() + " Current, "+this.getNodeId());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		}
	}
	public Endpoint getEndpoint()
	{
		return this.endpoint;
	}
}

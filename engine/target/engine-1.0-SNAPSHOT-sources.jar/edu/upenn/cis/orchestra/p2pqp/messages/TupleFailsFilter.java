package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class TupleFailsFilter extends QpMessage {
	private static final long serialVersionUID = 1L;

	public TupleFailsFilter(RetrieveTupleMessage origMsg, QpTuple<?> t) {
		super(origMsg, true);
	}

	protected void subclassSerialize(OutputBuffer buf) {

	}

	public String toString() {
		return "TupleFailsFilter";
	}

	public TupleFailsFilter(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
	}
}


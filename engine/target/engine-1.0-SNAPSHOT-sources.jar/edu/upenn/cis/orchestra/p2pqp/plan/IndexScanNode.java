package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.Filter;
import edu.upenn.cis.orchestra.p2pqp.FilterSerialization;
import edu.upenn.cis.orchestra.p2pqp.IndexScanOperator;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.Operator.OperatorCreationException;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class IndexScanNode extends NoInputQueryPlan {
	private static final long serialVersionUID = 1L;

	final byte[] filterBytes;
	

	public IndexScanNode(QpSchema table, Filter<? super QpTuple<?>> f, Location loc, int operatorId) {
		super(table.getRelationName(), loc, operatorId, loc.isDistributed());
		filterBytes = FilterSerialization.getBytes(f, table);
	}

	@Override
	<M> IndexScanOperator<M> createOperator(QueryExecution<M> exec, Operator<M> parent,
			WhichChild dest, boolean allowRecovery) throws OperatorCreationException {
		QpSchema schema = exec.getSchema(outputSchema);
		Filter<? super QpTuple<?>> f = FilterSerialization.fromBytes(schema, filterBytes);
		return new IndexScanOperator<M>(exec.app, f, schema.relId, exec.epoch,
				parent, dest, exec.queryId, exec.getNodeAddress(), this.operatorId,
				exec.getRecordTuples(), exec.app.getMetadataFactory(), allowRecovery);
	}

	@Override
	public boolean equals(Object o) {
		if (o == null || o.getClass() != this.getClass()) {
			return false;
		}
		IndexScanNode isn = (IndexScanNode) o;
		return this.outputSchema.equals(isn.outputSchema) && Arrays.equals(filterBytes, isn.filterBytes);
	}

	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc,el,schemas);
		QpSchema ns = schemas.get(outputSchema);
		
		if (ns == null) {
			throw new IllegalArgumentException("Missing schema for relation " + outputSchema);
		}
		
		if (filterBytes != null) {
			Element filterEl = DomUtils.addChild(doc, el, "keyColsFilter");
			Filter<? super QpTuple<?>> f = FilterSerialization.fromBytes(ns, filterBytes);
			FilterSerialization.serialize(doc, filterEl, f, ns);
		}
	}

	public static IndexScanNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QpSchema ns = schemas.get(qpd.outputSchema);
		
		Filter<? super QpTuple<?>> f = null;
		
		Element keyColsFilterEl = DomUtils.getChildElementByName(el, "keyColsFilter");
		if (keyColsFilterEl != null) {
			f = FilterSerialization.deserialize(keyColsFilterEl, ns);
		}
		
		return new IndexScanNode(ns, f, qpd.loc, qpd.operatorId);
	}
}

package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.ProbeScanOperator;
import edu.upenn.cis.orchestra.p2pqp.Filter;
import edu.upenn.cis.orchestra.p2pqp.FilterSerialization;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;


public class ProbeScanNode extends NoInputQueryPlan {
	private static final long serialVersionUID = 1L;

	final byte[] keyColsBytes, allColsBytes;
	
	public ProbeScanNode(QpSchema ns, Filter<? super QpTuple<?>> keyColsFilter,
			Filter<? super QpTuple<?>> allColsFilter, Location loc, int operatorId) {
		super(ns.getRelationName(), loc, operatorId, false);

		if (loc.isCentralized() || loc.isNamed()) {
			throw new IllegalArgumentException("A probe scan must have a distributed location");
		}
		
		if (keyColsFilter != null && (! ns.getKeyColsSet().containsAll(keyColsFilter.getColumns()))) {
			throw new IllegalArgumentException("Key columns filter uses non-key column");
		}

		keyColsBytes = FilterSerialization.getBytes(keyColsFilter, ns);
		allColsBytes = FilterSerialization.getBytes(allColsFilter, ns);
	}

	@Override
	<M> ProbeScanOperator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
			throws Operator.OperatorCreationException {
		QpSchema ns = exec.getSchema(outputSchema);
		Filter<? super QpTuple<?>> allColsFilter = FilterSerialization.fromBytes(ns, allColsBytes);
		
		return new ProbeScanOperator<M>(exec.getSchema(ns.getRelationName()), allColsFilter, exec.app.getStore(),
				parent, dest, exec.queryId, exec.getNodeAddress(), operatorId,
				exec.getRecordTuples(), exec.app.getMetadataFactory(), allowRecovery);
	}

	@Override
	public boolean equals(Object o) {
		if (o == null || o.getClass() != this.getClass()) {
			return false;
		}
		ProbeScanNode dsn = (ProbeScanNode) o;
		return outputSchema.equals(dsn.outputSchema) &&
		Arrays.equals(keyColsBytes, dsn.keyColsBytes) &&
		Arrays.equals(allColsBytes, dsn.allColsBytes);
	}

	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc,el,schemas);
		QpSchema ns = schemas.get(outputSchema);
		
		if (ns == null) {
			throw new IllegalArgumentException("Missing schema for relation " + outputSchema);
		}
		
		if (keyColsBytes != null) {
			Element filterEl = DomUtils.addChild(doc, el, "keyColsFilter");
			Filter<? super QpTuple<?>> f = FilterSerialization.fromBytes(ns, keyColsBytes);
			FilterSerialization.serialize(doc, filterEl, f, ns);
		}
		if (allColsBytes != null) {
			Element filterEl = DomUtils.addChild(doc, el, "allColsFilter");
			Filter<? super QpTuple<?>> f = FilterSerialization.fromBytes(ns, allColsBytes);
			FilterSerialization.serialize(doc, filterEl, f, ns);
		}
	}
	
	public static ProbeScanNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QpSchema ns = schemas.get(qpd.outputSchema);
		
		Filter<? super QpTuple<?>> keyColsFilter = null, allColsFilter = null;
		
		Element keyColsFilterEl = DomUtils.getChildElementByName(el, "keyColsFilter");
		if (keyColsFilterEl != null) {
			keyColsFilter = FilterSerialization.deserialize(keyColsFilterEl, ns);
		}
		
		Element allColsFilterEl = DomUtils.getChildElementByName(el, "allColsFilter");
		if (allColsFilterEl != null) {
			allColsFilter = FilterSerialization.deserialize(allColsFilterEl, ns);
		}
		
		return new ProbeScanNode(ns, keyColsFilter, allColsFilter, qpd.loc, qpd.operatorId);
	}
	
}

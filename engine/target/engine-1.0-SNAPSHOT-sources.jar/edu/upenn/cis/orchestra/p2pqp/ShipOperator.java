package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.datamodel.AbstractImmutableTuple.FieldSource;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.p2pqp.messages.DoesNotHaveQuery;
import edu.upenn.cis.orchestra.p2pqp.messages.RehashTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplySuccess;
import edu.upenn.cis.orchestra.p2pqp.messages.ShippedTuplesMessage;

public class ShipOperator<M> extends Operator<M> {
	static volatile boolean batchShips = false;
	public static final int defaultShipIntervalMs = 100;
	final private SendThread sendThread;
	final private QpApplication<M> app;
	final private QueryExecution<M> exec;
	final private InetSocketAddress dest;
	final private int queryId;
	private List<QpTuple<M>> pendingToShip;
	final private QpSchema newSchema;
	final private FieldSource[] newSchemaMapping;
	final private String namedDest;
	private final Router nonRecoveryRouter;

	private final Logger logger = Logger.getLogger(this.getClass());

	private Set<Long> outstandingMessages = Collections.synchronizedSet(new HashSet<Long>());

	public ShipOperator(QpApplication<M> app, QueryExecution<M> exec, InetSocketAddress dest, String namedDest, int queryId, InetSocketAddress nodeId, int operatorId, MetadataFactory<M> mdf, RecordTuples rt, boolean enableRecovery) {
		this(app, exec, null, null, dest, namedDest, queryId, nodeId, operatorId, mdf, rt, enableRecovery);
	}

	public ShipOperator(QpApplication<M> app, QueryExecution<M> exec, QpSchema newSchema, int[] newToOldPos,  InetSocketAddress dest, String namedDest, int queryId, InetSocketAddress nodeId, int operatorId, MetadataFactory<M> mdf, RecordTuples rt, boolean enableRecovery) {
		super(queryId, nodeId, operatorId, mdf, rt, enableRecovery);
		this.dest = dest;
		if (dest == null && (! enableRecovery)) {
			nonRecoveryRouter = exec.getMostRecentRouter();
		} else {
			nonRecoveryRouter = null;
		}
		this.queryId = queryId;
		this.app = app;
		this.exec = exec;
		this.newSchema = newSchema;
		if (newSchema == null) {
			this.newSchemaMapping = null;
		} else {
			if (newToOldPos == null) {
				throw new IllegalArgumentException("Need new schema mapping");
			} else if (newToOldPos.length != newSchema.getNumCols()) {
				throw new IllegalArgumentException("Schema mapping should one entry for each column in the new schema");
			}
			this.newSchemaMapping = new FieldSource[newSchema.getNumCols()];
			for (int i = 0; i < newToOldPos.length; ++i) {
				this.newSchemaMapping[i] = new FieldSource(newToOldPos[i],true);
			}
		}
		this.namedDest = namedDest;
		if (batchShips) {
			pendingToShip = new ArrayList<QpTuple<M>>();
			sendThread = new SendThread(defaultShipIntervalMs);
			sendThread.start();
		} else {
			sendThread = null;
			pendingToShip = null;
		}
	}

	@Override
	protected void receiveTuples(List<QpTuple<M>> tuples) {
		if (sendThread == null) {
			shipTuples(tuples);
		} else {
			synchronized (this) {
				pendingToShip.addAll(tuples);	
			}
		}

	}

	private void shipTuples(List<QpTuple<M>> input) {
		if (input.isEmpty()) {
			return;
		}
		
		List<QpTuple<M>> toSend;

		if (newSchema == null) {
			toSend = input;
		} else {
			toSend = new ArrayList<QpTuple<M>>(input.size());
			Iterator<QpTuple<M>> it = input.iterator();
			QpTuple<M> t = null;
			try {
				while (it.hasNext()) {
					t = it.next();
					QpTuple<M> newT = new QpTuple<M>(newSchema, newSchemaMapping, t, null);
					toSend.add(newT);
				}
			} catch (ValueMismatchException vme) {
				this.reportException(vme);
			}
			input.clear();

		}

		
		if (dest == null) {
			Map<InetSocketAddress,List<QpTuple<M>>> toRehash = new HashMap<InetSocketAddress,List<QpTuple<M>>>();
			final Router[] routers = exec.getRouters();
			// Doing a rehash
			if (enableRecovery) {
				List<ExecutionId> removed = new ArrayList<ExecutionId>(input.size());
				List<ExecutionId> added = new ArrayList<ExecutionId>(input.size());
				for (QpTuple<M> t : toSend) {
					ExecutionId exId = t.getId();
					Id id = t.getQPid();
					InetSocketAddress dest = routers[t.getId().phaseNo].getDest(id);
					byte[] destBytes = ExecutionId.getNodeIdBytes(dest);
					ExecutionId newId = this.getFreshId(exId, destBytes);
					added.add(newId);
					removed.add(exId);
					QpTuple<M> newT = t.changeId(newId);
					List<QpTuple<M>> forDest = toRehash.get(dest);
					if (forDest == null) {
						forDest = new ArrayList<QpTuple<M>>();
						toRehash.put(dest, forDest);
					}
					forDest.add(newT);
				}
				if (! added.isEmpty()) {
					tuplesAdded(added);
					tuplesRemoved(removed);
				}
			} else {
				for (QpTuple<M> t : toSend) {
					Id id = t.getQPid();
					InetSocketAddress dest = nonRecoveryRouter.getDest(id);
					List<QpTuple<M>> forDest = toRehash.get(dest);
					if (forDest == null) {
						forDest = new ArrayList<QpTuple<M>>();
						toRehash.put(dest, forDest);
					}
					forDest.add(t);
				}
			}
			toSend = null;
			for (Map.Entry<InetSocketAddress, List<QpTuple<M>>> me : toRehash.entrySet()) {
				final InetSocketAddress dest = me.getKey();
				final List<QpTuple<M>> tuples = me.getValue();		

				List<? extends QpMessage> rehashes = RehashTuplesMessage.build(dest, queryId, tuples, mdf);
				for (final QpMessage rehash : rehashes) {
					outstandingMessages.add(rehash.messageId);
					try {
						app.sendMessageAwaitReply(rehash, new ReplyContinuation() {
							private boolean finished = false;

							public boolean isFinished() {
								return finished;
							}

							public void processReply(Message m) {
								if (finished) {
									return;
								}
								finished = true;
								outstandingMessages.remove(rehash.messageId);
								if (! (m instanceof ReplySuccess)) {
									reportNodeFailure(dest);
								}
							}
						}, ReplySuccess.class);
					} catch (IOException e) {
						logger.error(e);
					} catch (InterruptedException ie) {
						return;
					}
				}
			}
		} else {
			List<? extends QpMessage> ships = ShippedTuplesMessage.build(dest, namedDest, queryId, toSend, mdf);
			for (final QpMessage ship : ships) {
				outstandingMessages.add(ship.messageId);
				try {
					app.sendMessageAwaitReply(ship, new ReplyContinuation() {
						private boolean finished = false;

						public boolean isFinished() {
							return finished;
						}

						public void processReply(Message m) {
							finished = true;
							outstandingMessages.remove(ship.messageId);
							if (m instanceof DoesNotHaveQuery) {
								return;
							} else if (!(m instanceof ReplySuccess)) {
								Exception e = new Exception("Could not deliver tuples (msg #" + m.messageId + ") to " + dest + " for query " + queryId + ": " + m);
								logger.error("Could not deliver tuples", e);
								reportException(e);
							}
						}

					}, ReplySuccess.class);
				} catch (IOException e) {
					logger.error(e);
				} catch (InterruptedException ie) {
					return;
				}
			}
		}
	}

	protected void close() {
		if (pendingToShip != null) {
			pendingToShip.clear();
		}
		if (sendThread != null) {
			try {
				sendThread.interrupt();
				sendThread.join();
			} catch (InterruptedException ie) {
				return;
			}
		}
		for (long msgId : outstandingMessages) {
			app.removeReplyContinuation(msgId);
		}
		outstandingMessages.clear();
	}

	private class SendThread extends Thread {
		private final int sendIntervalMs;
		SendThread(int sendIntervalMs) {
			super(app.tg, "ShipOperator(" + queryId + "," + operatorId + "," + app.localAddr + ")");
			this.sendIntervalMs = sendIntervalMs;
		}

		public void run() {
			while (! isInterrupted()) {
				try {
					Thread.sleep(sendIntervalMs);
				} catch (InterruptedException ie) {
					return;
				}
				List<QpTuple<M>> toSend = null;
				synchronized (ShipOperator.this) {
					if (pendingToShip.isEmpty()) {
						continue;
					}
					toSend = pendingToShip;
					pendingToShip = new ArrayList<QpTuple<M>>(toSend.size());
				}
				shipTuples(toSend);
			}
		}
	}

	int getOutstandingMessages() {
		return outstandingMessages.size();
	}
}

package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.Filter;
import edu.upenn.cis.orchestra.p2pqp.FilterSerialization;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class LocalTableScanNode extends NoInputQueryPlan {
	private final byte[] keyFilterBytes, fullFilterBytes;
	public LocalTableScanNode(QpSchema outputSchema, Filter<? super QpTuple<?>> keyFilter,
			Filter<? super QpTuple<?>> fullFilter, Location loc, int operatorId) {
		super(outputSchema.getName(), loc, operatorId, loc.isDistributed());
		
		if (keyFilter != null && (! outputSchema.getKeyColsSet().containsAll(keyFilter.getColumns()))) {
			throw new IllegalArgumentException("Key columns filter uses non-key column");
		}
		
		keyFilterBytes = FilterSerialization.getBytes(keyFilter, outputSchema);
		fullFilterBytes = FilterSerialization.getBytes(fullFilter, outputSchema);
	}

	private static final long serialVersionUID = 1L;

	<M> Operator<M> createOperator(QueryExecution<M> exec, Operator<M> parent,
			WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException {

		QpSchema ns = exec.getSchema(outputSchema);
		if (ns == null) {
			throw new IllegalStateException("Could not find schema for " + outputSchema);
		}
		Filter<? super QpTuple<?>> keyFilter = FilterSerialization.fromBytes(ns, keyFilterBytes);
		Filter<? super QpTuple<?>> fullFilter = FilterSerialization.fromBytes(ns, fullFilterBytes);
		
		
		return exec.app.getStore().beginScan(outputSchema, parent, dest, keyFilter, fullFilter, exec.epoch, exec.queryId, exec.getNodeAddress(), operatorId, exec.getRecordTuples(), allowRecovery, 0);
	}

	public boolean equals(Object o) {
		if (o == null || o.getClass() != this.getClass()) {
			return false;
		}
		
		LocalTableScanNode ltsn = (LocalTableScanNode) o;
		return (ltsn.loc.equals(loc)
				&& Arrays.equals(keyFilterBytes, ltsn.keyFilterBytes)
				&& Arrays.equals(fullFilterBytes, ltsn.fullFilterBytes));
	}

	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc,el,schemas);
		
		QpSchema ns = schemas.get(outputSchema);
		if (ns == null) {
			throw new IllegalArgumentException("Missing schema for relation " + outputSchema);
		}

		if (keyFilterBytes != null) {
			Element filterEl = DomUtils.addChild(doc, el, "keyColsFilter");
			Filter<? super QpTuple<?>> f = FilterSerialization.fromBytes(ns, keyFilterBytes);
			FilterSerialization.serialize(doc, filterEl, f, ns);
		}
		if (fullFilterBytes != null) {
			Element filterEl = DomUtils.addChild(doc, el, "allColsFilter");
			Filter<? super QpTuple<?>> f = FilterSerialization.fromBytes(ns, fullFilterBytes);
			FilterSerialization.serialize(doc, filterEl, f, ns);
		}

	}
	public static LocalTableScanNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QpSchema ns = schemas.get(qpd.outputSchema);
				
		Filter<? super QpTuple<?>> keyColsFilter = null, allColsFilter = null;;
		Element keyColsFilterEl = DomUtils.getChildElementByName(el, "keyColsFilter");
		if (keyColsFilterEl != null) {
			keyColsFilter = FilterSerialization.deserialize(keyColsFilterEl, ns);
		}

		Element allColsFilterEl = DomUtils.getChildElementByName(el, "allColsFilter");
		if (allColsFilterEl != null) {
			allColsFilter = FilterSerialization.deserialize(allColsFilterEl, ns);
		}

		return new LocalTableScanNode(ns, keyColsFilter, allColsFilter, qpd.loc, qpd.operatorId);
	}
}

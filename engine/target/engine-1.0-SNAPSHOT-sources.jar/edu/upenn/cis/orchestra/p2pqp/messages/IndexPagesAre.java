package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.IndexService.EpochNum;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class IndexPagesAre extends QpMessage {
	private static final long serialVersionUID = 1L;
	public final int numTuples;
	public final int treeNum;
	private final byte[] pages;

	public IndexPagesAre(RequestIndexPages request, byte[] data) {
		super(request, true);
		numTuples = IntType.getValFromBytes(data, 0, IntType.bytesPerInt);
		treeNum = IntType.getValFromBytes(data, IntType.bytesPerInt, IntType.bytesPerInt);
		pages = new byte[data.length - 2 * IntType.bytesPerInt];
		System.arraycopy(data, 2 * IntType.bytesPerInt, pages, 0, data.length - 2 * IntType.bytesPerInt);
	}

	public String toString() {
		return "IndexPagesAre";
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(numTuples);
		buf.writeInt(treeNum);
		buf.writeBytes(pages);
	}


	public IndexPagesAre(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		numTuples = buf.readInt();
		treeNum = buf.readInt();
		pages = buf.readBytes();
	}
	
	public List<EpochNum> getPageIds() {
		List<EpochNum> retval = new ArrayList<EpochNum>();
		ByteBufferReader bbr = new ByteBufferReader(pages);
		while (! bbr.hasFinished()) {
			int epoch = bbr.readInt();
			int num = bbr.readInt();
			retval.add(new EpochNum(epoch,num));
		}
		return retval;
	}
}

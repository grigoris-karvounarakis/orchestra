package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import rice.environment.Environment;
import rice.p2p.commonapi.Node;
import rice.pastry.NodeHandle;
import rice.pastry.NodeIdFactory;
import rice.pastry.PastryNode;
import rice.pastry.socket.SocketNodeHandle;
import rice.pastry.socket.SocketPastryNodeFactory;
import rice.pastry.standard.IPNodeIdFactory;

public class PastryNodeFactory implements NodeFactory {
	rice.environment.Environment env;
	NodeIdFactory nidFactory;
	SocketPastryNodeFactory factory;
	NodeHandle bootHandle;
	int createdCount = 0;
	int port;
	private final PastryIdFactory idFactory;
	InetAddress bindAddress;

	private static final Logger logger = Logger.getLogger(PastryNodeFactory.class);

	public PastryNodeFactory(int port) {
		this(port, null, null);
	}
	
	public PastryNodeFactory(int port, InetAddress bindAddress) {
		this(port, null, bindAddress);
	}
	
	public PastryNodeFactory(int port, InetSocketAddress bootHandle) {
		this(port,bootHandle,null);
	}


	public PastryNodeFactory(int port, InetSocketAddress bootHandle, InetAddress bindAddress) {
		env = new Environment();
		env.getParameters().setString("nat_search_policy","never");
		env.getParameters().setInt("pastry_socket_writer_max_queue_length", 50000);
		env.getParameters().setBoolean("pastry_messageDispatch_bufferIfNotReady", true);
		env.getParameters().setInt("pastry_messageDispatch_bufferSize", 128);
		env.getParameters().setInt("pastry_leafSetMaintFreq", 60); // Default is 60
		env.getParameters().setInt("pastry_routeSetMaintFreq", 900); // Default is 900
		env.getParameters().setInt("p2p_scribe_maintenance_interval", 15000);
		env.getParameters().setInt("p2p_scribe_message_timeout", 2000);
		env.getParameters().setInt("pastry_socket_reader_selector_deserialization_max_size", 1024 * 1024 * 64); // Default is 1MB
		env.getParameters().setInt("pastry_lSetSize", 100);

		this.port = port;
		try {
			if (bindAddress == null) {
				bindAddress = InetAddress.getLocalHost();
			}
			nidFactory = new IPNodeIdFactory(bindAddress, port, env);
		} catch (UnknownHostException e) {
			throw new RuntimeException(e);
		}
		try {
			factory = new SocketPastryNodeFactory(nidFactory, bindAddress, port, env, null);
		} catch (java.io.IOException ioe) {
			throw new RuntimeException(ioe.getMessage(), ioe);
		}
		if (bootHandle != null) {
			this.bootHandle = factory.generateNodeHandle(bootHandle);
		}

		idFactory = new PastryIdFactory();
		this.bindAddress = bindAddress;
	}

	public Node getNode(Id nodeId) {
		PastryNode node = null;
		// Make sure that only one node per factory tries to create
		// a new ring
		rice.pastry.Id pastryNodeId = null;
		if (nodeId != null) {
			pastryNodeId = new PastryIdFactory().toRiceId(nodeId);
		}
		synchronized (this) {
			if (bootHandle == null) {
				if (createdCount == 0) {
					if (nodeId == null) {
						node = factory.newNode(null);
					} else {
						node = factory.newNode(null, pastryNodeId);
					}
				} else {
					InetSocketAddress bootaddress = new InetSocketAddress(bindAddress, port);
					bootHandle = factory.getNodeHandle(bootaddress);
				}
				++createdCount;
			}
		}
		if (node == null) {
			if (nodeId == null) {
				node = factory.newNode(bootHandle);
			} else {
				node = factory.newNode(bootHandle, pastryNodeId);
			}
		}
		node.getEnvironment().getSelectorManager().setPriority(Thread.MAX_PRIORITY);
		return node;
	}

	public void shutdownNode(Node n) {
		((PastryNode) n).destroy();	
	}

	public PastryIdFactory getIdFactory() {
		return idFactory;
	}

	public static class PastryIdFactory implements IdFactory {

		public Id toP2PQP(rice.p2p.commonapi.Id id) {
			rice.pastry.Id pid = (rice.pastry.Id) id;
			byte[] data = pid.toByteArray();
			return Id.fromLSBBytes(data);			
		}

		public IdRange toP2PQP(rice.p2p.commonapi.IdRange range) {
			if (range.isEmpty()) {
				return IdRange.empty();
			} else {
				Id ccw = toP2PQP(range.getCCWId());
				Id cw = toP2PQP(range.getCWId());
				return new IdRange(ccw,cw);
			}
		}

		public rice.pastry.Id toRiceId(Id id) {
			return rice.pastry.Id.build(id.getLSBBytes());
		}
	}

	public boolean isReady(Node n) {
		PastryNode pn = (PastryNode) n;
		return pn.isReady();
	}

	public int getCreatedCount() {
		return createdCount;
	}

	public NodeHandle getRemoteNodeHandle(
			InetSocketAddress addr) {
		if (addr == null) {
			throw new NullPointerException();
		}
		return factory.generateNodeHandle(addr);
	}

	public void cleanup() {
		env.destroy();
		env = null;
		factory = null;
	}

	
	public InetSocketAddress getAddress(rice.p2p.commonapi.NodeHandle nh) {
		SocketNodeHandle snh = (SocketNodeHandle) nh;
		InetSocketAddress isa = snh.getAddress();
		if (isa == null) {
			logger.warn("Got null address for " + nh);
		}

		return isa;
	}

	public Set<InetSocketAddress> getOtherNodes(Node n, Collection<rice.p2p.commonapi.NodeHandle> nhs) {
		PastryNode pn = (PastryNode) n;
		nhs.clear();
		Set<InetSocketAddress> isas = new HashSet<InetSocketAddress>();

		for (Object o : pn.getLeafSet().asList()) {
			SocketNodeHandle nh = (SocketNodeHandle) o;
			if (! isas.contains(nh.getAddress())) {
				isas.add(nh.getAddress());
				nhs.add(nh);
			}
		}
		
		for (Object o : pn.getRoutingTable().asList()) {
			SocketNodeHandle nh = (SocketNodeHandle) o;
			if (! isas.contains(nh.getAddress())) {
				isas.add(nh.getAddress());
				nhs.add(nh);
			}
		}

		return isas;
	}

}

package edu.upenn.cis.orchestra.p2pqp;

import java.io.Serializable;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Router implements Serializable {	
	private static final long serialVersionUID = 1L;

	public static class NodeInfo implements Comparable<NodeInfo>, Serializable {
		private static final long serialVersionUID = 1L;
		public final Id id;
		public final InetSocketAddress pastryAddress;
		public final InetSocketAddress qpAddress;

		public NodeInfo(Id id, InetSocketAddress pastryAddress, InetSocketAddress qpAddress) {
			this.id = id;
			this.pastryAddress = pastryAddress;
			this.qpAddress = qpAddress;
			if (! pastryAddress.getAddress().equals(qpAddress.getAddress())) {
				throw new IllegalArgumentException("Pastry address and QP address must point to the same machine");
			} else if (pastryAddress.getPort() == qpAddress.getPort()) {
				throw new IllegalArgumentException("Pastry port and QP port cannot be the same");
			}
		}

		public String toString() {
			return "ID: " + id + " Pastry address: " + pastryAddress + " QP Address: " + qpAddress;
		}

		@SuppressWarnings("unchecked")
		public int compareTo(NodeInfo arg0) {
			return id.compareTo(arg0.id);
		}

		public void serialize(OutputBuffer buf) {
			id.serialize(buf);
			buf.writeInetSocketAddress(pastryAddress);
			buf.writeShort((short) qpAddress.getPort());
		}

		public static NodeInfo deserialize(InputBuffer buf) {
			Id id = Id.deserialize(buf);
			InetSocketAddress pastryAddress = buf.readInetSocketAddress();
			int qpPort = (buf.readShort() & 0xFFFF);
			InetSocketAddress qpAddress = new InetSocketAddress(pastryAddress.getAddress(), qpPort);
			return new NodeInfo(id,pastryAddress,qpAddress);
		}
	}

	private static class RangeInfo implements Comparable<RangeInfo>, Serializable {
		private static final long serialVersionUID = 1L;
		private final Id id;
		private final IdRange idRange;
		private final InetSocketAddress pastryAddress;
		private final InetSocketAddress qpAddress;

		private RangeInfo(Id id, IdRange idRange, InetSocketAddress pastryAddress, InetSocketAddress qpAddress) {
			this.id = id;
			this.idRange = idRange;
			this.pastryAddress = pastryAddress;
			this.qpAddress = qpAddress;
			if (! pastryAddress.getAddress().equals(qpAddress.getAddress())) {
				throw new IllegalArgumentException("Pastry address and QP address must point to the same machine");
			}
		}

		public String toString() {
			return "ID: " + id + " Pastry address: " + pastryAddress + " QP Address: " + qpAddress + " " + idRange;
		}

		@SuppressWarnings("unchecked")
		public int compareTo(RangeInfo arg0) {
			return id.compareTo(arg0.id);
		}

		private void serialize(OutputBuffer buf) {
			id.serialize(buf);
			idRange.serialize(buf);
			buf.writeInetSocketAddress(pastryAddress);
			buf.writeShort((short) qpAddress.getPort());
		}

		private static RangeInfo deserialize(InputBuffer buf) {
			Id id = Id.deserialize(buf);
			IdRange idRange = IdRange.deserialize(buf);
			InetSocketAddress pastryAddress = buf.readInetSocketAddress();
			int qpPort = (buf.readShort() & 0xFFFF);
			InetSocketAddress qpAddress = new InetSocketAddress(pastryAddress.getAddress(), qpPort);
			return new RangeInfo(id,idRange,pastryAddress,qpAddress);
		}
		
		private NodeInfo getNodeInfo() {
			return new NodeInfo(id, pastryAddress, qpAddress);
		}
	}

	private final RangeInfo[] ris;
	private final int size;
	private final Map<InetSocketAddress,InetSocketAddress> getPastryAddress;

	Router(Collection<NodeInfo> nis) {
		if (nis.isEmpty()) {
			throw new IllegalArgumentException("Must have at least one node");
		}
		ArrayList<NodeInfo> niList = new ArrayList<NodeInfo>(nis);
		size = niList.size();
		if (niList.size() == 1) {
			NodeInfo ni = niList.get(0);
			ris = new RangeInfo[] { new RangeInfo(ni.id, new IdRange(ni.id, ni.id), ni.pastryAddress, ni.qpAddress) };
		} else {
			Collections.sort(niList);
			ris = new RangeInfo[niList.size()];
			Id lower = niList.get(niList.size() - 1).id.findHalfway(niList.get(0).id);
			for (int i = 0; i < size; ++i) {
				NodeInfo ni = niList.get(i);
				Id nextId = niList.get(i == size - 1 ? 0 : i + 1).id;
				Id upper = ni.id.findHalfway(nextId);
				ris[i] = new RangeInfo(ni.id, new IdRange(lower,upper), ni.pastryAddress, ni.qpAddress);
				lower = upper;
			}
		}

		Map<InetSocketAddress,InetSocketAddress> participants = new HashMap<InetSocketAddress,InetSocketAddress>(nis.size());
		for (NodeInfo ni : nis) {
			participants.put(ni.qpAddress, ni.pastryAddress);
		}
		this.getPastryAddress = Collections.unmodifiableMap(participants);
	}
	
	private Router(RangeInfo[] ris) {
		this.ris = ris;
		size = ris.length;
		
		Map<InetSocketAddress,InetSocketAddress> participants = new HashMap<InetSocketAddress,InetSocketAddress>(size);
		for (RangeInfo ri : ris) {
			participants.put(ri.qpAddress, ri.pastryAddress);
		}
		this.getPastryAddress = Collections.unmodifiableMap(participants);
	}

	IdRange getOwnedRange(InetSocketAddress isa) {
		for (RangeInfo ri : ris) {
			if (ri.pastryAddress.equals(isa) || ri.qpAddress.equals(isa)) {
				return ri.idRange;
			}
		}
		return null;
	}
	
	private int getRangeInfoIndex(Id id) {
		int min = 0, max = size - 1;

		while (max - min > 1) {
			int half = (min + max) / 2;
			RangeInfo pivot = ris[half];
			if (pivot.idRange.contains(id)) {
				max = half;
				min = half;
			} else if (id.compareTo(pivot.id) < 0) {
				max = half - 1;
				if (max < min) {
					max = min;
				}
			} else {
				min = half + 1;
				if (min > max) {
					min = max;
				}
			}
		}

		if (ris[min].idRange.contains(id)) {
			return min;
		}
		if (min == 0) {
			if (ris[size - 1].idRange.contains(id)) {
				return size - 1;
			}
		}
		if (min == size - 1) {
			if (ris[0].idRange.contains(id)) {
				return 0;
			}
		}
		if (min != max) {
			if (ris[max].idRange.contains(id)) {
				return max;
			}

			if (max == size - 1) {
				if (ris[0].idRange.contains(id)) {
					return 0;
				}
			}
		}

		throw new IllegalStateException("Couldn't find node for " + id + ", known ranges are " + ris);
	}
	
	InetSocketAddress getDest(Id id) {
		return ris[getRangeInfoIndex(id)].qpAddress;
	}
	
	InetSocketAddress[] getDests(Id id, int numNodes) {
		if (numNodes % 2 != 1) {
			throw new IllegalArgumentException("numNodes must be odd");
		}
		if (numNodes >= size) {
			InetSocketAddress retval[] = new InetSocketAddress[size];
			return getPastryAddress.keySet().toArray(retval);
		}
		InetSocketAddress[] retval = new InetSocketAddress[numNodes];
		final int onEachSide = numNodes / 2;
		final int pos = getRangeInfoIndex(id);
		int index = 0;
		retval[index++] = ris[pos].qpAddress;
		for (int i = 1; i <= onEachSide; ++i) {
			int left = pos + i;
			if (left > size) {
				left -= size;
			}
			int right = pos - i;
			if (right < 0) {
				right += size;
			}
			retval[index++] = ris[left].qpAddress;
			retval[index++] = ris[right].qpAddress;
		}
		return retval;
	}

	Set<InetSocketAddress> getParticipants() {
		return getPastryAddress.keySet();
	}

	InetSocketAddress getPastryAddress(InetSocketAddress qpAddress) {
		return getPastryAddress.get(qpAddress);
	}
	
	Map<InetSocketAddress,InetSocketAddress> getPastryAddressMap() {
		return getPastryAddress;
	}

	Collection<InetSocketAddress> getPastryAddresses() {
		return getPastryAddress.values();
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		boolean first = true;
		for (RangeInfo ri : ris) {
			if (first) {
				first = false;
			} else {
				sb.append("\n");
			}
			sb.append(ri);
		}
		return sb.toString();
	}

	public int size() {
		return size;
	}
	
	public void serialize(OutputBuffer buf) {
		buf.writeInt(size);
		for (RangeInfo ri : ris) {
			ri.serialize(buf);
		}
	}
	
	public static Router deserialize(InputBuffer buf) {
		int size = buf.readInt();
		RangeInfo[] ris = new RangeInfo[size];
		for (int i = 0; i < size; ++i) {
			ris[i] = RangeInfo.deserialize(buf);
		}
		return new Router(ris);
	}
	
	Router getRouterWithout(Set<InetSocketAddress> failedNodes) {
		List<NodeInfo> nis = new ArrayList<NodeInfo>(ris.length);
		for (RangeInfo ri : ris) {
			if (! failedNodes.contains(ri.qpAddress)) {
				nis.add(ri.getNodeInfo());
			}
		}
		return new Router(nis);
	}
}

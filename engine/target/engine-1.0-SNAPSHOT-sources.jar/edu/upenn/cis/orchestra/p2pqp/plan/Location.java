package edu.upenn.cis.orchestra.p2pqp.plan;

import java.io.Serializable;

public abstract class Location implements Serializable {
	public abstract boolean equals(Object o);
	
	public boolean isCentralized() {
		return false;
	}
	
	public boolean isDistributed() {
		return false;
	}
	
	public boolean isNamed() {
		return false;
	}
	
	public String getName() {
		throw new IllegalStateException("Can only get the name of a named location");
	}
}

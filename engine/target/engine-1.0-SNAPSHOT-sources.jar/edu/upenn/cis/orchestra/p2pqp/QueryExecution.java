package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.p2pqp.IndexService.EpochNum;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.p2pqp.messages.BeginNewQueryPhase;
import edu.upenn.cis.orchestra.p2pqp.messages.BlockingOperatorsCanExecute;
import edu.upenn.cis.orchestra.p2pqp.messages.JoinInputHasFinished;
import edu.upenn.cis.orchestra.p2pqp.messages.QueryExecutionMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.RehashTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyFailure;
import edu.upenn.cis.orchestra.p2pqp.messages.ScanTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.ShippedTuplesMessage;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;
import edu.upenn.cis.orchestra.util.Pair;
import edu.upenn.cis.orchestra.util.Ranges;

public class QueryExecution<M> implements QpSchema.Source {
	public static boolean multipleScanThreads = true;
	public static int scanThreadPriority = Thread.NORM_PRIORITY;
	public static int blockSize = 5000;
	public static final int defaultSendDelayMs = 300;
	public static final int defaultStatusIntervalMs = 5000;
	public static final int defaultMemoryCheckIntervalMs = 2000;
	public static final float availMemoryFracCutoff = 0.3f;
	public final int queryId;
	private final Map<Integer,Operator<M>> operators;
	private final List<ShipOperator<?>> shipOperators;
	private final Map<Integer,OperatorAndDest> destOperators;
	public final QpApplication<M> app;
	public final int epoch;

	public final InetSocketAddress owner;

	private final RecordTuples rt;
	private final List<Thread> startedThreads = Collections.synchronizedList(new ArrayList<Thread>());

	private Set<Integer> finishedBlockingOperators;

	private final Collection<QpTuple<M>> tupleDest;

	private final Map<Integer,QpSchema> schemas;
	private final Map<String,QpSchema> schemasByName;

	private final Logger logger = Logger.getLogger(this.getClass());
	private final boolean isDistributed;
	private final String namedExec;

	private final boolean attemptRecovery;

	private final Set<InetSocketAddress> failedNodes = Collections.synchronizedSet(new HashSet<InetSocketAddress>()); 

	private final Map<Integer,Collection<EpochNum>> distributedScanPages;
	
	public String toString() {
		String start = "QueryExecution("+queryId +",";
		if (isDistributed) {
			return start + "distributed)";
		} else if (namedExec != null) {
			return start + namedExec + ")";
		} else {
			return start + "centralized)";
		}
	}

	private final List<Router> routers = new ArrayList<Router>();

	QueryExecution(Router queryRouter, Map<Integer,Collection<EpochNum>> distributedScanPages, int epoch, int queryId, Collection<QpSchema> schemas, QpApplication<M> app, InetSocketAddress queryOwner, String locName, boolean attemptRecovery) {
		this(queryRouter, distributedScanPages, epoch,queryId,schemas,app,new RecordTuplesRemote(app, defaultSendDelayMs, queryOwner, queryId), queryOwner, null, false, locName, attemptRecovery);
	}

	QueryExecution(Router queryRouter, Map<Integer,Collection<EpochNum>> distributedScanPages, int epoch, int queryId, Collection<QpSchema> schemas, QpApplication<M> app, InetSocketAddress queryOwner, boolean isDistributed, boolean attemptRecovery) {
		this(queryRouter, distributedScanPages, epoch,queryId,schemas,app,new RecordTuplesRemote(app, defaultSendDelayMs, queryOwner, queryId), queryOwner, null, isDistributed, null, attemptRecovery);
	}

	QueryExecution(Router queryRouter, Map<Integer,Collection<EpochNum>> distributedScanPages, int epoch, int queryId, Collection<QpSchema> schemas, QpApplication<M> app, QueryCoordinator rt, Collection<QpTuple<M>> tupleDest, boolean attemptRecovery) {
		this(queryRouter, distributedScanPages, epoch,queryId,schemas,app,rt, null, tupleDest, false, null, attemptRecovery);
	}

	private QueryExecution(Router queryRouter, Map<Integer,Collection<EpochNum>> distributedScanPages, int epoch, int queryId, Collection<QpSchema> schemas, QpApplication<M> app, RecordTuples rt, InetSocketAddress owner, Collection<QpTuple<M>> tupleDest, boolean isDistributed, String namedExec, boolean attemptRecovery) {
		routers.add(queryRouter);
		this.isDistributed = isDistributed;
		this.namedExec = namedExec;
		this.epoch = epoch;
		this.queryId = queryId;
		this.owner = owner;
		this.app = app;
		this.distributedScanPages = distributedScanPages;

		this.tupleDest = tupleDest;

		operators = new HashMap<Integer,Operator<M>>();
		shipOperators = new ArrayList<ShipOperator<?>>();
		destOperators = new HashMap<Integer,OperatorAndDest>();

		this.rt = rt;

		finishedBlockingOperators = new HashSet<Integer>();

		this.schemas = new HashMap<Integer,QpSchema>(schemas.size());
		this.schemasByName = new HashMap<String,QpSchema>(schemas.size());
		for (QpSchema s : schemas) {
			this.schemas.put(s.relId, s);
			this.schemasByName.put(s.getName(), s);
		}

		this.attemptRecovery = attemptRecovery;
	}

	void close() throws InterruptedException {
		for (Thread t : startedThreads) {
			t.interrupt();
			t.join();
		}
		logger.info("Closed all started threads for " + toString());
		for (Operator<?> o : operators.values()) {
			o.close();
		}
		logger.info("Closed all operators for " + toString());
		rt.close();
		logger.info("Closed RecordTuples for " + toString());
	}

	void start() {
		Thread t = new Thread(app.tg, QueryExecution.this + " Status Thread") {
			public void run() {
				while (! isInterrupted()) {
					try {
						Thread.sleep(defaultStatusIntervalMs);
					} catch (InterruptedException ie) {
						return;
					}
					if (logger.isInfoEnabled()) {
						if (rt instanceof RecordTuplesRemote) {
							RecordTuplesRemote rtr = (RecordTuplesRemote) rt;
							int outstanding = rtr.getOutstandingMessages();
							int sent = rtr.getSentMessages();
							StringBuilder msg = new StringBuilder("RecordTuplesRemote for " + queryId + (namedExec != null ? "(" + namedExec + ")" : "") + " at " + app.localAddr + " has sent " + sent + " messages");
							if (outstanding > 0) {
								msg.append(" and has " + outstanding + " outstanding messages");
							}
							logger.info(msg.toString());
						} else if (rt instanceof QueryCoordinator) {
							QueryCoordinator rtl = (QueryCoordinator) rt;
							logger.info("RecordTuplesMessages received by owner: " + rtl.getMessagesReceived());
						}
						int shippedMessages = 0;
						for (ShipOperator<?> so : shipOperators) {
							shippedMessages += so.getOutstandingMessages();
						}
						if (shippedMessages > 0) {
							logger.info("Ship operators for " + queryId + (namedExec != null ? "(" + namedExec + ")" : "") + " have " +
									shippedMessages + " outstanding messages");
						}
					}
				}
			}
		};

		t.start();
		startedThreads.add(t);

		t = new Thread(app.tg, QueryExecution.this + " Purge Thread") {
			final Set<JoinOperator> ops;
			{
				ops = new HashSet<JoinOperator>();
				for (Operator<?> op : operators.values()) {
					if (op instanceof JoinOperator) {
						ops.add((JoinOperator) op);
					}
				}
			}
			public void run() {
				final Runtime runtime = Runtime.getRuntime();
				while (! isInterrupted()) {
					try {
						sleep(defaultMemoryCheckIntervalMs);
					} catch (InterruptedException ie) {
						return;
					}
					long maxMemory = runtime.maxMemory();  
					long allocatedMemory = runtime.totalMemory();  
					long freeMemory = runtime.freeMemory();  
					float availMemoryFrac = (freeMemory + maxMemory - allocatedMemory) / ((float) maxMemory);
					boolean tryHard = availMemoryFrac < availMemoryFracCutoff;
					logger.info("Available memory fraction is " + availMemoryFrac);
					// Try to scavenge memory from purgeable join operators
					Iterator<JoinOperator> it = ops.iterator();
					while (it.hasNext()) {
						JoinOperator op = it.next();
						boolean didPurge = op.doPurge(tryHard, (! attemptRecovery));
						if (didPurge) {
							logger.info("Purged operator " + ((Operator<?>) op).operatorId + (attemptRecovery ? " non-destructively" : ""));
							tryHard = false;
						}
						if ((! attemptRecovery) && (! op.willBeAbleToPurgeAgain())) {
							it.remove();
						}
					}
					if (ops.isEmpty()) {
						// Won't be able to do any more purging
						return;
					}
				}
			}
		};

		t.start();		
		startedThreads.add(t);

		startScans(0);
	}

	private ScanTuplesThread stt = null;

	private void startScans(int phaseNo) {
		List<PullScanOperator<M>> pullScanOperators = new ArrayList<PullScanOperator<M>>();
		for (Operator<M> o : operators.values()) {
			if (o instanceof PullScanOperator) {
				pullScanOperators.add((PullScanOperator<M>) o);
			}
		}
		if (multipleScanThreads) {
			for (PullScanOperator<M> o : pullScanOperators) {
				ScanTuplesThread stt = new ScanTuplesThread(Collections.singleton(o), Integer.toString(o.operatorId), phaseNo, false);
				stt.start();
				stt.setPriority(scanThreadPriority);
				startedThreads.add(stt);
			}
		} else {
			synchronized (this) {
				if (stt == null) {
					stt = new ScanTuplesThread(pullScanOperators, "all", phaseNo, true);
					stt.start();
					stt.setPriority(scanThreadPriority);
					startedThreads.add(stt);
				} else {
					stt.addScans(pullScanOperators, phaseNo);
				}
			}
		}
	}

	private class ScanTuplesThread extends Thread {
		private final Queue<Pair<PullScanOperator<M>,Integer>> toScan;
		private volatile int phaseNo;
		private volatile PullScanOperator<M> currScan;
		private final boolean waitForMore;
		private volatile boolean interruptable = true;
		private volatile boolean interrupted = false;
		ScanTuplesThread(Collection<PullScanOperator<M>> toScan, String opIds, int phaseNo, boolean waitForMore) {
			super(app.tg, QueryExecution.this + " ScanTuplesThread " + opIds + " Phase " + phaseNo);
			this.toScan = new ArrayDeque<Pair<PullScanOperator<M>,Integer>>(toScan.size());
			this.phaseNo = phaseNo;
			this.waitForMore = waitForMore;
			addScans(toScan, phaseNo);
		}

		void addScans(Collection<PullScanOperator<M>> toScan, int phaseNo) {
			synchronized (this.toScan) {
				for (PullScanOperator<M> o : toScan) {
					this.toScan.add(new Pair<PullScanOperator<M>,Integer>(o,phaseNo));
				}
				this.toScan.notify();
			}
		}

		public boolean isInterrupted() {
			return interrupted;
		}
		
		public void run() {
			try {
				for ( ; ; ) {
					if (isInterrupted()) {
						return;
					}
					Pair<PullScanOperator<M>,Integer> o;
					synchronized (toScan) {
						o = toScan.poll();
						if (o == null && (! waitForMore)) {
							return;
						} else if (waitForMore) {
							while (o == null) {
								toScan.wait();
								o = toScan.poll();
							}
						}
					}
					try {
						if (o.getSecond() != 0 && (! o.getFirst().canRescan())) {
							// TODO: deal with this in a more elegant way
							continue;
						}
						phaseNo = o.getSecond();
						currScan = o.getFirst();
						if (logger.isInfoEnabled()) {
							if (isDistributed) {
								logger.info("PullScanOperator " + currScan.operatorId + " at " + app.localAddr + " is starting for phase " + phaseNo);
							} else {
								logger.info("PullScanOperator " + currScan.operatorId + " at central node is starting for phase " + phaseNo);
							}
						}
						interruptable = false;
						currScan.scanAll(blockSize, phaseNo);
						interruptable = true;
						rt.operatorHasFinished(currScan.operatorId, isDistributed ? app.localAddr : null);
						if (logger.isInfoEnabled()) {
							if (isDistributed) {
								logger.info("PullScanOperator " + currScan.operatorId + " at " + app.localAddr + " has finished for phase " + phaseNo);
							} else {
								logger.info("PullScanOperator " + currScan.operatorId + " at central node has finished for phase " + phaseNo);
							}
						}
						currScan.close();
						currScan = null;
					} catch (Exception e) {
						rt.reportException(e);
					}
				}
			} catch (InterruptedException ie) {
				return;
			}
		}

		public void interrupt() {
			if (interruptable) {
				super.interrupt();
			}
			interrupted = true;
			PullScanOperator<M> currScan = this.currScan;
			if (currScan != null) {
				currScan.interrupt(phaseNo);
				currScan.close();
			}
		}
	}

	public void addOperator(Operator<M> o) {
		operators.put(o.operatorId, o);
		if (o instanceof ShipOperator) {
			shipOperators.add((ShipOperator<?>) o);
		}
	}


	public void setDestOperator(Operator<M> o, WhichChild d, String schema) {
		QpSchema schemaObj = schemasByName.get(schema);
		if (schemaObj == null) {
			throw new IllegalArgumentException("Schema " + schema + " is not known for query " + queryId);
		}
		OperatorAndDest oad =  new OperatorAndDest(o,d);
		destOperators.put(schemaObj.relId, oad);
	}

	private class OperatorAndDest {
		final Operator<M> o;
		final WhichChild d;

		OperatorAndDest(Operator<M> o, WhichChild d) {
			this.o = o;
			this.d = d;
		}

		public boolean equals(Object obj) {
			if (obj == null || obj.getClass() != OperatorAndDest.class) {
				return false;
			}
			OperatorAndDest oad = (OperatorAndDest) obj;
			return (o == oad.o && d == oad.d);
		}

		public int hashCode() {
			return o.hashCode() + 37 * d.hashCode();
		}
	}

	public RecordTuples getRecordTuples() {
		return rt;
	}

	public QpSchema getSchema(int relationId) {
		QpSchema s = schemas.get(relationId);
		if (s == null) {
			throw new IllegalArgumentException("Relation with ID " + relationId + " is not known for query " + queryId);
		}
		return s;
	}

	public QpSchema getSchema(String name) {
		QpSchema s = schemasByName.get(name);
		if (s == null) {
			throw new IllegalArgumentException("Relation " + name + " is not known for query " + queryId);
		}
		return s;
	}

	public DHTService<M> getDHT() {
		return app.dht;
	}

	public TupleStore<M> getLocalStore() {
		return app.store;
	}


	void process(ShippedTuplesMessage m) throws IOException, InterruptedException {
		if (m.queryId != queryId) {
			throw new IllegalArgumentException("Message query ID (" + m.queryId + ") does not match expected query id (" + queryId + ")");			
		}
		if (failedNodes.contains(m.getOrigin())) {
			return;
		}
		List<QpTuple<M>> tuples = m.getTuples(this,app.mdf); 
		addTuples(tuples);
		app.sendReplySuccess(m);
		if (logger.isDebugEnabled()) {
			Map<Pair<InetSocketAddress,Integer>,Ranges> ranges = new HashMap<Pair<InetSocketAddress,Integer>,Ranges>();
			for (QpTuple<M> t : tuples) {
				ExecutionId tid = t.getId();
				Pair<InetSocketAddress,Integer> p = new Pair<InetSocketAddress,Integer>(tid.nodeId, tid.operatorId);
				Ranges r = ranges.get(p);
				if (r == null) {
					r = new Ranges();
					r.add(tid.tupleCount);
					ranges.put(p, r);
				} else {
					r.add(tid.tupleCount);
				}
			}
			logger.debug("ShippedTuplesMessage " + m.messageId + " from " + m.getOrigin() + " contains tuples " + ranges);
		}
	}


	void process(QueryExecutionMessage qem) {
		if (qem.getQueryId() != queryId) {
			throw new IllegalArgumentException("Message query ID (" + qem.getQueryId() + ") does not match expected query id (" + queryId + ")");
		}
		try {
			Message m = (Message) qem;
			if (failedNodes.contains(m.getOrigin())) {
				return;
			}
			if (qem instanceof RehashTuplesMessage) {
				RehashTuplesMessage rtm = (RehashTuplesMessage) qem;
				List<QpTuple<M>> ts = rtm.getData(this, app.mdf);
			    if (!rtm.getDestId().equals(this.app.getNodeId())) {
			    	Statistics.totalShippingMessages += rtm.getDataLength();
			    	Statistics.totalShippingTupleNum += ts.size();
			    }
				addTuples(ts);
				app.sendReplySuccess(rtm);
			} else if (qem instanceof BlockingOperatorsCanExecute) {
				for (int operatorId : ((BlockingOperatorsCanExecute) qem).operatorIds) {
					finishOperator(operatorId);
				}
			} else if (qem instanceof ScanTuplesMessage) {
				ScanTuplesMessage stm = (ScanTuplesMessage) qem;
				Operator<M> o = operators.get(stm.operatorId);
				if (o == null) {
					logger.error("Don't have operator " + stm.operatorId + " for query " + stm.getQueryId());
					app.sendMessage(new ReplyFailure(stm, "Don't have operator " + stm.operatorId + " for query " + stm.getQueryId(), false));
					return;
				}
				KeyReceiver kr = (KeyReceiver) o;
				List<ByteArrayWrapper> keys = stm.getData();
				kr.receiveKeys(stm.keySetNo, stm.getEpochNum(), keys);
				app.sendReplySuccess(stm);
				// TODO: Restore FixpointMessage class
			/*
			} else if (qem instanceof FixpointMessage) {
				FixpointMessage frm = (FixpointMessage) qem;
				Operator<M> o = operators.get(frm.operatorId);
				if (o == null) {
					app.sendMessage(new ReplyFailure(frm, "Don't have operator " + frm.operatorId + " for query " + frm.getQueryId(), false));
					return;
				}
				FixpointReceiverOperator<M> fro = (FixpointReceiverOperator<M>) o;
				List<QpTuple<M>> keys = frm.getData(fro.schema, this, app.mdf);
				fro.receiver(keys);
				app.sendReplySuccess(frm);
				*/
			} else if (qem instanceof JoinInputHasFinished) {
				JoinInputHasFinished jihf = (JoinInputHasFinished) qem;
				try {
					for (int op : jihf.leftOps) {
						Operator<?> purgeOp = operators.get(op);
						if (purgeOp != null) {
							((JoinOperator) purgeOp).inputHasFinished(true);
						}
					}
					for (int op : jihf.rightOps) {
						Operator<?> purgeOp = operators.get(op);
						if (purgeOp != null) {
							((JoinOperator) purgeOp).inputHasFinished(false);
						}
					}
					app.sendReplySuccess(jihf);
				} catch (Exception e) {
					rt.reportException(e);
				}
			} else {
				logger.error("QueryExecution does not know what to do with message " + qem);
			}
		} catch (Exception e) {
			rt.reportException(e);
		}
	}

	/**
	 * Add some tuples to be processed by this query execution. They must all have the
	 * same schema
	 * 
	 * @param ts			The tuples to be processed, which all have the same schema.
	 */
	void addTuples(List<QpTuple<M>> ts) {
		if (ts.isEmpty()) {
			return;
		}
		OperatorAndDest oad = null;
		for (QpTuple<M> t : ts) {
			oad = destOperators.get(t.getSchema().relId);
			if (oad == null) {
				logger.error("Couldn't find " + (this.owner == null ? "centralized" : "distributed") + " operator for tuple from relation "+ t.getRelationName());
				return;
			}
			break;
		}

		final WhichChild d = oad.d;
		for (QpTuple<?> t : ts) {
			t.setDest(d);
		}

		try {
			oad.o.receiveTuples(ts);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public InetSocketAddress getNamedNode(String nodeName) {
		return app.getNamedNodehandle(nodeName);
	}

	public Collection<QpTuple<M>> getTupleDest() {
		return this.tupleDest;
	}

	boolean hasOperator(Integer operator) {
		return operators.containsKey(operator);
	}

	void finishOperator(int operator) {
		synchronized (finishedBlockingOperators) {
			if (! finishedBlockingOperators.add(operator)) {
				// Operator already finished
				return;
			}
		}
		long startTime = 0;
		if (logger.isInfoEnabled()) {
			startTime = System.currentTimeMillis();
			logger.info("Finishing operator " + operator + " at " + app.localAddr);
		}
		BlockingOperator<?> bo = (BlockingOperator<?>) operators.get(operator);
		try {
			bo.finish(blockSize);
			rt.operatorHasFinished(operator, app.localAddr);
		} catch (Exception e) {
			rt.reportException(e);
		}
		if (logger.isInfoEnabled()) {
			long endTime = System.currentTimeMillis();
			logger.info("Finished operator " + operator + " at " + app.localAddr + ", took " + (endTime - startTime) + " ms");
		}
	}

	void joinInputHasFinished(int operator, boolean left) {
		try {
			JoinOperator jo = (JoinOperator) operators.get(operator);
			jo.inputHasFinished(left);
		} catch (Exception e) {
			rt.reportException(e);
		}
	}

	public InetSocketAddress getNodeAddress() {
		return app.localAddr;
	}

	public Set<InetSocketAddress> getFailedNodes() {
		synchronized (failedNodes) {
			if (failedNodes.isEmpty()) {
				return Collections.emptySet();
			} else {
				return Collections.unmodifiableSet(failedNodes);
			}
		}
	}

	void beginNewQueryPhase(BeginNewQueryPhase bnqp) {
		if (bnqp.queryId != queryId) {
			throw new IllegalArgumentException("Incorrect query ID");
		}
		if (! attemptRecovery) {
			try {
				app.sendMessage(new ReplyFailure(bnqp, "Query " + bnqp.queryId + " does not support recovery",false));
			} catch (Exception e) {
				logger.error(e);
			}
		}
		logger.info(this.toString() + " at " + app.localAddr + " is beginning query phase " + bnqp.phaseNo);
		addRouter(bnqp.phaseNo, bnqp.router);

		failedNodes.addAll(bnqp.newlyFailedNodes);

		byte[][] failedNodeIds = new byte[bnqp.newlyFailedNodes.size()][];
		int pos = 0;
		for (InetSocketAddress node : bnqp.newlyFailedNodes) {
			failedNodeIds[pos] = ExecutionId.getNodeIdBytes(node);
		}

		for (Operator<M> o : operators.values()) {
			o.disposeOfFailedTuples(bnqp.phaseNo, failedNodeIds);
			if (o instanceof JoinOperator) {
				((JoinOperator) o).inputsHaveNotFinished();
			}
		}

		for (Map.Entry<Integer, int[]> me : bnqp.joinOperatorsToResend.entrySet()) {
			Operator<M> o = operators.get(me.getKey());
			if (o == null) {
				continue;
			}
			JoinOperator jo = (JoinOperator) o;
			int[] hashCols = me.getValue();
			if (hashCols == null) {
				jo.resendGeneratedTuples(bnqp.phaseNo);
			} else {
				jo.resendGeneratedTuples(bnqp.phaseNo, me.getValue(), bnqp.previousPhaseFailedRanges);
			}
		}

		startScans(bnqp.phaseNo);
	}

	private void addRouter(int phaseNo, Router router) {
		if (router == null) {
			throw new NullPointerException();
		}
		synchronized (routers) {
			while (routers.size() <= phaseNo) {
				routers.add(null);
			}
			routers.set(phaseNo, router);
		}
	}

	Router getRouter(int phaseNo) {
		synchronized (routers) {
			if (routers.size() <= phaseNo) {
				return null;
			}
			return routers.get(phaseNo);
		}
	}

	Router getMostRecentRouter() {
		synchronized (routers) {
			return routers.get(routers.size() - 1);
		}
	}

	Router[] getRouters() {
		synchronized (routers) {
			Router[] retval = new Router[routers.size()];
			return routers.toArray(retval);
		}
	}

	public Collection<EpochNum> getDistributedScanPages(int operatorId) {
		Collection<EpochNum> retval = distributedScanPages.get(operatorId);
		if (retval == null) {
			throw new IllegalArgumentException("Don't have pages for distributed scan " + operatorId);
		}
		return retval;
	}
}
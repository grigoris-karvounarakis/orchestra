package edu.upenn.cis.orchestra.p2pqp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.datamodel.AbstractTuple;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;
import edu.upenn.cis.orchestra.datamodel.AbstractImmutableTuple.FieldSource;

public class TupleList implements TupleSetFilter {
	private QpSchema relation;
	private int[] columns;
	private int[] retainCols;

	private Set<QpTuple<?>> members;

	TupleList(QpSchema relation, int[] columns) {
		this.relation = relation;
		this.columns = new int[columns.length];
		System.arraycopy(columns, 0, this.columns, 0, columns.length);
		members = new HashSet<QpTuple<?>>();
		retainCols = new int[columns.length];
		System.arraycopy(columns, 0, retainCols, 0, retainCols.length);
		Arrays.sort(retainCols);
	}

	private static int[] toArray(List<Integer> columns) {
		int[] newCols = new int[columns.size()];
		for (int i = 0; i < newCols.length; ++i) {
			newCols[i] = columns.get(i);
		}
		return newCols;
	}

	public void changeRelation(QpSchema relation, int[] columns) throws ValueMismatchException {
		if (columns.length != this.columns.length) {
			throw new IllegalArgumentException("New list of columns must be the same size as old list of columns");
		}
		this.relation = relation;

		Set<QpTuple<?>> newMembers = new HashSet<QpTuple<?>>(members.size());

		// Copy relevant fields from old tuple
		FieldSource[] fss = new FieldSource[relation.getNumCols()];
		Object[] one = new Object[] { null };
		for (int i = 0; i < this.columns.length; ++i) {
			fss[columns[i]] = new FieldSource(this.columns[i], true);
		}
		// Copy other fields from array holding one null value;
		FieldSource fsNull = new FieldSource(0, false);
		for (int i = 0; i < fss.length; ++i) {
			if (fss[i] == null) {
				fss[i] = fsNull;
			}
		}
		
		// Switch tuples to new schema
		for (QpTuple<?> t : members) {
			QpTuple<?> newT = new QpTuple<Null>(relation, fss, t, null, one);
			newMembers.add(newT);
		}
		
		members = newMembers;
		
		System.arraycopy(columns, 0, this.columns, 0, columns.length);
		retainCols = new int[columns.length];
		System.arraycopy(columns, 0, retainCols, 0, retainCols.length);
		Arrays.sort(retainCols);
		
	}

	public void add(QpTuple<?> t) {
		if (t.getSchema() != relation) {
			throw new IllegalArgumentException("Can only add tuples from relation " + relation.getName());
		}
		members.add(new QpTuple<Null>(t, false, retainCols, t.getEpoch(), null, null));
	}

	byte[] getBytes() {
		ByteBufferWriter bbw = new ByteBufferWriter();
		getBytes(bbw);
		return bbw.getByteArray();
	}

	void getBytes(ByteBufferWriter bbw) {
		bbw.addToBuffer(relation.relId);
		bbw.addToBuffer(columns.length);
		for (int col : columns) {
			bbw.addToBuffer(col);
		}
		bbw.addToBuffer(members.size());
		for (QpTuple<?> subtuple : members) {
			bbw.addToBuffer(subtuple.getStoreBytes(null));
		}
	}

	TupleList(QpSchema ns, byte[] bytes, int offset, int length) {
		int pos = offset;
		int relId = IntType.getValFromBytes(bytes, pos, IntType.bytesPerInt);
		pos += IntType.bytesPerInt;
		if (relId != ns.relId) {
			throw new IllegalArgumentException("TupleList is for relation #" + relId + ", but supplied schema " + ns.getName() + " has id " + ns.relId);
		}
		relation = ns;
		int numCols = IntType.getValFromBytes(bytes, pos, IntType.bytesPerInt);
		pos += IntType.bytesPerInt;
		columns = new int[numCols];
		for (int colPos = 0; colPos < numCols; ++colPos) {
			columns[colPos] = IntType.getValFromBytes(bytes, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
		}
		int numTuples = IntType.getValFromBytes(bytes, pos, IntType.bytesPerInt);
		pos += IntType.bytesPerInt;
		members = new HashSet<QpTuple<?>>(numTuples);

		retainCols = new int[columns.length];
		System.arraycopy(columns, 0, retainCols, 0, retainCols.length);
		Arrays.sort(retainCols);

		while (numTuples > 0) {
			int tupleLen = IntType.getValFromBytes(bytes, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			QpTuple<?> t = QpTuple.fromBytes(SerializationMode.STORE, ns, null, null, bytes, pos, tupleLen, null);
			pos += tupleLen;
			members.add(t);
			--numTuples;
		}
		
		if (pos != (offset + length)) {
			throw new IllegalStateException("Incorrect position in byte array after decoding tuple list");
		}
	}

	public boolean eval(QpTuple<?> t) {
		if (t.getSchema() != relation) {
			throw new IllegalArgumentException("Can only evaluate tuples from relation " + relation.getName());
		}
		QpTuple<?> subtuple = new QpTuple<Null>(t, retainCols, t.getEpoch(), null, null);
		return members.contains(subtuple);
	}

	public Set<Integer> getColumns() {
		HashSet<Integer> retval = new HashSet<Integer>(columns.length);
		for (int col : columns) {
			retval.add(col);
		}
		return retval;
	}

	public QpSchema getRelation() {
		return relation;
	}

	public void serialize(Document d, Element e) {
		e.setAttribute("relationId", Integer.toString(relation.relId));
		Element colsEl = DomUtils.addChild(d, e, "columns");
		for (int col : columns) {
			Element colEl = DomUtils.addChild(d, colsEl, "col");
			colEl.setAttribute("pos", Integer.toString(col));
		}
		Element tuples = DomUtils.addChild(d, e, "tuples");
		for (QpTuple<?> subtuple : members) {
			Element tuple = DomUtils.addChild(d, tuples, "tuple");
			subtuple.serialize(d, tuple);
		}
	}

	public static TupleList deserialize(Element e, final QpSchema ns) throws XMLParseException {
		String relation = e.getAttribute("relationId");
		if (relation.length() == 0) {
			throw new XMLParseException("Missing relationId tag", e);
		}
		final int relationId;
		try {
			relationId = Integer.parseInt(relation);
		} catch (NumberFormatException nfe) {
			throw new XMLParseException("Error parsing relationId", nfe);
		}
		if (relationId != ns.relId) {
			throw new XMLParseException("RelationId tag does not match supplied schema", e);
		}
		List<Integer> columns = new ArrayList<Integer>();
		Element colsEl = DomUtils.getChildElementByName(e, "columns");
		if (colsEl == null) {
			throw new XMLParseException("Missing columns element", e);
		}
		for (Element colEl : DomUtils.getChildElementsByName(colsEl, "col")) {
			String col = colEl.getAttribute("pos");
			if (col.length() == 0) {
				throw new XMLParseException("Missing position attribute", colEl);
			}
			columns.add(Integer.parseInt(col));
		}
		TupleList retval = new TupleList(ns, toArray(columns));

		Element tuples = DomUtils.getChildElementByName(e, "tuples");
		if (tuples == null) {
			throw new XMLParseException("Missing tuple element", e);
		}
		AbstractTuple.TupleFactory<QpSchema,QpTuple<Null>> tf = new AbstractTuple.TupleFactory<QpSchema,QpTuple<Null>>() {
			public QpTuple<Null> createTuple(String relationName,
					Object... fields) throws ValueMismatchException {
				if (! relationName.equals(ns.getName())) {
					throw new IllegalArgumentException("Only know how to create tuples from relation " + ns.getName());
				}
				return new QpTuple<Null>(ns, false, -1, fields);
			}

			public QpSchema getSchema(String relationName) {
				if (! relationName.equals(ns.getName())) {
					throw new IllegalArgumentException("Only know how to create tuples from relation " + ns.getName());
				}
				return ns;
			}
		};
		for (Element tuple : DomUtils.getChildElementsByName(tuples, "tuple")) {
			QpTuple<Null> t = AbstractTuple.deserialize(tuple, tf);
			retval.add(t);
		}
		return retval;
	}

	public String toString() {
		return "TupleList(" + members + ")";
	}
}

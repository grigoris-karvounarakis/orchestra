package edu.upenn.cis.orchestra.p2pqp.messages;

import edu.upenn.cis.orchestra.p2pqp.Message;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;

public class ReplySendingFailed extends Message {
	private static final long serialVersionUID = 1L;

	public final long origMsgId;
	public final boolean canRetry;
	
	public ReplySendingFailed(QpMessage m) {
		this.origMsgId = m.messageId;
		canRetry = m.hasDestId();
	}

	public boolean isReply() {
		return true;
	}
	
	public long[] getOrigIds() {
		return new long[] {origMsgId};
	}
	
	protected boolean canRetry() {
		return canRetry;
	}
}

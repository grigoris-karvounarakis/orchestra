package edu.upenn.cis.orchestra.p2pqp.messages;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.EXECUTION;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.MetadataFactory;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpApplication;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class ShippedTuplesMessage extends QpMessage {
	private static final long serialVersionUID = 1L;
	private final int relId;
	private final byte[] data;
	public final String namedNodeDest;
	public final int queryId;

	public static <M> List<ShippedTuplesMessage> build(InetSocketAddress dest, String namedNodeDest, int queryId,
			Collection<QpTuple<M>> toShip, MetadataFactory<M> mdf) {

		List<ShippedTuplesMessage> retval = new ArrayList<ShippedTuplesMessage>();
		int overhead = 5000;
		ByteBufferWriter bbw = new ByteBufferWriter();

		boolean first = true;
		int relId = 0;
		
		for (QpTuple<M> t : toShip) {
			if (first) {
				relId = t.getSchema().relId;
				first = false;
			} else if (relId != t.getSchema().relId) {
				throw new IllegalArgumentException("Tuples must all be from the same schema");
			}
			byte[] bytes = t.getExecutionBytes(mdf);
			if (overhead + bbw.getCurrentLength() + bytes.length > QpApplication.MAX_MSG_SIZE) {
				retval.add(new ShippedTuplesMessage(dest, namedNodeDest, queryId, relId, bbw.getByteArray()));
				bbw.clear();
			}
			bbw.addToBuffer(bytes);
		}

		if (bbw.getCurrentLength() != 0) {
			retval.add(new ShippedTuplesMessage(dest, namedNodeDest, queryId, relId, bbw.getByteArray()));
		}

		return retval;
	}

	private ShippedTuplesMessage(InetSocketAddress dest, String namedNodeDest, int queryId, int relId, byte[] data) {
		super(dest);
		this.queryId = queryId;
		this.namedNodeDest = namedNodeDest;
		this.relId = relId;
		this.data = data;
	}

	public <M> List<QpTuple<M>> getTuples(QpSchema.Source schemas, MetadataFactory<M> mdf) {
		byte[] data = this.data;
		List<QpTuple<M>> retval = new ArrayList<QpTuple<M>>();
		int pos = 0;
		QpSchema schema = schemas.getSchema(relId);
		while (pos < data.length) {
			int tupleLen = IntType.getValFromBytes(data, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			retval.add(QpTuple.fromBytes(EXECUTION, schema, schemas, mdf, data, pos, tupleLen, null));
			pos += tupleLen;
		}
		return retval;
	}
	
	public long getDataLength() {
		return this.data.length;
	}

	public String toString() {
		return "ShippedTuplesMessage";
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(relId);
		buf.writeBytes(data);

		buf.writeString(namedNodeDest);
		buf.writeInt(queryId);
	}

	public ShippedTuplesMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		relId = buf.readInt();
		data = buf.readBytes();
		namedNodeDest = buf.readString();
		queryId = buf.readInt();
	}
}
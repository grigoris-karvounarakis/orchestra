package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.Filter;
import edu.upenn.cis.orchestra.p2pqp.FilterSerialization;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.ProbeJoin;
import edu.upenn.cis.orchestra.p2pqp.ProbeJoinFixedPoint;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class ProbeJoinNode extends OneInputQueryPlan {
	final String probeTable;
	final List<Integer> leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos;
	final boolean fixedPoint;
	final int maxTuplesForList;

	private final byte[] keyFilterBytes, fullFilterBytes;
	
	public ProbeJoinNode(QpSchema inputSchema, QpSchema outputSchema,
			QpSchema probeTable, List<Integer> leftJoinIndices,
			List<Integer> rightJoinIndices, List<Integer> leftOutputPos,
			List<Integer> rightOutputPos,
			Filter<? super QpTuple<?>> rhsKeyFilter, Filter<? super QpTuple<?>> rhsFullFilter,
			int maxTuplesForList,
			Location loc, int operatorId, QueryPlan input) {
		this(inputSchema, outputSchema, probeTable, leftJoinIndices, rightJoinIndices,
				leftOutputPos, rightOutputPos, rhsKeyFilter, rhsFullFilter,
				maxTuplesForList,
				false, loc, operatorId, input);
	}
	public ProbeJoinNode(QpSchema inputSchema, QpSchema outputSchema,
			QpSchema probeTable, List<Integer> leftJoinIndices,
			List<Integer> rightJoinIndices, List<Integer> leftOutputPos,
			List<Integer> rightOutputPos,
			Filter<? super QpTuple<?>> rhsKeyFilter, Filter<? super QpTuple<?>> rhsFullFilter, int maxTuplesForList,
			boolean fixedPoint,
			Location loc, int operatorId, QueryPlan input) {
		super(inputSchema.getRelationName(), outputSchema.getRelationName(), loc, operatorId, input);

		if (fixedPoint && (! outputSchema.getRelationName().equals(inputSchema.getRelationName()))) {
			throw new IllegalArgumentException("Must have same schema for input and output in a fixed point operator");
		}
		
		if (rhsKeyFilter != null && (! probeTable.getKeyColsSet().containsAll(rhsKeyFilter.getColumns()))) {
			throw new IllegalArgumentException("Right table key columns filter uses non-key column");
		}

		
		this.probeTable = probeTable.getRelationName();
		this.leftJoinIndices = new ArrayList<Integer>(leftJoinIndices);
		this.rightJoinIndices = new ArrayList<Integer>(rightJoinIndices);
		this.leftOutputPos = new ArrayList<Integer>(leftOutputPos);
		this.rightOutputPos = new ArrayList<Integer>(rightOutputPos);
		this.fixedPoint = fixedPoint;
		this.maxTuplesForList = maxTuplesForList;
		
		this.keyFilterBytes = FilterSerialization.getBytes(rhsKeyFilter, probeTable);
		this.fullFilterBytes = FilterSerialization.getBytes(rhsFullFilter, probeTable);

		TwoInputQueryPlan.checkJoinIndices(inputSchema, probeTable, outputSchema, leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos);
	}
	
	private static final long serialVersionUID = 1L;


	@Override
	<M> Operator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
	throws Operator.OperatorCreationException {
		QpSchema schema = exec.getSchema(probeTable);
		Filter<? super QpTuple<?>> keyFilter = FilterSerialization.fromBytes(schema, keyFilterBytes);
		Filter<? super QpTuple<?>> fullFilter = FilterSerialization.fromBytes(schema, fullFilterBytes);
		
		if (fixedPoint) {
			return new ProbeJoinFixedPoint<M>(exec.app, maxTuplesForList,
					exec.getSchema(outputSchema), exec.getSchema(probeTable), exec.epoch,
					keyFilter, fullFilter,
					leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos,
					parent, dest, exec.queryId, exec.getNodeAddress(), operatorId,
					exec.getRecordTuples());
		} else {
			return new ProbeJoin<M>(exec.app, maxTuplesForList, exec.getSchema(inputSchema),
					exec.getSchema(probeTable), exec.epoch,
					keyFilter,fullFilter,
					leftJoinIndices, rightJoinIndices,
					leftOutputPos, rightOutputPos, true, exec.getSchema(outputSchema),
					parent, dest, exec.queryId, exec.getNodeAddress(), operatorId,
					exec.getRecordTuples());
		}
	}
	@Override
	protected boolean subclassEquals(OneInputQueryPlan qp) {
		if (! (qp instanceof ProbeJoinNode)) {
			return false;
		}
		ProbeJoinNode pjn = (ProbeJoinNode) qp;
		return fixedPoint == pjn.fixedPoint &&
			probeTable.equals(pjn.probeTable) &&
			leftJoinIndices.equals(pjn.leftJoinIndices) &&
			rightJoinIndices.equals(pjn.rightJoinIndices) &&
			leftOutputPos.equals(pjn.leftOutputPos) &&
			rightOutputPos.equals(pjn.rightOutputPos);
	}
	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc, el, schemas);
		Element leftJoinEl = DomUtils.addChild(doc, el, "leftJoinIndices");
		writeList(doc, leftJoinEl, leftJoinIndices);
		Element rightJoinEl = DomUtils.addChild(doc, el, "rightJoinIndices");
		writeList(doc, rightJoinEl, rightJoinIndices);
		Element leftOutputEl = DomUtils.addChild(doc, el, "leftOutputPos");
		writeList(doc, leftOutputEl, leftOutputPos);
		Element rightOutputEl = DomUtils.addChild(doc, el, "rightOutputPos");
		writeList(doc, rightOutputEl, rightOutputPos);
		
		el.setAttribute("fixedPoint", Boolean.toString(fixedPoint));
		el.setAttribute("probeTable", probeTable);
		el.setAttribute("maxTuplesForList", Integer.toString(maxTuplesForList));
		
		QpSchema probeSchema = schemas.get(probeTable);
		
		if (keyFilterBytes != null) {
			Filter<? super QpTuple<?>> rhsKeyFilter = FilterSerialization.fromBytes(probeSchema, keyFilterBytes);
			Element filterEl = DomUtils.addChild(doc, el, "rightKeyFilter");
			FilterSerialization.serialize(doc, filterEl, rhsKeyFilter, probeSchema);
		}

		if (fullFilterBytes != null) {
			Filter<? super QpTuple<?>> rhsFullFilter = FilterSerialization.fromBytes(probeSchema, fullFilterBytes);
			Element filterEl = DomUtils.addChild(doc, el, "rightFullFilter");
			FilterSerialization.serialize(doc, filterEl, rhsFullFilter, probeSchema);
		}
	}
	
	private static void writeList(Document doc, Element parent, List<Integer> list) {
		for (Integer col : list) {
			Element colEl = DomUtils.addChild(doc, parent, "col");
			if (col != null && col != -1) {
				colEl.setAttribute("pos", Integer.toString(col));
			}
		}
	}
	
	public static ProbeJoinNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan input = getInputQueryPlan(el, schemas, alreadyIds);
		
		Element leftJoinEl = DomUtils.getChildElementByName(el, "leftJoinIndices");
		if (leftJoinEl == null) {
			throw new XMLParseException("Missing leftJoinIndices child", el);
		}
		List<Integer> leftJoinIndices = readList(leftJoinEl);
		
		Element rightJoinEl = DomUtils.getChildElementByName(el, "rightJoinIndices");
		if (rightJoinEl == null) {
			throw new XMLParseException("Missing rightJoinIndices child", el);
		}
		List<Integer> rightJoinIndices = readList(rightJoinEl);
		
		Element leftOutputEl = DomUtils.getChildElementByName(el, "leftOutputPos");
		if (leftOutputEl == null) {
			throw new XMLParseException("Missing leftOutputPos child", el);
		}
		List<Integer> leftOutputPos = readList(leftOutputEl);
		
		Element rightOutputEl = DomUtils.getChildElementByName(el, "rightOutputPos");
		if (rightOutputEl == null) {
			throw new XMLParseException("Missing rightOutputPos child", el);
		}
		List<Integer> rightOutputPos = readList(rightOutputEl);
		
		boolean fixedPoint = Boolean.parseBoolean(getAttribute(el, "fixedPoint"));
		String probeTable = getAttribute(el, "probeTable");
		int maxTuplesForList;
		try {
			maxTuplesForList = Integer.parseInt(getAttribute(el, "maxTuplesForList"));
		} catch (NumberFormatException nfe) {
			throw new XMLParseException("Badly formatted maxTuplesForList", nfe, el);
		}
		
		QpSchema probeSchema = schemas.get(probeTable);
		
		Element rightKeyFilterEl = DomUtils.getChildElementByName(el, "rightKeyFilter");
		Filter<? super QpTuple<?>> rightKeyFilter = null;
		if (rightKeyFilterEl != null) {
			rightKeyFilter = FilterSerialization.deserialize(rightKeyFilterEl, probeSchema);
		}
		
		Element rightFullFilterEl = DomUtils.getChildElementByName(el, "rightFullFilter");
		Filter<? super QpTuple<?>> rightFullFilter = null;
		if (rightFullFilterEl != null) {
			rightFullFilter = FilterSerialization.deserialize(rightFullFilterEl, probeSchema);
		}
		return new ProbeJoinNode(schemas.get(input.outputSchema), schemas.get(qpd.outputSchema), probeSchema,
				leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos,
				rightKeyFilter, rightFullFilter,
				maxTuplesForList, fixedPoint, qpd.loc, qpd.operatorId,
				input);
	}
	
	private static List<Integer> readList(Element parent) throws XMLParseException {
		List<Element> children = DomUtils.getChildElementsByName(parent, "col");
		List<Integer> retval = new ArrayList<Integer>(children.size());
		for (Element el : children) {
			String pos = el.getAttribute("pos");
			if (pos.length() == 0) {
				retval.add(null);
			} else {
				retval.add(Integer.parseInt(pos));
			}
		}
		return retval;
	}
}

package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.ProjectOperator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpSchema.Source;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class ProjectNode extends OneInputQueryPlan {
	private static final long serialVersionUID = 1L;
	private final Map<Integer,Integer> inverseSchemaMapping; 

	public ProjectNode(QpSchema inputSchema, Map<Integer,Integer> inverseSchemaMapping,
			QpSchema outputSchema, Location loc, int operatorId,
			QueryPlan input) {
		super(inputSchema.getRelationName(), outputSchema.getRelationName(), loc, operatorId, input);
		this.inverseSchemaMapping = inverseSchemaMapping;
	}

	@Override
	<M> ProjectOperator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) {
		return new ProjectOperator<M>(exec.getSchema(outputSchema), inverseSchemaMapping, parent, dest, operatorId, exec.app.getMetadataFactory(), exec.getRecordTuples());
	}

	@Override
	protected boolean subclassEquals(OneInputQueryPlan qp) {
		if (qp instanceof ProjectNode) {
			return true;
		}	else {
			return false;
		}
	}

	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc,el,schemas);
		if (inverseSchemaMapping != null) {
			Element mapping = DomUtils.addChild(doc, el, "mapping");
			for (Map.Entry<Integer, Integer> me : inverseSchemaMapping.entrySet()) {
				Element entry = DomUtils.addChild(doc, mapping, "entry");
				entry.setAttribute("outputPos", Integer.toString(me.getKey()));
				entry.setAttribute("inputPos", Integer.toString(me.getValue()));
			}
		}
	}

	public static ProjectNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan input = getInputQueryPlan(el, schemas, alreadyIds);
		QpSchema inputSchema = schemas.get(input.outputSchema);
		QpSchema outputSchema = schemas.get(qpd.outputSchema);
		Element mapping = DomUtils.getChildElementByName(el, "mapping");
		Map<Integer,Integer> inverseSchemaMapping = null;
		if (mapping != null) {
			List<Element> entries = DomUtils.getChildElementsByName(mapping, "entry");
			inverseSchemaMapping = new HashMap<Integer,Integer>(entries.size());
			for (Element entry : entries) {
				String inputPos = entry.getAttribute("inputPos");
				String outputPos = entry.getAttribute("outputPos");
				if (inputPos.length() == 0 || outputPos.length() == 0) {
					throw new XMLParseException("Each schema mapping entry must have an inputPos and an outputPos", entry);
				}
				try {
					int inputPosInt = Integer.parseInt(inputPos);
					int outputPosInt = Integer.parseInt(outputPos);
					inverseSchemaMapping.put(outputPosInt, inputPosInt);
				} catch (NumberFormatException nfe) {
					throw new XMLParseException(nfe, entry);
				}
			}
		}
		return new ProjectNode(inputSchema, inverseSchemaMapping, outputSchema, qpd.loc, qpd.operatorId, input);
	}

	void getRecoveryJoinOperators(Map<Integer, int[]> opsHashCols, List<Integer> hashCols, Source schemas, boolean prevStatfulOperatorIsAgg) {
		if (hashCols != null) {
			List<Integer> newHashCols = new ArrayList<Integer>(hashCols.size());
			for (Integer hashCol : hashCols) {
				Integer inputCol = inverseSchemaMapping.get(hashCol);
				if (inputCol == null) {
					throw new IllegalStateException("Missing entries from schema mapping");
				}
				newHashCols.add(inputCol);
			}
			hashCols = newHashCols;
		}
		input.getRecoveryJoinOperators(opsHashCols, hashCols, schemas, prevStatfulOperatorIsAgg);
	}
}
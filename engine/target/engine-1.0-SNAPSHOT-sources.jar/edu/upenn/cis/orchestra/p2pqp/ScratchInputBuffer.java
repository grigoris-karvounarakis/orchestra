package edu.upenn.cis.orchestra.p2pqp;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

public class ScratchInputBuffer extends InputBuffer {
	private DataInputStream dis;
	ScratchInputBuffer() {
	}
	
	public ScratchInputBuffer(byte[] data) {
		dis = new DataInputStream(new ByteArrayInputStream(data));
	}
	
	void reset(byte[] data) {
		dis = new DataInputStream(new ByteArrayInputStream(data));
	}

	@Override
	public
	boolean readBoolean() {
		try {
			return dis.readBoolean();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public
	byte[] readBytes(int length) {
		byte[] retval = new byte[length];
		try {
			dis.readFully(retval);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		
		return retval;
	}

	@Override
	public
	int readInt() {
		try {
			return dis.readInt();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public short readShort() {
		try {
			return dis.readShort();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public
	long readLong() {
		try {
			return dis.readLong();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	int remaining() {
		try {
			return dis.available();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}

package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.HashJoinFixedPoint;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.PipelinedHashJoin;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpSchema.Source;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class PipelinedJoinNode extends TwoInputQueryPlan {
	private static final long serialVersionUID = 1L;

	final List<Integer> leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos;
	final boolean fixedPoint;

	public PipelinedJoinNode(QpSchema outputSchema, List<Integer> leftJoinIndices,
			List<Integer> rightJoinIndices, List<Integer> leftOutputPos,
			List<Integer> rightOutputPos, Location loc,
			QueryPlan left, QueryPlan right, int operatorId) {
		this(outputSchema,leftJoinIndices,rightJoinIndices,leftOutputPos,
				rightOutputPos,loc,false,left,right,operatorId);
	}
	public PipelinedJoinNode(QpSchema outputSchema, List<Integer> leftJoinIndices,
			List<Integer> rightJoinIndices, List<Integer> leftOutputPos,
			List<Integer> rightOutputPos, Location loc, boolean fixedPoint,
			QueryPlan left, QueryPlan right, int operatorId) {
		super(outputSchema.getRelationName(), loc, left, right, operatorId);

		this.fixedPoint = fixedPoint;

		this.leftJoinIndices = new ArrayList<Integer>(leftJoinIndices);
		this.rightJoinIndices = new ArrayList<Integer>(rightJoinIndices);
		this.leftOutputPos = new ArrayList<Integer>(leftOutputPos);
		this.rightOutputPos = new ArrayList<Integer>(rightOutputPos);
	}

	@Override
	<M> Operator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
	throws Operator.OperatorCreationException {

		QpSchema outputSchema = exec.getSchema(this.outputSchema);
		
		if (fixedPoint) {
			return new HashJoinFixedPoint<M>(parent, dest, exec.queryId, exec.getNodeAddress(),
					operatorId, exec.getRecordTuples(), exec.app.getMetadataFactory(), outputSchema, exec.getSchema(right.outputSchema),
					leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos);
		} else {
			return new PipelinedHashJoin<M>(exec.getSchema(left.outputSchema), exec.getSchema(right.outputSchema),
					leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos,
					outputSchema, parent, dest, exec.queryId, exec.getNodeAddress(),
					operatorId, exec.getRecordTuples(), exec.app.getMetadataFactory(), allowRecovery);
		}
	}
	@Override
	protected boolean subclassEquals(TwoInputQueryPlan jqp) {
		if (jqp instanceof PipelinedJoinNode) {
			PipelinedJoinNode pjn = (PipelinedJoinNode) jqp;
			return fixedPoint == pjn.fixedPoint &&
				leftJoinIndices.equals(pjn.leftJoinIndices) &&
				rightJoinIndices.equals(pjn.rightJoinIndices) &&
				leftOutputPos.equals(pjn.leftOutputPos) &&
				rightOutputPos.equals(pjn.rightOutputPos);
		} else {
			return false;
		}
	}
	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc, el, schemas);
		Element leftJoinEl = DomUtils.addChild(doc, el, "leftJoinIndices");
		writeList(doc, leftJoinEl, leftJoinIndices);
		Element rightJoinEl = DomUtils.addChild(doc, el, "rightJoinIndices");
		writeList(doc, rightJoinEl, rightJoinIndices);
		Element leftOutputEl = DomUtils.addChild(doc, el, "leftOutputPos");
		writeList(doc, leftOutputEl, leftOutputPos);
		Element rightOutputEl = DomUtils.addChild(doc, el, "rightOutputPos");
		writeList(doc, rightOutputEl, rightOutputPos);
		
		if (fixedPoint) {
			el.setAttribute("fixedPoint", Boolean.toString(fixedPoint));
		}

	}

	private static void writeList(Document doc, Element parent, List<Integer> list) {
		for (Integer col : list) {
			Element colEl = DomUtils.addChild(doc, parent, "col");
			if (col != null && col != -1) {
				colEl.setAttribute("pos", Integer.toString(col));
			}
		}
	}
	
	public static PipelinedJoinNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan leftInput = getLeftInput(el, schemas, alreadyIds);
		QueryPlan rightInput = getRightInput(el, schemas, alreadyIds);
		
		Element leftJoinEl = DomUtils.getChildElementByName(el, "leftJoinIndices");
		if (leftJoinEl == null) {
			throw new XMLParseException("Missing leftJoinIndices child", el);
		}
		List<Integer> leftJoinIndices = readList(leftJoinEl);
		
		Element rightJoinEl = DomUtils.getChildElementByName(el, "rightJoinIndices");
		if (rightJoinEl == null) {
			throw new XMLParseException("Missing rightJoinIndices child", el);
		}
		List<Integer> rightJoinIndices = readList(rightJoinEl);
		
		Element leftOutputEl = DomUtils.getChildElementByName(el, "leftOutputPos");
		if (leftOutputEl == null) {
			throw new XMLParseException("Missing leftOutputPos child", el);
		}
		List<Integer> leftOutputPos = readList(leftOutputEl);
		
		Element rightOutputEl = DomUtils.getChildElementByName(el, "rightOutputPos");
		if (rightOutputEl == null) {
			throw new XMLParseException("Missing rightOutputPos child", el);
		}
		List<Integer> rightOutputPos = readList(rightOutputEl);
		
		boolean fixedPoint;
		String fixedPointStr = el.getAttribute("fixedPoint");
		if (fixedPointStr.length() == 0) {
			fixedPoint = false;
		} else {
			fixedPoint = Boolean.parseBoolean(fixedPointStr);
		}
		
		return new PipelinedJoinNode(schemas.get(qpd.outputSchema), leftJoinIndices,
				rightJoinIndices, leftOutputPos, rightOutputPos, qpd.loc,
				fixedPoint, leftInput, rightInput, qpd.operatorId);
	}
	
	static List<Integer> readList(Element parent) throws XMLParseException {
		List<Element> children = DomUtils.getChildElementsByName(parent, "col");
		List<Integer> retval = new ArrayList<Integer>(children.size());
		for (Element el : children) {
			String pos = el.getAttribute("pos");
			if (pos.length() == 0) {
				retval.add(null);
			} else {
				retval.add(Integer.parseInt(pos));
			}
		}
		return retval;
	}

	void getRecoveryJoinOperators(Map<Integer, int[]> opsHashCols, List<Integer> hashCols, Source schemas, boolean prevStatfulOperatorIsAgg) {
		if (prevStatfulOperatorIsAgg) {
			opsHashCols.put(operatorId, null);
		}
		if (hashCols != null) {
			int[] val = new int[hashCols.size()];
			int pos = 0;
			for (int col : hashCols) {
				val[pos++] = col;
			}
			opsHashCols.put(operatorId, val);
		}
		left.getRecoveryJoinOperators(opsHashCols, null, schemas, false);
		right.getRecoveryJoinOperators(opsHashCols, null, schemas, false);
	}
}

package edu.upenn.cis.orchestra.p2pqp.messages;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.KEY;

import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class MissingTuplesAre extends QpMessage {
	private static final long serialVersionUID = 1L;
	private final byte[] missingTuples;

	public MissingTuplesAre(CheckRelation cr, Collection<QpTuple<?>> missing) {
		super(cr);

		ByteBufferWriter bbw = new ByteBufferWriter();
		for (QpTuple<?> t : missing) {
			bbw.addToBuffer(t.getKeyBytes());
		}

		missingTuples = bbw.getByteArray();
	}

	public MissingTuplesAre(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		missingTuples = buf.readBytes();
	}

	@Override
	protected
	void subclassSerialize(OutputBuffer buf) {
		buf.writeBytes(missingTuples);
	}

	public Set<QpTuple<?>> getData(QpSchema schema, QpSchema.Source schemas) {
		Set<QpTuple<?>> retval = new HashSet<QpTuple<?>>();
		ByteBufferReader bbr = new ByteBufferReader(missingTuples);
		while (! bbr.hasFinished()) {
			retval.add(QpTuple.fromBytes(KEY, schema, schemas, null, bbr.readByteArray(), null));
		}
		return retval;
	}
}

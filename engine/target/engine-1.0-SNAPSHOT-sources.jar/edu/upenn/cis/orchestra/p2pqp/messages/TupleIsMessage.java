package edu.upenn.cis.orchestra.p2pqp.messages;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.STORE;

import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.MetadataFactory;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class TupleIsMessage extends QpMessage {
	private static final long serialVersionUID = 1L;
	public final byte[] t;

	public <M> TupleIsMessage(RetrieveTupleMessage origMsg, QpTuple<M> contents, MetadataFactory<M> mdf) {
		super(origMsg, true);
		if (contents == null) {
			throw new IllegalArgumentException("Cannot return null tuple");
		} else {
			t = contents.getStoreBytes(mdf);
		}
	}

	public 	<M> QpTuple<M> getTuple(QpSchema schema, QpSchema.Source schemas, MetadataFactory<M> mdf) {
		return QpTuple.fromBytes(STORE, schema, schemas, mdf, t, null);
	}

	public String toString() {
		return "TupleIsMessage";
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeBytes(t);
	}

	public TupleIsMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		t = buf.readBytes();

	}
}


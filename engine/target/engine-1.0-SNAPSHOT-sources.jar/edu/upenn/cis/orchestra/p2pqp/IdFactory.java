package edu.upenn.cis.orchestra.p2pqp;

public interface IdFactory {
	/**
	 * Convert an Id used by the underlying peer-to-peer network
	 * into an Id used by the query processor
	 * 
	 * @param id		The underlying network Id
	 * @return			The p2p query processor ID
	 */
	public Id toP2PQP(rice.p2p.commonapi.Id id);
	
	/**
	 * Convert an IdRange used by the underlying peer-to-peer network
	 * into an IdRange used by the query processor
	 * 
	 * @param range		The underlying network Id range
	 * @return			The p2p query processor ID range
	 */
	public IdRange toP2PQP(rice.p2p.commonapi.IdRange range);
	
	public rice.p2p.commonapi.Id toRiceId(Id id);
}

package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class SendTreePage extends IndexMessage {
	private static final long serialVersionUID = 1L;
	public final int relId, pageNum;
	public final byte[] data;
	
	public SendTreePage(InetSocketAddress dest, int relId, int pageNum, byte[] data) {
		super(dest);
		this.relId = relId;
		this.pageNum = pageNum;
		this.data = data;
	}
	
	public SendTreePage(GetTreePage request, byte[] treeContents) {
		super(request);
		this.relId = request.relId;
		this.pageNum = request.pageNum;
		this.data = treeContents;
	}
	
	public String toString() {
		return "SendTree(" + relId + "," + pageNum + ")";
	}
	
	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(relId);
		buf.writeInt(pageNum);
		buf.writeBytes(data);
	}
	
	public SendTreePage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		this.relId = buf.readInt();
		this.pageNum = buf.readInt();
		this.data = buf.readBytes();
	}
}

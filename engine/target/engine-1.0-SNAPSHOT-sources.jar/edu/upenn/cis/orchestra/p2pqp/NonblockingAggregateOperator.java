package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.datamodel.Subtuple;
import edu.upenn.cis.orchestra.datamodel.Type;
import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.datamodel.exceptions.NotNumericalException;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.optimization.Aggregate.AggFunc;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.p2pqp.plan.AggregateNode.OutputColumn;

public class NonblockingAggregateOperator<M> extends Operator<M> {
	private final QpSchema newSchema;
	private final Map<Integer,Integer> inverseSchemaMapping;
	private final HashMap<Subtuple,Collection<QpTuple<Null>>> aggregateTable;
	private final HashMap<QpTuple<Null>, M> storeMetadata;
	//Need to propagate aggregateTuple
	private final HashMap<Subtuple,QpTuple<M>> aggregateTuple;
	private int[] groupingColumns = null;
	private OutputColumn[] outputColumns = null;
	private final Logger logger = Logger.getLogger(this.getClass());
	
	public NonblockingAggregateOperator(QpSchema newSchema, Map<Integer,Integer> inverseSchemaMapping, List<Integer> groupingColumns, List<OutputColumn> outputColumns, Operator<M> dest, WhichChild destInput, int queryId, InetSocketAddress nodeId, int operatorId, MetadataFactory<M> mdf, RecordTuples rt) {
		super(dest,destInput,queryId,nodeId,operatorId,mdf,rt,false);
		this.newSchema = newSchema;
		if (newSchema == null) {
			this.inverseSchemaMapping = null;
		} else {
			if (inverseSchemaMapping == null) {
				throw new IllegalArgumentException("Need new schema mapping");
			}
			for (Map.Entry<?,?> me : inverseSchemaMapping.entrySet()) {
				if (me.getKey() == null || me.getValue() == null) {
					throw new NullPointerException("Cannot have null entry in schema mapping");
				}
			}
			this.inverseSchemaMapping = inverseSchemaMapping;
		}
		if (mdf == null || mdf instanceof NullMetadataFactory) {
			this.aggregateTable = null;
			this.aggregateTuple = null;
			this.storeMetadata = null;
		} else {
			this.aggregateTable = new HashMap<Subtuple, Collection<QpTuple<Null>>>();
			this.aggregateTuple = new HashMap<Subtuple, QpTuple<M>>();
			this.storeMetadata = new HashMap<QpTuple<Null>, M>();
		}
		
		if (groupingColumns != null && outputColumns != null) {
			this.groupingColumns = new int[groupingColumns.size()];
			int pos = 0;
			for (int col : groupingColumns) {
				this.groupingColumns[pos] = col;
				++pos;
			}
			this.outputColumns = new OutputColumn[outputColumns.size()];
			pos = 0;
			for (OutputColumn oc: outputColumns) {
				this.outputColumns[pos] = oc;
				++pos;
			}
		}
	}
	
	
	@Override
	protected void receiveTuples(List<QpTuple<M>> tuples) {
		// TODO: Reimplement NonblockingAggregateOperator to work with changes merged in from Nick's branch
		throw new UnsupportedOperationException("Need to re-implement based on version in subversion revision 7592");
	}
	
	protected void close() {
		synchronized(this) {
			if (storeMetadata != null) { 
				try {	
					System.out.println(" NonblockingAggregate Size:"+aggregateTuple.size());	
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
			storeMetadata.clear();
		}
		
	}
}
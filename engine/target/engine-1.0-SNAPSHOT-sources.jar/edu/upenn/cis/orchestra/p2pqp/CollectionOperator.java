package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;


public class CollectionOperator<M> extends Operator<M> {
	final Collection<QpTuple<M>> tuples;

	public CollectionOperator(Collection<QpTuple<M>> tuples, int queryId,
			InetSocketAddress nodeId, int operatorId, RecordTuples rt, MetadataFactory<M> mdf) {
		super(null,null,queryId,nodeId,operatorId,mdf,rt,false);
		this.tuples = tuples;
	}

	CollectionOperator(Collection<QpTuple<M>> tupleDest, int operatorId) {
		super(operatorId, null, null);
		this.tuples = tupleDest;
	}

	public void receiveTuples(List<QpTuple<M>> tuples) {
		synchronized (tuples) {
			this.tuples.addAll(tuples);
		}
	}

	CollectionScan<M> beginScan(Operator<M> dest, WhichChild outputDest, int operatorId) {
		return new CollectionScan<M>(tuples, dest, outputDest, operatorId);
	}

	public static class CollectionScan<M> extends PullScanOperator<M> {
		private volatile boolean interrupted = false;
		
		private final Iterator<QpTuple<M>> i;
		private CollectionScan(Collection<QpTuple<M>> tuples, Operator<M> dest, WhichChild outputDest, int operatorId) {
			super(dest,outputDest,operatorId);
			i = tuples.iterator();
		}

		public boolean isFinished(int phaseNo) {
			return (interrupted || (! i.hasNext()));
		}

		@Override
		public void scan(int blockSize, int phaseNo) {	
			scan(blockSize,false);
		}

		@Override
		public void scanAll(int blockSize, int phaseNo) {
			scan(blockSize,true);
		}

		private void scan(int blockSize, boolean all) {
			ArrayList<QpTuple<M>> block = new ArrayList<QpTuple<M>>(blockSize);
			while ((! interrupted) && i.hasNext()) {
				block.add(i.next());
				if (block.size() == blockSize) {
					if (all) {
						sendTuples(block);
						block.clear();
					} else {
						break;
					}
				}
			}
			if (! block.isEmpty()) {
				sendTuples(block);
			}
		}

		@Override
		public void interrupt(int phaseNo) {
			interrupted = true;
		}

	};

}
package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.optimization.Aggregate.AggFunc;
import edu.upenn.cis.orchestra.p2pqp.FixpointOperator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.p2pqp.plan.AggregateNode.OutputColumn;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class FixpointNode extends TwoInputQueryPlan {
	private static final long serialVersionUID = 1L;
	private List<Integer> groupingColumns = null;
	private List<OutputColumn> outputColumns = null;

	public void setGroupingAggregates(List<Integer> groupingColumns, List<OutputColumn> outputColumns) {
		if (groupingColumns != null && !groupingColumns.isEmpty()) {
			this.groupingColumns = new ArrayList<Integer>(groupingColumns);	
		}
		
		if (outputColumns != null && !outputColumns.isEmpty()) {
			this.outputColumns = new ArrayList<OutputColumn>(outputColumns);	
		}
	}
	public FixpointNode(QpSchema outputSchema, Location loc, QueryPlan left, QueryPlan right, int operatorId) {
		this(outputSchema, null, null, loc, left, right, operatorId);
	}
	public FixpointNode(QpSchema outputSchema, List<Integer> groupingColumns, List<OutputColumn> outputColumns, Location loc, QueryPlan left, QueryPlan right, int operatorId) {
		super(outputSchema.getRelationName(), loc, left, right, operatorId); 
		
		if (groupingColumns != null && !groupingColumns.isEmpty()) {
			this.groupingColumns = new ArrayList<Integer>(groupingColumns);	
		}
		
		if (outputColumns != null && !outputColumns.isEmpty()) {
			this.outputColumns = new ArrayList<OutputColumn>(outputColumns);	
		}
	}
	
	@Override
	<M> Operator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
	throws Operator.OperatorCreationException {
	
		QpSchema outputSchema = exec.getSchema(this.outputSchema);
		
		FixpointOperator<M> retval = new FixpointOperator<M>(exec.app, groupingColumns, outputColumns, left.outputSchema, right.outputSchema, 
				outputSchema, parent, dest, exec.queryId, exec.getNodeAddress(),operatorId, exec.getRecordTuples(), exec.app.getMetadataFactory()); 
		return retval;
	}
	@Override
	protected boolean subclassEquals(TwoInputQueryPlan jqp) {
		if (jqp instanceof FixpointNode) {
			return true;
		} else {
			return false;
		}
	}
	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc, el, schemas);
		if (groupingColumns != null) {
			Element grouping = DomUtils.addChild(doc, el, "grouping");
			for (int col : groupingColumns) {
				Element colEl = DomUtils.addChild(doc, grouping, "column");
				colEl.setAttribute("pos", Integer.toString(col));
			}
		}
		if (outputColumns != null){	
			Element output = DomUtils.addChild(doc, el, "output");
			for (OutputColumn oc : outputColumns) {
				Element colEl = DomUtils.addChild(doc, output, "aggField");
				if (oc.inputCol >= 0) {
					colEl.setAttribute("pos", Integer.toString(oc.inputCol));
				}
				if (oc.countCol >= 0) {
					colEl.setAttribute("count", Integer.toString(oc.countCol));
				}
				if (oc.agg != null) {
					colEl.setAttribute("func", oc.agg.name());
				}
			}		
		}
	}

	
	public static FixpointNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan leftInput = getLeftInput(el, schemas, alreadyIds);
		QueryPlan rightInput = getRightInput(el, schemas, alreadyIds);
		
		List<Integer> groupingColumns = null;
		Element grouping = DomUtils.getChildElementByName(el, "grouping");
		if (grouping != null) {
			List<Element> groupingColEls = DomUtils.getChildElementsByName(grouping, "column");
			groupingColumns = new ArrayList<Integer>();
			for (Element e : groupingColEls) {
				String pos = e.getAttribute("pos");
				if (pos.length() == 0) {
					throw new XMLParseException("Missing position attribute in grouping column element", e);
				}
				groupingColumns.add(Integer.parseInt(pos));
			}
		}
		
		List<OutputColumn> outputColumns = null;
		Element output = DomUtils.getChildElementByName(el, "output");
		if (output != null) {
			List<Element> outputEls = DomUtils.getChildElementsByName(output, "aggField");
			outputColumns = new ArrayList<OutputColumn>();
			for (Element e : outputEls) {
				String pos = e.getAttribute("pos");
				int posInt;
				if (pos.length() == 0) {
					posInt = -1;
				} else {
					try {
						posInt = Integer.parseInt(pos);
					} catch (NumberFormatException nfe) {
						throw new XMLParseException("Error parsing pos attribute", nfe,e);
					}
				}
				String count = e.getAttribute("count");
				int countInt;
				if (count.length() == 0) {
					countInt = -1;
				} else {
					try {
						countInt = Integer.parseInt(count);
					} catch (NumberFormatException nfe) {
						throw new XMLParseException("Error parsing count attribute", nfe, e);
					}
				}
				String func = e.getAttribute("func");
				AggFunc agg = null;
				if (func.length() > 0) {
					agg = AggFunc.valueOf(func);
					if (agg == null) {
						throw new XMLParseException("Invalid aggregate function " + func, e);
					}
				}
				if (posInt < 0) {
					outputColumns.add(new OutputColumn(agg));
				} else if (countInt < 0) {
					outputColumns.add(new OutputColumn(posInt, agg));
				} else {
					if (agg != null) {
						throw new XMLParseException("Should not supply aggregate function for rewritten average", e);
					}
					outputColumns.add(new OutputColumn(posInt, countInt));
				}
			}
				
		}
		FixpointNode ret = new FixpointNode(schemas.get(qpd.outputSchema), groupingColumns, outputColumns, qpd.loc,
				 leftInput, rightInput, qpd.operatorId);

		return ret;
	}
	
	/*
	@Override
	public <M> void createCentralExecution(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException {
		if (parent != null) {
			exec.setDestOperator(parent, dest, rehashSchema.getName());
		}
		super.createCentralExecution(exec, parent, dest, allowRecovery);
	}

	@Override
	public <M> void createDistributedExecution(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException {
		if (parent != null) {
			exec.setDestOperator(parent, dest, rehashSchema.getName());
		}
		super.createDistributedExecution(exec, parent, dest, allowRecovery);
	}

	@Override
	public <M> void createNamedExecution(String name, QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException {
		if (parent != null) {
			exec.setDestOperator(parent, dest, rehashSchema.getName());
		}
		super.createNamedExecution(name, exec, parent, dest, allowRecovery);
	}*/

}

package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.StreamPipelinedHashJoin;
import edu.upenn.cis.orchestra.p2pqp.Operator.OperatorCreationException;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class StreamPipelinedJoinNode extends PipelinedJoinNode {
	private static final long serialVersionUID = 1L;
	protected String mode;
	protected int nVal, size, advance;
	
	
	public StreamPipelinedJoinNode(QpSchema outputSchema, List<Integer> leftJoinIndices,
			List<Integer> rightJoinIndices, List<Integer> leftOutputPos,
			List<Integer> rightOutputPos, Location loc,
			QueryPlan left, QueryPlan right, int operatorId, String tmode, int nValue, int size, int advance) {
		super(outputSchema, leftJoinIndices,rightJoinIndices, leftOutputPos,rightOutputPos, loc, left, right, operatorId);
		this.mode = tmode;
		this.nVal = nValue;
		this.size = size;
		this.advance = advance;
	}
	@Override
	<M> Operator<M> createOperator(QueryExecution<M> exec, Operator<M> parent,
			WhichChild dest, boolean allowRecovery) throws OperatorCreationException {
		// TODO Auto-generated method stub
		QpSchema outputSchema = exec.getSchema(this.outputSchema);
		return new StreamPipelinedHashJoin<M>(left.outputSchema, right.outputSchema,
				leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos, true,
				outputSchema, parent, dest, exec.queryId, exec.getNodeAddress(),
				operatorId, exec.getRecordTuples(), exec.app.getMetadataFactory(), mode,nVal, size, advance);
	}
	
	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		super.serialize(doc, el, schemas);

		// serialize mode, nVal etc.
		el.setAttribute("mode", mode);
		el.setAttribute("nVal", Integer.toString(nVal));
		el.setAttribute("size", Integer.toString(size));
		el.setAttribute("advance", Integer.toString(advance));
	}

	public static StreamPipelinedJoinNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan leftInput = getLeftInput(el, schemas, alreadyIds);
		QueryPlan rightInput = getRightInput(el, schemas, alreadyIds);
		
		Element leftJoinEl = DomUtils.getChildElementByName(el, "leftJoinIndices");
		if (leftJoinEl == null) {
			throw new XMLParseException("Missing leftJoinIndices child", el);
		}
		List<Integer> leftJoinIndices = readList(leftJoinEl);
		
		Element rightJoinEl = DomUtils.getChildElementByName(el, "rightJoinIndices");
		if (rightJoinEl == null) {
			throw new XMLParseException("Missing rightJoinIndices child", el);
		}
		List<Integer> rightJoinIndices = readList(rightJoinEl);
		
		Element leftOutputEl = DomUtils.getChildElementByName(el, "leftOutputPos");
		if (leftOutputEl == null) {
			throw new XMLParseException("Missing leftOutputPos child", el);
		}
		List<Integer> leftOutputPos = readList(leftOutputEl);
		
		Element rightOutputEl = DomUtils.getChildElementByName(el, "rightOutputPos");
		if (rightOutputEl == null) {
			throw new XMLParseException("Missing rightOutputPos child", el);
		}
		List<Integer> rightOutputPos = readList(rightOutputEl);
		
		//nval
		String nValStr = el.getAttribute("nVal");
		if (nValStr.length() == 0) {
			throw new XMLParseException("Missing nVal attribute", el);
		}
		int nVal;
		try {
			nVal = Integer.parseInt(nValStr);
		} catch (NumberFormatException nfe) {
			throw new XMLParseException("Invalid nVal attribute", nfe, el);
		}
		//tmode
		String tmode = el.getAttribute("mode");
		
		if (tmode.length() == 0) {
			throw new XMLParseException("Missing tmode attribute", el);
		}
		//Size
		String sizeStr = el.getAttribute("size");
		int size;
		try {
			size = Integer.parseInt(sizeStr);
		} catch (NumberFormatException nfe) {
			throw new XMLParseException("Invalid size attribute", nfe, el);
		}
		
		//advance
		String advanceStr = el.getAttribute("advance");
		int advance;
		try {
			advance = Integer.parseInt(advanceStr);
		} catch (NumberFormatException nfe) {
			throw new XMLParseException("Invalid advance attribute", nfe, el);
		}
		
		return new StreamPipelinedJoinNode(schemas.get(qpd.outputSchema), leftJoinIndices,
				rightJoinIndices, leftOutputPos, rightOutputPos, qpd.loc,
				 leftInput, rightInput, qpd.operatorId, tmode,nVal,size, advance);

	}
	protected boolean subclassEquals(TwoInputQueryPlan jqp) {
		if (jqp instanceof StreamPipelinedJoinNode) {
			StreamPipelinedJoinNode spjn = (StreamPipelinedJoinNode) jqp;
			return 
				leftJoinIndices.equals(spjn.leftJoinIndices) &&
				rightJoinIndices.equals(spjn.rightJoinIndices) &&
				leftOutputPos.equals(spjn.leftOutputPos) &&
				rightOutputPos.equals(spjn.rightOutputPos);
		} else {
			return false;
		}
	}
	
}

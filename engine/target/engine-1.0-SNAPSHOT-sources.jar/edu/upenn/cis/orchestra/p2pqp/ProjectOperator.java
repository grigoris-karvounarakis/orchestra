package edu.upenn.cis.orchestra.p2pqp;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.datamodel.AbstractImmutableTuple.FieldSource;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public class ProjectOperator<M> extends Operator<M> {
	private final QpSchema newSchema;
	private final FieldSource[] fss;
	private final Logger logger = Logger.getLogger(this.getClass());
	
	public ProjectOperator(QpSchema newSchema, Map<Integer,Integer> inverseSchemaMapping, Operator<M> dest, WhichChild destInput, int operatorId, MetadataFactory<M> mdf, RecordTuples rt) {
		super(dest,destInput,operatorId,mdf,rt);
		this.newSchema = newSchema;
		if (newSchema == null) {
			throw new IllegalArgumentException("Need new schema");
		} else {
			if (inverseSchemaMapping == null) {
				throw new IllegalArgumentException("Need new schema mapping");
			}
			if (inverseSchemaMapping.size() != newSchema.getNumCols()) {
				throw new IllegalArgumentException("Mismatach between inverseSchemaMapping and newSchema");
			}
			fss = new FieldSource[newSchema.getNumCols()];
			for (Map.Entry<Integer,Integer> me : inverseSchemaMapping.entrySet()) {
				if (me.getKey() == null || me.getValue() == null) {
					throw new NullPointerException("Cannot have null entry in schema mapping");
				}
				fss[me.getKey()] = new FieldSource(me.getValue(), true);
			}
		}
	}
	
	
	@Override
	protected void receiveTuples(List<QpTuple<M>> tuples) {
		List<QpTuple<M>> outputTuples = new ArrayList<QpTuple<M>>();
		for (QpTuple<M> t: tuples) {
			try {
				if (mdf.shouldDelete(t.getMetadata())) {
					throw new RuntimeException("t's metadata is zero!");
				}
				QpTuple<M> newTuple = new QpTuple<M>(newSchema, fss, t, null);
				outputTuples.add(newTuple);
			}
		   catch (ValueMismatchException e) {
			logger.error("Could not convert tuple from " + t.getSchema().getRelationName() + " to " + newSchema.getRelationName());
			reportException(e);
		   }
		}
		if (! outputTuples.isEmpty()) {
			sendTuples(outputTuples);
		}
	}
}
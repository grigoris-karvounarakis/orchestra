package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.optimization.Aggregate.AggFunc;
import edu.upenn.cis.orchestra.p2pqp.NonblockingAggregateOperator;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.p2pqp.plan.AggregateNode.OutputColumn;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class NonblockingAggregateNode extends OneInputQueryPlan {
	private static final long serialVersionUID = 1L;
	private List<Integer> groupingColumns = null;
	private List<OutputColumn> outputColumns = null;
	private final Map<Integer,Integer> inverseSchemaMapping; 

	
	public NonblockingAggregateNode(QpSchema inputSchema, Map<Integer,Integer> inverseSchemaMapping,
			QpSchema outputSchema, Location loc, int operatorId,
			QueryPlan input) {
		this(inputSchema, inverseSchemaMapping, outputSchema, null, null, loc, operatorId, input);
	}
	
	public NonblockingAggregateNode(QpSchema inputSchema, Map<Integer,Integer> inverseSchemaMapping,
			QpSchema outputSchema, List<Integer> groupingColumns, List<OutputColumn> outputColumns, Location loc, int operatorId,
			QueryPlan input) {
		super(inputSchema.getRelationName(), outputSchema.getRelationName(), loc, operatorId, input);
		this.inverseSchemaMapping = inverseSchemaMapping;
		if (groupingColumns != null && !groupingColumns.isEmpty()) {
			this.groupingColumns = new ArrayList<Integer>(groupingColumns);	
		}
		
		if (outputColumns != null && !outputColumns.isEmpty()) {
			this.outputColumns = new ArrayList<OutputColumn>(outputColumns);	
		}
	}

	@Override
	<M> Operator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) {
		return new NonblockingAggregateOperator<M>(exec.getSchema(outputSchema), inverseSchemaMapping, groupingColumns, outputColumns, parent, dest, exec.queryId, exec.getNodeAddress(), operatorId, exec.app.getMetadataFactory(), exec.getRecordTuples());
	}

	@Override
	protected boolean subclassEquals(OneInputQueryPlan qp) {
		if (qp instanceof NonblockingAggregateNode) {
			return true;
		}	else {
			return false;
		}
	}

	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc,el,schemas);
		if (inverseSchemaMapping != null) {
			Element mapping = DomUtils.addChild(doc, el, "mapping");
			for (Map.Entry<Integer, Integer> me : inverseSchemaMapping.entrySet()) {
				Element entry = DomUtils.addChild(doc, mapping, "entry");
				entry.setAttribute("inputPos", Integer.toString(me.getKey()));
				entry.setAttribute("outputPos", Integer.toString(me.getValue()));
			}
		}
		if (groupingColumns != null) {
			Element grouping = DomUtils.addChild(doc, el, "grouping");
			for (int col : groupingColumns) {
				Element colEl = DomUtils.addChild(doc, grouping, "column");
				colEl.setAttribute("pos", Integer.toString(col));
			}
		}
		if (outputColumns != null){	
			Element output = DomUtils.addChild(doc, el, "output");
			for (OutputColumn oc : outputColumns) {
				Element colEl = DomUtils.addChild(doc, output, "aggField");
				if (oc.inputCol >= 0) {
					colEl.setAttribute("pos", Integer.toString(oc.inputCol));
				}
				if (oc.countCol >= 0) {
					colEl.setAttribute("count", Integer.toString(oc.countCol));
				}
				if (oc.agg != null) {
					colEl.setAttribute("func", oc.agg.name());
				}
			}		
		}
	}

	public static NonblockingAggregateNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan input = getInputQueryPlan(el, schemas, alreadyIds);
		QpSchema inputSchema = schemas.get(input.outputSchema);
		QpSchema outputSchema = schemas.get(qpd.outputSchema);
		Element mapping = DomUtils.getChildElementByName(el, "mapping");
		Map<Integer,Integer> inverseSchemaMapping = null;
		if (mapping != null) {
			List<Element> entries = DomUtils.getChildElementsByName(mapping, "entry");
			inverseSchemaMapping = new HashMap<Integer,Integer>(entries.size());
			for (Element entry : entries) {
				String inputPos = entry.getAttribute("inputPos");
				String outputPos = entry.getAttribute("outputPos");
				if (inputPos.length() == 0 || outputPos.length() == 0) {
					throw new XMLParseException("Each schema mapping entry must have an inputPos and an outputPos", entry);
				}
				try {
					int inputPosInt = Integer.parseInt(inputPos);
					int outputPosInt = Integer.parseInt(outputPos);
					inverseSchemaMapping.put(inputPosInt, outputPosInt);
				} catch (NumberFormatException nfe) {
					throw new XMLParseException(nfe, entry);
				}
			}
		}
		List<Integer> groupingColumns = null;
		Element grouping = DomUtils.getChildElementByName(el, "grouping");
		if (grouping != null) {
			List<Element> groupingColEls = DomUtils.getChildElementsByName(grouping, "column");
			groupingColumns = new ArrayList<Integer>();
			for (Element e : groupingColEls) {
				String pos = e.getAttribute("pos");
				if (pos.length() == 0) {
					throw new XMLParseException("Missing position attribute in grouping column element", e);
				}
				groupingColumns.add(Integer.parseInt(pos));
			}
		}
		
		List<OutputColumn> outputColumns = null;
		Element output = DomUtils.getChildElementByName(el, "output");
		if (output != null) {
			List<Element> outputEls = DomUtils.getChildElementsByName(output, "aggField");
			outputColumns = new ArrayList<OutputColumn>();
			for (Element e : outputEls) {
				String pos = e.getAttribute("pos");
				int posInt;
				if (pos.length() == 0) {
					posInt = -1;
				} else {
					try {
						posInt = Integer.parseInt(pos);
					} catch (NumberFormatException nfe) {
						throw new XMLParseException("Error parsing pos attribute", nfe,e);
					}
				}
				String count = e.getAttribute("count");
				int countInt;
				if (count.length() == 0) {
					countInt = -1;
				} else {
					try {
						countInt = Integer.parseInt(count);
					} catch (NumberFormatException nfe) {
						throw new XMLParseException("Error parsing count attribute", nfe, e);
					}
				}
				String func = e.getAttribute("func");
				AggFunc agg = null;
				if (func.length() > 0) {
					agg = AggFunc.valueOf(func);
					if (agg == null) {
						throw new XMLParseException("Invalid aggregate function " + func, e);
					}
				}
				if (posInt < 0) {
					outputColumns.add(new OutputColumn(agg));
				} else if (countInt < 0) {
					outputColumns.add(new OutputColumn(posInt, agg));
				} else {
					if (agg != null) {
						throw new XMLParseException("Should not supply aggregate function for rewritten average", e);
					}
					outputColumns.add(new OutputColumn(posInt, countInt));
				}
			}
				
		}
		return new NonblockingAggregateNode(inputSchema, inverseSchemaMapping, outputSchema, groupingColumns, outputColumns, qpd.loc, qpd.operatorId, input);
	}
}
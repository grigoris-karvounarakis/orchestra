package edu.upenn.cis.orchestra.p2pqp.messages;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.EXECUTION;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.MetadataFactory;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpApplication;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class RehashTuplesMessage extends QpMessage implements QueryExecutionMessage {
	private static final long serialVersionUID = 1L;
	private final byte[] data;
	private final int queryId;
	private final int relId;

	public static <M> List<RehashTuplesMessage> build(InetSocketAddress dest, int queryId, Collection<QpTuple<M>> content, MetadataFactory<M> mdf) {
		List<RehashTuplesMessage> retval = new ArrayList<RehashTuplesMessage>();

		int overhead = 5000;
		ByteBufferWriter bbw = new ByteBufferWriter();

		boolean first = true;
		int relId = 0;
		
		for (QpTuple<M> t : content) {
			if (first) {
				relId = t.getSchema().relId;
			} else if (relId != t.getSchema().relId) {
				throw new IllegalArgumentException("Tuples must all be from same relation");
			}
			byte[] bytes = t.getExecutionBytes(mdf);
			if (overhead + bbw.getCurrentLength() + bytes.length > QpApplication.MAX_MSG_SIZE) {
				retval.add(new RehashTuplesMessage(dest, queryId, relId, bbw.getByteArray()));
				bbw.clear();
			}
			bbw.addToBuffer(bytes);
		}

		if (bbw.getCurrentLength() != 0) {
			retval.add(new RehashTuplesMessage(dest, queryId, relId, bbw.getByteArray()));
		}

		return retval;
	}


	private RehashTuplesMessage(InetSocketAddress dest, int queryId, int relId, byte[] data) {
		super(dest);
		this.queryId = queryId;
		this.data = data;
		this.relId = relId;
	}

	public <M> List<QpTuple<M>> getData(QpSchema.Source schemas, MetadataFactory<M> mdf) {
		QpSchema schema = schemas.getSchema(relId);
		List<QpTuple<M>> retval = new ArrayList<QpTuple<M>>();
		ByteBufferReader bbr = new ByteBufferReader(data);
		while (! bbr.hasFinished()) {
			retval.add(QpTuple.fromBytes(EXECUTION, schema, schemas, mdf, bbr.readByteArray(), null));
		}
		return retval;
	}
	
	public long getDataLength() {
		return this.data.length;
	}
	
	public String toString() {
		return "RehashTuplesMessage";
	}

	@Override
	protected
	void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(queryId);
		buf.writeInt(relId);
		buf.writeBytes(data);
	}

	public RehashTuplesMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		queryId = buf.readInt();
		relId = buf.readInt();
		data = buf.readBytes();
	}

	public int getQueryId() {
		return queryId;
	}
}

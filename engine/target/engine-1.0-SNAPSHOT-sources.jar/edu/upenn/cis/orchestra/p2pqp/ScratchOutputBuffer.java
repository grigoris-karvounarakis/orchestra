package edu.upenn.cis.orchestra.p2pqp;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;


public class ScratchOutputBuffer extends OutputBuffer {
	private final ByteArrayOutputStream baos = new ByteArrayOutputStream();
	private final DataOutputStream dos = new DataOutputStream(baos);


	@Override
	public
	void writeBoolean(boolean bool) {
		try {
			dos.writeBoolean(bool);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public
	void writeBytesNoLength(byte[] b) {
		try {
			dos.write(b);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public
	void writeInt(int v) {
		try {
			dos.writeInt(v);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public
	void writeLong(long l) {
		try {
			dos.writeLong(l);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public void reset() {
		baos.reset();
	}

	public byte[] getData() {
		return baos.toByteArray();
	}

	public String toString() {
		return Arrays.toString(baos.toByteArray());
	}

	@Override
	public void writeShort(short s) {
		try {
			dos.writeShort(s);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}

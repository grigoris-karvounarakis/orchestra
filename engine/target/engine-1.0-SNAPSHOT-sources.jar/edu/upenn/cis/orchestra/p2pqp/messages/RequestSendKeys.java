package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.Id;
import edu.upenn.cis.orchestra.p2pqp.IdRange;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class RequestSendKeys extends IndexMessage {
	private static final long serialVersionUID = 1L;

	public final int relId;
	public final int epoch, number, queryId, operatorId;
	public final int phaseNo;
	public final IdRange[] rangesToSend;
	
	public final byte[] keyFilterBytes;

	public RequestSendKeys(Id dest, int relId, int epoch, int number, int queryId, int operatorId, byte[] keyFilterBytes, int phaseNo, IdRange[] rangesToSend) {
		super(dest);
		this.relId = relId;
		this.epoch = epoch;
		this.number = number;
		this.queryId = queryId;
		this.operatorId = operatorId;
		this.phaseNo = phaseNo;
		this.rangesToSend = rangesToSend;
		
		if (rangesToSend != null && rangesToSend.length == 0) {
			throw new IllegalArgumentException("rangesToSend must be null or non-empty");
		}
		
		this.keyFilterBytes = keyFilterBytes;
	}

	public String toString() {
		return "RequestSendKeys(" + relId + "," + epoch + "," + number + "," + queryId + "," + operatorId + "," + phaseNo + ")";
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(relId);
		buf.writeInt(epoch);
		buf.writeInt(number);
		buf.writeInt(queryId);
		buf.writeInt(operatorId);
		buf.writeInt(phaseNo);
		
		if (rangesToSend == null) {
			buf.writeInt(-1);
		} else {
			buf.writeInt(rangesToSend.length);
			for (IdRange range : rangesToSend) {
				range.serialize(buf);
			}
		}
		
		buf.writeBytes(keyFilterBytes);
	}

	public RequestSendKeys(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		relId = buf.readInt();
		epoch = buf.readInt();
		number = buf.readInt();
		queryId = buf.readInt();
		operatorId = buf.readInt();
		phaseNo = buf.readInt();
		
		int numRanges = buf.readInt();
		if (numRanges < 0) {
			rangesToSend = null;
		} else {
			rangesToSend = new IdRange[numRanges];
			for (int i = 0; i < numRanges; ++i) {
				rangesToSend[i] = IdRange.deserialize(buf);
			}
		}
		
		keyFilterBytes = buf.readBytes();
	}
}

package edu.upenn.cis.orchestra.p2pqp;

import net.sf.javabdd.BDD;

/** @deprecated */
public class ProvenanceOperators {
	
	public static BDD Join(BDD r_1, BDD r_2) {
		return r_1.and(r_2);
	}
	public static BDD Union(BDD r_1, BDD r_2) {
		return r_1.or(r_2);
	}
	public static BDD Difference (BDD r_1, BDD r_2){
		return r_1.and(r_2.not());
    }
	public static BDD SetZero(BDD r_1, BDD r_2) {
		return r_1.restrict(r_2.not());
	}
 	/*
	public BDD TupleProvenanceSelect(BDD r, BDD p){
		return r.restrict(p);
	}
	public BDD TupleProvenanceProject(BDD r, BDD v){
		return r.exist(v);
	}
	public BDD TupleProvenanceJoinProject(BDD r_1, BDD r_2, BDD v){
		return r_1.relprod(r_2, v);
	}
	public BDD TupleProvenanceRename(BDD r, BDDPairing p){
		return r.replace(p);
	}
	public BDD TupleProvenanceCopy(BDD r) {
		return r.id();
	}
	
	public boolean TupleProvenanceEqual(BDD r_1, BDD r_2) {
		return r_1.equals(r_2);
	}

	public String TupleProvenancePrintout(BDD r) {
		return r.high().toString();
	}
	
	public int TupleProvenanceGetsize(BDD r){
		return r.nodeCount();
	}
	public int TupleProvenanceIdentifier(BDD r) {
		return r.hashCode();
	}
	public BDD Setzero(BDD r, BDD p){
		return r.xor(p);
	}

class ViewMaintenance {
	
    public boolean DeletionPropagation(BDD r_1,BDD r_2){
    	if (r_1.xor(r_2).isZero()) {
    		return false;
    	}
    	return true;
    }
}*/

}
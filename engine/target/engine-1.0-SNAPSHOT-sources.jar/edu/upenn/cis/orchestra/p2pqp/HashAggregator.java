package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.Type;
import edu.upenn.cis.orchestra.datamodel.AbstractImmutableTuple.FieldSource;
import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.datamodel.exceptions.NotNumericalException;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.optimization.Aggregate.AggFunc;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public class HashAggregator<M> extends BlockingOperator<M> {
	private final QpSchema inputSchema, outputSchema;
	private final int[] groupingColumns;
	private final OutputColumn[] outputColumns;
	private int lastCol = 0;
	private boolean doneAddingColumns = false;
	private int numAggs = 0;
	private FieldSource[] fss;
	private final Logger logger = Logger.getLogger(this.getClass());
	private final boolean enableRecovery;

	private class GroupData {
		private final List<M> metadata = (mdf == null) ? null : new ArrayList<M>();
		private final Aggregator[] aggregators = new Aggregator[numAggs];
		private int epoch = Integer.MIN_VALUE;

		GroupData() {
			int pos = 0;
			for (int i = 0; i < outputColumns.length; ++i) {
				OutputColumn oc = outputColumns[i];
				if (oc instanceof AggColumn) {
					Aggregator agg;
					Type t = oc.inputCol >= 0 ? inputSchema.getColType(oc.inputCol) : null;
					AggColumn ac = (AggColumn) oc;
					if (ac.func == AggFunc.AVG) {
						agg = new AvgAggregator(t, oc.inputCol);
					} else if (ac.func == AggFunc.COUNT) {
						agg = new CountAggregator(oc.inputCol);
					} else if (ac.func == AggFunc.MAX) {
						agg = new MaxAggregator(t, oc.inputCol);
					} else if (ac.func == AggFunc.MIN) {
						agg = new MinAggregator(t, oc.inputCol);
					} else if (ac.func == AggFunc.SUM) {
						agg = new SumAggregator(t, oc.inputCol);
					} else {
						throw new RuntimeException("Need to implement aggregate function " + ac);
					}
					aggregators[pos++] = agg;
				} else if (oc instanceof RewrittenAvgColumn) {
					RewrittenAvgColumn rac = (RewrittenAvgColumn) oc;
					Aggregator agg = new RewrittenAvgAggregator(inputSchema.getColType(rac.inputCol), rac.inputCol, rac.countCol);
					aggregators[pos++] = agg;
				}
			}
		}

		synchronized void addTuple(QpTuple<M> t) throws CompareMismatch, NotNumericalException, ValueMismatchException {
			for (Aggregator agg : aggregators) {
				if (agg != null) {
					agg.addTuple(t);
				}
			}
			if (t.getEpoch() > epoch) {
				epoch = t.getEpoch();
			}
			if (metadata != null) {
				metadata.add(t.getMetadata());
			}
		}

		QpTuple<M> getResult(QpTuple<?> groupingCols, ExecutionId aggTupleId) throws NotNumericalException, ValueMismatchException {
			Object[] aggFields = new Object[aggregators.length];
			for (int i = 0; i < aggregators.length; ++i) {
				aggFields[i] = aggregators[i].getResult();
			}
			return new QpTuple<M>(outputSchema, fss, groupingCols, epoch, aggTupleId, mdf == null ? null : mdf.agg(HashAggregator.this, metadata), aggFields);
		}
	}


	private QpTupleMap<GroupData> groups;
	private int count = 0;
	private int currPhaseNo = 0;
	private int mostRecentPhase = 0;

	public HashAggregator(Operator<M> dest, WhichChild outputDest,
			QpSchema inputSchema, QpSchema outputSchema,
			List<Integer> groupingColumns, int queryId, InetSocketAddress nodeId,
			int operatorId, RecordTuples rt, MetadataFactory<M> mdf, boolean enableRecovery) {
		super(dest,outputDest,queryId,nodeId,operatorId,rt,mdf,enableRecovery);
		this.inputSchema = inputSchema;
		this.outputSchema = outputSchema;
		this.groupingColumns = new int[groupingColumns.size()];
		int pos = 0;
		for (int col : groupingColumns) {
			this.groupingColumns[pos] = col;
			++pos;
		}
		Arrays.sort(this.groupingColumns);

		this.enableRecovery = enableRecovery;

		outputColumns = new OutputColumn[outputSchema.getNumCols()];
		groups = new QpTupleMap<GroupData>(this.groupingColumns, new QpTupleMap.ValueFactory<GroupData>() {
			public GroupData getNewValue() {
				return new GroupData();
			}
		}, true);
	}

	public void addOutputColumn(int inputColumn) {
		if (inputColumn > inputSchema.getNumCols()) {
			throw new IllegalArgumentException("Input column out of bounds: " + inputColumn);
		}
		if (lastCol == outputColumns.length) {
			throw new IllegalArgumentException("Already have enough output columns");
		}
		if (doneAddingColumns) {
			throw new IllegalStateException("Cannot add column when finishAddingColumns() has been called");
		}

		boolean foundCol = false;
		for (int i : groupingColumns) {
			if (inputColumn == i) {
				foundCol = true;
			}
		}

		if (! foundCol) {
			throw new IllegalArgumentException("Column " + inputColumn + " is not a grouping column");
		}

		outputColumns[lastCol] = new OutputColumn(inputColumn);
		++lastCol;
	}

	public void addOutputColumn(AggFunc agg) {
		if (doneAddingColumns) {
			throw new IllegalStateException("Cannot add column when finishAddingColumns() has been called");
		}
		if (! agg.canBeNullary) {
			throw new IllegalArgumentException("Aggregate function " + agg + " cannot be nullary");
		}
		outputColumns[lastCol] = new AggColumn(agg);
		++lastCol;
	}

	public void addOutputColumn(int sumColumn, int countColumn) {
		if (doneAddingColumns) {
			throw new IllegalStateException("Cannot add column when finishAddingColumns() has been called");
		}
		if (sumColumn > inputSchema.getNumCols()) {
			throw new IllegalArgumentException("Input column out of bounds: " + sumColumn);
		}
		if (countColumn > inputSchema.getNumCols()) {
			throw new IllegalArgumentException("Input column out of bounds: " + countColumn);
		}
		if (lastCol == outputColumns.length) {
			throw new IllegalArgumentException("Already have enough output columns");
		}

		int foundCol = -1;
		for (int i : groupingColumns) {
			if (sumColumn == i || countColumn == i) {
				foundCol = i;
				break;
			}
		}

		if (foundCol != -1) {
			throw new IllegalArgumentException("Column " + foundCol + " is a grouping column");
		}

		if (!(inputSchema.getColType(countColumn) instanceof IntType)) {
			throw new IllegalArgumentException("Count column must be an integer");
		}

		outputColumns[lastCol] = new RewrittenAvgColumn(sumColumn, countColumn);
		++lastCol;
	}

	public void addOutputColumn(int inputColumn, AggFunc agg) {
		if (doneAddingColumns) {
			throw new IllegalStateException("Cannot add column when finishAddingColumns() has been called");
		}
		if (inputColumn > inputSchema.getNumCols()) {
			throw new IllegalArgumentException("Input column out of bounds: " + inputColumn);
		}
		if (lastCol == outputColumns.length) {
			throw new IllegalArgumentException("Already have enough output columns");
		}

		boolean foundCol = false;
		for (int i : groupingColumns) {
			if (inputColumn == i) {
				foundCol = true;
				break;
			}
		}

		if (foundCol) {
			throw new IllegalArgumentException("Column " + inputColumn + " is a grouping column");
		}


		outputColumns[lastCol] = new AggColumn(inputColumn, agg);
		++lastCol;
	}

	public void finishAddingColumns() {
		if (doneAddingColumns) {
			return;
		}
		if (lastCol != outputColumns.length) {
			throw new IllegalArgumentException("Not all output columns have been specified");
		}

		doneAddingColumns = true;

		numAggs = 0;
		fss = new FieldSource[outputColumns.length];
		for (int i = 0; i < outputColumns.length; ++i) {
			OutputColumn oc = outputColumns[i];
			if (oc instanceof AggColumn) {
				fss[i] = new FieldSource(numAggs,false);
				++numAggs;
			} else if (oc instanceof RewrittenAvgColumn) {
				fss[i] = new FieldSource(numAggs,false);
				++numAggs;
			} else {
				fss[i] = new FieldSource(oc.inputCol,true);
			}
		}
	}

	public void finish(int blockSize) {
		if (! doneAddingColumns) {
			throw new IllegalStateException("Must call finishAddingColumns() before processing");
		}

		List<QpTuple<M>> block = new ArrayList<QpTuple<M>>(blockSize);
		List<ExecutionId> addedTuples = new ArrayList<ExecutionId>(blockSize);

		synchronized (groups) {
			logger.info("Finishing aggregator " + operatorId + " during phase " + currPhaseNo + " using data from " + count + " input tuples");
			int currPhaseNo;
			currPhaseNo = this.currPhaseNo;
			if (currPhaseNo == mostRecentPhase) {
				for (QpTupleMap<GroupData>.Entry entry : groups) {
					QpTuple<M> output;
					try {
						output = entry.value.getResult(entry.key, getFreshId(currPhaseNo));
						addedTuples.add(output.getId());
					} catch (Exception vm) {
						throw new RuntimeException("Couldn't create output tuple", vm);
					}
					block.add(output);
					if (block.size() == blockSize) {
						tuplesAdded(addedTuples);
						sendTuples(block);
						block.clear();
						addedTuples.clear();
					}

				}

				if (! block.isEmpty()) {
					tuplesAdded(addedTuples);
					sendTuples(block);
				}
			}
		}
	}

	public void receiveTuples(List<QpTuple<M>> tuples) {
		if (! doneAddingColumns) {
			throw new IllegalStateException("Must call finishAddingColumns() before processing");
		}
		if (tuples.isEmpty()) {
			return;
		}

		int discardedCount = 0;
		
		if (enableRecovery) {
			int ourMostRecentPhase = Integer.MIN_VALUE;
			List<QpTuple<M>> tuplesToProcess = new ArrayList<QpTuple<M>>(tuples.size());
			for (QpTuple<M> t : tuples) {
				int phaseNo = t.getId().phaseNo;
				if (phaseNo > ourMostRecentPhase) {
					discardedCount += tuplesToProcess.size();
					tuplesToProcess.clear();
					ourMostRecentPhase = phaseNo;
				}
				if (phaseNo == ourMostRecentPhase) {
					tuplesToProcess.add(t);
				} else {
					++discardedCount;
				}
			}

			synchronized (groups) {
				if (ourMostRecentPhase > mostRecentPhase) {
					logger.info("HashAggregator " + operatorId + " received tuples from " + ourMostRecentPhase + ", clearing data from " + mostRecentPhase);
					groups.clear();
					count = 0;
					mostRecentPhase = ourMostRecentPhase;
				}
				if (ourMostRecentPhase == mostRecentPhase) {
					try {
						count += tuplesToProcess.size();
						for (QpTuple<M> t : tuplesToProcess) {
							groups.getOrCreate(t).addTuple(t);
						}
					} catch (Exception e) {
						reportException(e);
					}
				} else {
					discardedCount += tuplesToProcess.size();
				}
			}
		} else {
			synchronized (groups) {
				count += tuples.size();
			}
			try {
				for (QpTuple<M> t : tuples) {
					groups.getOrCreate(t).addTuple(t);
				}
			} catch (Exception e) {
				reportException(e);
			}
		}

		List<ExecutionId> tids = new ArrayList<ExecutionId>(tuples.size());
		for (QpTuple<M> t : tuples) {
			tids.add(t.getId());
		}
		tuplesRemoved(tids);
		
		if (discardedCount > 0) {
			logger.info("Aggregator " + operatorId + " discarded " + discardedCount + " tuples from previous epochs");
		}
	}

	void reset () {
		groups.clear();
		count = 0;
	}

	private static class OutputColumn {
		final int inputCol;
		OutputColumn(int inputCol) {
			this.inputCol = inputCol;
		}
	}

	private static class AggColumn extends OutputColumn {
		final AggFunc func;
		AggColumn(int inputCol, AggFunc func) {
			super(inputCol);
			this.func = func;
		}
		AggColumn(AggFunc func) {
			super(-1);
			this.func = func;
		}
	}

	private static class RewrittenAvgColumn extends OutputColumn {
		final int countCol;

		RewrittenAvgColumn(int sumCol, int countCol) {
			super(sumCol);
			this.countCol = countCol;
		}
	}

	protected void close() {
		groups = null;
	}

	private interface Aggregator {
		void addTuple(QpTuple<?> t) throws NotNumericalException, ValueMismatchException, CompareMismatch;
		Object getResult() throws NotNumericalException, ValueMismatchException;
	}

	private static class AvgAggregator implements Aggregator {
		private final Type t;
		private final int inputCol;
		private Object sum;
		private int count;

		AvgAggregator(Type t, int inputCol) {
			this.t = t;
			this.inputCol = inputCol;
			sum = null;
		}

		public void addTuple(QpTuple<?> t) throws NotNumericalException, ValueMismatchException {
			Object o = t.get(inputCol);
			if (o != null) {
				sum = this.t.add(o, sum);
				++count;
			}
		}

		public Object getResult() throws NotNumericalException, ValueMismatchException {
			return t.divide(sum, count);
		}
	}

	private static class CountAggregator implements Aggregator {
		private final int inputCol;
		private int count;

		CountAggregator(int inputCol) {
			this.inputCol = inputCol;
			count = 0;
		}

		public void addTuple(QpTuple<?> t) {
			if (inputCol < 0) {
				++count;
			} else if (! t.isNull(inputCol)) {
				++count;
			}
		}

		public Object getResult() {
			return count;
		}
	}

	private static class MaxAggregator implements Aggregator {
		private final Type t;
		private final int inputCol;
		private Object max;

		MaxAggregator(Type t, int inputCol) {
			this.t = t;
			this.inputCol = inputCol;
			max = null;
		}

		public void addTuple(QpTuple<?> t) throws CompareMismatch {
			Object o = t.get(inputCol);
			if (max == null) {
				max = o;
			} else if (o != null && this.t.compareTwo(o, max) > 0) {
				max = o;
			}
		}

		public Object getResult() {
			return max;
		}
	}

	private static class MinAggregator implements Aggregator {
		private final Type t;
		private final int inputCol;
		private Object min;

		MinAggregator(Type t, int inputCol) {
			this.t = t;
			this.inputCol = inputCol;
			min = null;
		}

		public void addTuple(QpTuple<?> t) throws CompareMismatch {
			Object o = t.get(inputCol);
			if (min == null) {
				min = o;
			} else if (o != null && this.t.compareTwo(o, min) < 0) {
				min = o;
			}
		}

		public Object getResult() {
			return min;
		}
	}

	private static class SumAggregator implements Aggregator {
		private final Type t;
		private final int inputCol;
		private Object sum;

		SumAggregator(Type t, int inputCol) {
			this.t = t;
			this.inputCol = inputCol;
			sum = null;
		}

		public void addTuple(QpTuple<?> t) throws NotNumericalException, ValueMismatchException {
			Object o = t.get(inputCol);
			sum = this.t.add(o, sum);
		}

		public Object getResult() {
			return sum;
		}
	}

	private static class RewrittenAvgAggregator implements Aggregator {
		private final Type t;
		private final int sumCol, countCol;
		private Object sum;
		private int count;

		RewrittenAvgAggregator(Type t, int sumCol, int countCol) {
			this.t = t;
			this.sumCol = sumCol;
			this.countCol = countCol;
			sum = null;
			count = 0;
		}

		public void addTuple(QpTuple<?> t) throws NotNumericalException,
		ValueMismatchException {
			Object tSum = t.get(sumCol);
			Object tCount = t.get(countCol);
			sum = this.t.add(sum, tSum);
			count += (Integer) tCount;
		}

		public Object getResult() throws NotNumericalException,
		ValueMismatchException {
			return t.divide(sum, count);
		}
	}

	protected void disposeOfFailedTuples(int newPhaseNo, byte[][] failedNodeIds) {
		synchronized (groups) {
			this.currPhaseNo = newPhaseNo;
		}
		logger.info("HashAggregator " + operatorId + " set new phase no = " + newPhaseNo);
	}
}
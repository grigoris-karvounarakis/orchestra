package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.FixpointReceiverOperator;
import edu.upenn.cis.orchestra.p2pqp.FixpointOperator;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.XMLParseException;


public class FixpointReceiverNode extends NoInputQueryPlan {
	private static final long serialVersionUID = 1L;
	QpSchema inputSchema;
	
	public FixpointReceiverNode(QpSchema inputSchema, Location loc, int operatorId) {
		super(inputSchema.getRelationName(), DistributedLoc.getInstance(), operatorId, false);
		this.inputSchema = inputSchema;
	}

	@Override
	<M> FixpointReceiverOperator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
			throws Operator.OperatorCreationException {
		
		FixpointReceiverOperator<M> retval = new FixpointReceiverOperator<M>(parent, dest, exec.queryId, exec.getNodeAddress(), operatorId,
				exec.getRecordTuples(), exec.app.getMetadataFactory());
		
		
		// TODO:  walk our parent recursively until we find a FixpointOperator that
		// does NOT have a receiver set.  Call setLoopBack() with ourselves as the parameter
		
		//Here we assume there's only one FixpointOperator and FixpointReceiverOperator in the whole picture
		
		Operator<M> traverse = retval;
		while (traverse != null && !traverse.getClass().equals(FixpointOperator.class)) {
			traverse = traverse.getDest();
			if (traverse == null) break;
			if (traverse.equals(retval)) break;
		}
		
		if (traverse != null && traverse.getClass().equals(FixpointOperator.class)) {
			FixpointOperator<M> fpr = (FixpointOperator<M>) traverse;
			if (!fpr.hasLoopBack()) {
				fpr.setLoopBack(retval);
			}
		} else {
			throw new Operator.OperatorCreationException("Cannot find fixpoint operator for fixpointReceiver operator!");
		}
		
		return retval;
	}

	@Override
	public boolean equals(Object o) {
		if (o == null || o.getClass() != this.getClass()) {
			return false;
		}
		FixpointReceiverNode dsn = (FixpointReceiverNode) o;
		return outputSchema.equals(dsn.outputSchema);
	}

	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc,el,schemas);
		
		QpSchema ns = schemas.get(outputSchema);
		
		if (ns == null) {
			throw new IllegalArgumentException("Missing schema for relation " + outputSchema);
		}
	}
	
	public static FixpointReceiverNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QpSchema ns = schemas.get(qpd.outputSchema);
		
		return new FixpointReceiverNode(ns, qpd.loc, qpd.operatorId);
	}
}

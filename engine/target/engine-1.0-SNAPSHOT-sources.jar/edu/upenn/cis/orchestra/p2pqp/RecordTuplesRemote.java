package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.p2pqp.messages.DoesNotHaveQuery;
import edu.upenn.cis.orchestra.p2pqp.messages.RecordTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplySendingFailed;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplySuccess;
import edu.upenn.cis.orchestra.p2pqp.messages.RecordTuplesMessage.OperatorAndPhase;

public class RecordTuplesRemote implements RecordTuples {

	private enum EntryType {
		ADDED, REMOVED, SCANNED, FINISHED, EXCEPTION, MISSING, FAILED
	}

	private static class Entry {
		final EntryType type;
		final Object o;

		Entry(NodeAndOp nao) {
			this(EntryType.FINISHED, nao);
		}

		Entry(Exception e) {
			this(EntryType.EXCEPTION, e);
		}

		static Entry added(ExecutionId tid) {
			return new Entry(EntryType.ADDED, tid);
		}

		static Entry removed(ExecutionId tid) {
			return new Entry(EntryType.REMOVED, tid);
		}

		static Entry scanned(QpTuple<?> key, int operator, int phase)  {
			return new Entry(EntryType.SCANNED, new TupleAndOp(key,operator,phase));
		}

		static Entry missing(QpTuple<?> key, int operator, int phase) {
			return new Entry(EntryType.MISSING, new TupleAndOp(key, operator, phase));
		}

		static Entry failed(InetSocketAddress node) {
			return new Entry(EntryType.FAILED, node);
		}

		private Entry(EntryType t, Object o) {
			this.type = t;
			this.o = o;
		}
	}

	private List<Entry> entries = new ArrayList<Entry>();

	final private QpApplication<?> app;
	final private SendThread sendThread;
	final private InetSocketAddress dest;
	final private int queryId;

	private final Logger logger = Logger.getLogger(this.getClass());

	private Set<Long> outstandingMessages = Collections.synchronizedSet(new HashSet<Long>());
	private List<Long> sentMessages = Collections.synchronizedList(new ArrayList<Long>());

	RecordTuplesRemote(QpApplication<?> app, int sendDelayMs, InetSocketAddress dest, int queryId) {
		this.dest = dest;
		this.queryId = queryId;
		this.app = app;
		sendThread = new SendThread(sendDelayMs);
		sendThread.start();
	}

	public synchronized void tupleAdded(ExecutionId tupleId) {
		entries.add(Entry.added(tupleId));
	}

	public synchronized void tupleRemoved(ExecutionId tupleId) {
		entries.add(Entry.removed(tupleId));
	}

	public synchronized void nodesHaveFailed(Collection<InetSocketAddress> nodes) {
		for (InetSocketAddress node : nodes) {
			entries.add(Entry.failed(node));
		}
	}

	public void close() {
		try {
			sendThread.interrupt();
			sendThread.join();
		} catch (InterruptedException ie) {
			logger.error("Interrupted while closing RecordTuplesRemote for query " + queryId, ie);
			return;
		}

		entries.clear();
		sentMessages.clear();
		for (long msgId : outstandingMessages) {
			app.removeReplyContinuation(msgId);
		}
		outstandingMessages.clear();
		logger.info("Closed RecordTuplesRemote for query " + queryId);
	}

	private class SendThread extends Thread {
		final int sendDelayMs;
		SendThread(int sendDelayMs) {
			super(app.tg, "RecordTuplesLocal SendThread(" + queryId + "," + app.localAddr + ")");
			this.sendDelayMs = sendDelayMs;
		}

		public void run() {
			try {
				while (! isInterrupted()) {
					Thread.sleep(sendDelayMs);
					List<Entry> toProcess;
					synchronized (RecordTuplesRemote.this) {
						if (entries.isEmpty()) {
							continue;
						}
						toProcess = entries;
						entries = new ArrayList<Entry>(toProcess.size());
					}
					Set<ExecutionId> added = new HashSet<ExecutionId>();
					ArrayList<ExecutionId> removed = new ArrayList<ExecutionId>();
					Map<OperatorAndPhase,List<QpTuple<?>>> scanned = new HashMap<OperatorAndPhase,List<QpTuple<?>>>();
					List<NodeAndOp> finished = new ArrayList<NodeAndOp>();
					List<Exception> exceptions = new ArrayList<Exception>();
					Map<OperatorAndPhase,List<QpTuple<?>>> missing = new HashMap<OperatorAndPhase,List<QpTuple<?>>>();
					Set<InetSocketAddress> failed = new HashSet<InetSocketAddress>();

					for (Entry e : toProcess) {
						if (e.type == EntryType.ADDED) {
							ExecutionId tid = (ExecutionId) e.o;
							if (! removed.remove(tid)) {
								added.add(tid);
							}
						} else if (e.type == EntryType.REMOVED) {
							ExecutionId tid = (ExecutionId) e.o;
							if (! added.remove(tid)) {
								removed.add(tid);
							}
						} else if (e.type == EntryType.SCANNED) {
							TupleAndOp tao = (TupleAndOp) e.o;
							OperatorAndPhase oap = new OperatorAndPhase(tao.operatorId, tao.phaseNo);
							List<QpTuple<?>> scannedForOp = scanned.get(oap);
							if (scannedForOp == null) {
								scannedForOp = new ArrayList<QpTuple<?>>();
								scanned.put(oap, scannedForOp);
							}
							scannedForOp.add(tao.t);
						} else if (e.type == EntryType.FINISHED) {
							finished.add((NodeAndOp) e.o);
						} else if (e.type == EntryType.EXCEPTION) {
							exceptions.add((Exception) e.o);
						} else if (e.type == EntryType.MISSING) {
							TupleAndOp tao = (TupleAndOp) e.o;
							OperatorAndPhase oap = new OperatorAndPhase(tao.operatorId, tao.phaseNo);
							List<QpTuple<?>> missingForOp = missing.get(oap);
							if (missingForOp == null) {
								missingForOp = new ArrayList<QpTuple<?>>();
								missing.put(oap, missingForOp);
							}
							missingForOp.add(tao.t);
						} else if (e.type == EntryType.FAILED) {
							failed.add((InetSocketAddress) e.o);
						} else {
							throw new IllegalStateException("Need to write code to process entry type " + e.type);
						}
					}

					if (added.isEmpty() && removed.isEmpty() && scanned.isEmpty() && missing.isEmpty() && finished.isEmpty() && exceptions.isEmpty() && failed.isEmpty()) {
						continue;
					}
					List<? extends QpMessage> rtms = RecordTuplesMessage.build(dest, added, removed, scanned, finished, exceptions, failed, missing, queryId);
					for (final QpMessage rtm : rtms) {
						outstandingMessages.add(rtm.messageId);
						sentMessages.add(rtm.messageId);
						try {
							app.sendMessageAwaitReply(rtm, new ReplyContinuation() {
								boolean finished = false;
								public synchronized boolean isFinished() {
									return finished;
								}

								public synchronized void processReply(Message m) {
									finished = true;
									outstandingMessages.remove(rtm.messageId);
									if ((m instanceof DoesNotHaveQuery) || (m instanceof ReplySendingFailed)) {
										return;
									} else if (! (m instanceof ReplySuccess)) {
										Exception e = new Exception("Error sending RecordTuplesMessage to " + dest + ": " + m);
										logger.error(e);
									}
								}
							}, ReplySuccess.class);
						} catch (IOException e) {
							logger.error(e);
						}
					}
				}
			} catch (InterruptedException ie) {
				return;
			}
		}
	}

	public synchronized void keysScanned(int operatorId, List<QpTuple<?>> keys, int phaseNo) {
		for (QpTuple<?> key : keys) {
			entries.add(Entry.scanned(key, operatorId, phaseNo));
		}
	}


	public synchronized void tuplesAdded(Collection<ExecutionId> tupleIds) {
		for (ExecutionId tupleId : tupleIds) {
			entries.add(Entry.added(tupleId));
		}
	}


	public synchronized void tuplesRemoved(Collection<ExecutionId> tupleIds) {
		for (ExecutionId tupleId : tupleIds) {
			entries.add(Entry.removed(tupleId));
		}
	}


	public synchronized void operatorHasFinished(int operatorId, InetSocketAddress nodeId) {
		entries.add(new Entry(new NodeAndOp(nodeId,operatorId)));
	}

	public synchronized void reportException(Exception e) {
		entries.add(new Entry(e));
	}

	public synchronized void keysNotFound(int operatorId, List<QpTuple<?>> keys, int phaseNo) {
		for (QpTuple<?> key : keys) {
			entries.add(Entry.missing(key, operatorId, phaseNo));
		}
	}

	int getOutstandingMessages() {
		return outstandingMessages.size();
	}

	int getSentMessages() {
		return sentMessages.size();
	}
}

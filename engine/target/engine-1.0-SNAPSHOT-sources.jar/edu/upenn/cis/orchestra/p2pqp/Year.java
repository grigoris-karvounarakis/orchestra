package edu.upenn.cis.orchestra.p2pqp;

import edu.upenn.cis.orchestra.datamodel.Date;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.datamodel.DateType;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.Type;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;

public class Year extends Function {
	private static final long serialVersionUID = 1L;
	private static Year instance = null;
		
	public static synchronized Year getInstance() {
		if (instance == null) {
			instance = new Year();
		}
		return instance;
	}
	
	private Year() {
	}
	
	public boolean equals(Object o) {
		return (o instanceof Year);
	}

	public synchronized Object evaluateFunction(Object[] inputs)
			throws ValueMismatchException, EvaluateException {
		if (inputs.length != 1) {
			throw new IllegalArgumentException("Year takes one input");
		}
		Object o = inputs[0];
		if (o instanceof Date) {
			return ((Date) o).getYear();
		} else {
			throw new ValueMismatchException(o, DateType.DATE);
		}
	}

	public int getNumInputs() {
		return 1;
	}

	public Type getOutputType() {
		return IntType.INT;
	}

	public int hashCode() {
		return 1776;
	}

	public boolean isValidForInput(int pos, Type inputType) {
		if (pos != 0) {
			throw new IllegalArgumentException("Year takes one argument");
		}
		return inputType.canPutInto(DateType.DATE);
	}
	

	protected void subclassSerialize(Document d, Element e,
			Map<String, QpSchema> schemas) {
	}

	public static Year deserialize(Element e, Map<String,QpSchema> schemas) {
		return getInstance();
	}
}

package edu.upenn.cis.orchestra.p2pqp;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;

public class RelativeProvenance extends TupleProvenance {
	
	public static class InvalidOp extends Exception {
		private static final long serialVersionUID = 1L;
		public InvalidOp() {
			super();
		}
		public InvalidOp(String str) {
			super(str);
		}
	}
	
	public static abstract class Node {
		public ProvToken token;
		public static String getOpName(OP_TYPE op) {
			if (op == OP_TYPE.AND)
				return "AND";
			else if (op == OP_TYPE.OR)
				return "OR";
			else
				return "LEAF";
		}
		public abstract List<ProvToken> getChildren();
		public abstract int getNumChildren();
		public abstract ProvToken getChildAt(int i) throws InvalidOp ;
		public abstract boolean addChild(ProvToken c) throws InvalidOp;
		
		public abstract boolean merge(Node n2) throws InvalidOp;
		public abstract boolean join(Node n2) throws InvalidOp;
		
		public abstract void setZero(ProvToken tok);
		
		/** Returns true if this subtree already contains
		 * a conjunctive expression like n2.  ORs are disallowed.
		 * @param n2
		 */
		//public abstract boolean contains(Node n2) throws InvalidOp;
		
		public abstract byte[] getBytes();
		//public abstract byte[] getBytes(ByteBufferWriter bbw);
		
		/** Deep copy */
		public abstract Node copy();
		
		public OP_TYPE getOpType() { return op; }
		
		/*
		public static Node fromBytes(byte[] ar) {
			return fromBytes(new ByteBufferReader(null, ar));
		}
		*/
		public static Node fromBytes(byte[] buf) {
			ByteBufferReader brr = new ByteBufferReader(null, buf);
			
			byte[] provTokenBuf = brr.readByteArray();
			ProvToken tok = ProvToken.fromBytes(provTokenBuf);
			
			int typ = brr.readInt();
			int opid = brr.readInt();
			
			Node ret;
			int count;
			switch (typ) {
			case 0:
				byte[] nestedBuf = brr.readByteArray();
				ret = new EdbNode(KeyandEpoch.fromBytes(nestedBuf), tok, opid);
				break;
			case 1:
				ret = new IdbNode(tok, OP_TYPE.AND, opid);
				count = brr.readInt();
				for (int i = 0; i < count; i++)
					try {
						byte[] Buf = brr.readByteArray();
						if (Buf != null)
							ret.addChild(ProvToken.fromBytes(Buf));
					} catch (InvalidOp o) {
					}
				break;
			case 2:
				ret = new IdbNode(tok, OP_TYPE.OR, opid);
				count = brr.readInt();
				for (int i = 0; i < count; i++)
					try {
						//ret.addChild(ProvToken.fromBytes(brr));
						byte[] Buf = brr.readByteArray();
						if (Buf != null)
							ret.addChild(ProvToken.fromBytes(Buf));
					} catch (InvalidOp o) {
					}
				break;
			default:
				ret = null;
			}
			return ret;
		}
		
		public enum OP_TYPE {AND, OR, LEAF};
		public int operatorid;
		public OP_TYPE op;
	}
	
	public static class IdbNode extends Node {
		public IdbNode(ProvToken tok, OP_TYPE typ, int producer) {
			token = tok;
			operatorid = producer;
			op = typ;
			children = new ArrayList<ProvToken>();
		}
		
		public IdbNode copy() {
			IdbNode two = new IdbNode(token, op, operatorid);
			
			try {
				for (ProvToken n : children) {
					two.addChild(n);
				}
			} catch (InvalidOp io) {
				
			}
			
			return two;
		}
		
		// Merge two nodes -- should ONLY make sense for OR nodes
		public boolean merge(Node n2) throws InvalidOp {
			if (op == OP_TYPE.OR && (!(n2 instanceof IdbNode) || 
					n2.op != OP_TYPE.OR)) {
				if (!children.contains(n2.token)) {
					children.add(n2.token);
					return true;
				}
				return false;
			} else if (n2.op != op) {
				//System.out.println(n2.op+" "+op);
				//System.out.println(n2.toString());
				throw new InvalidOp(getOpName(n2.op) + " should match " + getOpName(op));
			}
			
			// Don't merge AND nodes -- they should be the same
			if (op == OP_TYPE.AND)
				return false;
			
			IdbNode i = (IdbNode)n2;
			
			boolean added = false;
			for (ProvToken k : i.children)
				if (!children.contains(k)) {
					children.add(k);
					added = true;
				}
			
			return added;
		}
		
		public void setZero(ProvToken tok) {
			if (children.contains(tok))
				if (op == OP_TYPE.AND)
					children.clear();
				else
					children.remove(tok);
		}
		
		// Join two AND nodes
		public boolean join(Node n2) throws InvalidOp {
			if (!(n2 instanceof IdbNode) || n2.op != op)
				throw new InvalidOp();
			
			// Don't merge AND nodes -- they should be the same
			if (op != OP_TYPE.AND)
				return false;
			
			IdbNode i = (IdbNode)n2;
			
			boolean added = false;
			for (ProvToken k : i.children)
				if (!children.contains(k)) {
					children.add(k);
					added = true;
				}
			
			return added;
		}
		
		public byte[] getBytes() {
			ByteBufferWriter bbw = new ByteBufferWriter(); 
			bbw.addToBuffer(token.getBytes());
			if (op == OP_TYPE.AND)
				bbw.addToBuffer(1);
			else if (op == OP_TYPE.OR)
				bbw.addToBuffer(2);
			bbw.addToBuffer(operatorid);
			bbw.addToBuffer(children.size());
			for (int i = 0; i < children.size(); i++) {
				try {
					bbw.addToBuffer(getChildAt(i).getBytes());
				} catch (InvalidOp io) {	
				}
			}
			return bbw.getByteArray();
		}
		/*
		public byte[] getBytes(ByteBufferWriter bbw) {
			token.getBytes(bbw);
			if (op == OP_TYPE.AND)
				bbw.addToBuffer(1);
			else if (op == OP_TYPE.OR)
				bbw.addToBuffer(2);
			bbw.addToBuffer(operatorid);
			bbw.addToBuffer(children.size());
			for (int i = 0; i < getNumChildren(); i++) {
				try {
					//bbw.addToBuffer(getChildAt(i).getBytes(bbw));
					getChildAt(i).getBytes(bbw);
				} catch (InvalidOp io) {
					
				}
			}
			
			return bbw.getByteArray();
		}
		*/
		
		public void remove(int i) {
			children.remove(i);
		}

		/*
		public boolean contains(Node n2) throws InvalidOp {
			if (op == OP_TYPE.AND) {
				if (n2.op == OP_TYPE.OR)
					throw new InvalidOp();
				
				// Same tuple derived but different op that derived it
				if (n2.operatorid != operatorid)
					return false;
				
				// Conjunction of a different length
				if (n2.getNumChildren() != getNumChildren())
					return false;

				// See if the children match
				for (int i = 0; i < getNumChildren(); i++) {
					if (!getChildAt(i).contains(n2.getChildAt(i)))
						return false;
				}
				return true;
			} else {
				for (Node child : children) {
					if (child.contains(n2))
						return true;
				}
			}
			return false;
		}*/
		
		public int getNumChildren() { return children.size(); }
		public ProvToken getChildAt(int i) throws InvalidOp {
			if (i < children.size())
				return children.get(i);
			else
				throw new InvalidOp(); 
		}
		public List<ProvToken> getChildren() {
			return children;
		}
		
		public boolean addChild(ProvToken c) throws InvalidOp {
			if (!children.contains(c)) {
				children.add(c);
				return true;
			} else
				return false;
		}

		public String toString() {
			StringBuffer buf = new StringBuffer();
			String oper;
			if (op == OP_TYPE.OR) {
				oper = "+";
			} else {
				oper = "*";
			}
			
			buf.append("(" + children.get(0).toString() + ")");
			for (int i = 1; i < children.size(); i++)
				buf.append(" " + oper + 
						" (" + children.get(i).toString() + ")");
			
			return new String(buf);
		}

		public ArrayList<ProvToken> children;
	}
	
	public static class EdbNode extends Node {
		public EdbNode(KeyandEpoch key, ProvToken tok, int producer) {
			base = key;
			token = tok;
			op = OP_TYPE.LEAF;
			operatorid = producer;
		}
		public EdbNode copy() {
			return new EdbNode(base, token, operatorid);
		}
		public int getNumChildren() { return 0; }
		public ProvToken getChildAt(int i) throws InvalidOp { throw new InvalidOp(); }
		public boolean addChild(ProvToken c) throws InvalidOp { return false; }
		public List<ProvToken> getChildren() {
			return new ArrayList<ProvToken>();
		}
		
		public boolean merge(Node n2) throws InvalidOp {
			return false;
		}
		public boolean join(Node n2) throws InvalidOp {
			return false;
		}
		/*
		public boolean contains(ProvToken n2) {
			if (!(n2 instanceof EdbNode))
				return false;
			
			return (operatorid == n2.operatorid && 
					base.equals(((EdbNode)n2).base));
		}*/
		
		public void setZero(ProvToken tok) {
			
		}
		
		public String toString() {
			return base.toString();
		}
		
		public byte[] getBytes() {
			ByteBufferWriter bbw = new ByteBufferWriter();
			bbw.addToBuffer(token.getBytes());
			bbw.addToBuffer(0);
			bbw.addToBuffer(operatorid);
			bbw.addToBuffer(base.getBytes());
			return bbw.getByteArray();
		}

		public KeyandEpoch base;
	}
	
	ProvToken provRoot;
	Map<ProvToken,Node> provenances;
	int thisOp;
	
	public RelativeProvenance(KeyandEpoch key, int producer) {
		//int prod = t.getId().operatorId;
		thisOp = producer;
		//Node rt = new IdbNode(Node.OP_TYPE.OR, producer);
		
		provenances = new HashMap<ProvToken,Node>();

		//try {
			
			ProvToken token = new ProvToken(key.getKey(), thisOp);
			EdbNode edb = new EdbNode(key, token, producer);
			//rt.addChild(token);
			provenances.put(token, edb);
			provRoot = token;
			/*
		} catch (InvalidOp io) {
			io.printStackTrace();
		}*/
	}

	public RelativeProvenance(RelativeProvenance old) {
		thisOp = old.thisOp;
		//provRoot = new IdbNode(Node.OP_TYPE.OR, old.thisOp);
		
		provenances = new HashMap<ProvToken,Node>();
		for (ProvToken tok : old.provenances.keySet()) {
			provenances.put(tok, old.provenances.get(tok).copy());
		}
		provRoot = old.provRoot;
	}
	
	/*
	public RelativeProvenance(int producer) {
		thisOp = producer;
		provRoot = new IdbNode(Node.OP_TYPE.OR, producer);		
	}*/
	
	protected RelativeProvenance(ProvToken pr, int producer) {
		provenances = new HashMap<ProvToken,Node>();
		provRoot = pr;
		thisOp = producer;
	}

	@Override
	public RelativeProvenance copy() {
		RelativeProvenance rel = new RelativeProvenance(this);
		return rel;
	}

	// this - r_2
	@Override
	public TupleProvenance differenceWith(TupleProvenance r_2) {
		/*
		if (!(r_2 instanceof RelativeProvenance))
			return null;
		RelativeProvenance r2 = (RelativeProvenance)r_2;
		
		RelativeProvenance r3 = new RelativeProvenance(this);
		
		if (r2.provenances.get(r2.provRoot).op != Node.OP_TYPE.OR || 
				r3.provenances.get(r3.provRoot).op != Node.OP_TYPE.OR)
			throw new RuntimeException("Unexpected: not a sum of products!");

		r3.provenances.clear();
		r3.provenances.put(r3.provRoot, new IdbNode(provRoot, Node.OP_TYPE.OR, thisOp));
		try {
			// Copy our root's children *unless* they are in r2
			for (ProvToken tok: provenances.get(provRoot).getChildren()) {
				if (!r2.provenances.get(r2.provRoot).getChildren().contains(tok))
					r3.provenances.get(r3.provRoot).addChild(tok);
			}
				
		} catch (InvalidOp op) {
			op.printStackTrace();
		}
		
		r3.setCreator(thisOp);
        */
            //TupleProvenance newone = new RelativeProvenance(this).setZero(r_2);
			
			if (!(r_2 instanceof RelativeProvenance))
				return null;
			RelativeProvenance r2 = (RelativeProvenance)r_2;
			
			RelativeProvenance r3 = new RelativeProvenance(this);
			
			if (r2.provenances.get(r2.provRoot).op != Node.OP_TYPE.OR || 
					r3.provenances.get(r3.provRoot).op != Node.OP_TYPE.OR)
				throw new RuntimeException("Unexpected: not a sum of products!");

			r3.provenances.clear();
			r3.provenances.put(r3.provRoot, new IdbNode(provRoot, Node.OP_TYPE.OR, thisOp));
			try {
				// Copy our root's children *unless* they are in r2
				for (ProvToken tok: provenances.get(provRoot).getChildren()) {
					if (!r2.provenances.get(r2.provRoot).getChildren().contains(tok))
						r3.provenances.get(r3.provRoot).addChild(tok);
				}
					
			} catch (InvalidOp op) {
				op.printStackTrace();
			}
			
			r3.setCreator(thisOp);
            return r3;    
		
	}

	@Override
	public boolean equalProvenance(TupleProvenance r_2) {
		if (!(r_2 instanceof RelativeProvenance))
			return false;
		//RelativeProvenance r2 = (RelativeProvenance)r_2;

		return contains(r_2) && r_2.contains(new RelativeProvenance(this));
		//return provRoot.equals(r2.provRoot);
	}
	
	@Override
	public boolean contains(TupleProvenance r_2) {
		if (!(r_2 instanceof RelativeProvenance))
			return false;
		RelativeProvenance r2 = (RelativeProvenance)r_2;
        if (r2.differenceWith(new RelativeProvenance(this)).isZero()) {
           return true;	
        } else {
        	return false;
        }
	}

	@Override
	public byte[] getBytes() {
		ByteBufferWriter bww = new ByteBufferWriter();
		
		bww.addToBuffer(provRoot.getBytes());
		//provRoot.getBytes(bww);
	//	bww.addToBuffer(0x1331);
		bww.addToBuffer(thisOp);
		bww.addToBuffer(provenances.size());
		
		for (ProvToken t : provenances.keySet()) {
			bww.addToBuffer(0xbadf00d);
			bww.addToBuffer(t.getBytes());
			//t.getBytes(bww);
			bww.addToBuffer(provenances.get(t).getBytes());
			//provenances.get(t).getBytes(bww);
		}
		return bww.getByteArray();
	}
	
	public static RelativeProvenance fromBytes(byte[] buf) {
		ByteBufferReader brr = new ByteBufferReader(null, buf);
		
		//Node pr = Node.fromBytes(brr);
		byte[] bytes = brr.readByteArray();
		ProvToken tok = ProvToken.fromBytes(bytes);

		int op = brr.readInt();
		int count = brr.readInt();

		RelativeProvenance rp = new RelativeProvenance(tok, op);
		for (int i = 0; i < count; i++) {
			
			int test = brr.readInt();
			if (test != 0xbadf00d)
				System.err.println("err");
			
			byte[] provBytes = brr.readByteArray();
			ProvToken k = ProvToken.fromBytes(provBytes);
			
			byte[] nodeBytes = brr.readByteArray();
			Node n = Node.fromBytes(nodeBytes);
			
			rp.provenances.put(k, n);			
		}
		return rp;
	}

	@Override
	public boolean isZero() {
		return provenances == null || provenances.size() == 0 || (provenances.get(provRoot) instanceof IdbNode && provenances.size() ==1);
	}

	@Override
	public TupleProvenance derive(int oper) {
		RelativeProvenance r3 = new RelativeProvenance(this);
		
		ProvToken newToken = new ProvToken(provRoot, oper);
		Node newOr = new IdbNode(newToken, Node.OP_TYPE.OR, oper);
		r3.provenances.put(newToken, newOr);
		try {
			newOr.addChild(provRoot);
		} catch (InvalidOp io) {
			
		}
		r3.provRoot = newToken;
		r3.setCreator(oper);

		return r3;
	}
	@Override
	public TupleProvenance joinWith(TupleProvenance r_2) {
		if (!(r_2 instanceof RelativeProvenance))
			return null;
		RelativeProvenance r2 = (RelativeProvenance)r_2;
		
		RelativeProvenance r3 = new RelativeProvenance(this);
		
//		r3.provRoot = new ProvToken(provRoot, thisOp);
		
		// Create a blank OR node
		r3.provenances.put(r3.provRoot, new IdbNode(r3.provRoot, Node.OP_TYPE.OR, thisOp));
		
		// Take each of r2, r3 and for each provRoot child, join them
		Node r2r = r2.provenances.get(r2.provRoot);
		Node tr = provenances.get(provRoot);
		
		try {
			if (r2r.op != Node.OP_TYPE.OR || tr.op != Node.OP_TYPE.OR) {
				ProvToken joinToken = new ProvToken(provRoot, r2.provRoot, thisOp);
				r3.provenances.get(r3.provRoot).addChild(joinToken);
				
				// Union in all of the provenances from r2
				for (ProvToken tok : r2.provenances.keySet()) {
					if (r3.provenances.get(tok) == null) {
						r3.provenances.put(tok, r2.provenances.get(tok).copy());
					}
				}
				
			} else {
				// Do a cross-product on the provenances
				for (ProvToken pt : tr.getChildren()) {
					for (ProvToken pt2 : r2r.getChildren()) {
						ProvToken joinToken = new ProvToken(pt, pt2, thisOp);
						r3.provenances.get(r3.provRoot).addChild(joinToken);
					}
				}
	
				// Union in all of the provenances from r2
				for (ProvToken tok : r2.provenances.keySet()) {
					if (r3.provenances.get(tok) == null) {
						r3.provenances.put(tok, r2.provenances.get(tok).copy());
					}
				}
			}
		} catch (InvalidOp op) {
			op.printStackTrace();
		}
		
		r3.setCreator(thisOp);

		return r3;
	}
	
	@Override
	public TupleProvenance find(TupleProvenance r_2) {
		if (!(r_2 instanceof RelativeProvenance))
			return null;
		RelativeProvenance r2 = (RelativeProvenance)r_2;
		return new RelativeProvenance(r2);
	}

	@Override
	public TupleProvenance setZero(TupleProvenance p) {
		if (!(p instanceof RelativeProvenance))
			return null;
		RelativeProvenance r2 = (RelativeProvenance)p;
		
		RelativeProvenance ret = copy();
		
		if (provenances.keySet().contains(r2.provRoot)) {
			boolean changed = false;
			//changed |= 
			provenances.remove(r2.provRoot);
			
			ProvToken rem = r2.provRoot;
			do {
				changed = false;
				
				ArrayList<ProvToken> toRemove = new ArrayList<ProvToken>();
				// Zero out all references to this token
				for (ProvToken t : provenances.keySet()) {
					Node n = provenances.get(t);
					int count = n.getNumChildren();
					n.setZero(rem);
					
					// Did we change the number of children?
					if (n.getNumChildren() > 0 && n.getNumChildren() != count)
						if (removeIfUnderivable(t))
							toRemove.add(t);
				}
				while (toRemove.size() > 0) {
					rem = toRemove.get(0);
					toRemove.remove(0);
					provenances.remove(rem);
					// Zero out all references to this token
					for (ProvToken t : provenances.keySet()) {
						Node n = provenances.get(t);
						int count = n.getNumChildren();
						n.setZero(rem);
						
						// Did we change the number of children?
						if (n.getNumChildren() > 0 && n.getNumChildren() != count)
							if (removeIfUnderivable(t))
								toRemove.add(t);
					}
				}
				
				// Find the first token that's empty
				for (ProvToken t : provenances.keySet())
					if (provenances.get(t).getOpType() != Node.OP_TYPE.LEAF
							&& provenances.get(t).getNumChildren() == 0) {
						changed = true;
						rem = t;
						break;
					}
			} while (changed);
		}
		
		ret.setCreator(thisOp);
		return ret;
	}

	@Override
	public int size() {
		return provenances.size();
	}

	@Override
	public String toString() {
		return provRoot.toString();
	}

	// Union this with r_2
	@Override
	public TupleProvenance unionWith(TupleProvenance r_2) {
		if (!(r_2 instanceof RelativeProvenance))
			return null;
		RelativeProvenance r2 = (RelativeProvenance)r_2;
		
		RelativeProvenance r3 = new RelativeProvenance(this);
		
		
		if (r2.provenances.get(r2.provRoot).op != Node.OP_TYPE.OR) {
			r3.provenances.put(r3.provRoot, new IdbNode(r2.provRoot, Node.OP_TYPE.OR, thisOp));
		}
		
			
		try {
			for (ProvToken tok: provenances.get(provRoot).getChildren())
				r3.provenances.get(r3.provRoot).addChild(tok);
			for (ProvToken tok: r2.provenances.get(r2.provRoot).getChildren())
				r3.provenances.get(r3.provRoot).addChild(tok);
			
			for (ProvToken tok : r2.provenances.keySet()) {
				
				if (r3.provenances.get(tok) == null) {
					r3.provenances.put(tok, r2.provenances.get(tok).copy());
				} else {
					// Get the various tokens' content and merge it
					r3.provenances.get(tok).merge(r2.provenances.get(tok));					
				}
			}
		} catch (InvalidOp op) {
			op.printStackTrace();
		}
		
		r3.setCreator(thisOp);

		return r3;
	}
	
	protected boolean isDerivableFromEdb(ProvToken t, Set<ProvToken> visited) {
		Node us = provenances.get(t);
		visited.add(t);
		if (us.op == Node.OP_TYPE.LEAF)
			return true;
		else if (us.op == Node.OP_TYPE.AND) {
			boolean isDer = true;
			for (int i = 0; i < us.getNumChildren(); i++) {
				try {
					if (!visited.contains(us.getChildAt(i)))
						isDer = isDer && isDerivableFromEdb(us.getChildAt(i), visited);
					if (!isDer)
						return false;
				} catch (InvalidOp io) {
					
				}
			}
			return true;
		} else { // OR node -- need to find only one satisfying case
			boolean isDer = false;
			for (int i = 0; i < us.getNumChildren(); i++) {
				try {
					if (!visited.contains(us.getChildAt(i)))
						isDer = isDer || isDerivableFromEdb(us.getChildAt(i), visited);
					if (isDer)
						return true;
				} catch (InvalidOp io) {
					
				}
			}
			return false;
		}
	}
	
	protected boolean removeIfUnderivable(ProvToken t) {
		Set<ProvToken> visited = new HashSet<ProvToken>();
		
		if (!isDerivableFromEdb(t, visited)) {
			return true;
		} else
			return false;
	}

}

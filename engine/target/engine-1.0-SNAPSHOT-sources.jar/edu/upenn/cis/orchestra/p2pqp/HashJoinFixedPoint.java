package edu.upenn.cis.orchestra.p2pqp;

import static edu.upenn.cis.orchestra.p2pqp.ExecutionId.UNKNOWN_PHASE_NO;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public class HashJoinFixedPoint<M> extends PipelinedHashJoin<M> {

	public HashJoinFixedPoint(Operator<M> dest, WhichChild outputDest, int queryId, InetSocketAddress nodeId, int operatorId,
			RecordTuples rt, MetadataFactory<M> mdf, 
			QpSchema baseSchema, QpSchema recursiveSchema, List<Integer> baseJoinIndices,
			List<Integer> recursiveJoinIndices, List<Integer> baseOutputPos, List<Integer> recursiveOutputPos) {
		super(baseSchema, recursiveSchema,
				baseJoinIndices, recursiveJoinIndices, baseOutputPos, recursiveOutputPos, false, 
				baseSchema, dest, outputDest, queryId, nodeId, operatorId, rt, mdf, false);
	}

	@Override
	protected void receiveTuples(List<QpTuple<M>> tuples) {
		// Output left tuples before they join with anything
		// if they haven't already been stored (and therefore output)
		Set<QpTuple<M>> outputTuples = new HashSet<QpTuple<M>>();
		List<ExecutionId> addedTuples = new ArrayList<ExecutionId>();

		for (QpTuple<M> t : tuples) {
			if (t.isLeft() && (! hasLeftTuple(t))) {
				QpTuple<M> newT = t.changeId(getFreshId(UNKNOWN_PHASE_NO)); 
				outputTuples.add(newT);
				addedTuples.add(newT.getId());
			}
		}
		if (! outputTuples.isEmpty()) {
			tuplesAdded(addedTuples);
			super.sendTuples(new ArrayList<QpTuple<M>>(outputTuples));
		}
		super.receiveTuples(tuples);
	}

	@Override
	protected void sendTuples(List<QpTuple<M>> tuples) {
		for (QpTuple<?> t : tuples) {
			t.setDest(WhichChild.LEFT);
		}
		receiveTuples(tuples);
	}
}

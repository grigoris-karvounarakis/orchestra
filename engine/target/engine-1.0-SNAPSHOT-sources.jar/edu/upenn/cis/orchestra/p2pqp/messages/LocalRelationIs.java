package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.MetadataFactory;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class LocalRelationIs extends QpMessage {
	private static final long serialVersionUID = 1L;
	public final int relationId;
	private final byte[] tuples;

	public <M> LocalRelationIs(InetSocketAddress dest, int relationId, Collection<QpTuple<M>> tuples, MetadataFactory<M> mdf) {
		super(dest);
		ByteBufferWriter bbw = new ByteBufferWriter();
		for (QpTuple<M> t : tuples) {
			if (t.getSchema().relId != relationId) {
				throw new IllegalArgumentException("Tuple " + t + " does not belong to correct relation");
			}
			bbw.addToBuffer(t.getStoreBytes(mdf));
		}

		this.relationId = relationId;
		this.tuples = bbw.getByteArray();
	}
	
	private LocalRelationIs(InetSocketAddress dest, LocalRelationIs other) {
		super(dest);
		this.relationId = other.relationId;
		this.tuples = other.tuples;
	}
	
	public LocalRelationIs retarget(InetSocketAddress newDest) {
		return new LocalRelationIs(newDest, this);
	}

	public <M> List<QpTuple<M>> getTuples(QpSchema.Source findSchema, MetadataFactory<M> mdf) {
		List<QpTuple<M>> tuples = new ArrayList<QpTuple<M>>();
		ByteBufferReader bbr = new ByteBufferReader(this.tuples);

		QpSchema schema = findSchema.getSchema(relationId);
		
		while (! bbr.hasFinished()) {
			byte[] tBytes = bbr.readByteArray();

			QpTuple<M> t = QpTuple.fromBytes(QpTuple.SerializationMode.STORE, schema, findSchema, mdf, tBytes, null);
			tuples.add(t);
		}

		return tuples;
	}

	public LocalRelationIs(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf,origin);
		relationId = buf.readInt();
		tuples = buf.readBytes();
	}
	
	@Override
	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(relationId);
		buf.writeBytes(tuples);
	}
}

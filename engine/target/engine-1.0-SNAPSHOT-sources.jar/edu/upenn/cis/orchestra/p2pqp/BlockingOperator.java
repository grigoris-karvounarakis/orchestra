package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public abstract class BlockingOperator<M> extends Operator<M> {
	public BlockingOperator(Operator<M> dest, WhichChild destInput, int queryId,
			InetSocketAddress nodeId, int operatorId, RecordTuples rt, MetadataFactory<M> mdf, boolean enableRecovery) {
		super(dest, destInput, queryId, nodeId, operatorId, mdf, rt, enableRecovery);
	}
	
	public abstract void finish(int blockSize);
}

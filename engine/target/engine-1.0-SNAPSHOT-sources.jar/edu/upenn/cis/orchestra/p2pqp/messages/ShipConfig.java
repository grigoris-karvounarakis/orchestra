package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class ShipConfig extends QpMessage {
	private static final long serialVersionUID = 1L;
	public final boolean batchShips;
	
	public ShipConfig(InetSocketAddress dest, boolean batchShips) {
		super(dest);
		this.batchShips = batchShips;
	}
	
	public ShipConfig(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf,origin);
		this.batchShips = buf.readBoolean();
	}

	@Override
	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeBoolean(batchShips);
	}
}

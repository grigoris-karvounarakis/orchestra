package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.List;

import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public class FixpointReceiverOperator<M> extends Operator<M> {
	
	public FixpointReceiverOperator(Operator<M> dest,
			WhichChild destInput, int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt,
			MetadataFactory<M> mdf) {
		super(dest, destInput, queryId, nodeId, operatorId, mdf, rt, false);
	}

	protected void receiveTuples(List<QpTuple<M>> tuples) {
		sendTuples(tuples);	
	}
}

package edu.upenn.cis.orchestra.p2pqp.plan;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.datamodel.ForeignKey;
import edu.upenn.cis.orchestra.datamodel.AbstractRelation.GetSchema;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class QueryPlanWithSchemas {
	public final QueryPlan qp;
	public final double expectedCost;
	public final Map<String,QpSchema> querySchemas;

	public QueryPlanWithSchemas(QueryPlan qp, Collection<? extends QpSchema> schemas) {
		this(qp,schemas,Double.NaN);
	}
	
	public QueryPlanWithSchemas(QueryPlan qp, Collection<? extends QpSchema> schemas, double expectedCost) {
		this.qp = qp;
		Map<String,QpSchema> querySchemas = new HashMap<String,QpSchema>(schemas.size());
		for (QpSchema s : schemas) {
			querySchemas.put(s.getName(), s);
		}
		this.querySchemas = Collections.unmodifiableMap(querySchemas);
		this.expectedCost = expectedCost;
	}

	public QueryPlanWithSchemas(QueryPlan qp, Map<String,QpSchema> schemas) {
		this(qp,schemas,Double.NaN);
	}
	public QueryPlanWithSchemas(QueryPlan qp, Map<String,QpSchema> schemas, double expectedCost) {
		this.qp = qp;
		querySchemas = Collections.unmodifiableMap(new HashMap<String,QpSchema>(schemas));
		this.expectedCost = expectedCost;
	}

	public void serialize(Document doc, Element el, Map<String,QpSchema> otherSchemas) {
		NumberFormat nf = NumberFormat.getInstance();
		List<QpSchema> schemas = new ArrayList<QpSchema>(querySchemas.values());
		Collections.sort(schemas, new Comparator<QpSchema>() {
			public int compare(QpSchema s1, QpSchema s2) {
				String s1name = s1.getName();
				String s2name = s2.getName();
				List<ForeignKey> fks = new ArrayList<ForeignKey>(s2.getForeignKeys());
				for (int pos = 0; pos < fks.size(); ++pos) {
					ForeignKey fk = fks.get(pos);
					String refRel = fk.getRefRelation().getName(); 
					if (refRel.equals(s1name)) {
						return -1;
					}
					if (querySchemas.containsKey(refRel)) {
						fks.addAll(querySchemas.get(refRel).getForeignKeys());
					}
				}
				fks.clear();
				fks.addAll(s1.getForeignKeys());
				for (int pos = 0; pos < fks.size(); ++pos) {
					ForeignKey fk = fks.get(pos);
					String refRel = fk.getRefRelation().getName(); 
					if (refRel.equals(s2name)) {
						return 1;
					}
					if (querySchemas.containsKey(refRel)) {
						fks.addAll(querySchemas.get(refRel).getForeignKeys());
					}
				}
				return 0;
			}

		});
		
		Map<String,QpSchema> combined = new UnionMap(otherSchemas,querySchemas);
		
		Element queryPlan = DomUtils.addChild(doc, el, "queryPlan");
		if (! Double.isNaN(expectedCost)) {
			queryPlan.setAttribute("expectedCost", nf.format(expectedCost));
		}
		queryPlan.appendChild(qp.serialize(doc, combined));
		for (QpSchema s : schemas) {
			el.appendChild(s.serialize(doc));
		}
	}

	public static QueryPlanWithSchemas deserialize(Element el, final Map<String,QpSchema> otherSchemas) throws XMLParseException {
		final Map<String,QpSchema> newSchemas = new HashMap<String,QpSchema>(); 
		GetSchema<QpSchema> gs = new GetSchema<QpSchema>() {
			public QpSchema getSchema(String name) {
				QpSchema qs = otherSchemas.get(name);
				if (qs != null) {
					return qs;
				}
				return newSchemas.get(name);
			}
		};
		Element queryPlan = DomUtils.getChildElementByName(el, "queryPlan");
		if (queryPlan == null) {
			throw new XMLParseException("Missing queryPlan node", el);
		}
		List<Element> serializedQps = DomUtils.getChildElements(queryPlan);
		if (serializedQps.isEmpty() || serializedQps.size() > 1) {
			throw new XMLParseException("Expected one child", queryPlan);
		}

		List<Element> schemaEls = DomUtils.getChildElementsByName(el, "QpSchema");
		for (Element schemaEl : schemaEls) {
			QpSchema s = QpSchema.deserialize(schemaEl, gs);
			newSchemas.put(s.getName(), s);
		}

		Map<String,QpSchema> schemas = new UnionMap(otherSchemas, newSchemas);

		QueryPlan qp = QueryPlan.deserializePlan(serializedQps.get(0), schemas);
		String expectedCostStr = queryPlan.getAttribute("expectedCost");
		double expectedCost = Double.NaN;
		if (expectedCostStr.length() != 0) {
			NumberFormat nf = NumberFormat.getInstance();
			try {
				expectedCost = nf.parse(expectedCostStr).doubleValue();
			} catch (ParseException e) {
				throw new XMLParseException("Error parsing expected cost", e, queryPlan);
			}
		}

		return new QueryPlanWithSchemas(qp,newSchemas, expectedCost);
	}

	private static class UnionMap implements Map<String,QpSchema> {
		private Map<String,QpSchema> otherSchemas;
		private Map<String,QpSchema> newSchemas;

		UnionMap(Map<String,QpSchema> otherSchemas, Map<String,QpSchema> newSchemas) {
			this.otherSchemas = otherSchemas;
			this.newSchemas = newSchemas;
		}


		public void clear() {
			throw new UnsupportedOperationException();
		}

		public boolean containsKey(Object key) {
			return otherSchemas.containsKey(key) || newSchemas.containsKey(key);
		}

		public boolean containsValue(Object value) {
			throw new UnsupportedOperationException();
		}

		public Set<java.util.Map.Entry<String, QpSchema>> entrySet() {
			throw new UnsupportedOperationException();
		}

		public QpSchema get(Object key) {
			QpSchema qs = otherSchemas.get(key);
			if (qs != null) {
				return qs;
			}
			return newSchemas.get(key);
		}

		public boolean isEmpty() {
			return otherSchemas.isEmpty() && newSchemas.isEmpty();
		}

		public Set<String> keySet() {
			throw new UnsupportedOperationException();
		}

		public QpSchema put(String key, QpSchema value) {
			throw new UnsupportedOperationException();
		}

		public void putAll(Map<? extends String, ? extends QpSchema> m) {
			throw new UnsupportedOperationException();
		}

		public QpSchema remove(Object key) {
			throw new UnsupportedOperationException();
		}

		public int size() {
			throw new UnsupportedOperationException();
		}

		public Collection<QpSchema> values() {
			throw new UnsupportedOperationException();
		}			
	};

}

package edu.upenn.cis.orchestra.p2pqp;

import java.util.Collection;

import edu.upenn.cis.orchestra.p2pqp.QpSchema.Source;


public class NullMetadataFactory implements MetadataFactory<Null> {
	public Null agg(Operator<Null> o, Collection<Null> inputs) {
		return null;
	}

	public Null applyFunctions(Operator<Null> o, Null m) {
		return null;
	}

	public String printMetadata(Null m) {
		return null;
	}
	
	public Null fromBytes(Source findSchema, IdFactory idf, MetadataFactory<Null> mdf, byte[] bytes, ExecutionId tupleId) {
		return null;
	}
	
	public Null derive(Operator<Null> o, Null m) {
		return null;
	}

	public Null join(Operator<Null> o, Null leftMetadata, Null rightMetadata) {
		return null;
	}

	public Null scan(Operator<Null> o, Null m) {
		return null;
	}

	public byte[] toBytes(Null m) {
		return null;
	}
	
	private NullMetadataFactory() {
	}

	private static final NullMetadataFactory instance;
	
	static {
		instance = new NullMetadataFactory();
	}
	
	public static NullMetadataFactory getInstance() {
		return instance;
	}


	public Null combineMetadata(Null m1, Null m2) {
		return null;
	}

	public boolean shouldDelete(Null m) {
		return false;
	}

    public Null differenceMetadata(Null newMetadata, Null oldMetadata) {
    	return null;
    }
	
	public Null setZero(Null origMetadata, Null testMetadata) {
		return null;
	}
	
	public Null duplicate(Null m) {
		return  null;
	}
}

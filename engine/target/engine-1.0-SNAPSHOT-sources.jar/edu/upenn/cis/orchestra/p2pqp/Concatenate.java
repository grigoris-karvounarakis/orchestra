package edu.upenn.cis.orchestra.p2pqp;

import edu.upenn.cis.orchestra.datamodel.StringType;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.Type;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Concatenate extends Function {
	private static final long serialVersionUID = 1L;
	private final boolean allowVaryingInputs;
	private final String[] betweenInputs;
	private final int[] inputLengths;
	private final StringType outputType;
	
	public Concatenate(boolean allowVaryingInputs, List<String> betweenInputs, List<Integer> inputLengths) {
		if (betweenInputs.size() != (inputLengths.size() + 1)) {
			throw new IllegalArgumentException("betweenInputs must have one more entry that inputLengths");
		}
		this.betweenInputs = betweenInputs.toArray(new String[betweenInputs.size()]);
		this.inputLengths = new int[inputLengths.size()];
		for (int i = 0; i < this.inputLengths.length; ++i) {
			this.inputLengths[i] = inputLengths.get(i);
		}
		this.allowVaryingInputs = allowVaryingInputs;
		int length = 0;
		for (int inputLength : inputLengths) {
			length += inputLength;
		}
		for (String s : betweenInputs) {
			if (s != null) {
				length += s.length();
			}
		}
		outputType = new StringType(false, allowVaryingInputs, length);
	}
	
	@Override
	public boolean equals(Object o) {
		if (o == null || o.getClass() != this.getClass()) {
			return false;
		}
		Concatenate c = (Concatenate) o;
		if (allowVaryingInputs != c.allowVaryingInputs) {
			return false;
		}
		if (inputLengths.length != c.inputLengths.length) {
			return false;
		}
		
		if (! Arrays.equals(inputLengths, c.inputLengths)) {
			return false;
		}
		
		return (Arrays.equals(betweenInputs, c.betweenInputs));
	}

	@Override
	public Object evaluateFunction(Object[] inputs) throws ValueMismatchException, EvaluateException {
		
		//input can also be IntType
		if (inputs.length != inputLengths.length) {
			throw new EvaluateException("Incorrect number of inputs");
		}
		for (int i = 0; i < inputs.length; ++i) {
			if (inputs[i] == null) {
				return null;
			}
			/*
			Type t = new StringType(false,allowVaryingInputs,inputLengths[i]);
			if (! t.isValidForColumn(inputs[i])) {
				throw new ValueMismatchException(inputs[i], t);
			}*/
		}
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < inputs.length; ++i) {
			if (betweenInputs[i] != null) {
				sb.append(betweenInputs[i]);
			}
			
			String str = inputs[i].toString();
			if (str.length() > inputLengths[i]) {
				throw new EvaluateException("Incorrect input length");
			}
			sb.append(str);
		}
		if (betweenInputs[inputs.length] != null) {
			sb.append(betweenInputs[inputs.length]);
		}
		return sb.toString();
	}

	@Override
	public int getNumInputs() {
		return inputLengths.length;
	}

	@Override
	public Type getOutputType() {
		return outputType;
	}

	@Override
	public int hashCode() {
		return Arrays.hashCode(inputLengths) + 37 * Arrays.hashCode(betweenInputs) + (allowVaryingInputs ? 79 : 0);
	}

	@Override
	public boolean isValidForInput(int pos, Type inputType) {
		if (pos >= inputLengths.length) {
			throw new IllegalArgumentException("Function does not have " + (pos + 1) + " inputs");
		}
		if (! (inputType instanceof StringType)) {
			if (inputType instanceof IntType) {
				if (IntType.bytesPerInt > inputLengths[pos]) {
					return false;
				}
				return true;
			} else {
				return false;
			}
		}
		StringType st = (StringType) inputType;
		if (((! allowVaryingInputs) && st.isVariableLength()) || st.getLength() > inputLengths[pos]) {
			return false;
		}
		return true;
	}

	@Override
	protected void subclassSerialize(Document d, Element e,
			Map<String, QpSchema> schemas) {
		e.setAttribute("allowVaryingInputs", Boolean.toString(allowVaryingInputs));
		final int numInputs = inputLengths.length;
		
		for (int i = 0; i < numInputs; ++i) {
			if (betweenInputs[i] != null) {
				Element literal = DomUtils.addChild(d, e, "literal");
				literal.setAttribute("value", betweenInputs[i]);
			} else {
				Element literal = DomUtils.addChild(d, e, "literal");
				literal.setAttribute("value", "");
			}
			Element input = DomUtils.addChild(d, e, "input");
			input.setAttribute("length", Integer.toString(inputLengths[i]));
		}
		if (betweenInputs[numInputs] != null) {
			Element string = DomUtils.addChild(d, e, "literal");
			string.setAttribute("value", betweenInputs[numInputs]);
		}
	}
	
	public static Concatenate deserialize(Element e, Map<String,QpSchema> schemas) throws XMLParseException {
		boolean allowVaryingInputs = Boolean.parseBoolean(getAttribute(e, "allowVaryingInputs"));
		List<Element> els = DomUtils.getChildElements(e);
		List<Integer> inputLengths = new ArrayList<Integer>();
		List<String> betweenInputs = new ArrayList<String>();
		
		boolean gotBetween = false;
		for (Element el : els) {
			String tag = el.getTagName();
			if (tag.equals("literal")) {
				if (gotBetween) {
					throw new XMLParseException("Cannot have two consecutive literals in Concatenate function", el);
				} else {
					betweenInputs.add(getAttribute(el, "value"));
					gotBetween = true;
				}
			} else if (tag.equals("input")) {
				try {
					int length = Integer.parseInt(getAttribute(el,"length"));
					inputLengths.add(length);
				} catch (NumberFormatException nfe) {
					throw new XMLParseException("Invalid string length", nfe, el);
				}
				if (! gotBetween) {
					betweenInputs.add(null);
				}
				gotBetween = false;
			}
		}
		
		if (betweenInputs.size() != (inputLengths.size() + 1)) {
			throw new IllegalArgumentException("betweenInputs must have one more entry that inputLengths");
		}
		
		return new Concatenate(allowVaryingInputs, betweenInputs, inputLengths);
	}

}

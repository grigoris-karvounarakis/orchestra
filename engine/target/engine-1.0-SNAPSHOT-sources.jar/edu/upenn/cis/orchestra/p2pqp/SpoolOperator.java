package edu.upenn.cis.orchestra.p2pqp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class SpoolOperator<M> extends Operator<M> {
	private Collection<QpTuple<M>> tuples;

	public SpoolOperator(Collection<QpTuple<M>> tuples, int operatorId,
			RecordTuples rt, MetadataFactory<M> mdf) {
		super(null,null,operatorId,mdf,rt);

		this.tuples = tuples;
	}

	protected void receiveTuples(List<QpTuple<M>> tuples) {
		synchronized (this.tuples) {
			TUPLE: for (QpTuple<M> tuple : tuples) {
				if (failedNodeIds != null) {
					final ExecutionId id = tuple.getId();
					for (byte[] nodeId : failedNodeIds) {
						if (id.containsNodeId(nodeId)) {
							continue TUPLE;
						}
					}
				}
				this.tuples.add(tuple);
			}
		}

		List<ExecutionId> tids = new ArrayList<ExecutionId>(tuples.size());
		for (QpTuple<?> qt : tuples) {
			tids.add(qt.getId());
		}
		tuplesRemoved(tids);
	}

	protected void close() {
		tuples = null;
	}

	private byte[][] failedNodeIds = null;

	protected void disposeOfFailedTuples(int newPhaseNo, byte[][] failedNodeIds) {
		synchronized (this.tuples) {
			Iterator<QpTuple<M>> it = tuples.iterator();
			TUPLE: while (it.hasNext()) {
				final QpTuple<M> t = it.next();
				final ExecutionId id = t.getId();
				for (byte[] nodeId : failedNodeIds) {
					if (id.containsNodeId(nodeId)) {
						it.remove();
						continue TUPLE;
					}
				}
			}

			if (this.failedNodeIds == null) {
				this.failedNodeIds = failedNodeIds;
			} else {
				byte[][] newFailedNodeIds = new byte[this.failedNodeIds.length + failedNodeIds.length][];
				System.arraycopy(this.failedNodeIds, 0, newFailedNodeIds, 0, this.failedNodeIds.length);
				System.arraycopy(failedNodeIds, 0, newFailedNodeIds, this.failedNodeIds.length, failedNodeIds.length);
			}
		}
	}

}

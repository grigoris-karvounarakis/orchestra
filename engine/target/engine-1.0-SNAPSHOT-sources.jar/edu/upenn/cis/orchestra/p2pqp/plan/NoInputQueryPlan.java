package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.upenn.cis.orchestra.p2pqp.QpSchema.Source;

abstract class NoInputQueryPlan extends QueryPlan {
	public NoInputQueryPlan(String outputSchema, Location loc,
			int operatorId, boolean isReplicated) {
		super(outputSchema, loc, operatorId, getDescendents(), isReplicated);
	}

	final public Iterator<QueryPlanAndDest> iterator() {
		List<QueryPlanAndDest> empty = Collections.emptyList();
		return empty.iterator();
	}
		
	private static Set<Integer> getDescendents() {
		return Collections.emptySet();
	}
	
	void getRecoveryJoinOperators(Map<Integer, int[]> opsHashCols, List<Integer> hashCols, Source schemas, boolean prevStatfulOperatorIsAgg) {
	}
}

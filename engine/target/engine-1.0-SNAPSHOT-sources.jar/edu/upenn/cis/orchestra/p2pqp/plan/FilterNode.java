package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.Filter;
import edu.upenn.cis.orchestra.p2pqp.FilterOperator;
import edu.upenn.cis.orchestra.p2pqp.FilterSerialization;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;


public class FilterNode extends OneInputQueryPlan {
	private static final long serialVersionUID = 1L;

	private final List<byte[]> filterBytes;

	public FilterNode(QpSchema ns,
			Collection<? extends Filter<? super QpTuple<?>>> filters, Location loc, int operatorId,
			QueryPlan input) {
		super(ns.getRelationName(), ns.getRelationName(), loc, operatorId, input);

		this.filterBytes = new ArrayList<byte[]>(filters.size());
		for (Filter<? super QpTuple<?>> f : filters) {
			this.filterBytes.add(FilterSerialization.getBytes(f, ns));
		}
	}

	@Override
	<M> Operator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) {
		QpSchema ns = exec.getSchema(inputSchema);
		List<Filter<? super QpTuple<?>>> filters = new ArrayList<Filter<? super QpTuple<?>>>(this.filterBytes.size());
		for (byte[] bytes : this.filterBytes) {
			filters.add(FilterSerialization.fromBytes(ns, bytes));
		}
		return new FilterOperator<M>(filters, parent, dest, operatorId, exec.app.getMetadataFactory(), exec.getRecordTuples());
	}

	@Override
	protected boolean subclassEquals(OneInputQueryPlan qp) {
		if (qp instanceof FilterNode) {
			FilterNode fn = (FilterNode) qp;
			if (fn.filterBytes.size() != filterBytes.size()) {
				return false;
			}
			OUTER: for (byte[] f1 : filterBytes) {
				for (byte[] f2 : fn.filterBytes) {
					if (Arrays.equals(f1, f2)) {
						continue OUTER;
					}
				}
				return false;
			}
			OUTER2: for (byte[] f1 : fn.filterBytes) {
				for (byte[] f2 : filterBytes) {
					if (Arrays.equals(f1, f2)) {
						continue OUTER2;
					}
				}
				return false;
			}
			return true;
		}	else {
			return false;
		}
	}

	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc,el,schemas);
		QpSchema ns = schemas.get(outputSchema);
		if (ns == null) {
			throw new IllegalArgumentException("Schemas for " + outputSchema + " not found");
		}
		for (byte[] fb : filterBytes) {
			Filter<? super QpTuple<?>> f = FilterSerialization.fromBytes(ns, fb);
			Element filterEl = DomUtils.addChild(doc, el, "filter");
			FilterSerialization.serialize(doc, filterEl, f, ns);
		}
	}

	public static FilterNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan input = getInputQueryPlan(el,schemas,alreadyIds);
		QpSchema ns = schemas.get(qpd.outputSchema);
		
		List<Filter<? super QpTuple<?>>> filters = new ArrayList<Filter<? super QpTuple<?>>>();
		List<Element> filterEls = DomUtils.getChildElementsByName(el, "filter");
		for (Element filterEl : filterEls) {
			filters.add(FilterSerialization.deserialize(filterEl, ns));
		}
		
		return new FilterNode(ns, filters, qpd.loc, qpd.operatorId, input);
	}

}

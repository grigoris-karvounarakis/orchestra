package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.TimerTask;

import edu.upenn.cis.orchestra.p2pqp.messages.ReplyTimeout;

class ReplyData {
	final ReplyContinuation rc;
	final Message m;
	private final int retryDelay;
	private final int replyTimeout;
	private int retriesRemaining;
	private TimerTask pendingAction;
	final Class<?> successReplies[];
	private boolean hasFinished;
	private boolean receivedTimeoutOrFailure;
	private boolean sent;
	
	InetSocketAddress sentTo;

	ReplyData(ReplyContinuation rc, Message m, int retryDelay, int numRetries, int replyTimeout, Class<?> successReplies[]) {
		this.rc = rc;
		this.m = m;
		this.retryDelay = retryDelay;
		this.retriesRemaining = numRetries;
		this.replyTimeout = replyTimeout;
		this.successReplies = successReplies;
		hasFinished = false;
		sent = false;
		receivedTimeoutOrFailure = false;
	}
			
	synchronized void cancelPendingAction() {
		if (pendingAction != null) {
			pendingAction.cancel();
			pendingAction = null;
		}
	}
	
	synchronized void startPendingAction(QpApplication<?> app) {
		if (hasFinished) {
			return;
		}
		
		cancelPendingAction();

		if (app.socketManager.throttles(sentTo)) {
			return;
		}
		
		if (receivedTimeoutOrFailure) {
			pendingAction = app.scheduleResendMessage(this, retryDelay);
		} else if (sent && replyTimeout != 0) {
			pendingAction = app.scheduleDeliverMessage(new ReplyTimeout(m), replyTimeout);
		}
	}

	synchronized void setSentTo(InetSocketAddress dest) {
		sentTo = dest;
	}
			
	synchronized void recordFailure() {
		this.receivedTimeoutOrFailure = true;
		--retriesRemaining;
	}
	
	synchronized void resend(QpApplication<?> app) throws IOException, InterruptedException {
		if (! this.receivedTimeoutOrFailure) {
			return;
		}
		this.receivedTimeoutOrFailure = false;
		app.sendMessageAwaitReply(this);
	}
	
	synchronized boolean hasFinished() {
		return hasFinished;
	}
	
	synchronized void setFinished() {
		hasFinished = true;
		cancelPendingAction();
	}
	
	synchronized boolean retriesLeft() {
		return retriesRemaining > 0;
	}
	
	synchronized void setSent() {
		this.sent = true;
		this.receivedTimeoutOrFailure = false;
	}	
}
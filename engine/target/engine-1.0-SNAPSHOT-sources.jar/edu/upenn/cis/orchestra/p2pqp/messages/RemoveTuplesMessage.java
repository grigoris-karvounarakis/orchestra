package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.p2pqp.Id;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class RemoveTuplesMessage extends DHTMessage {
	private static final long serialVersionUID = 1L;
	private final byte[] tuples;

	public RemoveTuplesMessage(Id dest, Collection<QpTuple<?>> ts) {
		super(dest);
		Map<Integer,List<byte[]>> toRemove = new HashMap<Integer,List<byte[]>>();
		for (QpTuple<?> t : ts) {
			int relId = t.getSchema().relId;
			List<byte[]> forRel = toRemove.get(relId);
			if (forRel == null) {
				forRel = new ArrayList<byte[]>();
				toRemove.put(relId, forRel);
			}
			forRel.add(t.getKeyBytes());
		}
		
		ByteBufferWriter bbw = new ByteBufferWriter();
		for (Map.Entry<Integer, List<byte[]>> me : toRemove.entrySet()) {
			bbw.addToBuffer(me.getKey());
			bbw.addToBuffer(me.getValue().size());
			for (byte[] t : me.getValue()) {
				bbw.addToBuffer(t);
			}
		}
		
		this.tuples = bbw.getByteArray();
	}

	public Map<Integer,List<byte[]>> getKeys() {
		Map<Integer,List<byte[]>> retval = new HashMap<Integer,List<byte[]>>();
		ByteBufferReader bbr = new ByteBufferReader(tuples);
		while (! bbr.hasFinished()) {
			int relId = bbr.readInt();
			int size = bbr.readInt();
			List<byte[]> tuples = new ArrayList<byte[]>(size);
			while (size > 0) {
				tuples.add(bbr.readByteArray());
				--size;
			}
			retval.put(relId, tuples);
		}
		return retval;
	}

	public String toString() {
		return "RemoveTuple";
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeBytes(tuples);
	}

	public RemoveTuplesMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		tuples = buf.readBytes();
	}
}

package edu.upenn.cis.orchestra.p2pqp.plan;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.ShipOperator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema.Source;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class ShipNode extends OneInputQueryPlan {
	private static final long serialVersionUID = 1L;

	private final boolean doesRehash;
	private final String namedDest;
	private final int[] newToOld;

	public ShipNode(QpSchema outputSchema, Location loc, int operatorId, QueryPlan input) {
		this(outputSchema,null,outputSchema,loc,operatorId,input);
	}
	
	public ShipNode(QpSchema inputSchema, Map<Integer,Integer> schemaMapping, QpSchema outputSchema, Location loc, int operatorId, QueryPlan input) {	
		super(inputSchema.getRelationName(), outputSchema.getRelationName(), loc, operatorId, input);
		edu.upenn.cis.orchestra.p2pqp.QpSchema.Location schemaLoc = outputSchema.getLocation();
		if (schemaLoc == edu.upenn.cis.orchestra.p2pqp.QpSchema.Location.STRIPED) {
			doesRehash = true;
			namedDest = null;
		} else if (schemaLoc == edu.upenn.cis.orchestra.p2pqp.QpSchema.Location.NAMED) {
			doesRehash = false;
			namedDest = outputSchema.getNamedLocation();
		} else {
			doesRehash = false;
			namedDest = null;
		}
		if (this.inputSchema.equals(this.outputSchema)) {
			this.newToOld = null;
		} else if (schemaMapping != null) {
			// newToOld[i] contains the index in the old schema from which to take field i in the new schema
			newToOld = new int[outputSchema.getNumCols()];
			Set<Integer> remaining = new HashSet<Integer>();
			if (schemaMapping.size() != outputSchema.getNumCols()) {
				throw new IllegalArgumentException("Schema mapping should contain same number of entries as the new schema");
			}
			for (int i = 0; i < newToOld.length; ++i) {
				remaining.add(i);
			}
			for (Map.Entry<Integer, Integer> me : schemaMapping.entrySet()) {
				if (me.getKey() == null || me.getValue() == null) {
					throw new NullPointerException("Schema mapping should not contain null mapping");
				}
				int key = me.getKey(), value = me.getValue();
				newToOld[value] = key;
				remaining.remove(value);
			}
			if (! remaining.isEmpty()) {
				throw new IllegalArgumentException("Schema mapping does not give source for fields " + remaining + " in new schema");
			}
		} else {
			throw new NullPointerException("Must specify schema mapping when ship node changes schema");
		}
	}

	@Override
	<M> ShipOperator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
			throws Operator.OperatorCreationException {

		InetSocketAddress node;
		if (doesRehash) {
			node = null;
		} else if (namedDest != null) {
			node = exec.getNamedNode(namedDest);
		} else {
			node = exec.owner;
		}

		ShipOperator<M> ship = null;
		if (outputSchema.equals(inputSchema)) {
			ship = new ShipOperator<M>(exec.app, exec, node, namedDest, exec.queryId, exec.getNodeAddress(), operatorId, exec.app.getMetadataFactory(), exec.getRecordTuples(), allowRecovery);
		} else {
			ship = new ShipOperator<M>(exec.app, exec, exec.getSchema(outputSchema), newToOld, node, namedDest, exec.queryId, exec.getNodeAddress(), operatorId, exec.app.getMetadataFactory(), exec.getRecordTuples(), allowRecovery);
		}
		
		return ship;
	}

	@Override
	public <M> void createCentralExecution(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException {
		if (parent != null) {
			exec.setDestOperator(parent, dest, outputSchema);
		}
		super.createCentralExecution(exec, parent, dest, allowRecovery);
	}

	@Override
	public <M> void createDistributedExecution(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException {
		if (parent != null) {
			exec.setDestOperator(parent, dest, outputSchema);
		}
		super.createDistributedExecution(exec, parent, dest, allowRecovery);
	}

	@Override
	public <M> void createNamedExecution(String name, QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException {
		if (parent != null) {
			exec.setDestOperator(parent, dest, outputSchema);
		}
		super.createNamedExecution(name, exec, parent, dest, allowRecovery);
	}

	@Override
	protected boolean subclassEquals(OneInputQueryPlan qp) {
		if (qp instanceof ShipNode) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc, el, schemas);
		if (newToOld != null) {
			Element mapping = DomUtils.addChild(doc, el, "mapping");
			for (int i = 0; i < newToOld.length; ++i) {
				Element entry = DomUtils.addChild(doc, mapping, "entry");
				entry.setAttribute("inputPos", Integer.toString(newToOld[i]));
				entry.setAttribute("outputPos", Integer.toString(i));
			}
		}
	}
	
	public static ShipNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan input = getInputQueryPlan(el, schemas, alreadyIds);
		QpSchema inputSchema = schemas.get(input.outputSchema);
		QpSchema outputSchema = schemas.get(qpd.outputSchema);
		Element mapping = DomUtils.getChildElementByName(el, "mapping");
		Map<Integer,Integer> schemaMapping = null;
		if (mapping != null) {
			List<Element> entries = DomUtils.getChildElementsByName(mapping, "entry");
			schemaMapping = new HashMap<Integer,Integer>(entries.size());
			for (Element entry : entries) {
				String inputPos = entry.getAttribute("inputPos");
				String outputPos = entry.getAttribute("outputPos");
				if (inputPos.length() == 0 || outputPos.length() == 0) {
					throw new XMLParseException("Each schema mapping entry must have an inputPos and an outputPos", entry);
				}
				try {
					int inputPosInt = Integer.parseInt(inputPos);
					int outputPosInt = Integer.parseInt(outputPos);
					schemaMapping.put(inputPosInt, outputPosInt);
				} catch (NumberFormatException nfe) {
					throw new XMLParseException(nfe, entry);
				}
			}
		}
		
		ShipNode ret = new ShipNode(inputSchema, schemaMapping, outputSchema, qpd.loc, qpd.operatorId, input);
		return ret;
	}
	
	void getRecoveryJoinOperators(Map<Integer, int[]> opsHashCols, List<Integer> hashCols, Source schemas, boolean prevStatfulOperatorIsAgg) {
		if (doesRehash) {
			QpSchema outputSchema = schemas.getSchema(this.outputSchema);
			hashCols = new ArrayList<Integer>();
			for (int hashCol : outputSchema.getHashCols()) {
				hashCols.add(hashCol);
			}
			if (newToOld != null) {
				for (int i = 0; i < hashCols.size(); ++i) {
					hashCols.set(i, newToOld[i]);
				}
			}
			input.getRecoveryJoinOperators(opsHashCols, hashCols, schemas, false);
		} else {
			input.getRecoveryJoinOperators(opsHashCols, hashCols, schemas, false);
		}
	}

}

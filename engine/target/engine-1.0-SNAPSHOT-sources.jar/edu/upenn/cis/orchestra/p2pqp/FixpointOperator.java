package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

//import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.datamodel.Subtuple;
import edu.upenn.cis.orchestra.datamodel.Type;
import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.datamodel.exceptions.NotNumericalException;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.optimization.Aggregate.AggFunc;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.p2pqp.plan.AggregateNode.OutputColumn;

public class FixpointOperator<M> extends Operator<M>{
	private final String leftSchema, rightSchema;
	private final QpSchema outputSchema; 
	private int[] groupingColumns = null;
	private OutputColumn[] outputColumns = null;
	private final HashMap<Subtuple,Collection<QpTuple<Null>>> aggregateTable;
	// Per Tuple per aggregate function, maintain aggregateTuples but didn't propagate aggregateTuples
	private final HashMap<Subtuple,List<QpTuple<Null>>> aggregateTuples;
	//private final HashMap<Subtuple, M> subTupleMetadata;
	private final HashMap<QpTuple<Null>,M> aggregateMetadata;
	private final HashMap<QpTuple<Null>,M> storeMetadata; 
	public static enum MaintenanceMode {Lazy, Eager};
	public static MaintenanceMode maintenanceMode = MaintenanceMode.Eager;
	public static boolean aggregateMode = false;
	private Operator<M> loopBackOp = null;
	
	public FixpointOperator(QpApplication<M> app, String leftSchema, String rightSchema, QpSchema outputSchema, 
			Operator<M> dest, WhichChild outputDest, int queryId, InetSocketAddress nodeId, int operatorId, 
			RecordTuples rt, MetadataFactory<M> mdf) {
		this(app, null, null, leftSchema, rightSchema, outputSchema, ShipOperator.defaultShipIntervalMs, dest, outputDest, queryId, 
				nodeId, operatorId, rt, mdf);
		
	}
	
	public FixpointOperator(QpApplication<M> app, List<Integer> groupingColumns, List<OutputColumn> outputColumns, String leftSchema, String rightSchema, QpSchema outputSchema, 
			Operator<M> dest, WhichChild outputDest, int queryId, InetSocketAddress nodeId, int operatorId, 
			RecordTuples rt, MetadataFactory<M> mdf) {
		this(app, groupingColumns, outputColumns, leftSchema, rightSchema, outputSchema, ShipOperator.defaultShipIntervalMs, dest, 
				outputDest, queryId, nodeId, operatorId, rt, mdf);
		
	}
	
	public FixpointOperator(QpApplication<M> app, List<Integer> groupingColumns, List<OutputColumn> outputColumns, String leftSchema, String rightSchema, QpSchema outputSchema, int ShipIntervalMs,
			Operator<M> dest, WhichChild outputDest, int queryId, InetSocketAddress nodeId, int operatorId,
			RecordTuples rt, MetadataFactory<M> mdf) {
		
		super(dest,outputDest,queryId, nodeId, operatorId, mdf, rt, false);
		
		this.leftSchema = leftSchema;
	    this.rightSchema = rightSchema;
        this.outputSchema = outputSchema;
	    
		if (mdf == null || mdf instanceof NullMetadataFactory) {
			this.storeMetadata = null;
			this.aggregateTable = null;
			this.aggregateTuples = null;
			this.aggregateMetadata = null;
			//this.subTupleMetadata = null;
		} else {
			this.storeMetadata = new HashMap<QpTuple<Null>,M>();
			this.aggregateTable = new HashMap<Subtuple, Collection<QpTuple<Null>>>();
			this.aggregateTuples = new HashMap<Subtuple,List<QpTuple<Null>>>();
			this.aggregateMetadata = new HashMap<QpTuple<Null>,M>();
			//this.subTupleMetadata = new HashMap<Subtuple, M>();
		}
		
		if (groupingColumns != null && outputColumns != null) {
			aggregateMode = true;
			this.groupingColumns = new int[groupingColumns.size()];
			int pos = 0;
			for (int col : groupingColumns) {
				this.groupingColumns[pos] = col;
				++pos;
			}
			this.outputColumns = new OutputColumn[outputColumns.size()];
			pos = 0;
			for (OutputColumn oc: outputColumns) {
				this.outputColumns[pos] = oc;
				++pos;
			}
		}
		//sendThread.start();
	}

	
	protected void close() {
		synchronized(this) {
			if (storeMetadata != null) { 
				try {	
					long bytesSum = 0;
					//PrintStream fs = new PrintStream("resultTuples.csv");
					//fs.flush(); 
					for (QpTuple<Null> tuple: storeMetadata.keySet()) {
						M metadata = storeMetadata.get(tuple);
					    long thisBytes = mdf.toBytes(metadata).length;
					    //System.out.println("FixpointTuple "+tuple+" : "+mdf.printMetadata(metadata));
						bytesSum += thisBytes;
					}
					//fs.close();
					
					Statistics.totalTupleNum += storeMetadata.size();
					Statistics.totalTupleSize += bytesSum; 
					System.out.println(" Fixpoint Size:"+bytesSum+" Size:"+storeMetadata.size());	
				
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
			/*
			if (!pendingToShip.isEmpty()) {
				throw new RuntimeException("Not all shipped");
			}
			
			pendingToShip.clear();
			*/
			storeMetadata.clear();
			//aggregateMetadata.clear();
			loopBackOp = null;
		}
		
		/*
		try {
			sendThread.interrupt();
			sendThread.join();
		} catch (InterruptedException ie) {
			return;
		}*/
	}
	
	public void setLoopBack(Operator<M> loopBackOp) {
		this.loopBackOp = loopBackOp;
	}
	
	public boolean hasLoopBack() {
		return (loopBackOp != null);
	}
    
	@Override
	protected synchronized void receiveTuples(List<QpTuple<M>> tuples) {
		// TODO: Reimplement FixpointOperator to work with changes merged in from Nick's branch
		throw new UnsupportedOperationException("Need to re-implement based on version in subversion revision 7592");
	}
}

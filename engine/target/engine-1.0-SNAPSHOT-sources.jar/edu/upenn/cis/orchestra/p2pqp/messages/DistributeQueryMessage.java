package edu.upenn.cis.orchestra.p2pqp.messages;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

import org.xml.sax.InputSource;

import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.Router;
import edu.upenn.cis.orchestra.p2pqp.IndexService.EpochNum;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class DistributeQueryMessage extends QpMessage {
	private static final long serialVersionUID = 1L;

	private final byte[] qpws;
	public final int epoch;
	public final int queryId;
	public final Router queryRouter;
	public final boolean attemptRecovery;
	public final Map<Integer,Collection<EpochNum>> distributedScanOperatorPages;

	public DistributeQueryMessage(InetSocketAddress dest, String queryPlanWithSchemas,
			int epoch, int queryId, Router queryRouter, boolean attemptRecovery, Map<Integer,Collection<EpochNum>> distributedScanOperatorPages) {
		super(dest);
		this.epoch = epoch;
		this.queryId = queryId;
		this.queryRouter = queryRouter;
		this.attemptRecovery = attemptRecovery;

		Deflater compressor = new Deflater();
		compressor.setLevel(Deflater.BEST_SPEED);
		try {
			compressor.setInput(queryPlanWithSchemas.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
		compressor.finish();
		ByteBufferWriter bbw = new ByteBufferWriter();
		byte[] block = new byte[1024];
		while (! compressor.finished()) {
			int count = compressor.deflate(block);
			bbw.addToBufferNoLength(block, 0, count);
		}
		qpws = bbw.getByteArray();
		this.distributedScanOperatorPages = Collections.unmodifiableMap(new HashMap<Integer,Collection<EpochNum>>(distributedScanOperatorPages));
	}

	private DistributeQueryMessage(InetSocketAddress dest, byte[] qpws, int epoch, int queryId, Router queryRouter, boolean attemptRecovery, Map<Integer,Collection<EpochNum>> distributedScanOperatorPages) {
		super(dest);
		this.qpws = qpws;
		this.epoch = epoch;
		this.queryId = queryId;
		this.queryRouter = queryRouter;
		this.attemptRecovery = attemptRecovery;
		this.distributedScanOperatorPages = distributedScanOperatorPages;
	}
	
	public DistributeQueryMessage retarget(InetSocketAddress newDest) {
		return new DistributeQueryMessage(newDest, qpws, epoch, queryId, queryRouter, attemptRecovery, distributedScanOperatorPages);
	}
	
	public String toString() {
		return "DistributeQueryMessage(" + queryId + ")";
	}

	public InputSource getQPWSInputSource() {
		InputSource is = new InputSource(new InflaterInputStream(new ByteArrayInputStream(qpws)));
		is.setEncoding("UTF-8");
		return is;
	}
	
	public String getQueryPlansWithSchemas() {
		Inflater decompressor = new Inflater();
		decompressor.setInput(qpws);
		ByteBufferWriter bbw = new ByteBufferWriter();
		byte[] block = new byte[1024];
		try {
			while (! decompressor.finished()) {
				int count = decompressor.inflate(block);
				bbw.addToBufferNoLength(block, 0, count);
			}

			return new String(bbw.getByteArray(), "UTF-8");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeBytes(qpws);
		buf.writeInt(epoch);
		buf.writeInt(queryId);
		queryRouter.serialize(buf);
		buf.writeBoolean(attemptRecovery);
		buf.writeInt(distributedScanOperatorPages.size());
		for (Map.Entry<Integer, Collection<EpochNum>> me : distributedScanOperatorPages.entrySet()) {
			buf.writeInt(me.getKey());
			Collection<EpochNum> pages = me.getValue();
			buf.writeInt(pages.size());
			for (EpochNum en : pages) {
				buf.writeInt(en.epoch);
				buf.writeInt(en.num);
			}
		}
	}
	
	public DistributeQueryMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf,origin);
		qpws = buf.readBytes();
		epoch = buf.readInt();
		queryId = buf.readInt();
		queryRouter = Router.deserialize(buf);
		attemptRecovery = buf.readBoolean();
		int numDistScans = buf.readInt();
		Map<Integer,Collection<EpochNum>> distScanOpPages = new HashMap<Integer,Collection<EpochNum>>(numDistScans);
		for (int i = 0; i < numDistScans; ++i) {
			int op = buf.readInt();
			int numPages = buf.readInt();
			List<EpochNum> pages = new ArrayList<EpochNum>(numPages);
			for (int j = 0; j < numPages; ++j) {
				int epoch = buf.readInt();
				int num = buf.readInt();
				pages.add(new EpochNum(epoch,num));
			}
			distScanOpPages.put(op, Collections.unmodifiableList(pages));
		}
		this.distributedScanOperatorPages = Collections.unmodifiableMap(distScanOpPages);
		
	}

}

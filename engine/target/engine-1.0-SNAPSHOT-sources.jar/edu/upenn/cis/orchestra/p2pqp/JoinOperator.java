package edu.upenn.cis.orchestra.p2pqp;


interface JoinOperator {
	void inputHasFinished(boolean left);
	void inputsHaveNotFinished();
	boolean doPurge(boolean tryHard, boolean allowDestructive);
	boolean willBeAbleToPurgeAgain();
	int getOperatorId();
	void resendGeneratedTuples(int phaseNo);
	void resendGeneratedTuples(int phaseNo, int[] outputSchemaIdCols, IdRange[] neededRanges);
}

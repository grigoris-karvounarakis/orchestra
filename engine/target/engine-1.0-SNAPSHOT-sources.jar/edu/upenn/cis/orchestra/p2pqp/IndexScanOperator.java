package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;

import edu.upenn.cis.orchestra.p2pqp.Filter.FilterException;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public class IndexScanOperator<M> extends PullScanOperator<M> {
	private final Filter<? super QpTuple<?>> filter;
	private int numPagesRemaining = -1;
	private boolean done = false;
	private final QpApplication<M> app;
	private final int relationId;
	private final int epoch;

	public IndexScanOperator(QpApplication<M> app, Filter<? super QpTuple<?>> filter, int relationId, int epoch, Operator<M> dest, WhichChild destInput, int queryId,
			InetSocketAddress nodeId, int operatorId, RecordTuples rt, MetadataFactory<M> mdf, boolean enableRecovery) {
		super(dest, destInput, queryId, nodeId, operatorId, rt, mdf, enableRecovery);

		this.filter = filter;
		this.app = app;
		this.relationId = relationId;
		this.epoch = epoch;
	}

	@Override
	public synchronized boolean isFinished(int phaseNo) {
		return done;
	}

	@Override
	public void scan(int blockSize, int phaseNo) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void scanAll(final int blockSize, final int phaseNo) {
			app.index.getTuplesInRelation(relationId, epoch, new IndexService.TupleSink() {
				public void deliverTuples(QpTuple<?>[] contents) {
					boolean finished = false;
					synchronized (IndexScanOperator.this) {
						if (numPagesRemaining < 0) {
							reportException(new RuntimeException("NumPages < 0, totalNumTuplesIs is not being called"));
							return;
						}
						--numPagesRemaining;
						if (numPagesRemaining < 0) {
							reportException(new RuntimeException("NumPages < 0, pages are being delivered multiple times"));
							return;
						}
						if (numPagesRemaining == 0) {
							finished = true;
						}
					}

					ArrayList<QpTuple<M>> toSend = new ArrayList<QpTuple<M>>(blockSize);
					List<ExecutionId> scannedIds = new ArrayList<ExecutionId>(contents.length);


					int pos = 0;
					while (pos < contents.length && contents[pos] != null) {
						try {
							while (pos < contents.length && contents[pos] != null && toSend.size() < blockSize) {
								QpTuple<?> t = contents[pos++];
								if (filter == null || filter.eval(t)) {
									QpTuple<M> newT = t.getNonKeyTuple(getFreshId(phaseNo), (M) null); 
									toSend.add(newT);
									scannedIds.add(newT.getId());
								}
							}
						} catch (FilterException fe) {
							reportException(fe);
							return;
						}
						sendTuples(toSend);
						toSend.clear();
						tuplesAdded(scannedIds);
						scannedIds.clear();
					}


					if (finished) {
						synchronized (IndexScanOperator.this) {
							done = finished;
							IndexScanOperator.this.notifyAll();
						}
					}
				}

				public void processException(Exception e) {
					IndexScanOperator.this.reportException(e);
				}

				public void totalNumTuplesIs(int numTuples, int numPages) {
					synchronized (IndexScanOperator.this) {
						IndexScanOperator.this.numPagesRemaining = numPages;
					}
				}
			});
		try {
			synchronized (this) {
				while (! done) {
					wait();
				}
			}
		} catch (InterruptedException ie) {
			reportException(ie);
			return;
		}
	}

	@Override
	public synchronized void interrupt(int phaseNo) {
		done = true;
		notifyAll();
	}

}

package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.Id;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class GetTreePage extends IndexMessage {
	private static final long serialVersionUID = 1L;
	public final int relId, pageNum;
	
	public GetTreePage(Id dest, int relId, int pageNum) {
		super(dest);
		this.relId = relId;
		this.pageNum = pageNum;
	}
	
	public String toString() {
		return "GetTree(" + relId + "," + pageNum + ")";
	}
	
	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(relId);
		buf.writeInt(pageNum);
	}
	
	public GetTreePage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf,origin);
		this.relId = buf.readInt();
		this.pageNum = buf.readInt();
	}
}

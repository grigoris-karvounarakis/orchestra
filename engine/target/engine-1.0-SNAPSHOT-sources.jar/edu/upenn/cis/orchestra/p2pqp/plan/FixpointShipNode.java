package edu.upenn.cis.orchestra.p2pqp.plan;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.optimization.Aggregate.AggFunc;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.FixpointShipOperator;
import edu.upenn.cis.orchestra.p2pqp.plan.AggregateNode.OutputColumn;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class FixpointShipNode extends OneInputQueryPlan {
	private static final long serialVersionUID = 1L;

	private final boolean doesRehash;
	private final String namedDest;
	private final Map<Integer,Integer> schemaMapping;
	private List<Integer> groupingColumns = null;
	private List<OutputColumn> outputColumns = null;

	public void setGroupingAggregates(List<Integer> groupingColumns, List<OutputColumn> outputColumns) {
		if (groupingColumns != null && !groupingColumns.isEmpty()) {
			this.groupingColumns = new ArrayList<Integer>(groupingColumns);	
		}
		
		if (outputColumns != null && !outputColumns.isEmpty()) {
			this.outputColumns = new ArrayList<OutputColumn>(outputColumns);	
		}
	}
	public FixpointShipNode(QpSchema outputSchema, Location loc, int operatorId, QueryPlan input) {
		this(outputSchema,null,outputSchema,null, null, loc,operatorId,input);
	}
	
	public FixpointShipNode(QpSchema inputSchema, Map<Integer,Integer> schemaMapping, QpSchema outputSchema,  Location loc, int operatorId, QueryPlan input) {
		this(inputSchema, schemaMapping, outputSchema, null, null, loc, operatorId, input);
	}
	
	public FixpointShipNode(QpSchema inputSchema, Map<Integer,Integer> schemaMapping, QpSchema outputSchema, List<Integer> groupingColumns, List<OutputColumn> outputColumns, Location loc, int operatorId, QueryPlan input) {	
		super(inputSchema.getRelationName(), outputSchema.getRelationName(), loc, operatorId, input);
		edu.upenn.cis.orchestra.p2pqp.QpSchema.Location schemaLoc = outputSchema.getLocation();
		if (schemaLoc == edu.upenn.cis.orchestra.p2pqp.QpSchema.Location.STRIPED) {
			doesRehash = true;
			namedDest = null;
		} else if (schemaLoc == edu.upenn.cis.orchestra.p2pqp.QpSchema.Location.NAMED) {
			doesRehash = false;
			namedDest = outputSchema.getNamedLocation();
		} else {
			doesRehash = false;
			namedDest = null;
		}
		if (this.inputSchema.equals(this.outputSchema)) {
			this.schemaMapping = null;
		} else if (schemaMapping != null) {
			for (Map.Entry<?, ?> me : schemaMapping.entrySet()) {
				if (me.getKey() == null || me.getValue() == null) {
					throw new NullPointerException("Schema mapping should not contain null mapping");
				}
			}
			this.schemaMapping = new HashMap<Integer,Integer>(schemaMapping);
		} else {
			throw new NullPointerException("Must specify schema mapping when ship node changes schema");
		}
		if (groupingColumns != null && !groupingColumns.isEmpty()) {
			this.groupingColumns = new ArrayList<Integer>(groupingColumns);	
		}
		
		if (outputColumns != null && !outputColumns.isEmpty()) {
			this.outputColumns = new ArrayList<OutputColumn>(outputColumns);	
		}
	}

	@Override
	<M> FixpointShipOperator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
			throws Operator.OperatorCreationException {

		InetSocketAddress nodeAddress;
		if (doesRehash) {
			nodeAddress = null;
		} else if (namedDest != null) {
			nodeAddress = exec.getNamedNode(namedDest);
		} else {
			nodeAddress = exec.owner;
		}
		
		FixpointShipOperator<M> ship = null;
		if (outputSchema.equals(inputSchema)) {
			ship = new FixpointShipOperator<M>(exec.app, groupingColumns, outputColumns, parent, dest, nodeAddress, namedDest, exec.getNodeAddress(), exec.queryId, operatorId, exec.app.getMetadataFactory(), exec.getRecordTuples());
		} else {
			ship = new FixpointShipOperator<M>(exec.app, exec.getSchema(outputSchema), schemaMapping, groupingColumns, outputColumns, parent, dest, nodeAddress, namedDest, exec.getNodeAddress(), exec.queryId, operatorId, exec.app.getMetadataFactory(), exec.getRecordTuples());
		}
		
		return ship;
	}

	@Override
	public <M> void createCentralExecution(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException {
		if (parent != null) {
			exec.setDestOperator(parent, dest, outputSchema);
		}
		super.createCentralExecution(exec, parent, dest, allowRecovery);
	}

	@Override
	public <M> void createDistributedExecution(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException {
		if (parent != null) {
			exec.setDestOperator(parent, dest, outputSchema);
		}
		super.createDistributedExecution(exec, parent, dest, allowRecovery);
	}

	@Override
	public <M> void createNamedExecution(String name, QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery) throws Operator.OperatorCreationException {
		if (parent != null) {
			exec.setDestOperator(parent, dest, outputSchema);
		}
		super.createNamedExecution(name, exec, parent, dest, allowRecovery);
	}

	@Override
	protected boolean subclassEquals(OneInputQueryPlan qp) {
		if (qp instanceof FixpointShipNode) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc, el, schemas);
		if (schemaMapping != null) {
			Element mapping = DomUtils.addChild(doc, el, "mapping");
			for (Map.Entry<Integer, Integer> me : schemaMapping.entrySet()) {
				Element entry = DomUtils.addChild(doc, mapping, "entry");
				entry.setAttribute("inputPos", Integer.toString(me.getKey()));
				entry.setAttribute("outputPos", Integer.toString(me.getValue()));
			}
		}
		
		if (groupingColumns!= null) {
			Element grouping = DomUtils.addChild(doc, el, "grouping");
			for (int col : groupingColumns) {
				Element colEl = DomUtils.addChild(doc, grouping, "column");
				colEl.setAttribute("pos", Integer.toString(col));
			}
		}
		if (outputColumns != null){
			Element output = DomUtils.addChild(doc, el, "output");
			for (OutputColumn oc : outputColumns) {
				Element colEl = DomUtils.addChild(doc, output, "aggField");
				if (oc.inputCol >= 0) {
					colEl.setAttribute("pos", Integer.toString(oc.inputCol));
				}
				if (oc.countCol >= 0) {
					colEl.setAttribute("count", Integer.toString(oc.countCol));
				}
				if (oc.agg != null) {
					colEl.setAttribute("func", oc.agg.name());
				}
			}			
		}
	}
	
	public static FixpointShipNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan input = getInputQueryPlan(el, schemas, alreadyIds);
		QpSchema inputSchema = schemas.get(input.outputSchema);
		QpSchema outputSchema = schemas.get(qpd.outputSchema);
		Element mapping = DomUtils.getChildElementByName(el, "mapping");
		Map<Integer,Integer> schemaMapping = null;
		if (mapping != null) {
			List<Element> entries = DomUtils.getChildElementsByName(mapping, "entry");
			schemaMapping = new HashMap<Integer,Integer>(entries.size());
			for (Element entry : entries) {
				String inputPos = entry.getAttribute("inputPos");
				String outputPos = entry.getAttribute("outputPos");
				if (inputPos.length() == 0 || outputPos.length() == 0) {
					throw new XMLParseException("Each schema mapping entry must have an inputPos and an outputPos", entry);
				}
				try {
					int inputPosInt = Integer.parseInt(inputPos);
					int outputPosInt = Integer.parseInt(outputPos);
					schemaMapping.put(inputPosInt, outputPosInt);
				} catch (NumberFormatException nfe) {
					throw new XMLParseException(nfe, entry);
				}
			}
		}
		
		List<Integer> groupingColumns = null;
		Element grouping = DomUtils.getChildElementByName(el, "grouping");
		if (grouping != null) {
			List<Element> groupingColEls = DomUtils.getChildElementsByName(grouping, "column");
			groupingColumns = new ArrayList<Integer>();
			for (Element e : groupingColEls) {
				String pos = e.getAttribute("pos");
				if (pos.length() == 0) {
					throw new XMLParseException("Missing position attribute in grouping column element", e);
				}
				groupingColumns.add(Integer.parseInt(pos));
			}
		}
		
		List<OutputColumn> outputColumns = null;
		Element output = DomUtils.getChildElementByName(el, "output");
		if (output != null)	{	
			List<Element> outputEls = DomUtils.getChildElementsByName(output, "aggField");
			outputColumns = new ArrayList<OutputColumn>();
			for (Element e : outputEls) {
				String pos = e.getAttribute("pos");
				int posInt;
				if (pos.length() == 0) {
					posInt = -1;
				} else {
					try {
						posInt = Integer.parseInt(pos);
					} catch (NumberFormatException nfe) {
						throw new XMLParseException("Error parsing pos attribute", nfe,e);
					}
				}
				String count = e.getAttribute("count");
				int countInt;
				if (count.length() == 0) {
					countInt = -1;
				} else {
					try {
						countInt = Integer.parseInt(count);
					} catch (NumberFormatException nfe) {
						throw new XMLParseException("Error parsing count attribute", nfe, e);
					}
				}
				String func = e.getAttribute("func");
				AggFunc agg = null;
				if (func.length() > 0) {
					agg = AggFunc.valueOf(func);
					if (agg == null) {
						throw new XMLParseException("Invalid aggregate function " + func, e);
					}
				}
				if (posInt < 0) {
					outputColumns.add(new OutputColumn(agg));
				} else if (countInt < 0) {
					outputColumns.add(new OutputColumn(posInt, agg));
				} else {
					if (agg != null) {
						throw new XMLParseException("Should not supply aggregate function for rewritten average", e);
					}
					outputColumns.add(new OutputColumn(posInt, countInt));
				}
			}
		}
		FixpointShipNode ret = new FixpointShipNode(inputSchema, schemaMapping, outputSchema, groupingColumns, outputColumns, qpd.loc, qpd.operatorId, input);
		return ret;
	}
}

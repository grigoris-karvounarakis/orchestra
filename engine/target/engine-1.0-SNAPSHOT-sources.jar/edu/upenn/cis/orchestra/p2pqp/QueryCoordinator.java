package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.p2pqp.Filter.FilterException;
import edu.upenn.cis.orchestra.p2pqp.IndexService.IndexServiceException;
import edu.upenn.cis.orchestra.p2pqp.plan.AggregateNode;
import edu.upenn.cis.orchestra.p2pqp.plan.FixpointNode;
import edu.upenn.cis.orchestra.p2pqp.plan.IndexScanNode;
import edu.upenn.cis.orchestra.p2pqp.plan.LocalTableScanNode;
import edu.upenn.cis.orchestra.p2pqp.plan.PipelinedJoinNode;
import edu.upenn.cis.orchestra.p2pqp.plan.QueryPlan;
import edu.upenn.cis.orchestra.p2pqp.plan.QueryPlan.RelationAndFilter;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;
import edu.upenn.cis.orchestra.util.IndexedHashSet;
import edu.upenn.cis.orchestra.util.IndexedSet;
import edu.upenn.cis.orchestra.util.Pair;
import edu.upenn.cis.orchestra.util.Ranges;

public class QueryCoordinator implements RecordTuples {
	public final int defaultCheckDelayMs = 500, defaultShowDelayMs = 5000;
	public final int defaultRecoveryIntervalMs = 1000;

	private static final Logger logger = Logger.getLogger(QueryCoordinator.class);

	private final int epoch;
	private final int queryId;
	private final List<RelationAndFilter> distributedScans;

	// Lock for these is added
	private final IndexedSet<ExecutionId,Integer> added = new IndexedHashSet<ExecutionId,Integer>(getTupleIdMetadata);
	private final IndexedSet<ExecutionId,Integer> removed = new IndexedHashSet<ExecutionId,Integer>(getTupleIdMetadata);

	private final HashMap<Integer,KeySet> keys;
	private final HashMap<Integer,QpSchema> scanSchemas;

	private volatile int nextPhase = 0;	
	private final Set<Integer> phasesReceivingKeys = Collections.synchronizedSet(new HashSet<Integer>());


	private final Object dataStructuresLock = new Object();
	private int methodsAccessingDataStructures = 0;
	private boolean canAccessDataStructures = true;

	private IdRange[][] failedRangesForPhases = new IdRange[1][0];
	private final Set<InetSocketAddress> failedNodes = new HashSet<InetSocketAddress>();
	private byte[][] failedNodeIds = new byte[0][];

	private final Set<InetSocketAddress> reportedFailedNodes = Collections.synchronizedSet(new HashSet<InetSocketAddress>());


	private final boolean attemptRecovery;

	private boolean done = false;
	private final QueryOwner<?> qo;

	private final Map<Integer,Set<Integer>> blockingOperatorDependents;
	private final Set<Integer> finishableOperators;
	// Lock for these is distributedBlockingOperatorsNotFinished
	private final Map<Integer,Set<InetSocketAddress>> distributedBlockingOperatorsNotFinished = new HashMap<Integer,Set<InetSocketAddress>>();
	private final Set<Integer> centralBlockingOperatorsNotFinished = new HashSet<Integer>();
	private final Map<Integer,InetSocketAddress> namedBlockingOperatorsNotFinished = new HashMap<Integer,InetSocketAddress>();

	private final Map<InetSocketAddress,List<Exception>> exceptions = new HashMap<InetSocketAddress,List<Exception>>();

	private final Map<Integer,int[]> recoveryJoinOperators;

	private final Map<Integer,Pair<Set<Integer>,Set<Integer>>> joinOperatorDeps;
	private final Set<Integer> centralJoinOperators, distributedJoinOperators;
	private final Map<Integer,InetSocketAddress> namedJoinOperators;
	// Lock for these is joinOperatorsNotLeftFinished
	private final Set<Integer> joinOperatorsNotLeftFinished = new HashSet<Integer>(), joinOperatorsNotRightFinished = new HashSet<Integer>();


	private final QueryPlan qp;
	private final Map<Integer,QueryPlan> operatorsMap;


	private final List<Thread> startedThreads = new ArrayList<Thread>();


	public static long timeout = 30000;

	private volatile long lastActivity = Long.MAX_VALUE;
	private volatile long currTime;

	QueryCoordinator(Router queryRouter, QueryOwner<?> qo, int epoch, int queryId, QueryPlan qp, QpSchema.Source ss, boolean attemptRecovery) throws IllegalArgumentException, InterruptedException, IndexServiceException, IOException {
		this.epoch = epoch;
		this.queryId = queryId;
		this.qo = qo;
		this.attemptRecovery = attemptRecovery;
		this.qp = qp;
		operatorsMap = new HashMap<Integer,QueryPlan>();
		qp.getOperators(operatorsMap);

		if (this.attemptRecovery) {
			recoveryJoinOperators = new HashMap<Integer,int[]>();
			qp.getRecoveryJoinOperators(recoveryJoinOperators, ss);
		} else {
			recoveryJoinOperators = null;
		}
		List<RelationAndFilter> ourDistScans = new ArrayList<RelationAndFilter>();
		qp.getDistributedScans(ourDistScans, ss);
		distributedScans = Collections.unmodifiableList(ourDistScans);
		phasesReceivingKeys.add(nextPhase++);

		Map<String,Integer> relCards = new HashMap<String,Integer>();
		for (RelationAndFilter raf : ourDistScans) {
			relCards.put(raf.relation, qo.app.index.getCardinality(ss.getSchema(raf.relation).relId, epoch));
		}


		blockingOperatorDependents = new HashMap<Integer,Set<Integer>>();
		qp.getBlockingOperatorDependents(blockingOperatorDependents);

		List<QueryPlan> finishableOperators = new ArrayList<QueryPlan>();
		qp.getOperatorsOfType(finishableOperators, AggregateNode.class, FixpointNode.class);
		this.finishableOperators = new HashSet<Integer>(finishableOperators.size());
		for (QueryPlan node : finishableOperators) {
			this.finishableOperators.add(node.operatorId);
		}

		List<RelationAndFilter> distributedScans = new ArrayList<RelationAndFilter>();
		qp.getDistributedScans(distributedScans, ss);

		Map<Integer,int[]> scanKeyCols = new HashMap<Integer,int[]>(distributedScans.size());
		Map<Integer,Integer> scanCards = new HashMap<Integer,Integer>(distributedScans.size());
		scanSchemas = new HashMap<Integer,QpSchema>();
		for (RelationAndFilter raf : distributedScans) {
			QpSchema schema = ss.getSchema(raf.relation);
			scanKeyCols.put(raf.operatorId, schema.getKeyColsListNoCopy());
			scanCards.put(raf.operatorId, relCards.get(raf.relation));
			scanSchemas.put(raf.operatorId, schema);
		}


		keys = new HashMap<Integer,KeySet>(scanKeyCols.size());
		for (Map.Entry<Integer, int[]> me : scanKeyCols.entrySet()) {
			keys.put(me.getKey(), new KeySet(me.getValue(), scanCards.get(me.getKey()) / 2));
		}

		joinOperatorDeps = new HashMap<Integer,Pair<Set<Integer>,Set<Integer>>>();
		qp.getJoinOperatorDependents(joinOperatorDeps);

		distributedJoinOperators = new HashSet<Integer>();
		centralJoinOperators = new HashSet<Integer>();
		namedJoinOperators = new HashMap<Integer,InetSocketAddress>();

		List<QueryPlan> joinNodes = new ArrayList<QueryPlan>();
		qp.getOperatorsOfType(joinNodes, PipelinedJoinNode.class);
		for (QueryPlan node : joinNodes) {
			if (node.loc.isDistributed()) {
				distributedJoinOperators.add(node.operatorId);
			}  else if (node.loc.isCentralized()) {
				centralJoinOperators.add(node.operatorId);
			} else if (node.loc.isNamed()) {
				namedJoinOperators.put(node.operatorId, qo.app.getNamedNodehandle(node.loc.getName()));
			}
		}

		initJoinsAndAggs(queryRouter.getParticipants());

		currTime = System.currentTimeMillis();
		Thread checkThread = new CheckThread(defaultCheckDelayMs, logger.isInfoEnabled() ? defaultShowDelayMs : Integer.MAX_VALUE);
		checkThread.start();
		startedThreads.add(checkThread);

		if (attemptRecovery) {
			Thread recoveryThread = new RecoveryThread(defaultRecoveryIntervalMs);
			recoveryThread.start();
			startedThreads.add(recoveryThread);
		}
	}

	private void initJoinsAndAggs(Set<InetSocketAddress> participants) {
		List<QueryPlan> blockingOperators = new ArrayList<QueryPlan>();
		qp.getBlockingOperatorDependents(blockingOperatorDependents);

		qp.getOperatorsOfType(blockingOperators, AggregateNode.class, LocalTableScanNode.class, IndexScanNode.class, FixpointNode.class);
		synchronized (distributedBlockingOperatorsNotFinished) {
			centralBlockingOperatorsNotFinished.clear();
			namedBlockingOperatorsNotFinished.clear();

			for (QueryPlan qpNode : blockingOperators) {
				if (qpNode instanceof LocalTableScanNode || qpNode instanceof IndexScanNode) {
					if (qpNode.loc.isDistributed()) {
						Set<InetSocketAddress> unfinished = distributedBlockingOperatorsNotFinished.get(qpNode.operatorId);
						if (unfinished != null) {
							unfinished.retainAll(participants);
							if (unfinished.isEmpty()) {
								distributedBlockingOperatorsNotFinished.remove(qpNode.operatorId);
							}
						}
					}
				} else {
					if (qpNode.loc.isCentralized()) {
						centralBlockingOperatorsNotFinished.add(qpNode.operatorId);
					} else if (qpNode.loc.isNamed()) {
						namedBlockingOperatorsNotFinished.put(qpNode.operatorId, qo.app.getNamedNodehandle(qpNode.loc.getName()));
					} else if (qpNode.loc.isDistributed()) {
						distributedBlockingOperatorsNotFinished.put(qpNode.operatorId, new HashSet<InetSocketAddress>(participants));				
					}
				}
			}
		}


		joinOperatorsNotLeftFinished.clear();
		joinOperatorsNotRightFinished.clear();
		for (Integer joinOp : joinOperatorDeps.keySet()) {
			PipelinedJoinNode pjn = (PipelinedJoinNode) operatorsMap.get(joinOp);
			if (! pjn.left.isReplicated) {
				joinOperatorsNotLeftFinished.add(joinOp);
			}
			if (! pjn.right.isReplicated) {
				joinOperatorsNotRightFinished.add(joinOp);
			}
		}

	}

	private class RecoveryThread extends Thread {
		private final int recoveryIntervalMs;

		RecoveryThread(int recoveryIntervalMs) {
			super(qo.app.tg, "RecoveryThread(" + qo.queryId + ")");
			this.recoveryIntervalMs = recoveryIntervalMs;
		}

		public void run() {
			if (! attemptRecovery) {
				return;
			}
			try {
				while (! isInterrupted()) {
					sleep(recoveryIntervalMs);

					Set<InetSocketAddress> newlyFailedNodes = new HashSet<InetSocketAddress>();
					Set<InetSocketAddress> allFailedNodes = new HashSet<InetSocketAddress>();
					synchronized (failedNodes) {
						synchronized (reportedFailedNodes) {
							for (InetSocketAddress node : reportedFailedNodes) {
								if (failedNodes.add(node)) {
									newlyFailedNodes.add(node);
								}
							}
							reportedFailedNodes.clear();
							if (newlyFailedNodes.isEmpty()) {
								continue;
							}
						}
						allFailedNodes.addAll(failedNodes);
					}

					qo.app.nodesHaveFailed(allFailedNodes);

					attemptRecovery(newlyFailedNodes);
				}
			} catch (InterruptedException ie) {
				return;
			} catch (Exception e) {
				logger.fatal("Error in RecoveryThread", e);
			}
		}

		private void attemptRecovery(Set<InetSocketAddress> newlyFailedNodes) throws IndexServiceException, InterruptedException, IOException {
			final int thisPhase = nextPhase++;
			logger.warn("Beginning recovery for " + newlyFailedNodes + " as phase " + thisPhase);
			phasesReceivingKeys.add(thisPhase);
			Router oldRouter = qo.getOwnedExecution().getRouter(thisPhase - 1);
			IdRange[] failedRanges = new IdRange[newlyFailedNodes.size()];
			int pos = 0;
			for (InetSocketAddress failedNode : newlyFailedNodes) {
				IdRange owned = oldRouter.getOwnedRange(failedNode);
				failedRanges[pos++] = owned;
			}
			Router newRouter = oldRouter.getRouterWithout(newlyFailedNodes);
			initJoinsAndAggs(newRouter.getParticipants());

			synchronized (dataStructuresLock) {
				canAccessDataStructures = false;
				while (methodsAccessingDataStructures > 0) {
					dataStructuresLock.wait();
				}
			}

			try {
				byte[][] newFailedNodeIds;
				synchronized (failedNodes) {
					newFailedNodeIds = new byte[failedNodes.size()][];
					pos = 0;
					for (InetSocketAddress node : failedNodes) {
						newFailedNodeIds[pos++] = ExecutionId.getNodeIdBytes(node);
					}
				}
				failedNodeIds = newFailedNodeIds;

				IdRange[][] newFailedRangesForPhases = new IdRange[thisPhase+1][];
				for(int i = 0; i < thisPhase; ++i) {
					newFailedRangesForPhases[i] = new IdRange[failedRanges.length + failedRangesForPhases[i].length];
					System.arraycopy(failedRangesForPhases[i], 0, newFailedRangesForPhases[i], 0, failedRangesForPhases[i].length);
					System.arraycopy(failedRanges, 0, newFailedRangesForPhases[i], failedRangesForPhases[i].length, failedRanges.length);
				}
				newFailedRangesForPhases[thisPhase] = new IdRange[0];
				failedRangesForPhases = newFailedRangesForPhases;

				synchronized (added) {
					Iterator<ExecutionId> it = added.iterator();
					while (it.hasNext()) {
						ExecutionId id = it.next();
						for (byte[] nodeId : failedNodeIds) {
							if (id.containsNodeId(nodeId)) {
								it.remove();
								break;
							}
						}
					}
					it = removed.iterator();
					while (it.hasNext()) {
						ExecutionId id = it.next();
						for (byte[] nodeId : failedNodeIds) {
							if (id.containsNodeId(nodeId)) {
								it.remove();
								break;
							}
						}
					}
				}

				for (Map.Entry<Integer, KeySet> me : keys.entrySet()) {
					final QpSchema schema = scanSchemas.get(me.getKey());
					final byte[] scratch = new byte[schema.getNumHashCols() * IntType.bytesPerInt];
					Iterator<ByteArrayWrapper> it = me.getValue().iterator();
					while (it.hasNext()) {
						ByteArrayWrapper baw = it.next();
						QpTuple<?> key = QpTuple.fromBytes(QpTuple.SerializationMode.KEY, schema, null, null, baw.array, baw.offset, baw.length, null);
						Id id = key.getQPid(scratch);
						for (IdRange range : failedRanges) {
							if (range.contains(id)) {
								it.remove();
								break;
							}
						}
					}
				}
			} finally {
				synchronized (dataStructuresLock) {
					canAccessDataStructures = true;
					dataStructuresLock.notifyAll();
				}
			}

			Set<InetSocketAddress> failed = qo.beginNewQueryPhase(thisPhase, newRouter, failedRanges, newlyFailedNodes, recoveryJoinOperators);
			if (! failed.isEmpty()) {
				nodesHaveFailed(failed);
			}

			initDistributedScans(thisPhase, failedRanges);
		}

	}

	private class CheckThread extends Thread {
		private final long checkIntervalMs;
		private final long showIntervalMs;
		private final long sleepMs;
		private long lastCheck = System.currentTimeMillis();
		private long lastShow = lastCheck;

		CheckThread(int checkIntervalMs, int showIntervalMs) {
			super(qo.app.tg, "CheckThread(" + qo.queryId + ")");
			this.checkIntervalMs = checkIntervalMs;
			this.showIntervalMs = showIntervalMs;

			long min, max;
			if (checkIntervalMs < showIntervalMs) {
				min = checkIntervalMs;
				max = showIntervalMs;
			} else {
				max = checkIntervalMs;
				min = showIntervalMs;
			}

			if (min * 2 > max) {
				sleepMs = max / 4;
			} else {
				sleepMs = min;
			}
		}

		public void run() {
			long currTime = System.currentTimeMillis();
			lastActivity = currTime;
			while (! isInterrupted()) {
				try {
					sleep(sleepMs);
				} catch (InterruptedException ie) {
					return;
				}

				currTime = System.currentTimeMillis();
				long lastActivity = QueryCoordinator.this.lastActivity;
				QueryCoordinator.this.currTime = currTime;

				if (currTime - lastCheck > checkIntervalMs) {
					boolean done;
					synchronized (QueryCoordinator.this) {
						done = QueryCoordinator.this.done;
					}
					if (! done) {
						done = checkDone();
					}
					if (done) {
						return;
					}
					checkBlockingOperatorsCanExecute();
					checkJoinInputsHaveFinished();
					lastCheck = currTime;
				}

				currTime = System.currentTimeMillis();
				QueryCoordinator.this.currTime = currTime;
				lastActivity = QueryCoordinator.this.lastActivity;

				if (currTime - lastActivity > timeout) {
					boolean isThrottled = qo.app.throttlingOccurring();
					if (isThrottled) {
						lastActivity = currTime;
					} else {
						if (logger.isInfoEnabled()) {
							class NodeOpPhase {
								final InetSocketAddress node;
								final int operator;
								final int phase;

								NodeOpPhase(InetSocketAddress node, int operator, int phase) {
									this.node = node;
									this.operator = operator;
									this.phase = phase;
								}

								public String toString() {
									return "(" + node + ",op=" + operator + ",phase=" + phase + ")";
								}

								public int hashCode() {
									return node.hashCode() + 37 * operator + 1023 * phase;
								}

								public boolean equals(Object o) {
									if (o == null || o.getClass() != this.getClass()) {
										return false;
									}
									NodeOpPhase nop = (NodeOpPhase) o;
									return (nop.operator == operator && nop.phase == phase && nop.node.equals(node));
								}
							}

							List<TupleAndOp> missingKeys = new ArrayList<TupleAndOp>();
							List<TupleAndOp> extraScanned = new ArrayList<TupleAndOp>();
							Map<NodeOpPhase,Ranges> missingTuples = new HashMap<NodeOpPhase,Ranges>();
							for (Map.Entry<Integer, KeySet> me : keys.entrySet()) {
								int opId = me.getKey();
								List<QpTuple<?>> expected = me.getValue().expected(scanSchemas.get(opId));
								// TODO: compute actual phases
								for (QpTuple<?> t : expected) {
									missingKeys.add(new TupleAndOp(t, opId, 0));
								}
								List<QpTuple<?>> scanned = me.getValue().scanned(scanSchemas.get(opId));
								for (QpTuple<?> t : scanned) {
									extraScanned.add(new TupleAndOp(t, opId, 0));
								}
							}

							synchronized (added) {
								for (ExecutionId tid : added) {
									NodeOpPhase nop = new NodeOpPhase(tid.nodeId, tid.operatorId, tid.phaseNo);
									Ranges r = missingTuples.get(nop);
									if (r == null) {
										r = new Ranges();
										r.add(tid.tupleCount);
										missingTuples.put(nop, r);
									} else {
										r.add(tid.tupleCount);
									}
								}
							}
							Router r = qo.app.getRouter();
							Map<Pair<InetSocketAddress,Integer>,Integer> missingKeys2 = new HashMap<Pair<InetSocketAddress,Integer>,Integer>();
							for (TupleAndOp tao : missingKeys) {
								InetSocketAddress owner = r.getDest(tao.t.getQPid());
								Pair<InetSocketAddress,Integer> p = new Pair<InetSocketAddress,Integer>(owner, tao.operatorId);
								Integer count = missingKeys2.get(p);
								if (count == null) {
									missingKeys2.put(p, 1);
								} else {
									missingKeys2.put(p, count + 1);
								}
							}
							if (! missingTuples.isEmpty()) {
								logger.error("Missing intermediate results: " + missingTuples);
							}
							if (! missingKeys2.isEmpty()) {
								logger.error("Missing base tuples: " + missingKeys2);
							}
							if (! extraScanned.isEmpty()) {
								logger.error("Extra scanned tuples: " + extraScanned);
							}
						}
						reportException(new RuntimeException("RecordTuplesLocal has timed out"));
					}
				}

				if (currTime - lastShow > showIntervalMs) {
					showStatus();
					lastShow = currTime;
				}
			}
		}
	}

	private boolean checkDone() {
		boolean done = true;
		if (! phasesReceivingKeys.isEmpty()) {
			done = false;
		}
		if (done) {
			for (KeySet keysForRel : keys.values()) {
				if (keysForRel.getSize() != 0) {
					done = false;
					break;
				}
			}
		}
		if (done) {
			synchronized (added) {
				if ((! added.isEmpty()) || (! removed.isEmpty())) {
					done = false;
				}
			}
		}
		if (done) {
			synchronized (distributedBlockingOperatorsNotFinished) {
				if ((! distributedBlockingOperatorsNotFinished.isEmpty()) || (! centralBlockingOperatorsNotFinished.isEmpty())|| (! namedBlockingOperatorsNotFinished.isEmpty())) {
					done = false;
				}
			}
		}

		if (! exceptions.isEmpty()) {
			done = true;
		}

		if (done) {
			synchronized (this) {
				this.done = true;
				notifyAll();
			}
		}
		return done;
	}

	public void tuplesAdded(Collection<ExecutionId> tupleIds) {
		if (tupleIds.isEmpty()) {
			return;
		}
		synchronized (dataStructuresLock) {
			try {
				while (! canAccessDataStructures) {
					dataStructuresLock.wait();
				}
			} catch (InterruptedException ie) {
				return;
			}
			++methodsAccessingDataStructures;
		}
		final byte[][] failedNodeIds = this.failedNodeIds;
		try {
			synchronized (added) {
				if (failedNodeIds.length == 0) {
					for (ExecutionId tupleId : tupleIds) {
						if (! removed.remove(tupleId)) {
							added.add(tupleId);
						}
					}
				} else {
					TID: for (ExecutionId tupleId : tupleIds) {
						for (byte[] nodeId : failedNodeIds) {
							if (tupleId.containsNodeId(nodeId)) {
								continue TID;
							}
						}
						if (! removed.remove(tupleId)) {
							added.add(tupleId);
						}
					}
				}
			}
		} finally {
			synchronized (dataStructuresLock) {
				--methodsAccessingDataStructures;
				if (methodsAccessingDataStructures == 0) {
					dataStructuresLock.notify();
				}
			}
		}
		if (logger.isTraceEnabled()) {
			for (ExecutionId tupleId : tupleIds) {
				logger.trace("RTL: tuple added " + tupleId);
			}
		}
		lastActivity = currTime;
	}

	public void tuplesRemoved(Collection<ExecutionId> tupleIds) {
		if (tupleIds.isEmpty()) {
			return;
		}
		synchronized (dataStructuresLock) {
			try {
				while (! canAccessDataStructures) {
					dataStructuresLock.wait();
				}
			} catch (InterruptedException ie) {
				return;
			}
			++methodsAccessingDataStructures;
		}
		final byte[][] failedNodeIds = this.failedNodeIds;
		try {
			synchronized (added) {
				if (failedNodeIds.length == 0) {
					for (ExecutionId tupleId : tupleIds) {
						if (! added.remove(tupleId)) {
							removed.add(tupleId);
						}
					}
				} else {
					TID: for (ExecutionId tupleId : tupleIds) {
						for (byte[] nodeId : failedNodeIds) {
							if (tupleId.containsNodeId(nodeId)) {
								continue TID;
							}
						}
						if (! added.remove(tupleId)) {
							removed.add(tupleId);
						}
					}
				}
			}
		} finally {
			synchronized (dataStructuresLock) {
				--methodsAccessingDataStructures;
				if (methodsAccessingDataStructures == 0) {
					dataStructuresLock.notify();
				}
			}
		}

		if (logger.isTraceEnabled()) {
			for (ExecutionId tupleId : tupleIds) {
				logger.trace("RTL: tuple removed " + tupleId);
			}
		}
		lastActivity = currTime;
	}

	public static class QueryFailure extends Exception {
		private static final long serialVersionUID = 1L;

		QueryFailure(InetSocketAddress node, Exception e) {
			super("Failure during query processing at " + node, e);
		}

		QueryFailure(String msg, Exception e) {
			super(msg,e);
		}

		QueryFailure(String msg) {
			super(msg);
		}
	}

	public synchronized void waitUntilEmpty() throws InterruptedException, QueryFailure {
		while (! done) {
			wait();
		}
		synchronized (exceptions) {
			for (Map.Entry<InetSocketAddress, List<Exception>> me : exceptions.entrySet()) {
				InetSocketAddress node = me.getKey();
				List<Exception> exs = me.getValue();
				throw new QueryFailure(node, exs.get(0));
			}
		}
	}

	public Set<ExecutionId> getAdded() {
		return added.toSet();
	}

	public Set<ExecutionId> getRemoved() {
		return removed.toSet();
	}

	public void keysScanned(int operatorId, List<QpTuple<?>> keys, int phaseNo) {
		// These tuples must come from the query owner, so we can dispense with
		// any checks for failed nodes
		if (keys.isEmpty()) {
			return;
		}
		synchronized (dataStructuresLock) {
			try {
				while (! canAccessDataStructures) {
					dataStructuresLock.wait();
				}
			} catch (InterruptedException ie) {
				return;
			}
			++methodsAccessingDataStructures;
		}
		try {
			KeySet keysForRel = this.keys.get(operatorId);
			keysForRel.scanned(keys);
		} finally {
			synchronized (dataStructuresLock) {
				--methodsAccessingDataStructures;
				if (methodsAccessingDataStructures == 0) {
					dataStructuresLock.notify();
				}
			}
		}

		lastActivity = currTime;
	}

	void keysScanned(int operatorId, ByteArrayWrapper[] keys, int phaseNo, InetSocketAddress from) {
		if (keys.length == 0) {
			return;
		}
		synchronized (failedNodes) {
			if (failedNodes.contains(from)) {
				return;
			}
		}
		synchronized (dataStructuresLock) {
			try {
				while (! canAccessDataStructures) {
					dataStructuresLock.wait();
				}
			} catch (InterruptedException ie) {
				return;
			}
			++methodsAccessingDataStructures;
		}
		try {
			KeySet keysForRel = this.keys.get(operatorId);
			keysForRel.scanned(keys);
		} finally {
			synchronized (dataStructuresLock) {
				--methodsAccessingDataStructures;
				if (methodsAccessingDataStructures == 0) {
					dataStructuresLock.notify();
				}
			}
		}

		lastActivity = currTime;
	}

	void keysExpected(int operatorId, ByteArrayWrapper keys[], int phaseNo) {
		if (keys.length == 0) {
			return;
		}

		synchronized (dataStructuresLock) {
			try {
				while (! canAccessDataStructures) {
					dataStructuresLock.wait();
				}
			} catch (InterruptedException ie) {
				return;
			}
			++methodsAccessingDataStructures;
		}
		try {
			final QpSchema schema = scanSchemas.get(operatorId);
			final IdRange[] ranges = failedRangesForPhases[phaseNo];
			if (ranges.length != 0) {
				final int length = keys.length;
				final byte[] scratch = new byte[schema.getNumHashCols() * IntType.bytesPerInt];
				KEY: for (int i = 0; i < length; ++i) {
					ByteArrayWrapper baw = keys[i];
					if (baw == null) {
						continue;
					}
					QpTuple<?> key = QpTuple.fromBytes(QpTuple.SerializationMode.KEY, schema, null, null, baw.array, baw.offset, baw.length, null);
					final Id id = key.getQPid(scratch);
					for (IdRange range : ranges) {
						if (range.contains(id)) {
							keys[i] = null;
							continue KEY;
						}
					}
				}
			}
			KeySet keysForRel = this.keys.get(operatorId);
			keysForRel.expected(keys);
		} finally {
			synchronized (dataStructuresLock) {
				--methodsAccessingDataStructures;
				if (methodsAccessingDataStructures == 0) {
					dataStructuresLock.notify();
				}
			}
		}

		lastActivity = currTime;
	}

	static final IndexedSet.GetMetadata<ExecutionId,Integer> getTupleIdMetadata = new IndexedSet.GetMetadata<ExecutionId,Integer>() {
		public Integer getMetadata(ExecutionId obj) {
			return obj.operatorId;
		}
	};

	static final IndexedSet.GetMetadata<TupleAndOp,Integer> getTAOMetadata = new IndexedSet.GetMetadata<TupleAndOp,Integer>() {
		public Integer getMetadata(TupleAndOp obj) {
			return obj.operatorId;
		}
	};


	public void operatorHasFinished(int operatorId, InetSocketAddress node) {
		operatorsHaveFinished(Collections.singleton(new NodeAndOp(node,operatorId)));
	}


	public void operatorsHaveFinished(Collection<NodeAndOp> naos) {
		if (naos.isEmpty()) {
			return;
		}
		synchronized (distributedBlockingOperatorsNotFinished) {
			for (NodeAndOp nao : naos) {
				Set<InetSocketAddress> nodesNotFinished = distributedBlockingOperatorsNotFinished.get(nao.operatorId);
				if (nodesNotFinished != null) {
					nodesNotFinished.remove(nao.node);
					if (nodesNotFinished.isEmpty()) {
						distributedBlockingOperatorsNotFinished.remove(nao.operatorId);
					}
				}
				centralBlockingOperatorsNotFinished.remove(nao.operatorId);
				namedBlockingOperatorsNotFinished.remove(nao.operatorId);
			}
		}
		lastActivity = currTime;
	}

	private void checkJoinInputsHaveFinished() {
		if (! phasesReceivingKeys.isEmpty()) {
			return;
		}

		Set<Integer> centralLeft , centralRight;
		Set<Integer> distributedLeft, distributedRight;
		Map<InetSocketAddress,Pair<Collection<Integer>,Collection<Integer>>> named;
		synchronized (joinOperatorsNotLeftFinished) {
			Set<Integer> leftFinished, rightFinished;
			if (joinOperatorsNotLeftFinished.isEmpty() && joinOperatorsNotRightFinished.isEmpty()) {
				return;
			}
			leftFinished = new HashSet<Integer>(joinOperatorsNotLeftFinished);
			rightFinished = new HashSet<Integer>(joinOperatorsNotRightFinished);

			Iterator<Integer> leftIt = leftFinished.iterator(), rightIt = rightFinished.iterator();

			synchronized (distributedBlockingOperatorsNotFinished) {
				while (leftIt.hasNext()) {
					Integer op = leftIt.next();
					Collection<Integer> deps = joinOperatorDeps.get(op).getFirst();
					DEP: for (Integer dep : deps) {
						if (distributedBlockingOperatorsNotFinished.containsKey(dep) || centralBlockingOperatorsNotFinished.contains(dep) || namedBlockingOperatorsNotFinished.containsKey(dep)) {
							leftIt.remove();
							break DEP;
						}
					}
				}
				while (rightIt.hasNext()) {
					Integer op = rightIt.next();
					Collection<Integer> deps = joinOperatorDeps.get(op).getSecond();
					DEP: for (Integer dep : deps) {
						if (distributedBlockingOperatorsNotFinished.containsKey(dep) || centralBlockingOperatorsNotFinished.contains(dep) || namedBlockingOperatorsNotFinished.containsKey(dep)) {
							rightIt.remove();
							break DEP;
						}
					}
				}
			}

			if (leftFinished.isEmpty() && rightFinished.isEmpty()) {
				return;
			}

			leftIt = leftFinished.iterator();
			rightIt = rightFinished.iterator();

			synchronized (added) {
				while (leftIt.hasNext()) {
					Integer op = leftIt.next();
					Collection<Integer> deps = joinOperatorDeps.get(op).getFirst();
					DEP: for (Integer dep : deps) {
						if (! (added.getElementsForMetadata(dep).isEmpty() && removed.getElementsForMetadata(dep).isEmpty())) {
							leftIt.remove();
							break DEP;
						}
					}
				}
				while (rightIt.hasNext()) {
					Integer op = rightIt.next();
					Collection<Integer> deps = joinOperatorDeps.get(op).getSecond();
					DEP: for (Integer dep : deps) {
						if (! (added.getElementsForMetadata(dep).isEmpty() && removed.getElementsForMetadata(dep).isEmpty())) {
							rightIt.remove();
							break DEP;
						}
					}
				}
			}

			if (leftFinished.isEmpty() && rightFinished.isEmpty()) {
				return;
			}

			leftIt = leftFinished.iterator();
			rightIt = rightFinished.iterator();

			synchronized (dataStructuresLock) {
				try {
					while (! canAccessDataStructures) {
						dataStructuresLock.wait();
					}
				} catch (InterruptedException ie) {
					return;
				}
				++methodsAccessingDataStructures;
			}
			try {			
				while (leftIt.hasNext()) {
					Integer op = leftIt.next();
					Collection<Integer> deps = joinOperatorDeps.get(op).getFirst();
					DEP: for (Integer dep : deps) {
						KeySet keysForDep = keys.get(dep);
						if (keysForDep == null) {
							continue;
						}
						if (keysForDep.getSize() > 0) {
							leftIt.remove();
							break DEP;
						}
					}
				}

				while (rightIt.hasNext()) {
					Integer op = rightIt.next();
					Collection<Integer> deps = joinOperatorDeps.get(op).getSecond();
					DEP: for (Integer dep : deps) {
						KeySet keysForDep = keys.get(dep);
						if (keysForDep == null) {
							continue;
						}
						if (keysForDep.getSize() > 0) {
							rightIt.remove();
							break DEP;
						}
					}
				}
			} finally {
				synchronized (dataStructuresLock) {
					--methodsAccessingDataStructures;
					if (methodsAccessingDataStructures == 0) {
						dataStructuresLock.notify();
					}
				}
			}

			if (leftFinished.isEmpty() && rightFinished.isEmpty()) {
				return;
			}

			joinOperatorsNotLeftFinished.removeAll(leftFinished);
			joinOperatorsNotRightFinished.removeAll(rightFinished);

			centralLeft = new HashSet<Integer>();
			centralRight = new HashSet<Integer>();
			distributedLeft = new HashSet<Integer>();
			distributedRight = new HashSet<Integer>();
			named = new HashMap<InetSocketAddress,Pair<Collection<Integer>,Collection<Integer>>>();

			for (Integer op : leftFinished) {
				if (centralJoinOperators.contains(op)) {
					centralLeft.add(op);
				} else if (distributedJoinOperators.contains(op)) {
					distributedLeft.add(op);
				} else if (namedJoinOperators.containsKey(op)) {
					InetSocketAddress addr = namedJoinOperators.get(op);
					Pair<Collection<Integer>,Collection<Integer>> ops = named.get(addr);
					if (ops == null) {
						ops = new Pair<Collection<Integer>,Collection<Integer>>(new HashSet<Integer>(), new HashSet<Integer>());
						named.put(addr, ops);
					}
					ops.getFirst().add(op);
				} else {
					logger.error("Can't find join operator " + op);
				}
			}

			for (Integer op : rightFinished) {
				if (centralJoinOperators.contains(op)) {
					centralRight.add(op);
				} else if (distributedJoinOperators.contains(op)) {
					distributedRight.add(op);
				} else if (namedJoinOperators.containsKey(op)) {
					InetSocketAddress addr = namedJoinOperators.get(op);
					Pair<Collection<Integer>,Collection<Integer>> ops = named.get(addr);
					if (ops == null) {
						ops = new Pair<Collection<Integer>,Collection<Integer>>(new HashSet<Integer>(), new HashSet<Integer>());
						named.put(addr, ops);
					}
					ops.getSecond().add(op);
				} else {
					logger.error("Can't find join operator " + op);
				}
			}
		}
		qo.localJoinInputHasFinished(centralLeft, centralRight);
		qo.distributedJoinInputHasFinished(distributedLeft, distributedRight);
		qo.namedJoinInputHasFinished(named);
	}

	private void checkBlockingOperatorsCanExecute() {
		if (! phasesReceivingKeys.isEmpty()) {
			return;
		}
		Set<Integer> opsToRun;
		synchronized (distributedBlockingOperatorsNotFinished) {
			opsToRun = new HashSet<Integer>(distributedBlockingOperatorsNotFinished.keySet());
			opsToRun.addAll(centralBlockingOperatorsNotFinished);
			opsToRun.addAll(namedBlockingOperatorsNotFinished.keySet());
			opsToRun.retainAll(finishableOperators);
			Iterator<Integer> opIt = opsToRun.iterator();
			while (opIt.hasNext()) {
				Integer blockingOp = opIt.next();
				Set<Integer> deps = blockingOperatorDependents.get(blockingOp);
				if (deps == null) {
					reportException(new Exception("No dependents found for operator " + blockingOp));
					return;
				}
				for (Integer dependent : deps) {
					if (distributedBlockingOperatorsNotFinished.containsKey(dependent)) {
						opIt.remove();
						break;
					}
					if (centralBlockingOperatorsNotFinished.contains(dependent)) {
						opIt.remove();
						break;
					}
					if (namedBlockingOperatorsNotFinished.containsKey(dependent)) {
						opIt.remove();
						break;
					}
				}
			}
		}
		if (opsToRun.isEmpty()) {
			return;
		}
		synchronized (added) {
			Iterator<Integer> opIt = opsToRun.iterator();
			while (opIt.hasNext()) {
				Integer blockingOp = opIt.next();
				Set<Integer> deps = blockingOperatorDependents.get(blockingOp);
				for (Integer dependent : deps) {
					if (! added.getElementsForMetadata(dependent).isEmpty()) {
						opIt.remove();
						break;
					}
					if (! removed.getElementsForMetadata(dependent).isEmpty()) {
						opIt.remove();
						break;
					}
				}
			}
		}

		if (opsToRun.isEmpty()) {
			return;
		}

		synchronized (dataStructuresLock) {
			try {
				while (! canAccessDataStructures) {
					dataStructuresLock.wait();
				}
			} catch (InterruptedException ie) {
				return;
			}
			++methodsAccessingDataStructures;
		}
		try {			
			Iterator<Integer> opIt = opsToRun.iterator();
			while (opIt.hasNext()) {
				Integer blockingOp = opIt.next();
				Set<Integer> deps = blockingOperatorDependents.get(blockingOp);
				for (Integer dependent : deps) {
					KeySet keysForRel = keys.get(dependent);
					if (keysForRel == null) {
						continue;
					}

					if (keysForRel.getSize() != 0) {
						opIt.remove();
						break;
					}
				}
			}
		} finally {
			synchronized (dataStructuresLock) {
				--methodsAccessingDataStructures;
				if (methodsAccessingDataStructures == 0) {
					dataStructuresLock.notify();
				}
			}
		}

		if (opsToRun.isEmpty()) {
			return;
		}

		Map<InetSocketAddress,Set<Integer>> remoteOperatorsToFinish = new HashMap<InetSocketAddress,Set<Integer>>();
		Set<Integer> localOperatorsToFinish = new HashSet<Integer>();

		synchronized (distributedBlockingOperatorsNotFinished) {
			for (Integer op : opsToRun) {
				if (centralBlockingOperatorsNotFinished.contains(op)) {
					localOperatorsToFinish.add(op);
				} else {
					Set<InetSocketAddress> nodesToFinish;
					if (namedBlockingOperatorsNotFinished.containsKey(op)) {
						nodesToFinish = Collections.singleton(namedBlockingOperatorsNotFinished.get(op));
					} else if (distributedBlockingOperatorsNotFinished.containsKey(op)) {
						nodesToFinish = distributedBlockingOperatorsNotFinished.get(op);
					} else {
						continue;
					}
					for (InetSocketAddress node : nodesToFinish) {
						Set<Integer> opsForNode = remoteOperatorsToFinish.get(node);
						if (opsForNode == null) {
							opsForNode = new HashSet<Integer>();
							remoteOperatorsToFinish.put(node, opsForNode);
						}
						opsForNode.add(op);
					}
				}
			}
		}

		if (! localOperatorsToFinish.isEmpty()) {
			qo.finishLocalBlockingOperators(localOperatorsToFinish);
		}

		if (! remoteOperatorsToFinish.isEmpty()) {
			qo.finishRemoteBlockingOperators(remoteOperatorsToFinish);
		}
	}

	public void reportException(InetSocketAddress node, Exception e) {
		synchronized (exceptions) {
			List<Exception> exs = exceptions.get(node);
			if (exs == null) {
				exs = new ArrayList<Exception>();
				exceptions.put(node, exs);
			}
			exs.add(e);
		}
		
	}
	
	public void reportException(Exception e) {
		reportException(qo.app.localAddr,e);
	}

	public void keysNotFound(int operatorId, List<QpTuple<?>> keys, int phaseNo) {
		if (keys.isEmpty()) {
			return;
		}
		// TODO: do something cleverer here
		reportException(new RuntimeException("Missing tuples for " + operatorId + ": " + keys));
	}

	public void keysNotFound(Collection<TupleAndOp> taos) {
		if (taos.isEmpty()) {
			return;
		}
		// TODO: do something cleverer here
		for (TupleAndOp tao : taos) {
			reportException(new RuntimeException("Missing tuple for " + tao.operatorId + ": " + tao.t));
		}
	}

	private void showStatus() {
		boolean waitingForKeys = false;
		if (! phasesReceivingKeys.isEmpty()) {
			waitingForKeys = true;
		}
		if (waitingForKeys) {
			logger.info("RecordTuplesLocal is waiting for the list of all keys");
		} else {
			int totalExpectedKeys = 0;
			StringBuilder sb = new StringBuilder();
			for (Integer opId : keys.keySet()) {
				int expected = keys.get(opId).expectedCount();
				if (expected != 0) {
					sb.append("\n\tOperator #" + opId + ": " + expected);
					waitingForKeys = true;
					totalExpectedKeys += expected;
				}
			}
			if (waitingForKeys) {
				logger.info("RecordTuplesLocal is waiting for " + totalExpectedKeys + " keys to be scanned" + sb.toString());
			}
		}

		List<Integer> unfinishedBlockingOperators = null;
		if (! waitingForKeys) {
			unfinishedBlockingOperators = new ArrayList<Integer>();
			synchronized (distributedBlockingOperatorsNotFinished) {
				unfinishedBlockingOperators.addAll(distributedBlockingOperatorsNotFinished.keySet());
				unfinishedBlockingOperators.addAll(centralBlockingOperatorsNotFinished);
				unfinishedBlockingOperators.addAll(namedBlockingOperatorsNotFinished.keySet());
			}
			Collections.sort(unfinishedBlockingOperators);
		}

		synchronized (added) {
			if ((! waitingForKeys) && added.isEmpty() && removed.isEmpty()) {
				logger.info("RecordTuplesLocal is waiting for blocking operators " +  unfinishedBlockingOperators);
			}
			logger.info("RecordTuplesLocal has " + added.size() + " tuples in flight and " + removed.size() + " tuples that have been removed but not added");
			if (! removed.isEmpty()) {
				Set<Integer> operators = new HashSet<Integer>();
				for (ExecutionId tid : removed) {
					operators.add(tid.operatorId);
				}
				logger.info("Removed tuples are from operators " + operators);
			}
		}
	}

	public void close() {
		try {
			for (Thread t : startedThreads) {
				t.interrupt();
				t.join();
			}
		} catch (InterruptedException ie) {
		} finally {
			startedThreads.clear();
			added.clear();
			removed.clear();
			keys.clear();
			blockingOperatorDependents.clear();
			distributedBlockingOperatorsNotFinished.clear();
			centralBlockingOperatorsNotFinished.clear();
			namedBlockingOperatorsNotFinished.clear();
			finishableOperators.clear();
			joinOperatorDeps.clear();
			joinOperatorsNotLeftFinished.clear();
			joinOperatorsNotRightFinished.clear();
			logger.info("Closed RecordTuplesLocal for query " + qo.queryId);
		}
	}

	private Map<InetSocketAddress,List<Long>> msgsReceived = Collections.synchronizedMap(new HashMap<InetSocketAddress,List<Long>>());

	public void messageReceived(InetSocketAddress from, long msgId) {
		List<Long> received = msgsReceived.get(from);
		if (received == null) {
			received = new ArrayList<Long>();
			msgsReceived.put(from, received);
		}
		received.add(msgId);
		lastActivity = currTime;
	}

	public Map<InetSocketAddress,Integer> getMessagesReceived() {
		Map<InetSocketAddress,Integer> counts = new HashMap<InetSocketAddress,Integer>(msgsReceived.size());
		for (Map.Entry<InetSocketAddress,List<Long>> me : msgsReceived.entrySet()) {
			counts.put(me.getKey(), me.getValue().size());
		}
		return counts;
	}

	public void ownerActivityOccurred() {
		lastActivity = currTime;
	}

	static class KeySet implements Iterable<ByteArrayWrapper> {
		private static final int[] capacities = {149, 307, 613, 1229, 2503, 5003, 10007, 20021, 40039, 80077,
			160001, 320009, 640007, 1000003, 1280023, 1500007, 1750009, 2000003, 2250013, 2560021, 3000017,
			4000037, 5000011, 6000011, 7000003, 8000009, 9000011, 10000019};

		private class Entry {
			final ByteArrayWrapper key;
			Entry next = null;
			boolean scanned = false, expected = false;

			Entry(ByteArrayWrapper key) {
				this.key = key;
			}
		}

		private final Entry[] table;
		private final Object[] locks;
		private final int expected[], scanned[];
		private final int numLocks;

		final int expectedSize;

		KeySet(int cols[], int size) {
			numLocks = 19;
			locks = new Object[numLocks];
			for (int i = 0; i < numLocks; ++i) {
				locks[i] = new Object();
			}
			expected = new int[numLocks];
			scanned = new int[numLocks];

			int tableSize = size;
			for (int maybeSize : capacities) {
				if (maybeSize > tableSize) {
					tableSize = maybeSize;
					break;
				}
			}

			table = new Entry[tableSize];
			expectedSize = size;
		}

		void scanned(Collection<QpTuple<?>> keys) {
			KEY: for (QpTuple<?> key : keys) {
				if (key == null) {
					continue;
				}
				ByteArrayWrapper keyBytes = new ByteArrayWrapper(key.getKeyBytes());
				int hashCode = keyBytes.hashCode();
				int bucketNum = hashCode % table.length;
				if (bucketNum < 0) {
					bucketNum += table.length;
				}
				int lockNum = bucketNum % numLocks;
				synchronized (locks[lockNum]) {
					Entry e = table[bucketNum];
					if (e == null) {
						e = new Entry(keyBytes);
						table[bucketNum] = e;
						e.scanned = true;
						++scanned[lockNum];
						continue KEY;
					}
					Entry last = null;
					for ( ; ; ) {
						if (e.key.hashCode() == hashCode && e.key.equals(keyBytes)) {
							if (e.expected) {
								if (last == null) {
									table[bucketNum] = e.next;
								} else {
									last.next = e.next;
								}
								--expected[lockNum];
							}
							break;
						}
						last = e;
						e = e.next;
						if (e == null) {
							last.next = new Entry(keyBytes);
							last.next.scanned = true;
							++scanned[lockNum];
							break;
						}
					}
				}
			}
		}

		void scanned(ByteArrayWrapper[] keys) {
			KEY: for (ByteArrayWrapper key : keys) {
				if (key == null) {
					continue;
				}
				int hashCode = key.hashCode();
				int bucketNum = hashCode % table.length;
				if (bucketNum < 0) {
					bucketNum += table.length;
				}
				int lockNum = bucketNum % numLocks;
				synchronized (locks[lockNum]) {
					Entry e = table[bucketNum];
					if (e == null) {
						e = new Entry(key);
						table[bucketNum] = e;
						e.scanned = true;
						++scanned[lockNum];
						continue KEY;
					}
					Entry last = null;
					for ( ; ; ) {
						if (e.key.hashCode() == hashCode && e.key.equals(key)) {
							if (e.expected) {
								if (last == null) {
									table[bucketNum] = e.next;
								} else {
									last.next = e.next;
								}
								--expected[lockNum];
							}
							break;
						}
						last = e;
						e = e.next;
						if (e == null) {
							last.next = new Entry(key);
							last.next.scanned = true;
							++scanned[lockNum];
							break;
						}
					}
				}
			}
		}

		void expected(ByteArrayWrapper keys[]) {
			KEY: for (ByteArrayWrapper key : keys) {
				if (key == null) {
					continue;
				}
				int hashCode = key.hashCode();
				int bucketNum = hashCode % table.length;
				if (bucketNum < 0) {
					bucketNum += table.length;
				}
				int lockNum = bucketNum % numLocks;
				synchronized (locks[lockNum]) {
					Entry e = table[bucketNum];
					if (e == null) {
						e = new Entry(key);
						table[bucketNum] = e;
						e.expected = true;
						++expected[lockNum];
						continue KEY;
					}
					Entry last = null;
					for ( ; ; ) {
						if (e.key.hashCode() == hashCode && e.key.equals(key)) {
							if (e.scanned) {
								if (last == null) {
									table[bucketNum] = e.next;
								} else {
									last.next = e.next;
								}
							}
							--scanned[lockNum];
							break;
						}
						last = e;
						e = e.next;
						if (e == null) {
							last.next = new Entry(key);
							last.next.expected = true;
							++expected[lockNum];
							break;
						}
					}
				}
			}
		}

		int getSize() {
			int size = 0;
			for (int i = 0; i < numLocks; ++i) {
				synchronized (locks[i]) {
					size += expected[i];
					size += scanned[i];
				}
			}
			return size;
		}

		int expectedCount() {
			int expected = 0;
			for (int i = 0; i < numLocks; ++i) {
				synchronized (locks[i]) {
					expected += this.expected[i];
				}
			}
			return expected;
		}

		int scannedCount() {
			int scanned = 0;
			for (int i = 0; i < numLocks; ++i) {
				synchronized (locks[i]) {
					scanned += this.scanned[i];
				}
			}
			return scanned;
		}

		List<QpTuple<?>> expected(QpSchema schema) {
			List<QpTuple<?>> expected = new ArrayList<QpTuple<?>>(expectedCount());

			for (int i = 0; i < numLocks; ++i) {
				synchronized (locks[i]) {
					for (int j = i; j < table.length; j += numLocks) {
						Entry e = table[j];
						while (e != null) {
							if (e.expected) {
								expected.add(QpTuple.fromBytes(QpTuple.SerializationMode.KEY, schema, null, null, e.key.array, e.key.offset, e.key.length, null));
							}
							e = e.next;
						}
					}
				}
			}

			return expected;
		}

		List<QpTuple<?>> scanned(QpSchema schema) {
			List<QpTuple<?>> scanned = new ArrayList<QpTuple<?>>(expectedCount());

			for (int i = 0; i < numLocks; ++i) {
				synchronized (locks[i]) {
					for (int j = i; j < table.length; j += numLocks) {
						Entry e = table[j];
						while (e != null) {
							if (e.scanned) {
								scanned.add(QpTuple.fromBytes(QpTuple.SerializationMode.KEY, schema, null, null, e.key.array, e.key.offset, e.key.length, null));
							}
							e = e.next;
						}
					}
				}
			}

			return scanned;
		}

		public Iterator<ByteArrayWrapper> iterator() {
			return new Iterator<ByteArrayWrapper>() {
				Entry nextEntry;
				Entry currEntry = null;
				Entry prevEntry = null;
				int currBucket, nextBucket;
				int lockNum;
				{
					int foundBucket = -1;
					for (int i = 0; i < table.length; ++i) {
						if (table[i] != null) {
							foundBucket = i;
							break;
						}
					}
					if (foundBucket < 0) {
						nextBucket = table.length;
						currBucket = table.length;
						lockNum = -1;
						nextEntry = null;
					} else {
						nextBucket = foundBucket;
						currBucket = foundBucket;
						nextEntry = (Entry) table[foundBucket];
						lockNum = currBucket % numLocks;
					}

				}
				public boolean hasNext() {
					return nextEntry != null;
				}

				public ByteArrayWrapper next() {
					if (nextEntry == null) {
						throw new NoSuchElementException();
					}
					if (currEntry == null) {
						// Current entry was deleted, so don't advance the prev pointer
					} else if (prevEntry != null) {
						prevEntry = prevEntry.next;
					} else {
						// We were at the first entry in a bucket at now we're at the second
						prevEntry = currEntry;
					}
					// Clear the previous entry if we're entering a new
					// bucket
					if (currBucket != nextBucket) {
						prevEntry = null;
					}


					currBucket = nextBucket;
					lockNum = currBucket % numLocks;
					currEntry = nextEntry;
					if (nextEntry.next != null) {
						nextEntry = nextEntry.next;
					} else {
						nextEntry = null;
						++nextBucket;
						while (nextBucket < table.length) {
							if (table[nextBucket] != null) {
								nextEntry = (Entry) table[nextBucket];
								break;
							}
							++nextBucket;
						}
					}
					return currEntry.key;
				}

				public void remove() {
					if (currEntry == null) {
						throw new IllegalStateException();
					}
					if (prevEntry == null) {
						// Current entry is the first item in a bucket
						table[currBucket] = currEntry.next;
					} else {
						prevEntry.next = currEntry.next;
					}
					if (currEntry.expected) {
						--expected[lockNum];
					} else if (currEntry.scanned) {
						--scanned[lockNum];
					}
					currEntry = null;
				}
			};
		}
	}

	private void initDistributedScans(final int phaseNo, final IdRange[] rangesToSend) throws IndexServiceException, InterruptedException {
		if (distributedScans.isEmpty()) {
			phasesReceivingKeys.remove(phaseNo);
			return;
		}
		final List<RelationAndFilter> scansLeft = new ArrayList<RelationAndFilter>(distributedScans);
		for (final RelationAndFilter raf : distributedScans) {
			final QpSchema schema = qo.getOwnedExecution().getSchema(raf.relation);
			int relId = schema.relId;
			Thread t = qo.app.index.getTuplesInRelation(relId, epoch, new IndexService.SerializedTupleSink() {
				int numPagesRemaining = -1;
				public void deliverTuples(ByteArrayWrapper[] contents) {
					synchronized (QueryCoordinator.this) {
						if (QueryCoordinator.this.done) {
							// We've aborted
							return;
						}
					}
					ownerActivityOccurred();
					boolean last = false;
					Exception e = null;
					synchronized (this) {
						if (numPagesRemaining < 0) {
							e = new RuntimeException("numPagesRemaining < 0, is totalNumTuplesIs not being called?");
						}
						if (e == null) {
							--numPagesRemaining;
							if (numPagesRemaining < 0) {
								e = new RuntimeException("numPagesRemaining < 0, pages are being delivered multiple times");
							}
							if (numPagesRemaining == 0) {
								last = true;
							}
						}
					}
					if (e != null) {
						this.processException(e);
						return;
					}

					if (raf.keyFilter != null || rangesToSend != null) {
						try {
							final int length = contents.length;
							for (int i = 0; i < length; ++i) {
								ByteArrayWrapper tupleBytes = contents[i];
								if (tupleBytes == null) {
									break;
								}
								QpTuple<?> t = QpTuple.fromBytes(QpTuple.SerializationMode.KEY, schema, null, null, tupleBytes.array, tupleBytes.offset, tupleBytes.length, null);
								if (raf.keyFilter != null && (! raf.keyFilter.eval(t))) {
									contents[i] = null;
									continue;
								}
								if (rangesToSend != null) {
									final Id id = t.getQPid();
									boolean good = false;
									for (IdRange range : rangesToSend) {
										if (range.contains(id)) {
											good = true;
											break;
										}
									}
									if (! good) {
										contents[i] = null;
									}
								}
							}
						} catch (FilterException fe) {
							fe.printStackTrace();
						}
					}
					keysExpected(raf.operatorId, contents, phaseNo);

					if (last) {
						boolean scansLeftDone;
						synchronized (scansLeft) {
							scansLeft.remove(raf);
							logger.info("Done retrieving keys for " + raf.relation);
							scansLeftDone = scansLeft.isEmpty();
						}
						if (scansLeftDone) {
							phasesReceivingKeys.remove(phaseNo);
						}
					}
				}

				public synchronized void totalNumTuplesIs(int numTuples, int numPages) {
					this.numPagesRemaining = numPages;
				}

				public void processException(Exception e) {
					reportException(e);
				}
			});
			t.setPriority(Thread.MAX_PRIORITY - 1);
			synchronized (startedThreads) {
				startedThreads.add(t);
			}
			qo.app.index.sendKeyTuples(relId, epoch, queryId, raf.operatorId, raf.keyFilter, this, rangesToSend, phaseNo);
		}
	}

	void start() throws IndexServiceException, InterruptedException {
		initDistributedScans(0,null);
	}

	public void nodesHaveFailed(Collection<InetSocketAddress> nodes) {
		if (! qo.getOwnedExecution().getRouter(0).getParticipants().containsAll(nodes)) {
			throw new IllegalArgumentException("Nodes " + nodes + " are not all participating in query");
		}
		if (attemptRecovery) {
			reportedFailedNodes.addAll(nodes);
		} else {
			reportException(new RuntimeException("Node(s) " + nodes + " have failed"));
		}
	}

	int getCurrentPhase() {
		return nextPhase - 1;
	}

	boolean nodeHasFailed(InetSocketAddress node) {
		synchronized (failedNodes) {
			return failedNodes.contains(node);
		}
	}
}
package edu.upenn.cis.orchestra.p2pqp;

import static edu.upenn.cis.orchestra.p2pqp.ExecutionId.UNKNOWN_PHASE_NO;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.p2pqp.Filter.FilterException;
import edu.upenn.cis.orchestra.p2pqp.IndexService.TupleSink;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyException;
import edu.upenn.cis.orchestra.p2pqp.messages.RetrieveTupleMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.TupleFailsFilter;
import edu.upenn.cis.orchestra.p2pqp.messages.TupleIsMessage;

public class ProbeJoin<M> extends PipelinedHashJoin<M> {
	private final QpApplication<M> app;
	private final Filter<? super QpTuple<?>> rightKeyFilter, rightFullFilter;

	public static final int bloomFilterSize = 631;

	private final Set<Integer> returnFromProbe;
	private final boolean canProbeAgainstIndex;

	private final int maxTuplesForList;

	private int numPagesRemaining = -1;
	private final ArrayList<QpTuple<?>> tuplesForRelation;
	private boolean haveAllTuplesForRelation = false;
	private final List<QpTuple<M>> waitingTuples;

	private int probeCount = 0;
	private final Map<Integer,Integer> remainingTuplesForProbe;
	// To avoid race conditions with the query coordinator,
	// only process the tuples after all of their probing is done
	private final Map<Integer,List<QpTuple<M>>> tuplesForProbe;
	private final Map<Integer,List<ExecutionId>> retrievedTuplesForProbe;

	private final QpSchema.Source findProbeSchema;
	private final QpSchema probeSchema;

	private final int[] rightKeyInLeftRelation;
	private final int[] rightKeysPresentInLeftRelation;
	private final int[] leftJoinIndices, rightJoinIndices;

	private final QpSchema leftSchema;

	private final Set<QpTuple<Null>> probedKeys = new HashSet<QpTuple<Null>>();

	public ProbeJoin(QpApplication<M> app, int maxTuplesForList,
			QpSchema leftSchema, QpSchema rightTable, int epoch,
			List<Integer> leftJoinIndices, List<Integer> rightJoinIndices, List<Integer> leftOutputPos, List<Integer> rightOutputPos,
			QpSchema outputSchema, Operator<M> dest, WhichChild outputDest, int queryId, InetSocketAddress nodeId,
			int operatorId, RecordTuples rt) throws Operator.OperatorCreationException {
		this(app, maxTuplesForList, leftSchema, rightTable, epoch, 
				null, null, leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos, true,
				outputSchema, dest, outputDest, queryId, nodeId, operatorId, rt);
	}

	public ProbeJoin(QpApplication<M> app, int maxTuplesForList,
			QpSchema leftSchema, QpSchema rightTable, int epoch,
			List<Integer> leftJoinIndices, List<Integer> rightJoinIndices, List<Integer> leftOutputPos, List<Integer> rightOutputPos,
			boolean allowDuplicates, 
			QpSchema outputSchema, Operator<M> dest, WhichChild outputDest, int queryId, InetSocketAddress nodeId,
			int operatorId, RecordTuples rt) throws Operator.OperatorCreationException {
		this(app, maxTuplesForList, leftSchema, rightTable, epoch, 
				null, null, leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos, allowDuplicates,
				outputSchema, dest, outputDest, queryId, nodeId, operatorId, rt);
	}

	public ProbeJoin(QpApplication<M> app, int maxTuplesForList, QpSchema leftSchema, QpSchema rightTable, int epoch,
			Filter<? super QpTuple<?>> rightKeyFilter, Filter<? super QpTuple<?>> rightFullFilter,
					List<Integer> leftJoinIndices, List<Integer> rightJoinIndices, List<Integer> leftOutputPos, List<Integer> rightOutputPos,
					boolean allowDuplicates,
					QpSchema outputSchema, Operator<M> dest, WhichChild outputDest, int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt) throws Operator.OperatorCreationException {
		super(leftSchema, rightTable, leftJoinIndices, rightJoinIndices,
				leftOutputPos, rightOutputPos, allowDuplicates, outputSchema, dest, outputDest, queryId,
				nodeId, operatorId, rt, app.mdf, false);

		this.app = app;

		Set<Integer> desiredCols = new HashSet<Integer>(rightJoinIndices);
		int pos = 0;
		for (Integer col : rightOutputPos) {
			if (col != null && col >= 0) {
				desiredCols.add(pos);
			}
			++pos;
		}

		probeSchema = rightTable;
		this.leftSchema = leftSchema; 
		desiredCols.addAll(probeSchema.getKeyColsSet());

		this.returnFromProbe = Collections.unmodifiableSet(desiredCols);
		this.maxTuplesForList = maxTuplesForList;

		this.rightFullFilter = rightFullFilter;
		this.rightKeyFilter = rightKeyFilter;

		tuplesForRelation = new ArrayList<QpTuple<?>>();
		waitingTuples = new ArrayList<QpTuple<M>>();
		remainingTuplesForProbe = new HashMap<Integer,Integer>();
		tuplesForProbe = new HashMap<Integer,List<QpTuple<M>>>();
		retrievedTuplesForProbe = new HashMap<Integer,List<ExecutionId>>();


		if (rightKeyFilter != null && (! probeSchema.getKeyColsSet().containsAll(rightKeyFilter.getColumns()))) {
			throw new IllegalArgumentException("Right key columns filter uses non-key columns");
		}

		findProbeSchema = new QpSchema.SingleSource(probeSchema);

		app.index.getTuplesInRelation(probeSchema.relId, epoch, new TupleSink() {

			public void deliverTuples(QpTuple<?>[] contents) {
				synchronized (tuplesForRelation) {
					if (numPagesRemaining < 0) {
						reportException(new RuntimeException("numPagesRemaining < 0, is totalNumTuplesIs not being called?"));
						return;
					}
					for (QpTuple<?> t : contents) {
						if (t == null) {
							break;
						}
						tuplesForRelation.add(t);
					}
					--numPagesRemaining;
					if (numPagesRemaining < 0) {
						reportException(new RuntimeException("numPagesRemaining < 0, pages must be being delivered multiple times"));
						return;
					}
					if (numPagesRemaining == 0) {
						haveAllTuplesForRelation = true;
						processWaitingTuples();
					}
				}
			}

			public void totalNumTuplesIs(int numTuples, int numPages) {
				synchronized (tuplesForRelation) {
					tuplesForRelation.ensureCapacity(numTuples);
					numPagesRemaining = numPages;
				}
			}

			public void processException(Exception e) {
				ProbeJoin.this.reportException(e);
			}

		});

		Set<Integer> needed = new HashSet<Integer>(desiredCols);
		if (this.rightFullFilter != null) {
			needed.addAll(rightFullFilter.getColumns());
		}
		if (this.rightKeyFilter != null) {
			needed.addAll(rightKeyFilter.getColumns());
		}
		if (probeSchema.getKeyColsSet().containsAll(needed)) {
			canProbeAgainstIndex = true;
		} else {
			canProbeAgainstIndex = false;
		}

		// Want to check against join variables that are keys for the right
		// relation
		List<Integer> rightKeyInLeftRelation = new ArrayList<Integer>();
		List<Integer> rightKeysPresentInLeftRelation = new ArrayList<Integer>();
		final int numJoinCols = leftJoinIndices.size();
		for (int i = 0; i < numJoinCols; ++i) {
			if (probeSchema.getKeyColsSet().contains(rightJoinIndices.get(i))) {
				rightKeyInLeftRelation.add(leftJoinIndices.get(i));
				rightKeysPresentInLeftRelation.add(rightJoinIndices.get(i));
			}
		}

		this.rightKeyInLeftRelation = new int[rightKeyInLeftRelation.size()];
		this.rightKeysPresentInLeftRelation = new int[rightKeysPresentInLeftRelation.size()];
		for (int i = 0; i < this.rightKeyInLeftRelation.length; ++i) {
			this.rightKeyInLeftRelation[i] = rightKeyInLeftRelation.get(i);
			this.rightKeysPresentInLeftRelation[i] = rightKeysPresentInLeftRelation.get(i);
		}

		this.leftJoinIndices = new int[leftJoinIndices.size()];
		this.rightJoinIndices = new int[rightJoinIndices.size()];

		for (int i = 0; i < this.leftJoinIndices.length; ++i) {
			this.leftJoinIndices[i] = leftJoinIndices.get(i);
			this.rightJoinIndices[i] = rightJoinIndices.get(i);
		}
	}

	private void processWaitingTuples() {
		receiveTuples(waitingTuples);
		waitingTuples.clear();
	}


	protected void receiveTuples(List<QpTuple<M>> tuples) {
		if (tuples.isEmpty()) {
			return;
		}
		synchronized (tuplesForRelation) {
			if (! haveAllTuplesForRelation) {
				waitingTuples.addAll(tuples);
				return;
			}
		}

		List<QpTuple<M>> probeTuples = new ArrayList<QpTuple<M>>();
		synchronized (probedKeys) {
			for (QpTuple<M> t : tuples) {
				if (t.isLeft()) {
					QpTuple<Null> key = getKeyFromLeft(t);
					if (! probedKeys.contains(key)) {
						// Need to probe, but make sure we only do so once
						probeTuples.add(t);
						probedKeys.add(key);
					}
				}
			}
		}

		if (probeTuples.isEmpty()) {
			super.receiveTuples(tuples);
			return;
		}


		boolean useBloomFilter = tuples.size() > maxTuplesForList;

		TupleSetFilter f;
		if (useBloomFilter) {
			f = new BloomFilter(bloomFilterSize, probeTuples.size(), this.leftSchema, this.leftJoinIndices);
		} else {
			f = new TupleList(this.leftSchema, this.leftJoinIndices);
		}

		for (QpTuple<M> t : probeTuples) {
			f.add(t);
		}
		try {
			f.changeRelation(probeSchema, this.rightJoinIndices);
		} catch (ValueMismatchException vme) {
			this.reportException(vme);
			return;
		}

		if (canProbeAgainstIndex) {
			Filter<? super QpTuple<?>> indexFilter = f;
			if (rightKeyFilter != null || rightFullFilter != null) {
				List<Filter<? super QpTuple<?>>> filters = new ArrayList<Filter<? super QpTuple<?>>>(3);
				filters.add(f);
				if (rightKeyFilter != null) {
					filters.add(rightKeyFilter);
				}
				if (rightFullFilter != null) {
					filters.add(rightFullFilter);
				}
				indexFilter = new FilterConjunction<QpTuple<?>>(filters);
			}
			List<QpTuple<M>> rightTuples = new ArrayList<QpTuple<M>>();
			List<ExecutionId> addedTuples = new ArrayList<ExecutionId>();
			try {
				for (QpTuple<?> t : tuplesForRelation) {
					if (indexFilter.eval(t)) {
						QpTuple<M> newT = t.getNonKeyTuple(getFreshId(UNKNOWN_PHASE_NO), mdf == null ? null : mdf.scan(this, null));
						addedTuples.add(newT.getId());
						rightTuples.add(newT);
					}
				}
			} catch (FilterException fe) {
				fe.printStackTrace();
				return;
			}
			tuplesAdded(addedTuples);
			for (QpTuple<M> t : rightTuples) {
				t.setDest(WhichChild.RIGHT);
			}
			super.receiveTuples(rightTuples);
			super.receiveTuples(tuples);
			return;
		}

		TupleSetFilter localFilter = null;
		if (rightKeyInLeftRelation.length != 0) {
			if (useBloomFilter) {
				localFilter = new BloomFilter(bloomFilterSize, probeTuples.size(), this.leftSchema, rightKeyInLeftRelation);
			} else {
				localFilter = new TupleList(this.leftSchema, rightKeyInLeftRelation);
			}
			for (QpTuple<M> t : probeTuples) {
				localFilter.add(t);
			}
			try {
				localFilter.changeRelation(probeSchema, rightKeysPresentInLeftRelation);
			} catch (ValueMismatchException vme) {
				this.reportException(vme);
				return;
			}
		}

		Filter<? super QpTuple<?>> keyConjunct, fullConjunct;
		if (rightKeyFilter == null) {
			keyConjunct = localFilter;
		} else if (localFilter == null){
			keyConjunct = rightKeyFilter;
		} else {
			List<Filter<? super QpTuple<?>>> both = new ArrayList<Filter<? super QpTuple<?>>>(2);
			both.add(localFilter);
			both.add(rightKeyFilter);
			keyConjunct = new FilterConjunction<QpTuple<?>>(both);
		}

		if (rightFullFilter == null) {
			fullConjunct = f;
		} else {
			List<Filter<? super QpTuple<?>>> both = new ArrayList<Filter<? super QpTuple<?>>>(2);
			both.add(f);
			both.add(rightFullFilter);
			fullConjunct = new FilterConjunction<QpTuple<?>>(both);
		}

		List<QpTuple<?>> toProbe;
		if (keyConjunct == null) {
			toProbe = tuplesForRelation;
		} else {
			toProbe = new ArrayList<QpTuple<?>>();
			try {
				for (QpTuple<?> t : tuplesForRelation) {
					if (keyConjunct.eval(t)) {
						toProbe.add(t);
					}
				}
			} catch (FilterException fe) {
				fe.printStackTrace();
				return;
			}
		}

		final int probeNo;
		synchronized (remainingTuplesForProbe) {
			probeNo = this.probeCount++;
			remainingTuplesForProbe.put(probeNo, toProbe.size());
		}

		synchronized (tuplesForProbe) {
			tuplesForProbe.put(probeNo, new ArrayList<QpTuple<M>>(tuples));
		}

		synchronized (retrievedTuplesForProbe) {
			retrievedTuplesForProbe.put(probeNo, new ArrayList<ExecutionId>());
		}

		try {
			for (QpTuple<?> t: toProbe) {
				QpMessage m = new RetrieveTupleMessage(t,
						fullConjunct, returnFromProbe);
				ReplyContinuation rc = new ReplyContinuation() {
					boolean done = false;

					public synchronized boolean isFinished() {
						return done;
					}

					public synchronized void processReply(Message m) {
						if (m instanceof TupleIsMessage) {
							TupleIsMessage tim = (TupleIsMessage) m;
							QpTuple<M> probed = QpTuple.fromBytes(QpTuple.SerializationMode.STORE, probeSchema, findProbeSchema, mdf, tim.t, getFreshId(UNKNOWN_PHASE_NO));
							probed.setDest(WhichChild.RIGHT);
							synchronized (tuplesForProbe) {
								tuplesForProbe.get(probeNo).add(probed);
							}
							synchronized (retrievedTuplesForProbe) {
								retrievedTuplesForProbe.get(probeNo).add(probed.getId());								
							}
						} else if (! (m instanceof TupleFailsFilter)) {
							Throwable t;
							if (m instanceof ReplyException) {
								ReplyException re = (ReplyException) m;
								t = new Throwable("Recevied Exception reply to RetrieveTupleMessage: " + re.what, re.why);
							} else {
								t = new Throwable("Recevied unexpected reply to RetrieveTupleMessage: " + m);
							}
							t.printStackTrace();
							return;
						}
						boolean sendRest = false;
						synchronized (remainingTuplesForProbe) {
							Integer count = remainingTuplesForProbe.get(probeNo);
							if (count == null) {
								Exception e = new Exception("Missing remainingTuplesForProbe");
								reportException(e);
							} else {
								int remaining = count - 1;
								if (remaining == 0) {
									remainingTuplesForProbe.remove(probeNo);
									sendRest = true;
								} else {
									remainingTuplesForProbe.put(probeNo, remaining);
								}
							}
						}
						if (sendRest) {
							List<ExecutionId> addedIds;
							synchronized (retrievedTuplesForProbe) {
								addedIds = retrievedTuplesForProbe.remove(probeNo);
							}
							if (addedIds == null) {
								Exception e = new Exception("Missing retrievedTuplesForProbe");
								reportException(e);
							}  else {
								tuplesAdded(addedIds);
							}

							List<QpTuple<M>> toProcess;
							synchronized(tuplesForProbe) {
								toProcess = tuplesForProbe.remove(probeNo);
								if (tuplesForProbe.isEmpty()) {
									tuplesForProbe.notifyAll();
								}
							}
							if (toProcess == null) {
								Exception e = new Exception("Missing inputTuplesForProbe");
								reportException(e);
							} else if (! toProcess.isEmpty()) {
								ProbeJoin.super.receiveTuples(toProcess);
							}
						}
						done = true;
					}

				};
				app.sendMessageAwaitReply(m, rc, TupleIsMessage.class, TupleFailsFilter.class);
			}
		} catch (IOException e) {
			reportException(e);
		} catch (InterruptedException ie) {
			return;
		}

	}

	void waitUntilFinished() throws InterruptedException {
		synchronized (tuplesForProbe) {
			while (! tuplesForProbe.isEmpty()) {
				tuplesForProbe.wait();
			}
		}
	}

	protected void close() {
		super.close();
		tuplesForRelation.clear();
		waitingTuples.clear();
		tuplesForProbe.clear();
	}
}

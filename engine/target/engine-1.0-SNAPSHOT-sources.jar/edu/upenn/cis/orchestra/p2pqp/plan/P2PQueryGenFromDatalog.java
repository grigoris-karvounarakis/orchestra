package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import edu.upenn.cis.orchestra.datalog.Datalog;
import edu.upenn.cis.orchestra.datalog.DatalogProgram;
import edu.upenn.cis.orchestra.datalog.NonRecursiveDatalogProgram;
import edu.upenn.cis.orchestra.datalog.RecursiveDatalogProgram;
import edu.upenn.cis.orchestra.datamodel.Atom;
import edu.upenn.cis.orchestra.datamodel.AtomArgument;
import edu.upenn.cis.orchestra.datamodel.AtomConst;
import edu.upenn.cis.orchestra.datamodel.AtomVariable;
import edu.upenn.cis.orchestra.datamodel.PrimaryKey;
import edu.upenn.cis.orchestra.datamodel.AbstractRelation.BadColumnName;
import edu.upenn.cis.orchestra.datamodel.exceptions.UnknownRefFieldException;
import edu.upenn.cis.orchestra.datamodel.StringType;
import edu.upenn.cis.orchestra.mappings.Rule;
import edu.upenn.cis.orchestra.optimization.Aggregate.AggFunc;
import edu.upenn.cis.orchestra.p2pqp.Concatenate;
import edu.upenn.cis.orchestra.p2pqp.Sum;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.FunctionEvaluator.ColumnInput;
import edu.upenn.cis.orchestra.p2pqp.FunctionEvaluator.ColumnOrFunction;
import edu.upenn.cis.orchestra.p2pqp.FunctionEvaluator.EvalFunc;

public class P2PQueryGenFromDatalog {
	   static int operatorID = 0;
	   static int relID = 0;
	   static final int[] defaultHashCols = {0};
	   static public Collection<QpSchema> schemas = new HashSet<QpSchema>();
	   static public HashMap<String, QpSchema> baseSchemas = new HashMap<String, QpSchema>();
	   static Map<String,QpSchema> headSchemaByName = new HashMap<String, QpSchema>();
	   static Map<String,QueryPlan> headPlanByName = new HashMap<String, QueryPlan>();
	   static Map<String, List<Integer>> groupingsByName = new HashMap<String,List<Integer>>();
	   static Map<String, List<AggregateNode.OutputColumn>> outputColumnsByName = new HashMap<String, List<AggregateNode.OutputColumn>>();
	   static QpSchema rehashSchema = null;
	   
	   public static void init() {
		   operatorID = 0;
		   relID = 0; 
		   schemas = new HashSet<QpSchema>();
		   baseSchemas = new HashMap<String, QpSchema>();
		   headSchemaByName = new HashMap<String, QpSchema>();
		   headPlanByName = new HashMap<String, QueryPlan>();
		   groupingsByName = new HashMap<String,List<Integer>>();
		   outputColumnsByName = new HashMap<String, List<AggregateNode.OutputColumn>>();
		   rehashSchema = null;
	   }
	   
	   public static Map<Integer, Integer> generateMapping(int size) {
		   Map<Integer,Integer> mapping = new HashMap<Integer,Integer>();
		   for (int i = 0; i < size; i++) {
			   mapping.put(i,i);
		   }
		   mapping = Collections.unmodifiableMap(mapping);
		   return mapping;
	   }
	   
	   public static QueryPlan p2pSingleRuleEvalution(Atom th, List<Atom> body){
			QpSchema headSchema = new QpSchema(th.getRelation().getRelationName(), relID++);
			for (int i = 0; i < th.getRelation().getNumCols(); i++) {
				try {
				headSchema.addCol(th.getRelation().getColName(i), "", th.getRelation().getColType(i));
				} catch (BadColumnName bcn) {
					throw new RuntimeException("Error adding column:", bcn);
				}
			}
		
			headSchema.setPrimaryKey(th.getRelation().getPrimaryKey());
			headSchema.setHashCols(defaultHashCols);
			headSchema.markFinished();
			schemas.add(headSchema);
			headSchemaByName.put(th.getRelation().getRelationName(),headSchema);
			List<AtomArgument> headAtomArguments = th.getValues();

			boolean isRecursive = false;
			// Assume here linear rule, which means head only appears in the body once
			for (Atom bodyAtom: body) {
				if (bodyAtom.getRelation().equals(th.getRelation())) {
					if (isRecursive) {
						throw new RuntimeException("Can not have a rule whose head appears in the body more than once");
					}
					isRecursive = true;
				}
			}
			if (isRecursive) {
				// Recursive query
				ArrayList<Atom> newBody = new ArrayList<Atom>();
				Atom fixpointPredicate = null;
				for (Atom bodyAtom: body) {
					if (!bodyAtom.getRelation().equals(th.getRelation())) {
						newBody.add(bodyAtom);
					} else {
						fixpointPredicate = bodyAtom;
					}
				}
				
				boolean first = true;
				QpSchema recursiveSchema = null;
				QueryPlan recursiveNode = null;
				List<AtomArgument> recursiveAtomArguments = null;
				
				ArrayList<Atom> functionPredicateList = new ArrayList<Atom>();
				ArrayList<List<AtomArgument>> functionAtomArgumentsList = new ArrayList<List<AtomArgument>>();
				ArrayList<QpSchema> functionSchemaList = new ArrayList<QpSchema>();
				
				while (!newBody.isEmpty()) {
					//Configure baseSchema
					Atom basePredicate = newBody.remove(0);		
					QueryPlan baseNode = null;
					List<AtomArgument> baseAtomArguments = new ArrayList<AtomArgument>(basePredicate.getValues());
					QpSchema baseSchema; 
					if (!basePredicate.getRelation().getRelationName().startsWith("FUNC_")) {
						if (!headSchemaByName.containsKey(basePredicate.getRelation().getRelationName())) {
							if (baseSchemas.containsKey(basePredicate.getRelation().getRelationName())) {
								baseSchema = baseSchemas.get(basePredicate.getRelation().getRelationName());
							} else {
								baseSchema = new QpSchema(basePredicate.getRelation().getRelationName(), relID++);
								for (int i=0; i<basePredicate.getRelation().getNumCols(); i++) {
									try {
										baseSchema.addCol(basePredicate.getRelation().getColName(i), "", basePredicate.getRelation().getColType(i));
									} catch (BadColumnName bcn) {
										throw new RuntimeException("Error adding column:", bcn);
									}
								}
								baseSchema.setPrimaryKey(basePredicate.getRelation().getPrimaryKey());
								baseSchema.setHashCols(defaultHashCols);
								baseSchema.markFinished();
								schemas.add(baseSchema);
								//headSchemaByName.put(basePredicate.getRelation().getRelationName(),baseSchema);
								baseSchemas.put(basePredicate.getRelation().getRelationName(), baseSchema);	
							}
							baseNode = new DistributedScanNode(baseSchema, null, null, DistributedLoc.getInstance(), operatorID++);
						} else {
							baseSchema = headSchemaByName.get(basePredicate.getRelation().getRelationName());
							baseNode = headPlanByName.get(basePredicate.getRelation().getRelationName());
						}	
						
					} else {
						baseSchema = new QpSchema(basePredicate.getRelation().getRelationName(), relID++);
						try {
							baseSchema.addCol(basePredicate.getRelation().getColName(0), "", basePredicate.getRelation().getColType(0));
						} catch (BadColumnName bcn) {
							throw new RuntimeException("Error adding column:", bcn);
						}
						baseSchema.setPrimaryKey(basePredicate.getRelation().getPrimaryKey());
						baseSchema.setHashCols(defaultHashCols);
						baseSchema.markFinished();
						functionPredicateList.add(basePredicate);
						functionAtomArgumentsList.add(baseAtomArguments);
						functionSchemaList.add(baseSchema);
						continue;
					}

					//modify recursive schema;
					if (first) {
						recursiveSchema = baseSchema;
						recursiveNode = baseNode;
						recursiveAtomArguments = baseAtomArguments;
						first = false;
						continue;
					}
					
					//Join recursiveSchema with baseSchema
					
					List<Integer> recursiveJoinIndices = new ArrayList<Integer>();
					List<Integer> baseJoinIndices = new ArrayList<Integer>();
					
					Iterator<AtomArgument> baseIterator = baseAtomArguments.iterator();
					while (baseIterator.hasNext()) {
						AtomArgument baseArgument = baseIterator.next();
						if (recursiveAtomArguments.contains(baseArgument)) {
						  recursiveJoinIndices.add(recursiveAtomArguments.indexOf(baseArgument));
						  baseJoinIndices.add(baseAtomArguments.indexOf(baseArgument));
						}
					}
					
					List<Integer> recursiveOutputPos = new ArrayList<Integer>();
 
					int pos = 0; 
					for (int i = 0; i < recursiveAtomArguments.size(); i++) { 
						recursiveOutputPos.add(pos++);
					}
				
					List<Integer> baseOutputPos = new ArrayList<Integer>();
					for (int i = 0; i < baseAtomArguments.size(); i++) {
						if (baseJoinIndices.contains(i)) {
							baseOutputPos.add(null);
						} else { 
							baseOutputPos.add(pos++);
						}
					}
					
					//Materialized view, create intermediate schema newOutputSchema
					QpSchema newOutputSchema = new QpSchema("RECURSIVE_NEW"+relID, relID++);
					List<AtomArgument> newOutputAtomArguments = new ArrayList<AtomArgument>();
					List<String> newPrimaryKeyList = new ArrayList<String>();
					
					try {
						for (int i = 0; i < recursiveOutputPos.size(); i++) {
							if (recursiveOutputPos.get(i) != null) {
								newOutputSchema.addCol(recursiveSchema.getColName(i)+"_L", "", recursiveSchema.getColType(i));
								newOutputAtomArguments.add(recursiveAtomArguments.get(i));
								if (recursiveSchema.getKeyCols().contains(i)) {
									newPrimaryKeyList.add(recursiveSchema.getColName(i)+"_L");
								}
							}
						}
						
						for (int i = 0; i < baseOutputPos.size(); i++) {
							if (baseOutputPos.get(i) != null) {
								newOutputSchema.addCol(baseSchema.getColName(i)+"_R", "", baseSchema.getColType(i));
								newOutputAtomArguments.add(baseAtomArguments.get(i));
								if (baseSchema.getKeyCols().contains(i)) {
									newPrimaryKeyList.add(baseSchema.getColName(i)+"_R");
								}
							}
						}
					
					} catch (BadColumnName bcn) {
						throw new RuntimeException("Error adding column:", bcn);
					}
					//Assume by default the new tuples are hashed by the first attribute
					try {
						newOutputSchema.setPrimaryKey(new PrimaryKey("pk", newOutputSchema, newPrimaryKeyList));
					} catch (UnknownRefFieldException urfe){
						throw new RuntimeException("Error setting primary key for new schema:", urfe);
					}
					newOutputSchema.setHashCols(defaultHashCols);
					newOutputSchema.markFinished();
					schemas.add(newOutputSchema);
							
					//Should rehash baseNode from defaultHashCols to one of baseJoinIndices
					//Should rehash recursiveNode from defaultHashCols to one of recursiveJoinIndices
				    
				    if (!recursiveJoinIndices.contains(new Integer(defaultHashCols[0]))) {
						if (baseJoinIndices.contains(new Integer(defaultHashCols[0]))) {
							// no need to rehash baseNode
							// rehash recursiveNode to the position i, where
							// baseAtomArguments.get(defaultHashCols[0])=recursiveAtomArguments.get(i)
							int [] newRecursiveHashCols = {recursiveAtomArguments.indexOf(baseAtomArguments.get(defaultHashCols[0]))}; 
							QpSchema recursiveRehashSchema = QpSchema.rehashQpSchema(recursiveSchema, defaultHashCols, newRecursiveHashCols, relID++);
							schemas.add(recursiveRehashSchema);
						    recursiveNode = new ShipNode(recursiveSchema, generateMapping(recursiveSchema.getNumCols()), recursiveRehashSchema, DistributedLoc.getInstance(), operatorID++, recursiveNode);
						} else {
							// need to rehash baseNode and recursiveNode
							// rehash baseNode to the last possible position in baseJoinIndices;
							// rehash recursiveNode to the position i, where
							// baseAtomArguments.get(baseJoinIndices.get(baseJoinIndices.size()))=recursiveAtomArguments.get(i)
							int [] newBaseHashCols = {baseJoinIndices.get(baseJoinIndices.size()-1)};
							int [] newRecursiveHashCols = {recursiveAtomArguments.indexOf(baseAtomArguments.get(baseJoinIndices.get(baseJoinIndices.size()-1)))};
							QpSchema baseRehashSchema = QpSchema.rehashQpSchema(headSchema, defaultHashCols, newBaseHashCols, relID++);
							schemas.add(baseRehashSchema);
						    baseNode = new ShipNode(baseSchema, generateMapping(baseSchema.getNumCols()), baseRehashSchema, DistributedLoc.getInstance(), operatorID++, baseNode);
						    QpSchema recursiveRehashSchema = QpSchema.rehashQpSchema(recursiveSchema, defaultHashCols, newRecursiveHashCols, relID++);
						    schemas.add(recursiveRehashSchema);
						    recursiveNode = new ShipNode(recursiveSchema, generateMapping(recursiveSchema.getNumCols()), recursiveRehashSchema, DistributedLoc.getInstance(), operatorID++, recursiveNode);
						}			    		
				    } else {
				    	if (baseJoinIndices.contains(new Integer(defaultHashCols[0]))) {
				    		// no need to rehash baseNode and recursiveNode
				    	} else {
				    		// need to rehash baseNode
				    		int [] newBaseHashCols = {baseAtomArguments.indexOf(recursiveAtomArguments.get(defaultHashCols[0]))};
				    		QpSchema baseRehashSchema = QpSchema.rehashQpSchema(headSchema, defaultHashCols, newBaseHashCols, relID++);
				    		schemas.add(baseRehashSchema);
						    baseNode = new ShipNode(baseSchema, generateMapping(baseSchema.getNumCols()), baseRehashSchema, DistributedLoc.getInstance(), operatorID++, baseNode);
				    	}
				    }
				    recursiveNode = new PipelinedJoinNode(newOutputSchema, recursiveJoinIndices, baseJoinIndices, recursiveOutputPos, 
							baseOutputPos, DistributedLoc.getInstance(), false, recursiveNode, baseNode, operatorID++);
					recursiveSchema = newOutputSchema;
					recursiveAtomArguments = newOutputAtomArguments;
				}
			
				List<AtomArgument> fixpointAtomArguments = new ArrayList<AtomArgument>(fixpointPredicate.getValues()); 
				QpSchema fixpointSchema = headSchema;
				//Join recursiveSchema with fixpointSchema
				
				List<Integer> recursiveJoinIndices = new ArrayList<Integer>();
				List<Integer> fixpointJoinIndices = new ArrayList<Integer>();
				
				Iterator<AtomArgument> fixpointIterator = fixpointAtomArguments.iterator();
				while (fixpointIterator.hasNext()) {
					AtomArgument fixpointArgument = fixpointIterator.next();
					if (recursiveAtomArguments.contains(fixpointArgument)) {
					  recursiveJoinIndices.add(recursiveAtomArguments.indexOf(fixpointArgument));
					  fixpointJoinIndices.add(fixpointAtomArguments.indexOf(fixpointArgument));
					}
				}
				
				List<Integer> recursiveOutputPos = new ArrayList<Integer>();
				int pos = 0; 
				for (int i = 0; i < recursiveAtomArguments.size(); i++) {
					recursiveOutputPos.add(pos++);
				}
			
				List<Integer> fixpointOutputPos = new ArrayList<Integer>();
				for (int i = 0; i < fixpointAtomArguments.size(); i++) {
					if (fixpointJoinIndices.contains(i)) {
						fixpointOutputPos.add(null);
					} else {
						fixpointOutputPos.add(pos++);
					}
				}
				
				//Materialized view, create intermediate schema newOutputSchema
				QpSchema newOutputSchema = new QpSchema("RECURSIVE_NEW"+relID, relID++);
				List<AtomArgument> newOutputAtomArguments = new ArrayList<AtomArgument>();
				List<String> newPrimaryKeyList = new ArrayList<String>();
				
				try {
					for (int i = 0; i < recursiveOutputPos.size(); i++) {
						if (recursiveOutputPos.get(i) != null) {
							newOutputSchema.addCol(recursiveSchema.getColName(i)+"_L", "", recursiveSchema.getColType(i));
							newOutputAtomArguments.add(recursiveAtomArguments.get(i));
							if (recursiveSchema.getKeyCols().contains(i)) {
								newPrimaryKeyList.add(recursiveSchema.getColName(i)+"_L");
							}
						}
					}
					
					for (int i = 0; i < fixpointOutputPos.size(); i++) {
						if (fixpointOutputPos.get(i) != null) {
							newOutputSchema.addCol(fixpointSchema.getColName(i)+"_R", "", fixpointSchema.getColType(i));
							newOutputAtomArguments.add(fixpointAtomArguments.get(i));
							if (fixpointSchema.getKeyCols().contains(i)) {
								newPrimaryKeyList.add(fixpointSchema.getColName(i)+"_R");
							}
						}
					}
				
				} catch (BadColumnName bcn) {
					throw new RuntimeException("Error adding column:", bcn);
				}
				//Assume by default the new tuples are hashed by the first attribute
				try {
					newOutputSchema.setPrimaryKey(new PrimaryKey("pk", newOutputSchema, newPrimaryKeyList));
				} catch (UnknownRefFieldException urfe){
					throw new RuntimeException("Error setting primary key for new schema:", urfe);
				}
				newOutputSchema.setHashCols(defaultHashCols);
				newOutputSchema.markFinished();
				schemas.add(newOutputSchema);
				
				//Should rehash fixpointNode from defaultHashCols to one of fixpointJoinIndices
				//Should rehash recursiveNode from defaultHashCols to one of recursiveJoinIndices
				
				QpSchema fixpointRehashSchema = headSchema;
			    if (!recursiveJoinIndices.contains(new Integer(defaultHashCols[0]))) {
					if (fixpointJoinIndices.contains(new Integer(defaultHashCols[0]))) {
						// no need to rehash fixpointNode
						// rehash recursiveNode to the position i, where
						// fixpointAtomArguments.get(defaultHashCols[0])=recursiveAtomArguments.get(i)
						int [] newRecursiveHashCols = {recursiveAtomArguments.indexOf(fixpointAtomArguments.get(defaultHashCols[0]))}; 
						QpSchema recursiveRehashSchema = QpSchema.rehashQpSchema(recursiveSchema, defaultHashCols, newRecursiveHashCols, relID++);
						schemas.add(recursiveRehashSchema);
					    recursiveNode = new ShipNode(recursiveSchema, generateMapping(recursiveSchema.getNumCols()), recursiveRehashSchema, DistributedLoc.getInstance(), operatorID++, recursiveNode);
					} else {
						// need to rehash fixpointNode and recursiveNode
						// rehash fixpointNode to the last possible position in fixpointJoinIndices;
						// rehash recursiveNode to the position i, where
						// fixpointAtomArguments.get(fixpointJoinIndices.get(fixpointJoinIndices.size()))=recursiveAtomArguments.get(i)
						int [] newFixpointHashCols = {fixpointJoinIndices.get(fixpointJoinIndices.size()-1)};
						int [] newRecursiveHashCols = {recursiveAtomArguments.indexOf(fixpointAtomArguments.get(fixpointJoinIndices.get(fixpointJoinIndices.size()-1)))};
						fixpointRehashSchema = QpSchema.rehashQpSchema(headSchema, defaultHashCols, newFixpointHashCols, relID++);
						schemas.add(fixpointRehashSchema);
					    QpSchema recursiveRehashSchema = QpSchema.rehashQpSchema(recursiveSchema, defaultHashCols, newRecursiveHashCols, relID++);
					    schemas.add(recursiveRehashSchema);
					    recursiveNode = new ShipNode(recursiveSchema, generateMapping(recursiveSchema.getNumCols()), recursiveRehashSchema, DistributedLoc.getInstance(), operatorID++, recursiveNode);
					}			    		
			    } else {
			    	if (fixpointJoinIndices.contains(new Integer(defaultHashCols[0]))) {
			    		// no need to rehash fixpointNode and recursiveNode
			    	} else {
			    		// need to rehash fixpointNode
			    		int [] newFixpointHashCols = {fixpointAtomArguments.indexOf(recursiveAtomArguments.get(defaultHashCols[0]))};
			    		fixpointRehashSchema = QpSchema.rehashQpSchema(headSchema, defaultHashCols, newFixpointHashCols, relID++);
			    		schemas.add(fixpointRehashSchema);
			    	}
			    }
				
			    QueryPlan fixpointNode = new FixpointReceiverNode(fixpointRehashSchema, DistributedLoc.getInstance(), operatorID++);
				recursiveNode = new PipelinedJoinNode(newOutputSchema, recursiveJoinIndices, fixpointJoinIndices, recursiveOutputPos, fixpointOutputPos, 
						DistributedLoc.getInstance(), false, recursiveNode, fixpointNode, operatorID++);
				
				
				recursiveSchema = newOutputSchema;
				recursiveAtomArguments = newOutputAtomArguments;
				
				List<ColumnOrFunction> columnOrFunctionList = new ArrayList<ColumnOrFunction>();
				for (int i = 0; i < recursiveAtomArguments.size(); i++) {
					columnOrFunctionList.add(new ColumnInput(i));
				}
				for (int l = 0; l < functionPredicateList.size(); l++) {
					// FUNC: From newOutputSchema, concat baseSchema, to functionOutputSchema
					Atom basePredicate = functionPredicateList.get(l);
					List<AtomArgument> baseAtomArguments = functionAtomArgumentsList.get(l);

					ArrayList<ColumnOrFunction> inputList = new ArrayList<ColumnOrFunction>();
					List<String> between = new ArrayList<String>(baseAtomArguments.size());
					between.add("");
					for (int i = 1; i < baseAtomArguments.size()-1; i++) {
						between.add("#");
					}
					between.add("");
					List<Integer> lengths = new ArrayList<Integer>(baseAtomArguments.size()-1);
					Integer constantValue = new Integer(0);
					for (int i = 1; i < baseAtomArguments.size(); i++) {
						AtomArgument input = baseAtomArguments.get(i);
						if (input instanceof AtomConst) {
							if (!(((AtomConst) input).getValue() instanceof Integer)) {
								throw new RuntimeException("Only Integer input in Func is allowed!");
							}
							constantValue = constantValue + (Integer)((AtomConst) input).getValue();
							continue;
						}
						if (recursiveAtomArguments.indexOf(input) < 0) {
							throw new RuntimeException("Wrong FUNC_ function!");
						}
						inputList.add(new ColumnInput(recursiveAtomArguments.indexOf(input)));
						if (recursiveSchema.getColType(recursiveAtomArguments.indexOf(input)).bytesLength() < 0) {
							if (! (recursiveSchema.getColType(recursiveAtomArguments.indexOf(input)) instanceof StringType)) {
								throw new RuntimeException("RuntimeException!");
							}
							StringType strType = (StringType)(recursiveSchema.getColType(recursiveAtomArguments.indexOf(input))); 
							lengths.add(strType.getLength());			
						} else {
							lengths.add(recursiveSchema.getColType(recursiveAtomArguments.indexOf(input)).bytesLength());	
						}
					}
					if (basePredicate.getRelation().getRelationName().startsWith("FUNC_CONCAT")) {
						columnOrFunctionList.add(new EvalFunc(new Concatenate(true, between,lengths), inputList));	
					} else if (basePredicate.getRelation().getRelationName().startsWith("FUNC_SUM")) {
						List<Integer> multiplicites = new ArrayList<Integer>(inputList.size());
						for (int i = 0; i < inputList.size(); i++) {
							multiplicites.add(1);
						}
						columnOrFunctionList.add(new EvalFunc(new Sum(multiplicites, false, false, constantValue), inputList));
					};
				}
				
				if (functionPredicateList.size() > 0) {
					newOutputSchema = new QpSchema("RECURSIVE_NEW"+relID, relID++);
					newOutputAtomArguments = new ArrayList<AtomArgument>();
					newPrimaryKeyList = new ArrayList<String>();
					try {
						for (int i = 0; i < recursiveSchema.getNumCols(); i++) {
							if (recursiveSchema.getColName(i) != null) {
								newOutputSchema.addCol(recursiveSchema.getColName(i), "", recursiveSchema.getColType(i));
								newOutputAtomArguments.add(recursiveAtomArguments.get(i));
								if (recursiveSchema.getKeyCols().contains(i)) {
									newPrimaryKeyList.add(recursiveSchema.getColName(i));
								}
							}
						}
						
						for (int i = 0; i < functionPredicateList.size(); i++) {
							QpSchema baseSchema = functionSchemaList.get(i);
							List<AtomArgument> baseAtomArguments = functionAtomArgumentsList.get(i);
							if (baseSchema.getColName(0) != null) {
								newOutputSchema.addCol(baseSchema.getColName(0)+"_F"+i, "", baseSchema.getColType(0));
								newOutputAtomArguments.add(baseAtomArguments.get(0));
								if (baseSchema.getKeyCols().contains(0)) {
									newPrimaryKeyList.add(baseSchema.getColName(0)+"_F"+i);
								}
							}	
						}
					} catch (BadColumnName bcn) {
						throw new RuntimeException("Error adding column:", bcn);
					}
					//Assume by default the new tuples are hashed by the first attribute
					try {
						newOutputSchema.setPrimaryKey(new PrimaryKey("pk", newOutputSchema, newPrimaryKeyList));
					} catch (UnknownRefFieldException urfe){
						throw new RuntimeException("Error setting primary key for new schema:", urfe);
					}
					newOutputSchema.setHashCols(defaultHashCols);
					newOutputSchema.markFinished();
					schemas.add(newOutputSchema);
					
					recursiveNode = new FunctionNode(recursiveSchema, newOutputSchema, columnOrFunctionList, DistributedLoc.getInstance(), operatorID++, recursiveNode);	
				}
				// Project from newOutputSchema to headSchema
				Map<Integer,Integer> inverseSchemaMapping = new HashMap<Integer,Integer>();
				for (int i = 0; i < headSchema.getNumCols(); i++) {
					//find position j where newOutputAtomArguments.get(j)=headAtomArguments.get(i).
					if (newOutputAtomArguments.indexOf(headAtomArguments.get(i)) < 0) {
						throw new RuntimeException("Wrong headSchema!");
					}
					inverseSchemaMapping.put(i, newOutputAtomArguments.indexOf(headAtomArguments.get(i)));	
				}
				
				//Add FunctionNode here
				inverseSchemaMapping = Collections.unmodifiableMap(inverseSchemaMapping);
				recursiveNode = new ProjectNode(newOutputSchema, inverseSchemaMapping, headSchema, DistributedLoc.getInstance(), operatorID++, recursiveNode);
				rehashSchema = fixpointRehashSchema;
				headPlanByName.put(th.getRelation().getRelationName(), recursiveNode);
				return recursiveNode;
				
			} else {
				// nonRecursiveQuery    
				ArrayList<Atom> newBody = new ArrayList<Atom>(body);
				boolean first = true;

				QpSchema recursiveSchema = null;
				QueryPlan recursiveNode = null;
				List<AtomArgument> recursiveAtomArguments = null;
				ArrayList<Atom> functionPredicateList = new ArrayList<Atom>();
				ArrayList<List<AtomArgument>> functionAtomArgumentsList = new ArrayList<List<AtomArgument>>();
				ArrayList<QpSchema> functionSchemaList = new ArrayList<QpSchema>();
				
				while (!newBody.isEmpty()) {
					//Configure baseSchema
					Atom basePredicate = newBody.remove(0);
					QpSchema baseSchema; 

					List<AtomArgument> baseAtomArguments = new ArrayList<AtomArgument>(basePredicate.getValues());
					
					QueryPlan baseNode = null;
					if (!basePredicate.getRelation().getRelationName().startsWith("FUNC_")) {
						if (!headSchemaByName.containsKey(basePredicate.getRelation().getRelationName())) {
							if (baseSchemas.containsKey(basePredicate.getRelation().getRelationName())) {
								baseSchema = baseSchemas.get(basePredicate.getRelation().getRelationName());
							} else {
								baseSchema = new QpSchema(basePredicate.getRelation().getRelationName(), relID++);
								for (int i=0; i<basePredicate.getRelation().getNumCols(); i++) {
									try {
										baseSchema.addCol(basePredicate.getRelation().getColName(i), "", basePredicate.getRelation().getColType(i));
									} catch (BadColumnName bcn) {
										throw new RuntimeException("Error adding column:", bcn);
									}
								}
								baseSchema.setPrimaryKey(basePredicate.getRelation().getPrimaryKey());
								baseSchema.setHashCols(defaultHashCols);
								baseSchema.markFinished();
								schemas.add(baseSchema);
								//headSchemaByName.put(basePredicate.getRelation().getRelationName(),baseSchema);
								baseSchemas.put(basePredicate.getRelation().getRelationName(), baseSchema);	
							}
							baseNode = new DistributedScanNode(baseSchema, null, null, DistributedLoc.getInstance(), operatorID++);
						} else {
							baseSchema = headSchemaByName.get(basePredicate.getRelation().getRelationName());
							baseNode = headPlanByName.get(basePredicate.getRelation().getRelationName());
						}	
						
					} else {
						baseSchema = new QpSchema(basePredicate.getRelation().getRelationName(), relID++);
						try {
							baseSchema.addCol(basePredicate.getRelation().getColName(0), "", basePredicate.getRelation().getColType(0));
						} catch (BadColumnName bcn) {
							throw new RuntimeException("Error adding column:", bcn);
						}
						baseSchema.setPrimaryKey(basePredicate.getRelation().getPrimaryKey());
						baseSchema.setHashCols(defaultHashCols);
						baseSchema.markFinished();
						functionPredicateList.add(basePredicate);
						functionAtomArgumentsList.add(baseAtomArguments);
						functionSchemaList.add(baseSchema);
						continue;
					}
					
					
					//modify recursive schema;
					if (first) {
						recursiveAtomArguments = baseAtomArguments;
						recursiveSchema = baseSchema;
						recursiveNode = baseNode;
						first = false;
						continue;
					}
					
					//Join: Join recursiveSchema with baseSchema

					List<Integer> recursiveJoinIndices = new ArrayList<Integer>();
					List<Integer> baseJoinIndices = new ArrayList<Integer>();
					
					Iterator<AtomArgument> baseIterator = baseAtomArguments.iterator();
					while (baseIterator.hasNext()) {
						AtomArgument baseArgument = baseIterator.next();
						if (recursiveAtomArguments.contains(baseArgument)) {
						  recursiveJoinIndices.add(recursiveAtomArguments.indexOf(baseArgument));
						  baseJoinIndices.add(baseAtomArguments.indexOf(baseArgument));
						}
					}
					
					int pos = 0; 
					List<Integer> recursiveOutputPos = new ArrayList<Integer>();
					for (int i = 0; i < recursiveAtomArguments.size(); i++) {
						recursiveOutputPos.add(pos++);
					}
				
					List<Integer> baseOutputPos = new ArrayList<Integer>();
					for (int i = 0; i < baseAtomArguments.size(); i++) {
						if (baseJoinIndices.contains(i)) {
							baseOutputPos.add(null);
						} else {
							baseOutputPos.add(pos++);
						}
					}
					
					//Materialized view, create intermediate schema newOutputSchema
					QpSchema newOutputSchema = new QpSchema("RECURSIVE_NEW"+relID, relID++);
					List<AtomArgument> newOutputAtomArguments = new ArrayList<AtomArgument>();
					List<String> newPrimaryKeyList = new ArrayList<String>();
					
					try {
						for (int i = 0; i < recursiveOutputPos.size(); i++) {
							if (recursiveOutputPos.get(i) != null) {
								newOutputSchema.addCol(recursiveSchema.getColName(i)+"_L", "", recursiveSchema.getColType(i));
								newOutputAtomArguments.add(recursiveAtomArguments.get(i));
								if (recursiveSchema.getKeyCols().contains(i)) {
									newPrimaryKeyList.add(recursiveSchema.getColName(i)+"_L");
								}
							}
						}
						
						for (int i = 0; i < baseOutputPos.size(); i++) {
							if (baseOutputPos.get(i) != null) {
								newOutputSchema.addCol(baseSchema.getColName(i)+"_R", "", baseSchema.getColType(i));
								newOutputAtomArguments.add(baseAtomArguments.get(i));
								if (baseSchema.getKeyCols().contains(i)) {
									newPrimaryKeyList.add(baseSchema.getColName(i)+"_R");
								}
							}
						}
					
					} catch (BadColumnName bcn) {
						throw new RuntimeException("Error adding column:", bcn);
					}
					//Assume by default the new tuples are hashed by the first attribute
					try {
						newOutputSchema.setPrimaryKey(new PrimaryKey("pk", newOutputSchema, newPrimaryKeyList));
					} catch (UnknownRefFieldException urfe){
						throw new RuntimeException("Error setting primary key for new schema:", urfe);
					}
					newOutputSchema.setHashCols(defaultHashCols);
					newOutputSchema.markFinished();
					schemas.add(newOutputSchema);
							
					//Should rehash baseNode from defaultHashCols to one of baseJoinIndices
					//Should rehash recursiveNode from defaultHashCols to one of recursiveJoinIndices
				    
				    if (!recursiveJoinIndices.contains(new Integer(defaultHashCols[0]))) {
						if (baseJoinIndices.contains(new Integer(defaultHashCols[0]))) {
							// no need to rehash baseNode
							// rehash recursiveNode to the position i, where
							// baseAtomArguments.get(defaultHashCols[0])=recursiveAtomArguments.get(i)
							int [] newRecursiveHashCols = {recursiveAtomArguments.indexOf(baseAtomArguments.get(defaultHashCols[0]))}; 
							QpSchema recursiveRehashSchema = QpSchema.rehashQpSchema(recursiveSchema, defaultHashCols, newRecursiveHashCols, relID++);
							schemas.add(recursiveRehashSchema);
						    recursiveNode = new ShipNode(recursiveSchema, generateMapping(recursiveSchema.getNumCols()), recursiveRehashSchema, DistributedLoc.getInstance(), operatorID++, recursiveNode);
						} else {
							// need to rehash baseNode and recursiveNode
							// rehash baseNode to the last possible position in baseJoinIndices;
							// rehash recursiveNode to the position i, where
							// baseAtomArguments.get(baseJoinIndices.get(baseJoinIndices.size()))=recursiveAtomArguments.get(i)
							int [] newBaseHashCols = {baseJoinIndices.get(baseJoinIndices.size()-1)};
							int [] newRecursiveHashCols = {recursiveAtomArguments.indexOf(baseAtomArguments.get(baseJoinIndices.get(baseJoinIndices.size()-1)))};
							QpSchema baseRehashSchema = QpSchema.rehashQpSchema(headSchema, defaultHashCols, newBaseHashCols, relID++);
							schemas.add(baseRehashSchema);
						    baseNode = new ShipNode(baseSchema, generateMapping(baseSchema.getNumCols()), baseRehashSchema, DistributedLoc.getInstance(), operatorID++, baseNode);
						    QpSchema recursiveRehashSchema = QpSchema.rehashQpSchema(recursiveSchema, defaultHashCols, newRecursiveHashCols, relID++);
						    schemas.add(recursiveRehashSchema);
						    recursiveNode = new ShipNode(recursiveSchema, generateMapping(recursiveSchema.getNumCols()), recursiveRehashSchema, DistributedLoc.getInstance(), operatorID++, recursiveNode);
						}			    		
				    } else {
				    	if (baseJoinIndices.contains(new Integer(defaultHashCols[0]))) {
				    		// no need to rehash baseNode and recursiveNode
				    	} else {
				    		// need to rehash baseNode
				    		int [] newBaseHashCols = {baseAtomArguments.indexOf(recursiveAtomArguments.get(defaultHashCols[0]))};
				    		QpSchema baseRehashSchema = QpSchema.rehashQpSchema(headSchema, defaultHashCols, newBaseHashCols, relID++);
				    		schemas.add(baseRehashSchema);
						    baseNode = new ShipNode(baseSchema, generateMapping(baseSchema.getNumCols()), baseRehashSchema, DistributedLoc.getInstance(), operatorID++, baseNode);
				    	}
				    }
				    recursiveNode = new PipelinedJoinNode(newOutputSchema, recursiveJoinIndices, baseJoinIndices, recursiveOutputPos, 
							baseOutputPos, DistributedLoc.getInstance(), false, recursiveNode, baseNode, operatorID++);
					recursiveSchema = newOutputSchema;
					recursiveAtomArguments = newOutputAtomArguments;
				}
				
				List<ColumnOrFunction> columnOrFunctionList = new ArrayList<ColumnOrFunction>();
				for (int i = 0; i < recursiveAtomArguments.size(); i++) {
					columnOrFunctionList.add(new ColumnInput(i));
				}
				for (int l = 0; l < functionPredicateList.size(); l++) {
					// FUNC: From newOutputSchema, concat baseSchema, to functionOutputSchema
					Atom basePredicate = functionPredicateList.get(l);
					List<AtomArgument> baseAtomArguments = functionAtomArgumentsList.get(l);

					ArrayList<ColumnOrFunction> inputList = new ArrayList<ColumnOrFunction>();
					List<String> between = new ArrayList<String>(baseAtomArguments.size());
					between.add("");
					for (int i = 1; i < baseAtomArguments.size()-1; i++) {
						between.add("#");
					}
					between.add("");
					List<Integer> lengths = new ArrayList<Integer>(baseAtomArguments.size()-1);
					Integer constantValue = new Integer(0);
					for (int i = 1; i < baseAtomArguments.size(); i++) {
						AtomArgument input = baseAtomArguments.get(i);
						if (input instanceof AtomConst) {
							if (!(((AtomConst) input).getValue() instanceof Integer)) {
								throw new RuntimeException("Only Integer input in Func is allowed!");
							}
							constantValue = constantValue + (Integer)((AtomConst) input).getValue();
							continue;
						}
						if (recursiveAtomArguments.indexOf(input) < 0) {
							throw new RuntimeException("Wrong FUNC_ function!");
						}
						inputList.add(new ColumnInput(recursiveAtomArguments.indexOf(input)));
						if (recursiveSchema.getColType(recursiveAtomArguments.indexOf(input)).bytesLength() < 0) {
							if (! (recursiveSchema.getColType(recursiveAtomArguments.indexOf(input)) instanceof StringType)) {
								throw new RuntimeException("RuntimeException!");
							}
							StringType strType = (StringType)(recursiveSchema.getColType(recursiveAtomArguments.indexOf(input))); 
							lengths.add(strType.getLength());			
						} else {
							lengths.add(recursiveSchema.getColType(recursiveAtomArguments.indexOf(input)).bytesLength());	
						}
					}
					if (basePredicate.getRelation().getRelationName().startsWith("FUNC_CONCAT")) {
						columnOrFunctionList.add(new EvalFunc(new Concatenate(true, between,lengths), inputList));	
					} else if (basePredicate.getRelation().getRelationName().startsWith("FUNC_SUM")) {
						List<Integer> multiplicites = new ArrayList<Integer>(inputList.size());
						for (int i = 0; i < inputList.size(); i++) {
							multiplicites.add(1);
						}
						columnOrFunctionList.add(new EvalFunc(new Sum(multiplicites, false, false, constantValue), inputList));
					}
				}
				
				if (functionPredicateList.size() > 0) {
					QpSchema newOutputSchema = new QpSchema("RECURSIVE_NEW"+relID, relID++);
					List<AtomArgument> newOutputAtomArguments = new ArrayList<AtomArgument>();
					List<String> newPrimaryKeyList = new ArrayList<String>();
					try {
						for (int i = 0; i < recursiveSchema.getNumCols(); i++) {
							if (recursiveSchema.getColName(i) != null) {
								newOutputSchema.addCol(recursiveSchema.getColName(i), "", recursiveSchema.getColType(i));
								newOutputAtomArguments.add(recursiveAtomArguments.get(i));
								if (recursiveSchema.getKeyCols().contains(i)) {
									newPrimaryKeyList.add(recursiveSchema.getColName(i));
								}
							}
						}
						
						for (int i = 0; i < functionPredicateList.size(); i++) {
							QpSchema baseSchema = functionSchemaList.get(i);
							List<AtomArgument> baseAtomArguments = functionAtomArgumentsList.get(i);
							if (baseSchema.getColName(0) != null) {
								newOutputSchema.addCol(baseSchema.getColName(0)+"_F"+i, "", baseSchema.getColType(0));
								newOutputAtomArguments.add(baseAtomArguments.get(0));
								if (baseSchema.getKeyCols().contains(0)) {
									newPrimaryKeyList.add(baseSchema.getColName(0)+"_F"+i);
								}
							}	
						}
					} catch (BadColumnName bcn) {
						throw new RuntimeException("Error adding column:", bcn);
					}
					//Assume by default the new tuples are hashed by the first attribute
					try {
						newOutputSchema.setPrimaryKey(new PrimaryKey("pk", newOutputSchema, newPrimaryKeyList));
					} catch (UnknownRefFieldException urfe){
						throw new RuntimeException("Error setting primary key for new schema:", urfe);
					}
					newOutputSchema.setHashCols(defaultHashCols);
					newOutputSchema.markFinished();
					schemas.add(newOutputSchema);
					
					recursiveNode = new FunctionNode(recursiveSchema, newOutputSchema, columnOrFunctionList, DistributedLoc.getInstance(), operatorID++, recursiveNode);
					recursiveSchema = newOutputSchema;
					recursiveAtomArguments = newOutputAtomArguments;
				}
				
				// Project from recursiveSchema to headSchema
				//First groupingColumns, then aggFunc(outputColumns)
				Map<Integer,Integer> inverseSchemaMapping = new HashMap<Integer,Integer>();
				List<Integer> grouping = new ArrayList<Integer>();
				List<AggregateNode.OutputColumn> aggFunc = new ArrayList<AggregateNode.OutputColumn>();
				for (int i = 0; i < headSchema.getNumCols(); i++) {
					//find position j where recursiveAtomArguments.get(j)=headAtomArguments.get(i).
					AtomArgument thisAtomArgument = headAtomArguments.get(i);
					if (thisAtomArgument instanceof AtomVariable) {
						String name = ((AtomVariable) thisAtomArgument).getName();
						if (name.startsWith("min") || name.startsWith("max") || name.startsWith("sum") || name.startsWith("count")) {
							thisAtomArgument = new AtomVariable(name.substring(name.indexOf("<")+1, name.indexOf(">")));
							if (recursiveAtomArguments.indexOf(thisAtomArgument) < 0) {
								throw new RuntimeException("Wrong headSchema!");
							}
							if (name.startsWith("min")) {
								aggFunc.add(new AggregateNode.OutputColumn(recursiveAtomArguments.indexOf(thisAtomArgument), AggFunc.MIN));	
								//aggFunc.add(new AggregateNode.OutputColumn(i, AggFunc.MIN));
							} else if (name.startsWith("max")) {
								aggFunc.add(new AggregateNode.OutputColumn(recursiveAtomArguments.indexOf(thisAtomArgument), AggFunc.MAX));
								//aggFunc.add(new AggregateNode.OutputColumn(i, AggFunc.MAX));
							} else if (name.startsWith("sum")) {
								aggFunc.add(new AggregateNode.OutputColumn(recursiveAtomArguments.indexOf(thisAtomArgument), AggFunc.SUM));
								//aggFunc.add(new AggregateNode.OutputColumn(i, AggFunc.SUM));
							} else if (name.startsWith("count")) {
								aggFunc.add(new AggregateNode.OutputColumn(recursiveAtomArguments.indexOf(thisAtomArgument), AggFunc.COUNT));
								//aggFunc.add(new AggregateNode.OutputColumn(i, AggFunc.COUNT));
							} 
						} else {
							if (recursiveAtomArguments.indexOf(thisAtomArgument) < 0) {
								throw new RuntimeException("Wrong headSchema!");
							}
							grouping.add(recursiveAtomArguments.indexOf(thisAtomArgument));
							//grouping.add(i);
						}
					} else {
						throw new RuntimeException("HeadSchema cannot be of constant type");
					}
					if (recursiveAtomArguments.indexOf(thisAtomArgument) < 0) {
						throw new RuntimeException("Wrong headSchema!");
					}
					inverseSchemaMapping.put(i, recursiveAtomArguments.indexOf(thisAtomArgument));	
				}
				
				inverseSchemaMapping = Collections.unmodifiableMap(inverseSchemaMapping);
				if (!aggFunc.isEmpty()) {
					groupingsByName.put(recursiveSchema.getRelationName(), grouping);
					outputColumnsByName.put(recursiveSchema.getRelationName(), aggFunc);
					recursiveNode = new NonblockingAggregateNode(recursiveSchema, inverseSchemaMapping, headSchema, grouping, aggFunc, DistributedLoc.getInstance(), operatorID++, recursiveNode);
					//recursiveNode = new ProjectNode(recursiveSchema, inverseSchemaMapping, headSchema, DistributedLoc.getInstance(), operatorID++, recursiveNode);
				} else {
					recursiveNode = new ProjectNode(recursiveSchema, inverseSchemaMapping, headSchema, DistributedLoc.getInstance(), operatorID++, recursiveNode);	
				}
				headPlanByName.put(th.getRelation().getRelationName(), recursiveNode);
				return recursiveNode;
			}    	
	    }
	    
	   public static QueryPlan p2pCombineNonRecursiveRules(List<Rule> listRules, List<QueryPlan> queryPlans, Rule thisRule, QueryPlan thisPlan) {
		   QueryPlan result = thisPlan;
		   for (int l = 0; l < listRules.size(); l++) {
				Rule r = listRules.get(l);
				if (r.getHead().getRelation().equals(thisRule.getHead().getRelation())) {	
					Atom th = thisRule.getHead();
					QpSchema headSchema = new QpSchema(th.getRelation().getRelationName(), relID++);
					//schemas.add(headSchema);
					for (int i = 0; i < th.getRelation().getNumCols(); i++) {
						try {
						headSchema.addCol(th.getRelation().getColName(i),"", th.getRelation().getColType(i));
						} catch (BadColumnName bcn) {
							throw new RuntimeException("Error adding column:", bcn);
						}
					}
					headSchema.setPrimaryKey(th.getRelation().getPrimaryKey());
					headSchema.setHashCols(defaultHashCols);
					headSchema.markFinished();		
				    result = new UnionNode(headSchema, DistributedLoc.getInstance(), queryPlans.get(l), result, operatorID++);
				}
		   }
		   return result;
	   }
	   
	   public static QueryPlan p2pCombineRecursiveRules(List<QueryPlan> queryPlans, QueryPlan thisPlan) {
		   QueryPlan result = thisPlan;
		   QpSchema headSchema = headSchemaByName.get(thisPlan.outputSchema);
		   
		   // left : queryPlan;  right : thisPlan; outputPut: rehashSchema; 
		   boolean first = true;
		   for (int l = 0; l < queryPlans.size(); l++) {
				QueryPlan queryPlan = queryPlans.get(l);
				if (queryPlan.outputSchema.equals(thisPlan.outputSchema)) {
					if (!first) {
						throw new RuntimeException("Wrong arrangement of nonrecursive datalog program!");
					}
					//queryPlan = new ShipNode(queryPlan.outputSchema, generateMapping(headSchema.getNumCols()), rehashSchema, DistributedLoc.getInstance(), operatorID++, queryPlan);
					schemas.add(rehashSchema);
					List<Integer> grouping = groupingsByName.get(rehashSchema.getRelationName());
					List<AggregateNode.OutputColumn> outputColumns = outputColumnsByName.get(rehashSchema.getRelationName());
				    result = new FixpointShipNode(headSchema, generateMapping(headSchema.getNumCols()), rehashSchema, grouping, outputColumns, DistributedLoc.getInstance(), operatorID++, result);
				    
				    //headSchemaByName.put(rehashPredicate.getRelation().getRelationName(),rehashSchema);
			        //result = new FixpointNode(headSchema, generateMapping(headSchema.getNumCols()), rehashSchema,
					result  = new FixpointNode(rehashSchema, grouping, outputColumns, DistributedLoc.getInstance(), queryPlan, result, operatorID++);
					headSchemaByName.put(result.outputSchema, rehashSchema);
					headPlanByName.put(result.outputSchema, result);
			        first = false;
				}
		   }
		   return result;
	   }
	   
	   public static QueryPlan p2pResultGen(QueryPlan lastQueryPlan) {
		   
		   QpSchema headSchema = headSchemaByName.get(lastQueryPlan.outputSchema);
		   
		   QpSchema headResultSchema = new QpSchema(headSchema.getRelationName()+"_RESULT",relID++);
		   for (int i = 0; i < headSchema.getNumCols(); i++) {
			   try {
			   headResultSchema.addCol(headSchema.getColName(i), "", headSchema.getColType(i));
			   } catch (BadColumnName bcn) {
				   throw new RuntimeException("Error adding column:", bcn);
			   }
		   }
		   headResultSchema.setCentralized();
		   headResultSchema.markFinished();
		   schemas.add(headResultSchema);
		   
		   
		   QueryPlan qp = new ShipNode(headSchema, generateMapping(headSchema.getNumCols()), headResultSchema, DistributedLoc.getInstance(), operatorID++, lastQueryPlan);
		   qp = new SpoolNode(headResultSchema, operatorID++, qp);
		   return qp;
	   }
	   
	   
		public static List<QueryPlan> p2pNonRecursiveQueryEvaluate(List<Rule> r) {
			List<Rule> rules = new ArrayList<Rule>();
			List<QueryPlan> queryPlans = new ArrayList<QueryPlan>(); 
			for (Rule rule: r) {
				QueryPlan queryPlan = p2pSingleRuleEvalution(rule.getHead(), rule.getBody());
				QueryPlan result = p2pCombineNonRecursiveRules(rules, queryPlans, rule, queryPlan);
				List<Rule> newRules = new ArrayList<Rule>(rules);
				for (int l = 0; l < rules.size(); l++) {
					Rule lastRule = rules.get(l);
					if (lastRule.getHead().getRelation().equals(rule.getHead().getRelation())) {
						newRules.remove(l);
						queryPlans.remove(l);
					}
			   }
				rules = newRules;
				rules.add(rule);
				queryPlans.add(result);
			}
			return queryPlans;
		}
		
		public static QueryPlan p2pRecursiveQueryEvaluate(List<QueryPlan> totalQueryPlans, List<Rule> r) {
			if (r.size() != 1) {
				throw new RuntimeException("Recursive rule can only be a single rule: wrong recursive program!"); 
			}
			Rule rule = r.get(0);
			QueryPlan queryPlan = p2pSingleRuleEvalution(rule.getHead(), rule.getBody());
			QueryPlan result = p2pCombineRecursiveRules(totalQueryPlans, queryPlan);
			return result;
		}
		
		public static QueryPlan p2pProgramEvalute(List<Datalog> progs) {
			List<QueryPlan> totalQueryPlans = new ArrayList<QueryPlan>();
		    for (Datalog prog: progs) {
		    	if (prog instanceof DatalogProgram) {
		    		DatalogProgram datalog = (DatalogProgram) prog;
		    		if (datalog instanceof RecursiveDatalogProgram) {
		    			QueryPlan resultQueryPlan = p2pRecursiveQueryEvaluate(totalQueryPlans, datalog.getRules());
		    			totalQueryPlans.add(resultQueryPlan);
		    		} else if (datalog instanceof NonRecursiveDatalogProgram){
		    			List<QueryPlan> resultQueryPlans = p2pNonRecursiveQueryEvaluate(datalog.getRules());
		    			totalQueryPlans.addAll(resultQueryPlans);
		    		}
		    	}
		    }
		    //int index = rules.lastIndexOf(lastRule);
			QueryPlan lastQueryPlan = totalQueryPlans.get(totalQueryPlans.size()-1);
			/*
			if (!lastQueryPlan.outputSchema.equals(lastRule.getHead().getRelation().getName())) {
				throw new RuntimeException("Wrong lastQueryPlan!");
			}*/
			QueryPlan result = p2pResultGen(lastQueryPlan);
		    return result;
		}
		
		public static QueryPlan optimizeQueryPlan(QueryPlan thisQueryPlan) {
			scanForAggregates(thisQueryPlan);
			return thisQueryPlan;
		}
		
		public static void scanForAggregates(QueryPlan traverse) {
			if (traverse.getClass() == FixpointShipNode.class) {
				FixpointShipNode thisNode = (FixpointShipNode) traverse;
				List<Integer> grouping = groupingsByName.get(thisNode.outputSchema);
				List<AggregateNode.OutputColumn> outputColumns = outputColumnsByName.get(thisNode.outputSchema);
			    thisNode.setGroupingAggregates(grouping, outputColumns);
			}
			
			if (traverse.getClass() == FixpointNode.class) {
				FixpointNode thisNode = (FixpointNode) traverse;
				List<Integer> grouping = groupingsByName.get(thisNode.outputSchema);
				List<AggregateNode.OutputColumn> outputColumns = outputColumnsByName.get(thisNode.outputSchema);
			    thisNode.setGroupingAggregates(grouping, outputColumns);
			}
			
			if (traverse instanceof NoInputQueryPlan) {
				return;
			} else if (traverse instanceof OneInputQueryPlan) {
				scanForAggregates(((OneInputQueryPlan) traverse).input);
			} else if (traverse instanceof TwoInputQueryPlan) {
				scanForAggregates(((TwoInputQueryPlan) traverse).left);
				scanForAggregates(((TwoInputQueryPlan) traverse).right);
			};
		}
		
}
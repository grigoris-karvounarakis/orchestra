package edu.upenn.cis.orchestra.p2pqp;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class SynchronizedImmutableMap<K,V> implements Map<K,V> {
	private final Map<K,V> m;
	
	public SynchronizedImmutableMap(Map<K,V> m) {
		this.m = m;
	}
	
	
	public void clear() {
		throw new UnsupportedOperationException();
	}

	public boolean containsKey(Object key) {
		synchronized (m) {
			return m.containsKey(key);
		}
	}

	public boolean containsValue(Object value) {
		synchronized (m) {
			return m.containsValue(value);
		}
	}

	public Set<java.util.Map.Entry<K, V>> entrySet() {
		throw new UnsupportedOperationException();
	}

	public V get(Object key) {
		synchronized (m) {
			return m.get(key);
		}
	}

	public boolean isEmpty() {
		synchronized (m) {
			return m.isEmpty();
		}
	}

	public Set<K> keySet() {
		throw new UnsupportedOperationException();
	}

	public V put(K key, V value) {
		throw new UnsupportedOperationException();
	}

	public void putAll(Map<? extends K, ? extends V> t) {
		throw new UnsupportedOperationException();
	}

	public V remove(Object key) {
		throw new UnsupportedOperationException();
	}

	public int size() {
		synchronized (m) {
			return m.size();
		}
	}

	public Collection<V> values() {
		throw new UnsupportedOperationException();
	}
}

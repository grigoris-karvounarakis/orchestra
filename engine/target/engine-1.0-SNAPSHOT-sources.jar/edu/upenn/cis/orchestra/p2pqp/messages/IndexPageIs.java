package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class IndexPageIs extends QpMessage {
	private static final long serialVersionUID = 1L;
	private final byte[] data;

	public IndexPageIs(RequestIndexPage request, byte[] data) {
		super(request, true);
		this.data = data;
	}

	public String toString() {
		return "IndexPageIs";
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeBytes(data);
	}

	public IndexPageIs(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		data = buf.readBytes();
	}
	
	public byte[] getData() {
		return data;
	}
	
	public int getCompressedDataLength() {
		return data.length;
	}
}
package edu.upenn.cis.orchestra.p2pqp;

import java.io.Serializable;


public class IdRange implements Serializable {
	private static final long serialVersionUID = 1L;
	private final boolean empty;
	private final Id ccw, cw;

	/**
	 *	Construct an empty IdRange
	 * 
	 */
	private IdRange() {
		empty = true;
		ccw = null;
		cw = null;
	}

	private static IdRange emptyRange = new IdRange();

	static IdRange empty() {
		return emptyRange;
	}

	/**
	 * Construct a non-empty IdRange
	 * 
	 * @param ccw		The CCW bound, inclusive
	 * @param cw		The CW bound, exclusive 
	 */
	IdRange(Id ccw, Id cw) {
		empty = false;
		this.ccw = ccw;
		this.cw = cw;
	}

	boolean contains(Id id) {
		if (empty) {
			return false;
		}
		if (ccw.equals(cw)) {
			return true;
		}
		boolean rangeIncludesZero = (ccw.compareTo(cw) > 0);
		if (rangeIncludesZero) {
			return (ccw.compareTo(id) <= 0 || cw.compareTo(id) > 0);
		} else {
			return (ccw.compareTo(id) <= 0 && cw.compareTo(id) > 0);
		}

	}

	public void serialize(OutputBuffer buf) {
		if (empty) {
			buf.writeBoolean(true);
		} else {
			buf.writeBoolean(false);
			ccw.serialize(buf);
			cw.serialize(buf);
		}
	}

	public static IdRange deserialize(InputBuffer buf) {
		boolean empty = buf.readBoolean();
		if (empty) {
			return emptyRange;
		}
		Id ccw = Id.deserialize(buf);
		Id cw = Id.deserialize(buf);
		return new IdRange(ccw,cw);
	}

	public String toString() {
		if (empty) {
			return "[]";
		} else {
			return "[" + ccw + "," + cw + ")";
		}
	}
	
	/**
	 * Return the CCW edge, inclusive
	 * 
	 * @return		The CCW edge
	 */
	public Id getCCW() {
		return ccw;
	}
	
	/**
	 * Return the CW edge, exclusive
	 * 
	 * @return		The CW edge
	 */
	public Id getCW() {
		return cw;
	}
}

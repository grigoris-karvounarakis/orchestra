package edu.upenn.cis.orchestra.p2pqp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.InetSocketAddress;


public abstract class OutputBuffer {
	static final int addrLen = 4; // Assume that all addresses are IP4

	public final void writeBytes(byte[] b) {
		if (b == null) {
			writeInt(-1);
		} else {
			writeInt(b.length);
			writeBytesNoLength(b);
		}
	}

	public abstract void writeInt(int v);

	public abstract void writeShort(short s);

	public abstract void writeLong(long l);

	public abstract void writeBytesNoLength(byte[] bytes);

	public void writeString(String str) {
		if (str == null) {
			writeBytes(null);
		} else {
			try {
				writeBytes(str.getBytes("UTF-8"));
			} catch (UnsupportedEncodingException e) {
				throw new RuntimeException(e);
			}
		}
	}

	public void writeObject(Object o) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			oos.writeObject(o);
			oos.close();
			writeBytes(baos.toByteArray());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public abstract void writeBoolean(boolean bool);

	public final void writeInetAddress(InetAddress addr) {
		byte[] addrBytes = addr.getAddress();
		if (addrBytes.length != addrLen) {
			throw new IllegalArgumentException("All addresses should be " + addrLen + " bytes long");
		}
		writeBytesNoLength(addrBytes);
	}

	public final void writeInetSocketAddress(InetSocketAddress isa) {
		writeInetAddress(isa.getAddress());
		// Turn into signed short
		writeShort((short) isa.getPort());
	}

	public static class CommitException extends RuntimeException {
		private static final long serialVersionUID = 1L;
		public final int expectedLength, actualLength;

		CommitException(int expectedLength, int actualLength) {
			super("Transaction was supposed to contain " + expectedLength + " bytes, but actually contained " + actualLength + " bytes");
			this.expectedLength = expectedLength;
			this.actualLength = actualLength;
		}
	}
}

interface TransactionalOutputBufferControls {

	/**
	 * Begin writing a transaction to the output buffer
	 */
	abstract void beginTransaction();

	abstract void commitTransaction(long msgId);

	abstract void rollbackTransaction();
}
package edu.upenn.cis.orchestra.p2pqp;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.KEY;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;

public class SearchTree {
	private final QpSchema schema;
	private final QpSchema.Source schemas;
	private final PageSource pageSource;
	private final Map<Pointer,Node> nodes = new HashMap<Pointer,Node>();

	private Pointer root;

	public static final int DEFAULT_ARITY = 5;
	
	public interface PageSource {
		byte[] getTreePage(int relId, int pageNo);

	}

	/**
	 * Build a search tree from a PageSource using lazy loading.
	 * Pages are brought in and deserialized as needed
	 * 
	 * @param schema			The schema
	 * @param rootPage			The root page
	 * @param source			Where to get the serialized pages from
	 */
	SearchTree(QpSchema schema, int rootPage, PageSource source) {
		this.schema = schema;
		schemas = new QpSchema.SingleSource(schema);
		this.pageSource = source;
		root = new Pointer(rootPage,0);
	}
	
	/**
	 * Build a new search tree, using page numbers starting
	 * at <code>newRootPageId</code>
	 * 
	 * @param newRootPageId				The ID of the root page
	 * @param schema					The tuples' schema
	 * @param pageBots					The minimum key value that appears on each page
	 * @param createdPages				Where to put the ids of created pages
	 */
	SearchTree (int newRootPageId, QpSchema schema, List<QpTuple<?>> pageBots, Collection<Integer> createdPages) {
		this(newRootPageId, DEFAULT_ARITY, schema, pageBots, createdPages);
	}

	/**
	 * Build a new search tree, using page numbers starting
	 * at <code>newRootPageId</code>
	 * 
	 * @param newRootPageId				The ID of the root page
	 * @param arity						The fan-out of the tree
	 * @param schema					The tuples' schema
	 * @param pageBots					The minimum key value that appears on each page
	 * @param createdPages				Where to put the ids of created pages
	 */
	SearchTree(int newRootPageId, final int arity, QpSchema schema, List<QpTuple<?>> pageBots, Collection<Integer> createdPages) {
		this(schema, newRootPageId, null);
		if (arity < 3) {
			throw new IllegalArgumentException("Arity must be at least 3");
		}
		final int size = pageBots.size(); 

		List<QpTuple<?>> boundaries = pageBots.subList(1, pageBots.size());
		List<Pointer> pointers = new ArrayList<Pointer>(boundaries.size() + 1);

		for (int i = 0; i < size; ++i) {
			pointers.add(new Pointer(i));
		}

		int nextNode = 1;

		// Need to recursively build tree
		
		// TODO: make the tree more balanced if we decide
		// we want to do incremental maintenance 
		while (pointers.size() > arity) {
			int sizeGuess = pointers.size() / arity + 1;
			int boundariesPos = 0, pointersPos = 0;
			List<QpTuple<?>> newBoundaries = new ArrayList<QpTuple<?>>(sizeGuess);
			List<Pointer> newPointers = new ArrayList<Pointer>(sizeGuess + 1);
			while (pointersPos < pointers.size()) {
				int pointersRemaining = pointers.size() - pointersPos;
				int numPointers = pointersRemaining > arity ? arity : pointersRemaining;
				newPointers.add(addNode(newRootPageId, nextNode++, boundaries.subList(boundariesPos, boundariesPos + numPointers - 1), pointers.subList(pointersPos, pointersPos + numPointers)));
				pointersPos += numPointers;
				boundariesPos += numPointers - 1;
				if (boundariesPos < boundaries.size()) {
					newBoundaries.add(boundaries.get(boundariesPos));
					boundariesPos++;
				}
			}
			boundaries = newBoundaries;
			pointers = newPointers;
		}

		// Build top node
		addNode(newRootPageId, 0, boundaries, pointers);
		createdPages.add(newRootPageId);
	}


	private static class Pointer {
		// pageId < 0 => nodeId refers to a page of tuple Ids 
		final int treePageId;
		final int nodeId;

		Pointer(int tuplePageId) {
			nodeId = tuplePageId; 
			treePageId = -1;
		}

		Pointer(int treePageId, int nodeId) {
			this.treePageId = treePageId;
			this.nodeId = nodeId;
		}

		public int hashCode() {
			return treePageId + 31 * nodeId;
		}

		public boolean equals(Object o) {
			if (o == null || o.getClass() != this.getClass()) {
				return false;
			}
			Pointer p = (Pointer) o;
			return treePageId == p.treePageId && nodeId == p.nodeId;
		}
		
		public String toString() {
			if (treePageId == -1) {
				return "(" + nodeId + ")";
			} else {
				return "(" + treePageId + "," + nodeId + ")";
			}
		}
	}

	private class Node {
		private byte[] serialized;

		private QpTuple<?> keys[];
		private Pointer[] pointers;

		Node(List<QpTuple<?>> keys, List<Pointer> pointers) {
			this.keys = keys.toArray(new QpTuple<?>[keys.size()]);
			this.pointers = pointers.toArray(new Pointer[pointers.size()]);
			if (pointers.isEmpty() || pointers.size() != keys.size() + 1) {
				throw new IllegalArgumentException("Invalid keys and pointers");
			}
		}

		Node(byte[] serialized) {
			this.serialized = serialized;
		}

		byte[] serialize() {
			if (serialized != null) {
				return serialized;
			}
			ByteBufferWriter bbw = new ByteBufferWriter();
			bbw.addToBuffer(keys.length);
			for (QpTuple<?> key : keys) {
				bbw.addToBuffer(key.getKeyBytes());
			}
			for (Pointer p : pointers) {
				bbw.addToBuffer(p.treePageId);
				bbw.addToBuffer(p.nodeId);
			}
			return bbw.getByteArray();
		}

		private void deserialize() {
			ByteBufferReader bbr = new ByteBufferReader(serialized);
			int numKeys = bbr.readInt();
			keys = new QpTuple<?>[numKeys];
			pointers = new Pointer[numKeys + 1];
			for (int i = 0; i < numKeys; ++i) {
				byte[] key = bbr.readByteArray();
				keys[i] = QpTuple.fromBytes(KEY, schema, schemas, key, null);
			}
			for (int i = 0; i <= numKeys; ++i) {
				int treePageId = bbr.readInt();
				int nodeId = bbr.readInt();
				pointers[i] = new Pointer(treePageId,nodeId);
			}
		}

		Pointer route(QpTuple<?> probe) {
			if (keys == null) {
				deserialize();
			}
			if (keys.length == 0) {
				return pointers[0];
			}
			int pos = Arrays.binarySearch(keys, probe);
			int pointer;
			if (pos < 0) {
				pointer = -pos - 1;
			} else {
				pointer = pos + 1;
			}
			return pointers[pointer];
		}
		
		public String toString() {
			if (keys == null) {
				deserialize();
			}
			return "(" + Arrays.toString(keys) + "," + Arrays.toString(pointers) + ")";
		}
	}

	private Node getNode(Pointer p) {
		if (p.treePageId < 0) {
			throw new IllegalArgumentException();
		}
		Node n = nodes.get(p);
		if (n != null) {
			return n;
		}

		byte[] pageContents = pageSource.getTreePage(schema.relId, p.treePageId);

		ByteBufferReader bbr = new ByteBufferReader(pageContents);
		int count = 0;
		while (! bbr.hasFinished()) {
			byte[] node = bbr.readByteArray();
			Node newNode = new Node(node);
			nodes.put(new Pointer(p.treePageId, count), newNode);
			if (count == p.nodeId) {
				n = newNode;
			}
			++count;
		}

		return n;
	}

	private Pointer addNode(int page, int num, List<QpTuple<?>> keys, List<Pointer> pointers) {
		Node n = new Node(keys, pointers);
		Pointer p = new Pointer(page,num); 
		nodes.put(p, n);
		return p;
	}

	byte[] getTreePage(int num) {
		ByteBufferWriter bbw = new ByteBufferWriter();
		int count = 0;
		for ( ; ; ) {
			Node n = nodes.get(new Pointer(num,count));
			if (n == null) {
				break;
			}
			bbw.addToBuffer(n.serialize());
			count++;
		}
		return bbw.getByteArray();
	}
	
	int getIndexPage(QpTuple<?> key) {
		Pointer p = root;
		while (p.treePageId >= 0) {
			Node n = getNode(p);
			p = n.route(key);
		}
		return p.nodeId;
	}
}

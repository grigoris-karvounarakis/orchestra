package edu.upenn.cis.orchestra.p2pqp;

import java.util.Collection;

import edu.upenn.cis.orchestra.p2pqp.QpSchema.Source;

/**
 * Operations related to metadata
 * 
 * @author netaylor
 *
 * @param <M>		The type of the metadata
 */
/**
 * @author netaylor
 *
 * @param <M>
 */
public interface MetadataFactory<M> {
	/**
	 * Generate a new IDB metadata entry for a child's metadata
	 * 
	 * @param o				The operator performing the join
	 * @param m			The metadata for an input tuple
	 * @return				Derived metadata for this operator
	 */
	M derive(Operator<M> o, M m);
	
	/**
	 * Generate the metadata record for a joined tuple
	 * 
	 * @param o				The operator performing the join
	 * @param leftMetadata	The metadata for an input tuple
	 * @param rightMetadata	The metadata for the other input tuple
	 * @return				The joined tuple's metadata
	 */
	M join(Operator<M> o, M m2, M m1);
	/**
	 * Generate the metadata record for an aggregate tuple
	 * 
	 * @param o				The operator performing the aggregation
	 * @param inputs		The metadata for the input tuples
	 * @return				The metadata for the output tuple
	 */
	M agg(Operator<M> o, Collection<M> inputs);
	
	/**
	 * Generate the metadata for a scanned tuple
	 * 
	 * @param o				The operator doing the scan
	 * @return				The metadata supplied by the underlying
	 * 						storage, if any
	 */
	M scan(Operator<M> o, M inStorage);
	
	/**
	 * Generate the metadata for applying one or more functions
	 *  to a tuple
	 * 
	 * @param o				The operator performing the functions
	 * @param m				The input tuple's metadata
	 * @return				The output tuple's metadata
	 */
	M applyFunctions(Operator<M> o, M m);
	
	/**
	 * Print a metadata to a string
	 * @param m		The metadata record
	 * 
	 * @return		The string representation of the metadata
	 */
	String printMetadata(M m);
	/**
	 * Serialize a metadata record to a byte array
	 * @param m		The metadata record
	 * 
	 * @return		The byte array encoding of it
	 */
	byte[] toBytes(M m);
	
	/**
	 * Deserialize a the byte array representation of a
	 * metadata record
	 * 
	 * @param bytes	The byte array encoding of a metadata record
	 * @return		The decoded metadata record
	 */
	M fromBytes(Source findSchema, IdFactory idf, MetadataFactory<M> mdf, byte[] bytes, ExecutionId tupleId);
	
	/**
	 * How to combine metadata for duplicate tuples
	 * 
	 * @param origMetadata		The original metadata
	 * @param addedMetadata		The additional metadata
	 * @return					The combined metadata
	 */
	M combineMetadata(M origMetadata, M addedMetadata);
	
	
	/**
	 * Determine if tuples with a particular metadata value should be deleted
	 * 
	 * @param m			The metadata value
	 * @return			<code>true</code> if they should be deleted, <code>false</code<
	 * 					if they should not
	 */
	boolean shouldDelete(M m);
	
	
	/**
	 * The difference metadata from old to new metadata
	 * 
	 * @param oldMetadata		The original metadata
	 * @param newMetadata		The new metadata
	 * @return					The difference metadata
	 */
	
	M differenceMetadata(M newMetadata, M oldMetadata);
	
	M duplicate(M oldMatadata);
	
	
}

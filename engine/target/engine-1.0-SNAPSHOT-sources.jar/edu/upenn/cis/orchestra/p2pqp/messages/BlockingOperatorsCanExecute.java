package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.Collection;

import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class BlockingOperatorsCanExecute extends QpMessage implements QueryExecutionMessage {
	private static final long serialVersionUID = 1L;
	public final int queryId;
	public final int operatorIds[];

	public BlockingOperatorsCanExecute(InetSocketAddress dest, int queryId, Collection<Integer> operatorIds) {
		super(dest);
		this.queryId = queryId;
		this.operatorIds = new int[operatorIds.size()];
		int pos = 0;
		for (int id : operatorIds) {
			this.operatorIds[pos++] = id;
		}
	}

	public String toString() {
		return "BlockingOperatorsCanExecute(" + Arrays.toString(operatorIds) + ")";
	}

	public int getQueryId() {
		return queryId;
	}

	public BlockingOperatorsCanExecute(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf,origin);
		this.queryId = buf.readInt();
		this.operatorIds = new int[buf.readInt()];
		for (int i = 0; i < operatorIds.length; ++i) {
			operatorIds[i] = buf.readInt();
		}
	}
	
	@Override
	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(queryId);
		buf.writeInt(operatorIds.length);
		for (int i = 0; i < operatorIds.length; ++i) {
			buf.writeInt(operatorIds[i]);
		}
	}
}

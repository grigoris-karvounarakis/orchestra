package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.Id;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public abstract class IndexMessage extends QpMessage {
	IndexMessage(Id dest) {
		super(dest);
	}
	
	IndexMessage(InetSocketAddress dest) {
		super(dest);
	}

	IndexMessage(QpMessage request) {
		super(request);
	}

	IndexMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
	}
	private static final long serialVersionUID = 1L;
}
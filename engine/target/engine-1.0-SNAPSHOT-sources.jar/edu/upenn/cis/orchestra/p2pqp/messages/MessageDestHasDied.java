package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;
import java.util.Collection;

import edu.upenn.cis.orchestra.p2pqp.Message;

public class MessageDestHasDied extends Message {
	private static final long serialVersionUID = 1L;
	public final InetSocketAddress origMsgDest;
	private final long[] origMsgIds;
	private final boolean canRetry;
	
	public MessageDestHasDied(InetSocketAddress origMsgDest, Collection<Long> msgIds, boolean canRetry) {
		this.origMsgDest = origMsgDest;
		this.canRetry = canRetry;
		origMsgIds = new long[msgIds.size()];
		int pos = 0;
		for (long id : msgIds) {
			origMsgIds[pos++] = id;
		}
	}

	
	public String toString() {
		return "MessageDestHasDied(" + origMsgDest + ")";
	}
	
	public boolean canRetry() {
		return canRetry;
	}
	
	public long[] getOrigIds() {
		return origMsgIds;
	}
	
	public boolean isReply() {
		return true;
	}
}

package edu.upenn.cis.orchestra.p2pqp;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.KEY;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.log4j.Logger;

import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
import com.sleepycat.je.OperationStatus;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.p2pqp.messages.GetTreePage;
import edu.upenn.cis.orchestra.p2pqp.messages.IndexMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.IndexPageIs;
import edu.upenn.cis.orchestra.p2pqp.messages.IndexPagesAre;
import edu.upenn.cis.orchestra.p2pqp.messages.IndexPagesAreAt;
import edu.upenn.cis.orchestra.p2pqp.messages.IndexPagesAreData;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyException;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyFailure;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplySuccess;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyTimeout;
import edu.upenn.cis.orchestra.p2pqp.messages.RequestIndexPage;
import edu.upenn.cis.orchestra.p2pqp.messages.RequestIndexPages;
import edu.upenn.cis.orchestra.p2pqp.messages.RequestSendKeys;
import edu.upenn.cis.orchestra.p2pqp.messages.ScanTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.SendIndexPage;
import edu.upenn.cis.orchestra.p2pqp.messages.SendIndexPages;
import edu.upenn.cis.orchestra.p2pqp.messages.SendIndexPagesAreAt;
import edu.upenn.cis.orchestra.p2pqp.messages.SendTreePage;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;
import edu.upenn.cis.orchestra.util.Cache;
import edu.upenn.cis.orchestra.util.Holder;
import edu.upenn.cis.orchestra.util.LRUCache;
import edu.upenn.cis.orchestra.util.Pair;

public class IndexService implements SearchTree.PageSource {
	public final int NUM_INDEX_THREADS = 3;
	static class IndexServiceException extends Exception {
		private static final long serialVersionUID = 1L;
		IndexServiceException(String what) {
			super(what);
		}
		IndexServiceException(String what, Exception why) {
			super(what,why);
		}
	}
	private QpApplication<?> app;
	private Database indexDb;
	private Environment e;
	private final DatabaseConfig dc;
	private final String indexDbName;
	public static final int numTuplesPerPage = 5000;

	private Set<Thread> currentThreads = new HashSet<Thread>();

	private final Logger logger = Logger.getLogger(this.getClass());

	private static class CacheKey {
		final int relation;
		final int epoch;
		final int number;

		CacheKey(int relation, int epoch, int number) {
			this.relation = relation;
			this.epoch = epoch;
			this.number = number;
		}

		CacheKey(int relation, int epoch) {
			this(relation,epoch,-1);
		}

		public boolean equals(Object o) {
			if (o == null || o.getClass() != this.getClass()) {
				return false;
			}

			CacheKey ck = (CacheKey) o;

			return (epoch == ck.epoch && number == ck.number && relation == ck.relation);
		}

		public int hashCode() {
			return relation + 37 * epoch + 1601 * number;
		}
	}

	private Cache<CacheKey,Message> indexPagesAreCache;
	private Cache<CacheKey,Message> indexPagesCache;

	IndexService(QpApplication<?> app, Environment e, String indexDbName) throws DatabaseException {
		this.app = app;
		this.e = e;
		this.indexDbName = indexDbName;
		dc = new DatabaseConfig();
		dc.setAllowCreate(true);
		dc.setSortedDuplicates(false);
		EnvironmentConfig ec = e.getConfig();
		dc.setReadOnly(ec.getReadOnly());
		indexDb = e.openDatabase(null, indexDbName, dc);

		// Set default cache size of 15 MB
		indexPagesAreCache = new LRUCache<CacheKey,Message>(15 * 1024 * 1024, new LRUCache.GetSize<Message>() {
			public int getSize(Message m) {
				if (m instanceof IndexPagesAreAt) {
					return 50;
				} else if (m instanceof IndexPagesAre) {
					return 100;
				} else {
					String error;
					if (m == null) {
						error = "Should not have a null entry in IndexService.indexEntryCache";
					} else {
						error = "Should not have an entry of type " + m.getClass().getName() + " in IndexService.indexPagesAreCache";
					}
					if (logger == null) {
						System.err.println(error);
					} else {
						logger.warn(error);
					}
					return 0;
				}
			}
		});

		// Set default cache size to be 10% of max memory
		long maxMemory = Runtime.getRuntime().maxMemory();
		if (maxMemory == Long.MAX_VALUE) {
			// 4GB
			maxMemory = 4 * 1024 * 1024 * 1024;
		}
		indexPagesCache = new LRUCache<CacheKey,Message>((int)(0.1 * maxMemory), new LRUCache.GetSize<Message>() {
			public int getSize(Message m) {
				if (m instanceof IndexPageIs) {
					return ((IndexPageIs) m).getCompressedDataLength();
				} else {
					String error;
					if (m == null) {
						error = "Should not have a null entry in IndexService.indexEntryCache";
					} else {
						error = "Should not have an entry of type " + m.getClass().getName() + " in IndexService.indexPagesCache";
					}
					if (logger == null) {
						System.err.println(error);
					} else {
						logger.warn(error);
					}
					return 0;
				}
			}
		});

		for (int i = 0; i < NUM_INDEX_THREADS; ++i) {
			IndexThread it = new IndexThread(i);
			it.start();
			currentThreads.add(it);
		}
	}

	private class IndexThread extends Thread {
		IndexThread(int num) {
			super(app.tg, app.localAddr + " IndexThread #" + num);
		}

		public void run() {
			while (! isInterrupted()) {
				IndexMessage m;
				try {
					m = msgs.take();
				} catch (InterruptedException ie) {
					return;
				}
				interruptable = false;
				try {
					handleMessage(m);
				} finally {
					interruptable = true;
				}
			}
		}
		
		private volatile boolean interruptable = true, interrupted = false;
		
		public void interrupt() {
			if (interruptable) {
				super.interrupt();
			}
			interrupted = true;
		}
		
		public boolean isInterrupted() {
			return interrupted;
		}
	}

	void close() throws IndexServiceException, InterruptedException {
		synchronized (currentThreads) {
			for (Thread t : currentThreads) {
				t.interrupt();
				t.join();
			}
			currentThreads.clear();
		}

		try {
			indexDb.close();
		} catch (DatabaseException e) {
			throw new IndexServiceException("Error stopping index service", e);
		}
	}

	private interface IndexPageSink {
		void totalNumTuplesIs(int numTuples, int numPages);
		void deliverPage(EpochNum pageId, byte[] contents);
		void processException(Exception e);
	}

	public interface TupleSink {
		void totalNumTuplesIs(int numTuples, int numPages);
		/**
		 * Deliver a page of tuples. The array may contain extra
		 * null elements at the end.
		 * 
		 * @param contents
		 */
		void deliverTuples(QpTuple<?>[] contents);
		void processException(Exception e);
	}

	interface SerializedTupleSink {
		void totalNumTuplesIs(int numTuples, int numPages);
		/**
		 * Deliver a page of serialized tuples. The array may contain extra
		 * null elements at the end.
		 * 
		 * @param contents
		 */
		void deliverTuples(ByteArrayWrapper[] contents);
		void processException(Exception e);
	}

	private class GetTuplesThread extends Thread {
		private final int relId, epoch;
		final TupleSink ts;
		final SerializedTupleSink sts;
		final QpSchema.Source schemas;
		final QpSchema schema;

		GetTuplesThread(int relId, int epoch, TupleSink ts) {
			super(app.tg, "GetTuplesThread(" + relId + ")");
			this.relId = relId;
			this.epoch = epoch;
			this.ts = ts;
			this.sts = null;
			schema = app.store.getSchema(relId);
			schemas = new QpSchema.SingleSource(schema);
		}

		GetTuplesThread(int relId, int epoch, SerializedTupleSink sts) {
			super(app.tg, "GetTuplesThread(" + relId + ")");
			this.relId = relId;
			this.epoch = epoch;
			this.ts = null;
			this.sts = sts;
			schema = app.store.getSchema(relId);
			schemas = new QpSchema.SingleSource(schema);
		}

		private void getIndexPages(final int relId, int epoch, final IndexPageSink ips) throws IndexServiceException, InterruptedException, IOException {
			IndexEntry ie = getIndexEntry(relId, epoch);

			ips.totalNumTuplesIs(ie.numTuples, ie.indexPages.size());
			final int numNeededPages = ie.indexPages.size();

			final Holder<Exception> ex = new Holder<Exception>();
			final Set<EpochNum> remaining = new HashSet<EpochNum>(ie.indexPages);
			final List<Pair<EpochNum,IndexPageIs>> pages = new ArrayList<Pair<EpochNum,IndexPageIs>>(numNeededPages);

			for (final EpochNum en : ie.indexPages) {
				final CacheKey epochNumCK = new CacheKey(relId, en.epoch, en.num);
				Message cachedReply = indexPagesCache.probe(epochNumCK);
				if (cachedReply == null) {
					logger.trace("Probing network for keys for " + en + " for " + relId);
					ReplyContinuation pageRc = new ReplyContinuation() {
						private boolean finished = false;
						synchronized public boolean isFinished() {
							return finished;
						}

						synchronized public void processReply(Message m) {
							if (finished) {
								return;
							}
							finished = true;
							if (m instanceof IndexPageIs) {
								indexPagesCache.store(epochNumCK, m);
								synchronized (pages) {
									pages.add(new Pair<EpochNum,IndexPageIs>(en, (IndexPageIs) m));
									remaining.remove(en);
									pages.notify();
								}
							} else {
								synchronized (pages) {
									ex.value = new IndexServiceException("Received unexpected reply to RequestIndexPage for " + en + ": " + m);
									pages.notify();
								}
							}
						}

					};
					app.sendMessageAwaitReply(new RequestIndexPage(IndexService.this.getId(relId, en.epoch, en.num), relId, en.epoch, en.num), pageRc, IndexPageIs.class);
				} else {
					logger.trace("Found cached keys for " + en + " for " + relId);
					synchronized (pages){
						pages.add(new Pair<EpochNum,IndexPageIs>(en, (IndexPageIs) cachedReply));
						remaining.remove(en);
					}
				}
			}

			for ( ; ; ) {
				EpochNum en;
				IndexPageIs m;
				synchronized (pages) {
					if (ex.value != null) {
						break;
					}
					if (pages.isEmpty() && remaining.isEmpty()) {
						break;
					}
					while (pages.isEmpty()) {
						pages.wait();
					}
					Pair<EpochNum,IndexPageIs> p = pages.remove(pages.size() - 1);
					en = p.getFirst();
					m = p.getSecond();
				}
				ips.deliverPage(en, m.getData());
				logger.trace("Processed page " + en + " for " + relId);
			}
			if (ex.value != null) {
				ips.processException(ex.value);
			}
		}


		public void run() {
			try {
				getIndexPages(relId, epoch, new IndexPageSink() {
					public void deliverPage(EpochNum pageId, byte[] contents) {
						try {
							if (sts != null) {
								ByteArrayWrapper tuples[] = new ByteArrayWrapper[numTuplesPerPage];
								int pos = 0;
								int count = 0;
								final int length = contents.length;
								while (pos < length) {
									if (count >= tuples.length) {
										ByteArrayWrapper newTuples[] = new ByteArrayWrapper[tuples.length * 2];
										System.arraycopy(tuples, 0, newTuples, 0, tuples.length);
										tuples = newTuples;
									}
									int tupleLen = IntType.getValFromBytes(contents, pos, IntType.bytesPerInt);
									pos += IntType.bytesPerInt;
									tuples[count++] = new ByteArrayWrapper(contents, pos, tupleLen);
									pos += tupleLen;
								}
								sts.deliverTuples(tuples);
							}
							if (ts != null) {
								QpTuple<?> tuples[] = new QpTuple<?>[numTuplesPerPage];
								int pos = 0;
								int count = 0;
								final int length = contents.length;
								while (pos < length) {
									if (count >= tuples.length) {
										QpTuple<?> newTuples[] = new QpTuple<?>[tuples.length * 2];
										System.arraycopy(tuples, 0, newTuples, 0, tuples.length);
										tuples = newTuples;
									}
									int tupleLen = IntType.getValFromBytes(contents, pos, IntType.bytesPerInt);
									pos += IntType.bytesPerInt;
									tuples[count++] = QpTuple.fromBytes(KEY, schema, schemas, null, contents, pos, tupleLen, null);
									pos += tupleLen;
								}
								ts.deliverTuples(tuples);
							}
						} catch (Exception e) {
							processException(e);
							return;
						}
					}

					public void totalNumTuplesIs(int numTuples, int numPages) {
						if (sts != null) {
							sts.totalNumTuplesIs(numTuples, numPages);
						};
						if (ts != null) {
							ts.totalNumTuplesIs(numTuples, numPages);
						}
					}

					public void processException(Exception e) {
						e.printStackTrace();
						if (sts != null) {
							sts.processException(e);
						}
						if (ts != null) {
							ts.processException(e);
						}
					}
				});
			} catch (InterruptedException e) {
			} catch (Exception e) {
				e.printStackTrace();
				if (sts != null) {
					sts.processException(e);
				}
				if (ts != null) {
					ts.processException(e);
				}
			}

			synchronized (currentThreads) {
				currentThreads.remove(this);
			}
		}
	}


	public Thread getTuplesInRelation(final int relId, final int epoch, final TupleSink ts) {
		GetTuplesThread gtt = new GetTuplesThread(relId, epoch, ts);
		gtt.start();
		synchronized (currentThreads) {
			currentThreads.add(gtt);
		}
		return gtt;
	}

	public Thread getTuplesInRelation(final int relId, final int epoch, final SerializedTupleSink ts) {
		GetTuplesThread gtt = new GetTuplesThread(relId, epoch, ts);
		gtt.start();
		synchronized (currentThreads) {
			currentThreads.add(gtt);
		}
		return gtt;
	}

	private class SendKeyTuplesThread extends Thread {
		private final int relId, epoch, queryId, operatorId;
		private final byte[] filterBytes;
		private final RecordTuples rt;
		private final int phaseNo;
		private final IdRange[] rangesToSend;

		Set<EpochNum> remainingPages = new HashSet<EpochNum>();
		Set<EpochNum> failedPages = new HashSet<EpochNum>();
		
		SendKeyTuplesThread(int relId, int epoch, int queryId, int operatorId, byte[] filterBytes, RecordTuples rt, IdRange[] rangesToSend, int phaseNo) {
			super(app.tg, "SendKeyTuples(" + relId + "," + epoch + "," + queryId + "," + operatorId + ")");
			this.relId = relId;
			this.epoch = epoch;
			this.queryId = queryId;
			this.operatorId = operatorId;
			this.filterBytes = filterBytes;
			this.rt = rt;
			this.phaseNo = phaseNo;
			this.rangesToSend = rangesToSend;
		}

		public void run() {
			try {
				IndexEntry ie = getIndexEntry(relId,epoch);
				remainingPages.addAll(ie.indexPages);
				for (final EpochNum en : ie.indexPages) {
					QpMessage m = new RequestSendKeys(IndexService.this.getId(relId, en.epoch, en.num), relId, en.epoch, en.num, queryId, operatorId, filterBytes, phaseNo, rangesToSend);
					ReplyContinuation rc = new ReplyContinuation() {
						private boolean finished;
						synchronized public boolean isFinished() {
							return finished;
						}

						public synchronized void processReply(Message m) {
							finished = true;
							boolean failure = false;
							if (! (m instanceof ReplySuccess)) {
								failure = true;
								Exception e = new RuntimeException("Received unexpected reply to RequestSendKeys for relation " + relId + " " + en + ": " + m);
								rt.reportException(e);
							}
							synchronized (remainingPages) {
								remainingPages.remove(en);
								if (failure) {
									failedPages.add(en);
								}
								if (remainingPages.isEmpty()) {
									if (failedPages.isEmpty()) {
										logger.info("Successfully sent key tuples for relation " + relId + " operator " + operatorId + " phase " + phaseNo);
									} else {
										logger.info("Sent key tuples for relation " + relId + " operator " + operatorId + " phase " + phaseNo + " but had failed pages: " + failedPages);
									}
								}
							}
						}

					};
					app.sendMessageAwaitReply(m, rc, ReplySuccess.class);
				}
			} catch (Exception e) {
				rt.reportException(e);
			}

			synchronized (currentThreads) {
				currentThreads.remove(this);
			}
		}

	}

	void sendKeyTuples(int relId, int epoch, int queryId, int operatorId, Filter<? super QpTuple<?>> keyColsFilter, RecordTuples rt, IdRange[] rangesToSend, int phaseNo) throws IndexServiceException, InterruptedException {
		QpSchema schema = app.store.getSchema(relId);
		if (schema == null) {
			throw new IllegalArgumentException("Couldn't get schema for relation " + relId);
		}
		byte[] filterBytes;
		if (keyColsFilter == null) {
			filterBytes = null;
		} else {
			filterBytes = FilterSerialization.getBytes(keyColsFilter, schema);
		}
		SendKeyTuplesThread sktt = new SendKeyTuplesThread(relId, epoch, queryId, operatorId, filterBytes, rt, rangesToSend, phaseNo);
		sktt.start();
		synchronized (currentThreads) {
			currentThreads.add(sktt);
		}
	}

	private static class IndexEntry {
		final int numTuples;
		final int treeNum;
		final List<EpochNum> indexPages;

		IndexEntry(int numTuples, int treeNum, List<EpochNum> indexPages) {
			this.numTuples = numTuples;
			this.treeNum = treeNum;
			this.indexPages = indexPages;
		}
	}

	private IndexEntry getIndexEntry(int relId, int epoch) throws InterruptedException, IndexServiceException, IOException {
		CacheKey ck = new CacheKey(relId, epoch);
		Message m = indexPagesAreCache.probe(ck);
		ReplyHolder<Integer> awaitPage = new ReplyHolder<Integer>(1);
		if (m == null) {
			logger.trace("Probing network for page ids for " + relId);
			ReplyContinuation rc = new SimpleReplyContinuation<Integer>(1,awaitPage);
			app.sendMessageAwaitReply(new RequestIndexPages(getId(relId,epoch), relId, epoch, true), rc, IndexPagesAre.class, IndexPagesAreAt.class);
			awaitPage.waitUntilFinished();
			m = awaitPage.getReply(1);
			if (!((m instanceof IndexPagesAre) || (m instanceof IndexPagesAreAt))) {
				throw new IndexServiceException("Received unexpected reply to a RequestIndexPages(" + relId + "," + epoch + ") message from " + m.getOrigin() + ": " + m);
			}
			indexPagesAreCache.store(ck, m);
		} else {
			logger.trace("Found cached page ids for " + relId);
		}
		if (m instanceof IndexPagesAreAt) {
			IndexPagesAreAt ipaa = (IndexPagesAreAt) m;
			awaitPage.reset(1);
			ck = new CacheKey(relId, ipaa.epoch);
			m = indexPagesAreCache.probe(ck);
			if (m == null) {
				ReplyContinuation rc = new SimpleReplyContinuation<Integer>(1,awaitPage);
				app.sendMessageAwaitReply(new RequestIndexPages(getId(relId,ipaa.epoch), relId, ipaa.epoch, true), rc, IndexPagesAre.class);
				awaitPage.waitUntilFinished();
				m = awaitPage.getReply(1);
				if (m instanceof IndexPagesAreAt) {
					throw new IndexServiceException("Should not receive a redirect following a redirection");
				} else if (!(m instanceof IndexPagesAre)) {
					throw new IndexServiceException("Received unexpected reply to a RequestIndexPages message: " + m);
				}
				indexPagesAreCache.store(ck, m);
			} else {
				if (m instanceof IndexPagesAreAt) {
					throw new IndexServiceException("Should not find a redirect following a redirection in cache");
				} else if (!(m instanceof IndexPagesAre)) {
					throw new IndexServiceException("Received unexpected reply to a RequestIndexPages message from cache: " + m);
				}
			}
		}

		IndexPagesAre ipa = (IndexPagesAre) m;

		IndexEntry ie = new IndexEntry(ipa.numTuples, ipa.treeNum, Collections.unmodifiableList(ipa.getPageIds()));

		logger.trace("Processed page ids for " + relId);

		return ie;
	}

	void recordTuplesForEpoch(int relId, int epoch, SortedSet<byte[]> keys) throws IndexServiceException, InterruptedException {
		final int numTuples = keys == null ? 0 : keys.size();
		int numPages = numTuples / numTuplesPerPage;
		if ((numTuples % numTuplesPerPage) != 0) {
			++numPages;
		}

		List<EpochNum> pages = new ArrayList<EpochNum>(numPages);
		for (int i = 0; i < numPages; ++i) {
			pages.add(new EpochNum(epoch,i));
		}

		ByteBufferWriter bbw = new ByteBufferWriter();
		List<byte[]> pagesContents = new ArrayList<byte[]>(pages.size());
		List<QpTuple<?>> pageBots = new ArrayList<QpTuple<?>>(pages.size());

		final QpSchema schema = app.getStore().getSchema(relId);
		final QpSchema.Source schemas = app.getStore();

		if (keys != null) {
			Iterator<byte[]> it = keys.iterator();

			for (int i = 0; i < numPages; ++i) {
				byte[] curr = it.next();
				bbw.addToBuffer(curr);
				pageBots.add(QpTuple.fromBytes(KEY, schema, schemas, curr, null));
				if (it.hasNext()) {
					for (int j = 1; j < numTuplesPerPage; ++j) {
						bbw.addToBuffer(it.next());
						if (! it.hasNext()) {
							break;
						}
					}
				}
				pagesContents.add(bbw.getByteArray());
				bbw.clear();
			}
		}

		Set<Integer> createdPages = new HashSet<Integer>();
		SearchTree st = new SearchTree(0, schema, pageBots, createdPages);

		try {
			recordPages(relId,epoch,pagesContents);
			recordPagesForEpoch(relId, epoch, pages, numTuples, 0);
			recordTreePages(relId, st,createdPages);
		} catch (IOException e) {
			throw new IndexServiceException("Error recording tuples for epoch", e);
		}
	}

	void recordChangedTuplesForEpoch(int relId, int epoch, SortedSet<byte[]> removedKeys, SortedSet<byte[]> addedKeys) throws IndexServiceException, InterruptedException {
		int firstEpoch;
		try {
			firstEpoch = app.getFirstEpochForTable(relId);
		} catch (IllegalArgumentException iae) {
			throw new IndexServiceException("Couldn't determine first epoch for relation " + relId, iae);
		}
		if (epoch == firstEpoch) {
			throw new IndexServiceException("Cannot record changed tuples for first epoch");
		}

		if ((removedKeys == null || removedKeys.isEmpty()) && (addedKeys == null || addedKeys.isEmpty())) {
			// Refer to the previous epoch's index, either by pointing to it directly
			// (if it actually holds a list of pages) or my pointing to the epoch
			// it points to
			ReplyHolder<Integer> replies = new ReplyHolder<Integer>(1);

			try {
				app.sendMessageAwaitReply(new RequestIndexPages(getId(relId,epoch - 1),relId,epoch - 1,false), new SimpleReplyContinuation<Integer>(1,replies), IndexPagesAreAt.class, IndexPagesAreData.class);
				replies.waitUntilFinished();
			} catch (InterruptedException e) {
				throw new IndexServiceException("Interrupted while requesting index pages", e);
			} catch (IOException e) {
				throw new IndexServiceException("Error sending RequestIndexPages", e);
			}

			Message m = replies.getReply(1);
			int newLoc;
			if (m instanceof IndexPagesAreAt) {
				newLoc = ((IndexPagesAreAt) m).epoch;
			} else if (m instanceof IndexPagesAreData) {
				newLoc = epoch - 1;
			} else {
				throw new IndexServiceException("Received unexpected reply to RequestIndexPages while computing redirect: " + m);
			}

			try {
				recordPagesLocationForEpoch(relId, epoch, newLoc);
			} catch (IOException e) {
				throw new IndexServiceException("Error recoding redirect for epoch", e);
			}
			return;
		}

		if (removedKeys == null) {
			removedKeys = new TreeSet<byte[]>();
		}

		if (addedKeys == null) {
			addedKeys = new TreeSet<byte[]>();
		}

		IndexEntry ie;
		try {
			ie = getIndexEntry(relId, epoch - 1);
		} catch (IOException e1) {
			throw new IndexServiceException("Error retrieving index entry", e1);
		}
		Map<EpochNum,SortedSet<QpTuple<?>>> changedPages = new HashMap<EpochNum,SortedSet<QpTuple<?>>>();


		QpSchema.Source schemas = app.getStore();
		QpSchema schema = schemas.getSchema(relId);

		int relationSize = ie.numTuples;
		SearchTree st = new SearchTree(schema, ie.treeNum, this);

		// TODO: exploit the fact that removedKeys and addedKeys are sorted
		for (byte[] removed : removedKeys) {
			QpTuple<?> t = QpTuple.fromBytes(KEY, schema, schemas, removed, null);

			int index = st.getIndexPage(t);
			EpochNum en = ie.indexPages.get(index);
			SortedSet<QpTuple<?>> page = changedPages.get(en);
			if (page == null) {
				page = new TreeSet<QpTuple<?>>(this.getIndexPage(relId, en.epoch, en.num));
				changedPages.put(en, page);
			}
			page.remove(t);
			--relationSize;
		}
		for (byte[] added : addedKeys) {
			QpTuple<?> t = QpTuple.fromBytes(KEY, schema, schemas, added, null);
			int index = st.getIndexPage(t);
			EpochNum en = ie.indexPages.get(index);
			SortedSet<QpTuple<?>> page = changedPages.get(en);
			if (page == null) {
				page = new TreeSet<QpTuple<?>>(this.getIndexPage(relId, en.epoch, en.num));
				changedPages.put(en, page);
			}
			// Removing and then adding will ensure that the correct epoch number is in the index
			if (page.remove(t)) {
				--relationSize;
			}
			page.add(t);
			++relationSize;
		}
		int pageNum = 0;
		List<byte[]> newPages = new ArrayList<byte[]>(changedPages.size());
		List<EpochNum> pageNumbers = new ArrayList<EpochNum>();
		ByteBufferWriter bbw = new ByteBufferWriter();
		for (EpochNum oldPageNum : ie.indexPages) {
			SortedSet<QpTuple<?>> newPage = changedPages.get(oldPageNum);
			if (newPage == null) {
				pageNumbers.add(oldPageNum);
			} else {
				pageNumbers.add(new EpochNum(epoch, pageNum++));
				bbw.clear();
				for (QpTuple<?> t : newPage) {
					bbw.addToBuffer(t.getKeyBytes());
				}
				newPages.add(bbw.getByteArray());
			}
		}

		try {
			recordPages(relId,epoch,newPages);
			recordPagesForEpoch(relId,epoch,pageNumbers,relationSize,ie.treeNum);
		} catch (IOException e) {
			throw new IndexServiceException("Error recording changes", e);
		}
	}

	private List<QpTuple<?>> getIndexPage(int relId, int epoch, int num) throws IndexServiceException {
		QpMessage m = new RequestIndexPage(getId(relId,epoch,num), relId, epoch, num);
		ReplyHolder<Integer> replies = new ReplyHolder<Integer>(1);
		try {
			app.sendMessageAwaitReply(m, new SimpleReplyContinuation<Integer>(1, replies), IndexPageIs.class);
			replies.waitUntilFinished();
		} catch (Exception e) {
			throw new IndexServiceException("Error retrieving index page", e);
		}
		Message reply = replies.getReply(1);
		final QpSchema.Source schemas = app.getStore();
		final QpSchema schema = schemas.getSchema(relId);
		if (reply instanceof IndexPageIs) {
			List<QpTuple<?>> page = new ArrayList<QpTuple<?>>();
			ByteBufferReader bbr = new ByteBufferReader(((IndexPageIs) reply).getData());
			while (! bbr.hasFinished()) {
				byte[] tuple = bbr.readByteArray();
				page.add(QpTuple.fromBytes(KEY, schema, schemas, tuple, null));
			}
			return page;
		} else {
			throw new IndexServiceException("Received unexpected reply to " + m + ": " + reply);
		}
	}

	private void recordPagesForEpoch(int relId, int epoch, List<EpochNum> pages, int numTuples, int treeNum) throws IndexServiceException, IOException {
		InetSocketAddress[] dests = app.getRouter().getDests(getId(relId,epoch), app.replicationFactor);
		final ReplyHolder<Long> replies = new ReplyHolder<Long>(dests.length);
		try {
			for (InetSocketAddress dest : dests) {
				Message m = new SendIndexPages(dest, relId, epoch, pages, numTuples, treeNum);
				ReplyContinuation rc = new SimpleReplyContinuation<Long>(m.messageId, replies);
				app.sendMessageAwaitReply(m, rc, ReplySuccess.class);
			}
			replies.waitUntilFinished();
		} catch (InterruptedException ie) {
			throw new IndexServiceException("Interrupted while sending index pages or awaiting confirmation", ie);
		}

		for (Message m : replies) {
			if (! (m instanceof ReplySuccess)) {
				throw new IndexServiceException("Received unexpected reply to sending index pages: " + m);
			}
		}
	}

	private void recordPagesLocationForEpoch(int relId, int epoch, int locationEpoch) throws IndexServiceException, IOException {
		final ReplyHolder<Integer> replies = new ReplyHolder<Integer>(1);

		ReplyContinuation rc = new SimpleReplyContinuation<Integer>(1,replies);
		try {
			app.sendMessageAwaitReply(new SendIndexPagesAreAt(getId(relId,epoch), relId, epoch, locationEpoch), rc, ReplySuccess.class);
			replies.waitUntilFinished();
		} catch (InterruptedException ie) {
			throw new IndexServiceException("Interrupted while sending index pages or awaiting confirmation", ie);
		}

		Message m = replies.getReply(1);
		if (! (m instanceof ReplySuccess)) {
			throw new IndexServiceException("Received unexpected reply to sending index pages: " + m);
		}
	}

	private void recordPages(int relId, int epoch, List<byte[]> pages) throws IndexServiceException, IOException, InterruptedException {
		final ReplyHolder<Long> replies = new ReplyHolder<Long>(0);

		final Router r = app.getRouter();
		int pageNum = 0;
		for (byte[] page : pages) {
			InetSocketAddress dests[] = r.getDests(getId(relId,epoch,pageNum), app.replicationFactor);
			replies.addMoreRepliesExpected(dests.length);
			for (InetSocketAddress addr : dests) {
				Message m = new SendIndexPage(addr, relId, epoch, pageNum, page);
				ReplyContinuation rc = new SimpleReplyContinuation<Long>(m.messageId,replies);
				app.sendMessageAwaitReply(m, rc, ReplySuccess.class);
			}
			++pageNum;
		}

		replies.waitUntilFinished();

		for (Message m : replies) {
			if (!(m instanceof ReplySuccess)) {
				throw new IndexServiceException("Received unexpected reply to SendIndexPage message: " + m);
			}
		}
	}

	private void recordTreePages(int relId, SearchTree st, Collection<Integer> pages) throws IOException, InterruptedException, IndexServiceException {
		final ReplyHolder<Long> replies = new ReplyHolder<Long>(0);

		final Router r = app.getRouter();
		
		for (Integer page : pages) {
			byte[] pageContents = st.getTreePage(page);
			Id dest = getTreePageId(relId, page);
			InetSocketAddress[] nodes = r.getDests(dest, app.replicationFactor);
			replies.addMoreRepliesExpected(nodes.length);
			for (InetSocketAddress node : nodes) {
				Message m = new SendTreePage(node, relId, page, pageContents);
				ReplyContinuation rc = new SimpleReplyContinuation<Long>(m.messageId, replies);
				app.sendMessageAwaitReply(m, rc, ReplySuccess.class);
			}
		}
		replies.waitUntilFinished();

		for (Message m : replies) {
			if (!(m instanceof ReplySuccess)) {
				throw new IndexServiceException("Received unexpected reply to SendTreePage: " + m);
			}
		}
	}

	public static class EpochNum {
		public final int epoch;
		public final int num;

		public EpochNum(int epoch, int num) {
			this.epoch = epoch;
			this.num = num;
		}

		public boolean equals(Object o) {
			if (o == null || o.getClass() != this.getClass()) {
				return false;
			}
			EpochNum ren = (EpochNum) o;
			return (epoch == ren.epoch && num == ren.num);
		}

		public int hashCode() {
			return epoch + 1601 * num;
		}

		public String toString() {
			return "(" + epoch + "," + num + ")";
		}
	}

	private BlockingQueue<IndexMessage> msgs = new LinkedBlockingQueue<IndexMessage>();

	void processMessage(IndexMessage ism) throws InterruptedException {
		msgs.add(ism);
	}

	private void handleMessage(IndexMessage ism) {
		DatabaseEntry key, value = new DatabaseEntry();
		OperationStatus os;
		try {
			if (ism instanceof RequestIndexPages) {
				RequestIndexPages rip = (RequestIndexPages) ism;
				key = getKey(rip.relId, rip.epoch);
				os = indexDb.get(null, key, value, null);
				if (os == OperationStatus.SUCCESS) {
					byte[] result = value.getData();
					if (result[0] == 0) {
						// redirect
						int locEpoch = IntType.getValFromBytes(result, 1, IntType.bytesPerInt);
						app.sendMessage(new IndexPagesAreAt(rip,locEpoch));
					} else {
						if (rip.wantNonRedirect) {
							byte[] record = new byte[result.length - 1];
							System.arraycopy(result, 1, record, 0, record.length);
							app.sendMessage(new IndexPagesAre(rip,record));
						} else {
							// Are just trying to determine if this epoch has
							// actual data or just a redirect
							app.sendMessage(new IndexPagesAreData(rip));
						}
					}
				} else {
					app.sendMessage(new ReplyFailure(ism,"Could not find index entry in local DB for relation '" + rip.relId + "', epoch " + rip.epoch, true));
				}
			} else if ((ism instanceof SendIndexPages) || (ism instanceof SendIndexPagesAreAt)) {
				byte[] data;
				int relId;
				int epoch;
				if (ism instanceof SendIndexPages) {
					SendIndexPages sip = (SendIndexPages) ism;
					relId = sip.relId;
					epoch = sip.epoch;
					data = new byte[sip.data.length + 1];
					data[0] = 1;
					System.arraycopy(sip.data, 0, data, 1, sip.data.length);
				} else {
					// redirect
					SendIndexPagesAreAt sipaa = (SendIndexPagesAreAt) ism;
					data = new byte[IntType.bytesPerInt + 1];
					data[0] = 0;
					System.arraycopy(IntType.getBytes(sipaa.locEpoch), 0, data, 1, IntType.bytesPerInt);
					relId = sipaa.relId;
					epoch = sipaa.epoch;
				}
				key = getKey(relId, epoch);
				value.setData(data);
				os = indexDb.putNoOverwrite(null, key, value);
				if (os == OperationStatus.KEYEXIST) {
					indexDb.get(null, key, value, null);
					if (Arrays.equals(value.getData(), data)) {
						// Ignore double insertion of same data
						os = OperationStatus.SUCCESS;
					}
				}
				if (os == OperationStatus.SUCCESS) {
					app.sendReplySuccess(ism);
				} else {
					app.sendMessage(new ReplyFailure(ism, "Record already exists for (" + relId + "," + epoch + ")", false));
				}					
			} else if (ism instanceof RequestIndexPage) {
				RequestIndexPage rip = (RequestIndexPage) ism;
				key = getKey(rip.relId, rip.epoch, rip.number);
				os = indexDb.get(null, key, value, null);
				if (os == OperationStatus.SUCCESS) {
					app.sendMessage(new IndexPageIs(rip, value.getData()));
				} else {
					app.sendMessage(new ReplyFailure(rip, "Could not find index page (" + rip.relId + "," + rip.epoch + "," + rip.number + ")", true));
				}
			} else if (ism instanceof SendIndexPage) {
				SendIndexPage sip = (SendIndexPage) ism;
				key = getKey(sip.relId, sip.epoch, sip.number);
				value.setData(sip.data);
				os = indexDb.putNoOverwrite(null, key, value);
				if (os == OperationStatus.KEYEXIST) {
					indexDb.get(null, key, value, null);
					if (Arrays.equals(value.getData(), sip.data)) {
						// Ignore double insertion of same data
						os = OperationStatus.SUCCESS;
					}
				}
				if (os == OperationStatus.SUCCESS) {
					app.sendReplySuccess(ism);
				} else {
					app.sendMessage(new ReplyFailure(ism, "Record already exists for (" + sip.relId + "," + sip.epoch + "," + sip.number +")", false));
				}
			} else if (ism instanceof RequestSendKeys) {
				final RequestSendKeys rsk = (RequestSendKeys) ism;
				key = getKey(rsk.relId, rsk.epoch, rsk.number);
				os = indexDb.get(null, key, value, null);
				if (os == OperationStatus.SUCCESS) {
					final Router r = app.getRouterForQuery(rsk.queryId, rsk.phaseNo);
					if (r == null) {
						if (logger.isInfoEnabled()) {
							logger.info("Couldn't find router for phase " + rsk.phaseNo + " of query " + rsk.queryId);
						}
						app.sendMessage(new ReplyFailure(rsk, "Couldn't find router for phase " + rsk.phaseNo + " of query " + rsk.queryId, true));
					}
					final Set<InetSocketAddress> failedNodes;
					if (r == null) {
						failedNodes = null;
					} else {
						failedNodes = app.getFailedNodesForQuery(rsk.queryId);
						if (failedNodes == null) {
							if (logger.isInfoEnabled()) {
								logger.info("Couldn't find failed not set for query " + rsk.queryId);
							}
							app.sendMessage(new ReplyFailure(rsk, "Couldn't find failed not set for query " + rsk.queryId, true));
						}
					}
					if (r != null && failedNodes != null) {
						QpSchema schema = app.store.getSchema(rsk.relId);
						QpSchema.Source schemas = new QpSchema.SingleSource(schema);
						Map<InetSocketAddress,ByteBufferWriter> writers = new HashMap<InetSocketAddress,ByteBufferWriter>();
						for (InetSocketAddress addr : r.getParticipants()) {
							if (failedNodes.contains(addr)) {
								continue;
							}
							writers.put(addr, new ByteBufferWriter());
						}
						Filter<? super QpTuple<?>> f = null;
						if (rsk.keyFilterBytes != null) {
							f = FilterSerialization.fromBytes(schema, rsk.keyFilterBytes);
						}
						int pos = 0;
						byte[] data = value.getData();
						final int length = data.length;
						while (pos < length) {
							int tupleLength = IntType.getValFromBytes(data, pos, IntType.bytesPerInt);
							pos += IntType.bytesPerInt;
							QpTuple<?> t = QpTuple.fromBytes(KEY, schema, schemas, null, data, pos, tupleLength, null);
							if (f == null || f.eval(t)) {
								Id id = t.getQPid();
								boolean add;
								if (rsk.rangesToSend == null) {
									add = true;
								} else {
									add = false;
									for (IdRange range : rsk.rangesToSend) {
										if (range.contains(id)) {
											add = true;
											break;
										}
									}
								}
								if (add) {
									InetSocketAddress dest = r.getDest(id);
									ByteBufferWriter bbw = writers.get(dest);
									if (bbw != null) {
										bbw.addToBuffer(data, pos, tupleLength);
									}
								}
							}
							pos += tupleLength;
						}
						for (Map.Entry<InetSocketAddress, ByteBufferWriter> me : writers.entrySet()) {
							final InetSocketAddress dest = me.getKey();
							ReplyContinuation rc = new ReplyContinuation() {
								private boolean finished;
								synchronized public boolean isFinished() {
									return finished;
								}

								synchronized public void processReply(Message m) {
									// We're only doing this for retries etc.
									finished = true;
								}

							};
							QpMessage stm = new ScanTuplesMessage(dest, rsk.phaseNo, rsk.queryId, rsk.operatorId, me.getValue().getByteArray(), rsk.epoch, rsk.number);
							app.sendMessageAwaitReply(stm, rc, ReplySuccess.class, ReplyTimeout.class);
							
						}
						app.sendReplySuccess(rsk);
						if (logger.isInfoEnabled()) {
							logger.info(app.localAddr + " sent keys for relation " + rsk.relId + " epoch " + rsk.epoch + " page no. " + rsk.number + " phase no. " + rsk.phaseNo);
						}
					}
				} else {
					app.sendMessage(new ReplyFailure(rsk, "Could not request keys because could not find index page (" + rsk.relId + "," + rsk.epoch + "," + rsk.number + ")", true));
				}
			} else if (ism instanceof SendTreePage) {
				SendTreePage stp = (SendTreePage) ism;
				key = getTreePageKey(stp.relId, stp.pageNum);
				value.setData(stp.data);
				os = indexDb.putNoOverwrite(null, key, value);
				if (os == OperationStatus.KEYEXIST) {
					app.sendMessage(new ReplyFailure(stp, "Tree (" + stp.relId + "," + stp.pageNum + ") already in database", false));
				} else {
					app.sendReplySuccess(stp);
				}
			} else if (ism instanceof GetTreePage) {
				GetTreePage gtp = (GetTreePage) ism;
				key = getTreePageKey(gtp.relId, gtp.pageNum);
				os = indexDb.get(null, key, value, null);
				if (os == OperationStatus.SUCCESS) {
					app.sendMessage(new SendTreePage(gtp, value.getData()));
				} else {
					app.sendMessage(new ReplyFailure(gtp, "Tree (" + gtp.relId + "," + gtp.pageNum + ") not found in database", true));
				}
			} else {
				logger.error("Index service doesn't know what to do with message " + ism);
			}
		} catch (Exception e) {
			try {
				app.sendMessage(new ReplyException(ism, "Error procesing IndexMessage", e, false));
			} catch (IOException ioe) {
				logger.error(e);
			} catch (InterruptedException ie) {
				return;
			}
		}
	}

	private Id getTreePageId(int rel, int treePageNum) {
		return getId(rel, treePageNum,TREE);
	}

	private Id getId(int rel, int epoch) {
		return getId(rel,epoch,PAGES_FOR_EPOCH);
	}

	private Id getId(int rel, int epoch, int number) {
		ByteBufferWriter bbw = new ByteBufferWriter();
		bbw.addToBuffer(rel);
		bbw.addToBuffer(epoch);
		bbw.addToBuffer(number);
		return Id.fromContent(bbw.getByteArray());
	}

	private static final int PAGES_FOR_EPOCH = 1000, PAGE_CONTENTS = 2000, TREE = 3000;

	private DatabaseEntry getKey(int relId, int epoch) {
		ByteBufferWriter bbw = new ByteBufferWriter();
		bbw.addToBuffer(relId);
		bbw.addToBuffer(epoch);
		bbw.addToBuffer(PAGES_FOR_EPOCH);
		return new DatabaseEntry(bbw.getByteArray());
	}

	private DatabaseEntry getKey(int relId, int epoch, int number) {
		ByteBufferWriter bbw = new ByteBufferWriter();
		bbw.addToBuffer(relId);
		bbw.addToBuffer(epoch);
		bbw.addToBuffer(PAGE_CONTENTS);
		bbw.addToBuffer(number);
		return new DatabaseEntry(bbw.getByteArray());
	}

	private DatabaseEntry getTreePageKey(int relId, int pageNo) {
		ByteBufferWriter bbw = new ByteBufferWriter();
		bbw.addToBuffer(relId);
		bbw.addToBuffer(pageNo);
		bbw.addToBuffer(TREE);
		return new DatabaseEntry(bbw.getByteArray());
	}

	void clear() throws IndexServiceException {
		try {
			indexDb.close();
			e.truncateDatabase(null, indexDbName, false);
			indexDb = e.openDatabase(null, indexDbName, dc);
		} catch (DatabaseException de) {
			throw new IndexServiceException("Error resetting BerkeleyDB database", de);
		}
		indexPagesCache.reset();
		indexPagesAreCache.reset();
	}

	public byte[] getTreePage(int relId, int pageNo) {
		QpMessage m = new GetTreePage(getTreePageId(relId,pageNo),relId,pageNo);
		ReplyHolder<Integer> replies = new ReplyHolder<Integer>(1);
		try {
			app.sendMessageAwaitReply(m, new SimpleReplyContinuation<Integer>(1,replies), SendTreePage.class);
			replies.waitUntilFinished();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		Message reply = replies.getReply(1);
		if (reply instanceof SendTreePage) {
			return ((SendTreePage) reply).data;
		} else {
			throw new RuntimeException("Received unexpected reply to " + m + ": " + reply);
		}
	}

	public Collection<EpochNum> getPagesForRelation(int relId, int epoch) throws InterruptedException, IndexServiceException, IOException {
		return this.getIndexEntry(relId, epoch).indexPages;
	}

	public int getCardinality(int relId, int epoch) throws InterruptedException, IndexServiceException, IOException {
		return getIndexEntry(relId, epoch).numTuples;
	}
}

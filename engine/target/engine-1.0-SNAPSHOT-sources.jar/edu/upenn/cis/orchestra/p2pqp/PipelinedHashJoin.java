package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.AbstractImmutableTuple.FieldSource;
import edu.upenn.cis.orchestra.datamodel.AbstractImmutableTuple.JoinFieldSource;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public class PipelinedHashJoin<M> extends Operator<M> implements JoinOperator {
	private final Logger logger = Logger.getLogger(this.getClass());
	private final int leftSchemaId, rightSchemaId;
	private final QpSchema leftSchema, rightSchema;
	private final int[] retainLeftJoinIndices;
	private final FieldSource[] retainRightJoinIndices;
	private final JoinFieldSource jfss[];
	// Key is always in left schema

	// Lock is tuples
	private boolean leftInputFinished = false, rightInputFinished = false;

	private class JoinData {
		Collection<QpTuple<Null>> leftTuples, rightTuples;
		M leftMetadata, rightMetadata;
		// Let's lazily initialize these variables
	}

	protected final QpTupleMap<JoinData> tuples;
	private boolean canAccessTable = true;
	private int countInTable = 0;
	private int phaseNo = 0;
	private final QpSchema outputSchema;
	protected final boolean retainDuplicates;

	private final int[] leftNeededCols, rightNeededCols;
	private static final Object[] nullField = new Object[] {null};


	public PipelinedHashJoin(QpSchema leftSchema, QpSchema rightSchema, List<Integer> leftJoinIndices,
			List<Integer> rightJoinIndices, List<Integer> leftOutputPos, List<Integer> rightOutputPos, 
			QpSchema outputSchema, Operator<M> dest, WhichChild outputDest, int queryId, InetSocketAddress nodeId, int operatorId,
			RecordTuples rt, MetadataFactory<M> mdf, boolean allowRecovery) {
		this(leftSchema, rightSchema, leftJoinIndices, rightJoinIndices, leftOutputPos, rightOutputPos, true,
				outputSchema, dest, outputDest, queryId, nodeId, operatorId, rt, mdf, allowRecovery);
	}

	public PipelinedHashJoin(QpSchema leftSchema, QpSchema rightSchema, List<Integer> leftJoinIndices,
			List<Integer> rightJoinIndices, List<Integer> leftOutputPos, List<Integer> rightOutputPos, boolean retainDuplicates,
			QpSchema outputSchema, Operator<M> dest, WhichChild outputDest, int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt, MetadataFactory<M> mdf, boolean allowRecovery) {
		super(dest,outputDest,queryId, nodeId, operatorId, mdf, rt, allowRecovery);
		this.leftSchemaId = leftSchema.relId;
		this.rightSchemaId = rightSchema.relId;
		this.leftSchema = leftSchema;
		this.rightSchema = rightSchema;

		final int numJoinVars = leftJoinIndices.size();
		if (rightJoinIndices.size() != numJoinVars) {
			throw new IllegalArgumentException("Must have same number of left and right join variables");
		}

		retainLeftJoinIndices = new int[numJoinVars];
		retainRightJoinIndices = new FieldSource[leftSchema.getNumCols()];
		FieldSource nullField = new FieldSource(0, false);
		for (int i = 0; i < numJoinVars; ++i) {
			retainLeftJoinIndices[i] = leftJoinIndices.get(i);
			retainRightJoinIndices[leftJoinIndices.get(i)] = new FieldSource(rightJoinIndices.get(i), true);
		}
		for (int i = 0; i < retainRightJoinIndices.length; ++i) {
			if (retainRightJoinIndices[i] == null) {
				retainRightJoinIndices[i] = nullField;
			}
		}
		Arrays.sort(retainLeftJoinIndices);



		final int numOutputCols = outputSchema.getNumCols();
		Set<Integer> remainingOutputPos = new HashSet<Integer>(numOutputCols);
		for (int i = 0; i < numOutputCols; ++i) {
			remainingOutputPos.add(i);
		}

		jfss = new JoinFieldSource[numOutputCols];
		Set<Integer> leftNeededCols = new HashSet<Integer>();
		Set<Integer> rightNeededCols = new HashSet<Integer>();

		// leftOutPos[pos] = i => column i in output comes from pos in left input
		int pos = 0;
		for (Integer i : leftOutputPos) {
			if (i == null || i == -1) {
			} else if (i >= 0) {
				if (remainingOutputPos.remove(i)) {
					jfss[i] = new JoinFieldSource(pos, true);
					leftNeededCols.add(pos);
				} else {
					throw new IllegalArgumentException("Output position " + i + " is specified more than once");
				}
			} else {
				throw new IllegalArgumentException("Output position must be >= -1 or null");
			}
			++pos;
		}

		pos = 0;
		for (Integer i : rightOutputPos) {
			if (i == null || i == -1) {
			} else if (i >= 0) {
				if (remainingOutputPos.remove(i)) {
					jfss[i] = new JoinFieldSource(pos, false);
					rightNeededCols.add(pos);
				} else {
					throw new IllegalArgumentException("Output position " + i + " is specified more than once in operator " + operatorId);
				}
			} else {
				throw new IllegalArgumentException("Output position must be >= -1 or null in operator " + operatorId);
			}
			++pos;
		}

		if (! remainingOutputPos.isEmpty()) {
			throw new IllegalArgumentException("Output positions " + remainingOutputPos + " are not specified in operator " + operatorId);
		}

		this.retainDuplicates = retainDuplicates;

		QpTupleMap.ValueFactory<JoinData> vf = new QpTupleMap.ValueFactory<JoinData>() {

			public JoinData getNewValue() {
				return new JoinData();
			}

		};

		tuples = new QpTupleMap<JoinData>(retainLeftJoinIndices, vf, false);

		this.outputSchema = outputSchema;

		for (int col : leftJoinIndices) {
			leftNeededCols.add(col);
		}

		for (int col : rightJoinIndices) {
			rightNeededCols.add(col);
		}

		if (leftNeededCols.size() == leftOutputPos.size()) {
			this.leftNeededCols = null;
		} else {
			this.leftNeededCols = new int[leftNeededCols.size()];
			pos = 0;
			for (int col : leftNeededCols) {
				this.leftNeededCols[pos++] = col;
			}
			Arrays.sort(this.leftNeededCols);
		}

		if (rightNeededCols.size() == rightOutputPos.size()) {
			this.rightNeededCols = null;
		} else {
			this.rightNeededCols = new int[rightNeededCols.size()];
			pos = 0;
			for (int col : rightNeededCols) {
				this.rightNeededCols[pos++] = col;
			}
			Arrays.sort(this.rightNeededCols);
		}
	}


	protected void receiveTuples(List<QpTuple<M>> tuples) {
		final int blockSize = QueryExecution.blockSize;
		List<QpTuple<M>> tuplesProduced = new ArrayList<QpTuple<M>>(blockSize);
		List<ExecutionId> tuplesAdded = new ArrayList<ExecutionId>(blockSize);
		List<ExecutionId> tuplesRemoved = new ArrayList<ExecutionId>(blockSize);

		ListIterator<QpTuple<M>> it = tuples.listIterator();

		try {
			while (it.hasNext()) {
				TUPLE: while ((tuplesProduced.size() < blockSize) && it.hasNext()) {
					QpTuple<M> t = it.next();
					it.set(null);
					tuplesRemoved.add(t.getId());
					final QpTuple<Null> key;
					final boolean left;
					final int[] neededCols;

					if (t.isLeft() && t.getSchema().relId == leftSchemaId) {
						key = getKeyFromLeft(t);
						neededCols = leftNeededCols;
						left = true;
					} else if (t.isRight() && t.getSchema().relId == rightSchemaId) {
						key = getKeyFromRight(t);
						neededCols = rightNeededCols;
						left = false;
					} else {
						throw new RuntimeException("Received unexpected " + (t.getDest() == null ? "unlabeled" : t.getDest().toString()) + " tuple " + t + " in join operator");
					}

					final JoinData jd;
					final boolean otherInputFinished;
					final int phaseNo;
					synchronized (tuples) {
						try {
							while (! canAccessTable) {
								tuples.wait();
							}
						} catch (InterruptedException ie) {
							return;
						}
						if (left && leftInputFinished) {
							Exception e = new RuntimeException("Left input has finished but received left tuple " + t);
							logger.error(e);
							this.reportException(e);
							return;
						} else if ((! left) && rightInputFinished) {
							Exception e = new RuntimeException("Right input has finished but received right tuple " + t);
							logger.error(e);
							this.reportException(e);
							return;
						}

						if (failedNodeIds != null) {
							final ExecutionId id = t.getId();
							for (byte[] nodeId : failedNodeIds) {
								if (id.containsNodeId(nodeId)) {
									continue TUPLE;
								}
							}
						}

						otherInputFinished = (retainDuplicates && ((left && rightInputFinished) || (((! left) && leftInputFinished))));

						if (otherInputFinished) {
							jd = this.tuples.getIfExists(key);
							if (jd == null) {
								continue;
							}
						} else {
							jd = this.tuples.getOrCreate(key);
						}
						++countInTable;
						phaseNo = this.phaseNo;
					}

					try {
						synchronized (jd) {
							// Update table for input relation
							Collection<QpTuple<Null>> tuplesForSubtuple;
							if (otherInputFinished) {
								tuplesForSubtuple = null;
							} else if (left) {
								tuplesForSubtuple = jd.leftTuples;
								if (tuplesForSubtuple == null) {
									tuplesForSubtuple = retainDuplicates ? new ArrayList<QpTuple<Null>>() : new HashSet<QpTuple<Null>>();
									jd.leftTuples = tuplesForSubtuple;
								}
							} else {
								tuplesForSubtuple = jd.rightTuples;
								if (tuplesForSubtuple == null) {
									tuplesForSubtuple = retainDuplicates ? new ArrayList<QpTuple<Null>>() : new HashSet<QpTuple<Null>>();
									jd.rightTuples = tuplesForSubtuple;
								}
							}

							// TODO: put generic metadata handling back

							if (tuplesForSubtuple != null) {
								// Update store copy
								QpTuple<Null> storeCopy;

								if (neededCols == null) {
									storeCopy = t.changeMetadata(((Null) null));
								} else {
									storeCopy = new QpTuple<Null>(t,neededCols,t.getEpoch(),t.getId(),null);
								}

								// Always probe if adding new tuple and we support duplicates
								if (! tuplesForSubtuple.add(storeCopy)) {
									continue;
								}
							}


							// Probe table for other relation
							tuplesForSubtuple = left ? jd.rightTuples : jd.leftTuples;
							if (tuplesForSubtuple == null || tuplesForSubtuple.isEmpty()) {
								continue;
							}

							final int tEpoch = t.getEpoch();
							
							for (QpTuple<Null> joinTuple : tuplesForSubtuple) {
								final int joinTupleEpoch = joinTuple.getEpoch();
								final int epoch = joinTupleEpoch > tEpoch ? joinTupleEpoch : tEpoch;

								M metadata = null;

								QpTuple<M> newTuple;
								if (left) {
									newTuple = new QpTuple<M>(outputSchema, this.jfss, t, joinTuple, epoch, getFreshId(t.getId(), joinTuple.getId(), phaseNo), metadata);
								} else {
									newTuple = new QpTuple<M>(outputSchema, this.jfss, joinTuple, t, epoch, getFreshId(t.getId(), joinTuple.getId(), phaseNo), metadata);
								}
								tuplesAdded.add(newTuple.getId());
								tuplesProduced.add(newTuple);

							}
						}
					} finally {
						synchronized (tuples) {
							--countInTable;
							if (countInTable == 0) {
								tuples.notify();
							}
						}
					}
				}
			if (! tuplesProduced.isEmpty()) {
				sendTuples(tuplesProduced);
			}
			if (! tuplesAdded.isEmpty()) {
				tuplesAdded(tuplesAdded);
			}
			tuplesRemoved(tuplesRemoved);
			tuplesProduced.clear();
			tuplesAdded.clear();
			tuplesRemoved.clear();
			}
		} catch (ValueMismatchException vm) {
			throw new RuntimeException("Error creating tuple in operator " + this.operatorId, vm);
		}
	}

	protected void clearState() {
		tuples.clear();
	}
	protected void close() {
		synchronized (tuples) {
			tuples.clear();
		}
	}

	protected QpTuple<Null> getKeyFromLeft(QpTuple<?> left) {
		if (left.getSchema().relId != leftSchemaId) {
			throw new IllegalArgumentException("Left tuples should be from schema " + leftSchema.getRelationName());
		}
		return new QpTuple<Null>(left, retainLeftJoinIndices, 0, null, null);
	}

	protected QpTuple<Null> getKeyFromRight(QpTuple<?> right) {
		if (right.getSchema().relId != rightSchemaId) {
			throw new IllegalArgumentException("Right tuples should be from schema " + rightSchema.getRelationName());
		}
		try {
			return new QpTuple<Null>(leftSchema, retainRightJoinIndices, right, 0, null, null, nullField);
		} catch (ValueMismatchException e) {
			throw new IllegalStateException("Error in PipelinedHashJoin " + operatorId, e);
		}
	}

	protected boolean hasLeftTuple(QpTuple<M> leftTuple) {
		QpTuple<?> key = getKeyFromLeft(leftTuple);
		JoinData jd = tuples.getOrCreate(key);
		synchronized (jd) {
			return jd.leftTuples != null && jd.leftTuples.contains(leftTuple);
		}
	}

	public void inputHasFinished(boolean left) {
		if (! retainDuplicates) {
			return;
		}
		if (left && leftInputFinished) {
			return;
		}
		if ((! left) && rightInputFinished) {
			return;
		}
		synchronized (tuples) {
			if (left) {
				leftInputFinished = true;
			} else {
				rightInputFinished = true;
			}
		}
		logger.info((left ? "Left" : "Right") + " input to operator " + operatorId + " has finished");
	}

	private boolean hasPurgedPartial = false, hasPurgedFull = false;

	public boolean doPurge(boolean tryHard, boolean allowDestructive) {
		synchronized (tuples) {
			if (leftInputFinished && rightInputFinished && allowDestructive && (! hasPurgedFull)) {
				tuples.clear();
				hasPurgedFull = true;
				return true;
			} else if (! tryHard) {
				return false;
			} else if (hasPurgedPartial) {
				return false;
			}
			if (leftInputFinished && rightInputFinished) {
				Iterator<QpTupleMap<JoinData>.Entry> it = tuples.iterator();
				while (it.hasNext()) {
					QpTupleMap<JoinData>.Entry entry = it.next();
					if (entry.value.leftTuples == null || entry.value.leftTuples.isEmpty() ||
							entry.value.rightTuples == null || entry.value.rightTuples.isEmpty()) {
						// Won't produce any join tuples so don't need to save
						it.remove();
					}
				}
				hasPurgedPartial = true;
				return true;
			} else if (leftInputFinished && (! rightInputFinished)) {
				Iterator<QpTupleMap<JoinData>.Entry> it = tuples.iterator();
				while (it.hasNext()) {
					QpTupleMap<JoinData>.Entry entry = it.next();
					if (entry.value.leftTuples == null || entry.value.leftTuples.isEmpty()) {
						// Doesn't have any left tuples so don't need to save
						it.remove();
					} else if (! enableRecovery) {
						entry.value.rightTuples = null;
						entry.value.rightMetadata = null;
					}
				}
				hasPurgedPartial = true;
				return true;
			} else if (rightInputFinished && (! leftInputFinished)) {
				Iterator<QpTupleMap<JoinData>.Entry> it = tuples.iterator();
				while (it.hasNext()) {
					QpTupleMap<JoinData>.Entry entry = it.next();
					if (entry.value.rightTuples == null || entry.value.rightTuples.isEmpty()) {
						// Doesn't have any right tuples so don't need to save
						it.remove();
					} else if (! enableRecovery) {
						entry.value.leftTuples = null;
						entry.value.leftMetadata = null;
					}
				}
				hasPurgedPartial = true;
				return true;
			}
		}
		return false;
	}

	public boolean willBeAbleToPurgeAgain() {
		synchronized (tuples) {
			return (! hasPurgedFull);
		}
	}

	public int getOperatorId() {
		return operatorId;
	}

	private byte[][] failedNodeIds;

	protected void disposeOfFailedTuples(int newPhaseNo, byte[][] failedNodeIds) {
		synchronized (tuples) {
			this.phaseNo = newPhaseNo;
			for (QpTupleMap<JoinData>.Entry e : tuples) {
				JoinData jd = e.value;
				if (jd.leftTuples != null) {
					Iterator<QpTuple<Null>> it = jd.leftTuples.iterator();
					TUPLE: while (it.hasNext()) {
						final ExecutionId id = it.next().getId();
						for (byte[] nodeId : failedNodeIds) {
							if (id.containsNodeId(nodeId)) {
								it.remove();
								continue TUPLE;
							}
						}
					}
				}
				if (jd.rightTuples != null) {
					Iterator<QpTuple<Null>> it = jd.rightTuples.iterator();
					TUPLE: while (it.hasNext()) {
						final ExecutionId id = it.next().getId();
						for (byte[] nodeId : failedNodeIds) {
							if (id.containsNodeId(nodeId)) {
								it.remove();
								continue TUPLE;
							}
						}
					}
				}
			}
			if (this.failedNodeIds == null) {
				this.failedNodeIds = failedNodeIds;
			} else {
				byte[][] newFailedNodeIds = new byte[this.failedNodeIds.length + failedNodeIds.length][];
				System.arraycopy(this.failedNodeIds, 0, newFailedNodeIds, 0, this.failedNodeIds.length);
				System.arraycopy(failedNodeIds, 0, newFailedNodeIds, this.failedNodeIds.length, failedNodeIds.length);
			}
		}
	}

	public void resendGeneratedTuples(int phaseNo) {
		List<QpTuple<M>> tuplesProduced = new ArrayList<QpTuple<M>>();
		List<ExecutionId> tuplesAdded = new ArrayList<ExecutionId>();
		try {
			synchronized (tuples) {
				try {
					if (! canAccessTable) {
						throw new IllegalStateException();
					}
					canAccessTable = false;
					try {
						while (countInTable > 0) {
							tuples.wait();
						}
					} catch (InterruptedException ie) {
						return;
					}
					for (QpTupleMap<JoinData>.Entry e : tuples) {
						JoinData jd = e.value;
						if (jd.leftTuples == null || jd.leftTuples.isEmpty()) {
							continue;
						}
						if (jd.rightTuples == null || jd.rightTuples.isEmpty()) {
							continue;
						}
						for (QpTuple<Null> left : jd.leftTuples) {
							if (left.getId().phaseNo >= phaseNo) {
								continue;
							}
							for (QpTuple<Null> right : jd.rightTuples) {
								QpTuple<M> newTuple = new QpTuple<M>(outputSchema, this.jfss, left, right, left.getEpoch() > right.getEpoch() ? left.getEpoch() : right.getEpoch(),
										getFreshId(left.getId(), right.getId(), phaseNo), null);
								tuplesAdded.add(newTuple.getId());
								tuplesProduced.add(newTuple);
							}
						}
					}
				} finally {
					canAccessTable = true;
					tuples.notifyAll();
				}
			}
		} catch (ValueMismatchException vme) {
			logger.error("Error creating recovery tuple", vme);
			reportException(vme);
		}
		logger.info("Regenerating operator " + operatorId + " during phase " + phaseNo + " generated " + tuplesProduced.size() + " tuples");
		if (! tuplesProduced.isEmpty()) {
			sendTuples(tuplesProduced);
		}
		if (! tuplesAdded.isEmpty()) {
			tuplesAdded(tuplesAdded);
		}
	}


	public void resendGeneratedTuples(int phaseNo, int[] outputSchemaIdCols,
			IdRange[] neededRanges) {
		byte[] idBytes = new byte[outputSchemaIdCols.length * IntType.bytesPerInt];
		int[] idColsInLeftJoinIndices = new int[outputSchemaIdCols.length];
		int[] idColsInLeftTuple = new int[outputSchemaIdCols.length];
		int[] idColsInRightTuple = new int[outputSchemaIdCols.length];
		for (int pos = 0; pos < outputSchemaIdCols.length; ++pos) {
			int col = outputSchemaIdCols[pos];
			JoinFieldSource jfs = jfss[col];
			if (jfs.fromFirstTuple) {
				if (idColsInLeftTuple != null) {
					idColsInLeftTuple[pos] = jfs.pos;
				}
				idColsInRightTuple = null;
			} else {
				if (idColsInRightTuple != null) {
					idColsInRightTuple[pos] = jfs.pos;
				}
				idColsInLeftTuple = null;
				idColsInLeftJoinIndices = null;
			}
			if (idColsInLeftJoinIndices != null) {
				boolean foundJoinPos = false;
				for (int joinIndex : retainLeftJoinIndices) {
					if (joinIndex == jfs.pos) {
						idColsInLeftJoinIndices[pos] = jfs.pos;
						foundJoinPos = true;
					}
				}
				if ( ! foundJoinPos) {
					idColsInLeftJoinIndices = null;
				}
			}
			if (idColsInLeftJoinIndices == null && idColsInLeftTuple == null && idColsInRightTuple == null) {
				break;
			}
		}
		List<QpTuple<M>> tuplesProduced = new ArrayList<QpTuple<M>>();
		List<ExecutionId> tuplesAdded = new ArrayList<ExecutionId>();
		try {
			synchronized (tuples) {
				try {
					if (! canAccessTable) {
						throw new IllegalStateException();
					}
					canAccessTable = false;
					try {
						while (countInTable > 0) {
							tuples.wait();
						}
					} catch (InterruptedException ie) {
						return;
					}
					if (idColsInLeftJoinIndices != null) {
						for (QpTupleMap<JoinData>.Entry e : tuples) {
							JoinData jd = e.value;
							if (jd.leftTuples == null || jd.leftTuples.isEmpty()) {
								continue;
							}
							if (jd.rightTuples == null || jd.rightTuples.isEmpty()) {
								continue;
							}
							Id qpId = e.key.getQPid(idColsInLeftJoinIndices, idBytes);
							boolean needed = false;
							for (IdRange range : neededRanges) {
								if (range.contains(qpId)) {
									needed = true;
									break;
								}
							}
							if (! needed) {
								continue;
							}
							for (QpTuple<Null> left : jd.leftTuples) {
								if (left.getId().phaseNo >= phaseNo) {
									continue;
								}
								for (QpTuple<Null> right : jd.rightTuples) {
									if (right.getId().phaseNo >= phaseNo) {
										continue;
									}
									QpTuple<M> newTuple = new QpTuple<M>(outputSchema, this.jfss, left, right, left.getEpoch() > right.getEpoch() ? left.getEpoch() : right.getEpoch(),
											getFreshId(left.getId(), right.getId(), phaseNo), null);
									tuplesAdded.add(newTuple.getId());
									tuplesProduced.add(newTuple);
								}
							}
						}
					} else if (idColsInLeftTuple != null) {
						for (QpTupleMap<JoinData>.Entry e : tuples) {
							JoinData jd = e.value;
							if (jd.leftTuples == null || jd.leftTuples.isEmpty()) {
								continue;
							}
							if (jd.rightTuples == null || jd.rightTuples.isEmpty()) {
								continue;
							}
							for (QpTuple<Null> left : jd.leftTuples) {
								if (left.getId().phaseNo >= phaseNo) {
									continue;
								}
								Id qpId = left.getQPid(idColsInLeftTuple, idBytes);
								boolean needed = false;
								for (IdRange range : neededRanges) {
									if (range.contains(qpId)) {
										needed = true;
										break;
									}
								}
								if (! needed) {
									continue;
								}
								for (QpTuple<Null> right : jd.rightTuples) {
									if (right.getId().phaseNo >= phaseNo) {
										continue;
									}
									QpTuple<M> newTuple = new QpTuple<M>(outputSchema, this.jfss, left, right, left.getEpoch() > right.getEpoch() ? left.getEpoch() : right.getEpoch(),
											getFreshId(left.getId(), right.getId(), phaseNo), null);
									tuplesAdded.add(newTuple.getId());
									tuplesProduced.add(newTuple);
								}
							}
						}
					} else if (idColsInRightTuple != null) {
						for (QpTupleMap<JoinData>.Entry e : tuples) {
							JoinData jd = e.value;
							if (jd.leftTuples == null || jd.leftTuples.isEmpty()) {
								continue;
							}
							if (jd.rightTuples == null || jd.rightTuples.isEmpty()) {
								continue;
							}
							for (QpTuple<Null> right : jd.rightTuples) {
								if (right.getId().phaseNo >= phaseNo) {
									continue;
								}
								Id qpId = right.getQPid(idColsInRightTuple, idBytes);
								boolean needed = false;
								for (IdRange range : neededRanges) {
									if (range.contains(qpId)) {
										needed = true;
										break;
									}
								}
								if (! needed) {
									continue;
								}
								for (QpTuple<Null> left : jd.leftTuples) {
									if (left.getId().phaseNo >= phaseNo) {
										continue;
									}
									QpTuple<M> newTuple = new QpTuple<M>(outputSchema, this.jfss, left, right, left.getEpoch() > right.getEpoch() ? left.getEpoch() : right.getEpoch(),
											getFreshId(left.getId(), right.getId(), phaseNo), null);
									tuplesAdded.add(newTuple.getId());
									tuplesProduced.add(newTuple);
								}
							}
						}
					} else {
						for (QpTupleMap<JoinData>.Entry e : tuples) {
							JoinData jd = e.value;
							if (jd.leftTuples == null || jd.leftTuples.isEmpty()) {
								continue;
							}
							if (jd.rightTuples == null || jd.rightTuples.isEmpty()) {
								continue;
							}
							for (QpTuple<Null> left : jd.leftTuples) {
								if (left.getId().phaseNo >= phaseNo) {
									continue;
								}
								for (QpTuple<Null> right : jd.rightTuples) {
									if (right.getId().phaseNo >= phaseNo) {
										continue;
									}
									for (int i = 0; i < outputSchemaIdCols.length; ++i) {
										JoinFieldSource jfs = jfss[outputSchemaIdCols[i]];
										int hashCode = (jfs.fromFirstTuple ? left : right).getColHashCode(jfs.pos);
										IntType.putBytes(hashCode, idBytes, i * IntType.bytesPerInt);
									}
									Id qpId = Id.fromContent(idBytes);
									boolean needed = false;
									for (IdRange range : neededRanges) {
										if (range.contains(qpId)) {
											needed = true;
											break;
										}
									}
									if (! needed) {
										continue;
									}
									QpTuple<M> newTuple = new QpTuple<M>(outputSchema, this.jfss, left, right, left.getEpoch() > right.getEpoch() ? left.getEpoch() : right.getEpoch(),
											getFreshId(left.getId(), right.getId(), phaseNo), null);
									tuplesAdded.add(newTuple.getId());
									tuplesProduced.add(newTuple);
								}
							}
						}

					}
				} finally {
					canAccessTable = true;
					tuples.notifyAll();
				}
			}
			logger.info("Regenerating operator " + operatorId + " during phase " + phaseNo + " generated " + tuplesProduced.size() + " tuples");
			
			if (! tuplesProduced.isEmpty()) {
				sendTuples(tuplesProduced);
			}
			if (! tuplesAdded.isEmpty()) {
				tuplesAdded(tuplesAdded);
			}
		} catch (ValueMismatchException vme) {
			logger.error("Error creating recovery tuple", vme);
			reportException(vme);
		}
	}

	public void inputsHaveNotFinished() {
		// TODO: implement		
	}

}

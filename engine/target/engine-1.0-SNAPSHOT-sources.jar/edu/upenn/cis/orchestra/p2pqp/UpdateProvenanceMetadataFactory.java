package edu.upenn.cis.orchestra.p2pqp;

import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.p2pqp.QpSchema.Source;
import edu.upenn.cis.orchestra.p2pqp.UpdateProvenance.UpdateType;

public class UpdateProvenanceMetadataFactory implements MetadataFactory<UpdateProvenance> {
	
    private static final UpdateProvenanceMetadataFactory instance;
	
	static {
		instance = new UpdateProvenanceMetadataFactory();
	}
	
	public static UpdateProvenanceMetadataFactory getInstance() {
		return instance;
	}
	
	/**
	 * Derive an IDB provenance token from the child tuple's provenance
	 */
	public UpdateProvenance derive(Operator<UpdateProvenance> o, UpdateProvenance metadata) {
		if (metadata == null) {
			throw new RuntimeException("The metadata is NULL");
		}
		TupleProvenance tuplePv = metadata.tuplePv.derive(o.operatorId);
		TupleProvenance replacePv = null;
		if (metadata.replacePv != null) {
			replacePv = metadata.replacePv.derive(o.operatorId);
		}
		UpdateProvenance newUpdateProvenance = new UpdateProvenance(tuplePv, metadata.updateType, replacePv);
		return newUpdateProvenance;
	}
	
	
	/**
	 * Derive an IDB provenance token from two provenance expressions that may
	 * both represent multiple derivations in a hash table
	 */
	public UpdateProvenance join(Operator<UpdateProvenance> o, UpdateProvenance leftMetadata, UpdateProvenance joinedMetadata) {
		
		if (joinedMetadata.updateType != UpdateType.INS) {
			throw new RuntimeException("Joined metdata should be of INSERT type!");
		}
		if (joinedMetadata.tuplePv == null || joinedMetadata.tuplePv.isZero()) {
			throw new RuntimeException("joinedMetadata cannot be zero!");
		}
		if (leftMetadata.tuplePv == null || leftMetadata.tuplePv.isZero()) {
			throw new RuntimeException("leftMetadata cannot be zero!");
		}
		
		TupleProvenance retTuplePv = leftMetadata.tuplePv.joinWith(joinedMetadata.tuplePv).derive(o.operatorId);
		
		UpdateProvenance returnPv = null;
		/*if (leftMetadata.updateType == UpdateType.REPLACE) {
			returnPv = new UpdateProvenance(retTuplePv, UpdateType.REPLACE, leftMetadata.replacePv.joinWith(joinedMetadata.tuplePv));	
		} else */
		if (leftMetadata.updateType == UpdateType.INS){
			returnPv = new UpdateProvenance(retTuplePv, UpdateType.INS, null);
		} else if (leftMetadata.updateType == UpdateType.DEL) {
			returnPv = new UpdateProvenance(retTuplePv, UpdateType.DEL, null);
		}
		if (returnPv.updateType == UpdateType.REPLACE && returnPv.replacePv == null) {
			new RuntimeException("Wrong returnPv!");
		}
		
		if (retTuplePv.isZero()) {
			return null;
		}
		return returnPv;
	}
	
	public UpdateProvenance agg(Operator<UpdateProvenance> o, Collection<UpdateProvenance> inputs) {
		//TODO: consider deletions and zeros	
		ArrayList<UpdateProvenance> inputUpdateProvenance = new ArrayList<UpdateProvenance>(inputs);
		Iterator<UpdateProvenance> it = inputUpdateProvenance.iterator();
		
		UpdateProvenance up = it.next();
		TupleProvenance tuplePv = up.tuplePv;
		
		while (it.hasNext()) {
			up = it.next();
			tuplePv = tuplePv.joinWith(up.tuplePv);
		}
	
		UpdateProvenance newUpdateProvenance = new UpdateProvenance(tuplePv, UpdateType.INS, null);
		return newUpdateProvenance;
	}
	
	public UpdateProvenance scan(Operator<UpdateProvenance> o, UpdateProvenance inStorage) {
		return inStorage;
	}
	
	public UpdateProvenance applyFunctions(Operator<UpdateProvenance> o, UpdateProvenance m) {
		return m;
	}
	/*
	public long funcEval(Statistics.Func conFunc, Statistics.Func aggFunc, UpdateProvenance m) {
		//TODO: consider deletions and zeros
		TupleProvenance tuplePv = m.tuplePv;
		return tuplePv.applyFunctions(conFunc, aggFunc);
	}*/
	
	public String printMetadata(UpdateProvenance m) {
		//TODO:
		return m.tuplePv.toString();
	}
	
	public byte[] toBytes(UpdateProvenance m) {
		
		ByteBufferWriter bbw = new ByteBufferWriter();
		
		// Add tupleProvenance
		bbw.addToBuffer(m.tuplePv.getBytes());
		
		// Add updateByte
        Byte updateByte;
		
		if (m.updateType == UpdateType.REPLACE) updateByte = 2;
		else if (m.updateType == UpdateType.DEL) updateByte = 1;
		else updateByte = 0;
		
		bbw.addToBuffer(updateByte);
		
		//Add replaceProvenance
		
		if (updateByte < 2 || m.replacePv == null) {
			bbw.addToBuffer((byte []) null);
		} else {
			bbw.addToBuffer(m.replacePv.getBytes());
		}
		
		return bbw.getByteArray();
		
	}
	public UpdateProvenance fromBytes(Source findSchema, IdFactory idf, MetadataFactory<UpdateProvenance> mdf, byte[] bytes, ExecutionId tupleId) {
		
		ByteBufferReader bbr = new ByteBufferReader(null, bytes);
		
		//Read tupleProvenance
		byte[] provenanceByte = bbr.readByteArray();
		TupleProvenance tuplePv = ProvenanceFactory.fromBytes(provenanceByte);
		
		//Read updateByte
		byte updateByte = bbr.readByte();
		
		UpdateType updateType;
		
		switch (updateByte) {
		case 0 : updateType = UpdateType.INS; break;
		case 1 : updateType = UpdateType.DEL; break;
		case 2 : updateType = UpdateType.REPLACE; break;
		default: updateType = UpdateType.INS; break;
		}

		//Read replaceProvenance
		TupleProvenance replacePv = null;
		if (updateByte == 2) {
			byte[] replaceByte = bbr.readByteArray();
			replacePv = ProvenanceFactory.fromBytes(replaceByte);
		}
		
		UpdateProvenance updateProvenance = new UpdateProvenance(tuplePv, updateType, replacePv);
		return updateProvenance;
		
	}

	/**
	 * Combine origMetadata and addedMetadata
	 */
	public UpdateProvenance combineMetadata(
			UpdateProvenance origMetadata, UpdateProvenance addedMetadata) {
		TupleProvenance tuplePv;
		UpdateProvenance updateProvenance = null; 
		
		if (addedMetadata.tuplePv == null) {
			new RuntimeException("addedMetadata is NULL");
		}
		if (origMetadata.tuplePv == null) {
			new RuntimeException("tuplePv is NULL");
		}
		if (addedMetadata.tuplePv.isZero()) {
			return origMetadata;
		}
		// if origMetadata is of deletion type
		if (origMetadata.updateType == UpdateType.DEL) {
			if (addedMetadata.updateType == UpdateType.INS) {
				throw new RuntimeException("addedMetadata is of INS type but origMetadata is of DEL type");
			} else if (addedMetadata.updateType == UpdateType.DEL) {
				tuplePv = origMetadata.tuplePv.unionWith(addedMetadata.tuplePv);
				updateProvenance = new UpdateProvenance(tuplePv, UpdateType.DEL, null);  
			} else {
				throw new RuntimeException("addedMetadata is of REPLACE type");
			}
		} else if (origMetadata.updateType == UpdateType.REPLACE) {
			// if origMetadata is of replace type
			throw new RuntimeException("origMetadata is of REPLACE type");
		} else if (origMetadata.updateType == UpdateType.INS) {
			// if origMetadata is of insert type
			if (addedMetadata.updateType == UpdateType.INS) {
				// MOST EXPENSIVE OPERATION
				tuplePv = origMetadata.tuplePv.unionWith(addedMetadata.tuplePv);
				updateProvenance = new UpdateProvenance(tuplePv, UpdateType.INS, null);   
			} else if (addedMetadata.updateType == UpdateType.DEL) {
				tuplePv = origMetadata.tuplePv.differenceWith(addedMetadata.tuplePv);
				updateProvenance = new UpdateProvenance(tuplePv, UpdateType.INS, null);
			} else { 
				throw new RuntimeException("addedMetadata is of REPLACE type");
			}
		} else return null;
		
		if (updateProvenance.tuplePv.isZero()) {
			updateProvenance.updateType = UpdateType.INS;
		}
		
		return updateProvenance;
	}
	
	/**
	 * Just compute the difference between newMetadata and oldMetadata
	 * 
	 * 
	 */
	// newMetadata and oldMetadata should be of non-null INSERT type and newMetadata should contain oldMetadata
	public synchronized UpdateProvenance differenceMetadata(UpdateProvenance newMetadata, UpdateProvenance oldMetadata) {
		TupleProvenance tuplePv;
		tuplePv = newMetadata.tuplePv.differenceWith(oldMetadata.tuplePv);
		UpdateProvenance updateProvenance = new UpdateProvenance(tuplePv, UpdateType.INS, null);
		return updateProvenance;
	}
	
	public boolean shouldDelete(UpdateProvenance m) {
		if (m.tuplePv.isZero()) {
			return true;
		}
		return false;
	}
	
	public boolean notInsert(UpdateProvenance m) {
		if (m == null || m.updateType != UpdateType.INS) {
			return true;
		}
		return false;
	}
	
	public void reverse(UpdateProvenance m) {
		if (m.updateType == UpdateType.INS) {
			m.updateType = UpdateType.DEL;
		} else {
			m.updateType = UpdateType.INS;
		}
	}
	
	public UpdateProvenance duplicate(UpdateProvenance m) {
		return new UpdateProvenance(m.tuplePv, m.updateType, m.replacePv);
	}
	
}
package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.SpoolOperator;
import edu.upenn.cis.orchestra.p2pqp.Operator.OperatorCreationException;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class SpoolNode extends OneInputQueryPlan {
	private static final long serialVersionUID = 1L;

	public SpoolNode(QpSchema inputSchema, int operatorId, QueryPlan input) {
		super(inputSchema.getRelationName(), null, CentralizedLoc.getInstance(), operatorId, input);
	}

	protected boolean subclassEquals(OneInputQueryPlan qp) {
		return (qp instanceof SpoolNode);
	}

	<M> Operator<M> createOperator(QueryExecution<M> exec, Operator<M> parent,
			WhichChild dest, boolean allowRecovery) throws OperatorCreationException {
		return new SpoolOperator<M>(exec.getTupleDest(), operatorId, exec.getRecordTuples(), exec.app.getMetadataFactory());
	}

	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc,el,schemas);
	}
	
	public static SpoolNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan input = getInputQueryPlan(el, schemas, alreadyIds);
		return new SpoolNode(schemas.get(input.outputSchema), qpd.operatorId, input);
	}

}

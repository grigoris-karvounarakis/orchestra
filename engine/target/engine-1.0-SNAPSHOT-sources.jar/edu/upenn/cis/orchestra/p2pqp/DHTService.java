package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.util.BitSet;

import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.RelationField;
import edu.upenn.cis.orchestra.p2pqp.IndexService.IndexServiceException;
import edu.upenn.cis.orchestra.p2pqp.TupleStore.ConstraintViolation;
import edu.upenn.cis.orchestra.p2pqp.messages.ConstraintViolationMsg;
import edu.upenn.cis.orchestra.p2pqp.messages.DHTMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.InsertTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.RemoveTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyException;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyFailure;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplySuccess;
import edu.upenn.cis.orchestra.p2pqp.messages.RetrieveTupleMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.TupleFailsFilter;
import edu.upenn.cis.orchestra.p2pqp.messages.TupleIsMessage;

public class DHTService<M> {
	public static final int NUM_DHT_THREADS = 2;

	public static class DHTException extends Exception {
		private static final long serialVersionUID = 1L;

		DHTException(String what) {
			super(what);
		}

		DHTException(String what, Exception why) {
			super(what,why);
		}
	}

	private class TupleBytesComparator implements Comparator<byte[]> {
		private final QpSchema schema;
		private final int numInts;
		private final boolean allInts;
		private final int bitSetSize;

		// TODO: be do the same thing for keys of other types as well?
		TupleBytesComparator(int relId) {
			schema = app.store.getSchema(relId);
			boolean allInts = true;
			List<RelationField> pk = schema.getPrimaryKey().getFields();
			for (RelationField rf : pk) {
				if (! (rf.getType() instanceof IntType)) {
					allInts = false;
					break;
				}
			}
			this.allInts = allInts;
			numInts = pk.size();
			bitSetSize = BitSet.numBytes(numInts);
		}

		public int compare(byte[] arg0, byte[] arg1) {
			if (allInts) {
				// After epoch and two bit sets
				int pos = IntType.bytesPerInt + 2 * bitSetSize; 
				for (int i = 0; i < numInts; ++i) {
					if (getLabeledNull(i,arg0)) {
						if (getLabeledNull(i,arg1)) {
							int val0 = IntType.getValFromBytes(arg0, pos, IntType.bytesPerInt);
							int val1 = IntType.getValFromBytes(arg1, pos, IntType.bytesPerInt);
							if (val0 != val1) {
								return val0 - val1;
							}
							pos += IntType.bytesPerInt;
						} else {
							return -1;
						}
					} else if (getNull(i,arg0)) {
						// arg0 is null for this column
						if (getLabeledNull(i,arg1)) {
							return 1;
						} else if (! getNull(i,arg1)) {
							return -1;
						}
					} else {
						// arg0 is non-null for this column
						if (getLabeledNull(i,arg1) || (getNull(i,arg1))) {
							return 1;
						} else {
							int val0 = IntType.getValFromBytes(arg0, pos, IntType.bytesPerInt);
							int val1 = IntType.getValFromBytes(arg1, pos, IntType.bytesPerInt);
							if (val0 != val1) {
								return val0 - val1;
							}
							pos += IntType.bytesPerInt;
						}
					}
				}
				return 0;
			} else {
				QpTuple<?> t0 = QpTuple.fromBytes(QpTuple.SerializationMode.KEY, schema, app.store, arg0, null);
				QpTuple<?> t1 = QpTuple.fromBytes(QpTuple.SerializationMode.KEY, schema, app.store, arg1, null);
				return t0.compareTo(t1);
			}
		}

		private boolean getNull(int pos, byte[] data) {
			return BitSet.getField(pos, data, IntType.bytesPerInt);
		}

		private boolean getLabeledNull(int pos, byte[] data) {
			return BitSet.getField(pos, data, IntType.bytesPerInt + bitSetSize);
		}
	}

	private QpApplication<M> app;
	int currentEpoch;
	// Both of these contain tuples with the current epoch
	Map<Integer,SortedSet<byte[]>> currentAdditions;
	Map<Integer,SortedSet<byte[]>> currentDeletions;
	Set<Integer> relationsFinishedForEpoch;
	private final MetadataFactory<M> mdf;

	private final Logger logger = Logger.getLogger(this.getClass());

	List<DHTThread> threads = new ArrayList<DHTThread>(NUM_DHT_THREADS);

	DHTService(QpApplication<M> app) {
		this.app = app;
		this.mdf = app.mdf;
		currentEpoch = Integer.MIN_VALUE;
		relationsFinishedForEpoch = new HashSet<Integer>();
		currentAdditions = new HashMap<Integer,SortedSet<byte[]>>();
		currentDeletions = new HashMap<Integer,SortedSet<byte[]>>();

		for (int i = 0; i < NUM_DHT_THREADS; ++i) {
			DHTThread t = new DHTThread(i);
			t.start();
			threads.add(t);
		}
	}

	void close() throws InterruptedException {
		for (Thread t : threads) {
			t.interrupt();
			t.join();
		}
	}

	public void addTuple(QpTuple<M> t) throws DHTException {
		addTuples(Collections.singleton(t), t.getEpoch());
	}

	public void addTuple(QpTuple<M> t, int epoch) throws DHTException  {
		addTuples(Collections.singleton(t), epoch);
	}

	public void addMutableTuples(Collection<QpMutableTuple<M>> ts, int epoch) throws DHTException {
		List<QpTuple<M>> cleaned = new ArrayList<QpTuple<M>>(ts.size());
		for (QpMutableTuple<M> t : ts) {
			cleaned.add(new QpTuple<M>(t, epoch, false));
		}
		addTuples(cleaned.iterator(), epoch);
	}

	public void addTuples(Collection<QpTuple<M>> ts, int epoch) throws DHTException {		
		addTuples(ts.iterator(), epoch);
	}

	public void addTuples(Iterator<QpTuple<M>> ts, int epoch) throws DHTException {	
		addTuples(ts,epoch,500);
	}

	public void addTuples(Iterator<QpTuple<M>> ts, int epoch, int sendBlockSize) throws DHTException {
		addTuples(ts,epoch,sendBlockSize,null);
	}

	public interface TupleCountObserver {
		void tuplesSentCountIs(int count);
	}

	public void addTuples(Iterator<QpTuple<M>> ts, int epoch, int sendBlockSize, TupleCountObserver tco) throws DHTException {
		if (currentAdditions.isEmpty() && currentDeletions.isEmpty()) {
			if (epoch < currentEpoch) {
				throw new DHTException("Cannot add tuple from epoch " + epoch + " after previous epoch " + currentEpoch);
			}
			currentEpoch = epoch;
			relationsFinishedForEpoch.clear();
		} else if (epoch != currentEpoch) {
			throw new DHTException("Cannot add tuple for epoch " + epoch + " during epoch " + currentEpoch);
		}

		class Info {
			int remainingMessages = 0;
			List<Exception> exs = new ArrayList<Exception>();
			List<InetSocketAddress> exNodes = new ArrayList<InetSocketAddress>();
			List<QpTuple<M>> errorTuples = new ArrayList<QpTuple<M>>();
			List<ConstraintViolation> errors = new ArrayList<ConstraintViolation>();
		};

		final Info info = new Info();
		int sentCount = 0;

		class InsertReplyContinuation implements ReplyContinuation {
			private boolean finished;
			synchronized public boolean isFinished() {
				return finished;
			}

			synchronized public void processReply(Message m) {
				finished = true;
				synchronized (info) {
					--info.remainingMessages;
					if (info.remainingMessages == 0) {
						info.notify();
					}
					if (m instanceof ReplySuccess) {
					} else {
						if (m instanceof ConstraintViolationMsg) {
							ConstraintViolationMsg cvm = (ConstraintViolationMsg) m;
							info.errors.addAll(cvm.errors);
							info.errorTuples.addAll(cvm.getErrorTuples(app.store, mdf));
						} else if (m instanceof ReplyException) {
							ReplyException re = (ReplyException) m; 
							info.exs.add(new RuntimeException(re.what, re.why));
							info.exNodes.add(m.getOrigin());
						} else {
							info.exs.add(new RuntimeException("Unexpected reply " + m + " from " + m.getOrigin()));
							info.exNodes.add(m.getOrigin());
						}
					}
				}
			}
		}

		final Router r = app.getRouter();

		final Map<InetSocketAddress,List<QpTuple<M>>> toSend = new HashMap<InetSocketAddress,List<QpTuple<M>>>();

		try {
			final InetSocketAddress[] oneDest = new InetSocketAddress[1];
			while (ts.hasNext()) {
				QpTuple<M> t = ts.next();
				if (t.getEpoch() != epoch) {
					t = t.changeEpoch(epoch);
				}
				final int relId = t.getSchema().relId;
				if (relationsFinishedForEpoch.contains(relId)) {
					throw new DHTException("Cannot add tuple to relation " + relId + " since it has already been finished for epoch " + currentEpoch);
				}

				SortedSet<byte[]> deletions = currentDeletions.get(relId);
				byte[] key = t.getKeyBytes();
				if (deletions != null && deletions.contains(key)) {
					throw new DHTException("Should not try to add and delete tuple with same key " + t.getKeyTuple() + " in same epoch");
				}
				SortedSet<byte[]> additions = currentAdditions.get(relId);
				if (additions == null) {
					additions = new TreeSet<byte[]>(new TupleBytesComparator(relId));
					currentAdditions.put(relId, additions);
				}
				if (additions.contains(key)) {
					throw new DHTException("Should not try to add two tuples with same key " + t.getKeyTuple() + " during one epoch");
				} else {
					additions.add(key);
				}

				Id id = t.getQPid();
				InetSocketAddress[] addrs;
				if (app.replicationFactor == 1) {
					InetSocketAddress addr = r.getDest(id);
					oneDest[0] = addr;
					addrs = oneDest;
				} else {
					addrs = r.getDests(id, app.replicationFactor);
				}
				for (InetSocketAddress addr : addrs) {
					List<QpTuple<M>> tuples = toSend.get(addr);
					if (tuples == null) {
						tuples = new ArrayList<QpTuple<M>>();
						toSend.put(addr, tuples);
					}
					tuples.add(t);
					if (tuples.size() >= sendBlockSize) {
						app.sendMessageAwaitReply(new InsertTuplesMessage(addr, tuples, mdf), new InsertReplyContinuation(),
								ReplySuccess.class, ConstraintViolationMsg.class );
						synchronized (info) {
							++info.remainingMessages;
						}
						tuples.clear();
					}
				}
				++sentCount;
				if (tco != null && (sentCount % 50000) == 0) {
					tco.tuplesSentCountIs(sentCount);
				}

			}

			for (Map.Entry<InetSocketAddress, List<QpTuple<M>>> me : toSend.entrySet()) {
				List<QpTuple<M>> tuples = me.getValue();
				if (tuples.isEmpty()) {
					continue;
				}
				InetSocketAddress addr = me.getKey();
				app.sendMessageAwaitReply(new InsertTuplesMessage(addr, tuples, mdf), new InsertReplyContinuation(),
						ReplySuccess.class, ConstraintViolationMsg.class );
				synchronized (info) {
					++info.remainingMessages;
				}
				sentCount += tuples.size();
				if (tco != null) {
					tco.tuplesSentCountIs(sentCount);
				}
				tuples.clear();
			}

		} catch (IOException e) {
			throw new DHTException("Error sending InsertTuplesMessage", e);
		} catch (InterruptedException e) {
			return;
		}

		try {
			synchronized (info) {
				while (info.remainingMessages > 0) {
					info.wait();
				}
			}

			if (!(info.errors.isEmpty() && info.exs.isEmpty())) {
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < info.errors.size(); ++i) {
					sb.append("Error inserting tuple " + info.errorTuples.get(i) + ": " + info.errors.get(i) + "\n");
				}
				for (int i = 0; i < info.exs.size(); ++i) {
					Exception e = (Exception) info.exs.get(i);
					if (e != null) {
						e.printStackTrace();
					}
					sb.append("Error at node " + info.exNodes.get(i) + ": " + e + "\n");
				}

				throw new DHTException(sb.toString());
			}

			// TODO: remove error tuples from the index entry being built			
		} catch (InterruptedException e) {
			throw new DHTException("Interrupted while trying to await replies to insertions", e);
		}
	}

	public void deleteTuple(QpTuple<M> t, int epoch) throws DHTException {
		deleteTuples(Collections.singleton(t), epoch);
	}

	public void deleteTuples(Collection<QpTuple<M>> ts, int epoch) throws DHTException {
		if (currentAdditions.isEmpty() && currentDeletions.isEmpty()) {
			if (epoch < currentEpoch) {
				throw new DHTException("Cannot add tuple during epoch " + epoch + " after previous epoch " + currentEpoch);
			}
			currentEpoch = epoch;
			relationsFinishedForEpoch.clear();
		} else if (epoch != currentEpoch) {
			throw new DHTException("Cannot delete tuple during epoch " + epoch + " since current epoch is " + currentEpoch);
		}
		Map<Id,List<QpTuple<?>>> toDelete = new HashMap<Id,List<QpTuple<?>>>();
		for (QpTuple<M> t : ts) {
			if (t.getEpoch() != epoch) {
				t = t.changeEpoch(epoch);
			}
			final int relId = t.getSchema().relId;
			if (relationsFinishedForEpoch.contains(relId)) {
				throw new DHTException("Cannot delete tuple from relation " + relId + " since it has already been finished for epoch " + currentEpoch);
			}
			try {
				int firstEpoch = app.getFirstEpochForTable(relId);
				if (firstEpoch == currentEpoch) {
					throw new DHTException("Cannot delete tuple " + t +" during first epoch for table");
				}
			} catch (IllegalArgumentException iae) {
				throw new DHTException("Could not determine first epoch for table " + relId, iae);
			}
			final byte[] key = t.getKeyBytes();
			SortedSet<byte[]> insertions = currentAdditions.get(relId);
			if (insertions != null && insertions.contains(key)) {
				throw new DHTException("Should not try to add and delete tuple with same key " + t.getKeyTuple() + " in same epoch");
			}

			SortedSet<byte[]> deletions = currentDeletions.get(relId);
			if (deletions == null) {
				deletions = new TreeSet<byte[]>(new TupleBytesComparator(relId));
				currentDeletions.put(relId, deletions);
			}
			if (deletions.contains(key)) {
				throw new DHTException("Should not try to delete two tuples with same key " + t.getKeyTuple() + " during one epoch");
			}
			deletions.add(key);

			Id id = t.getQPid();
			List<QpTuple<?>> forId = toDelete.get(id);
			if (forId == null) {
				forId = new ArrayList<QpTuple<?>>();
				toDelete.put(id, forId);
			}
			forId.add(t);

		}

		ReplyHolder<Id> replies = new ReplyHolder<Id>(toDelete.size());
		try {
			for (Map.Entry<Id, List<QpTuple<?>>> me : toDelete.entrySet()) {
				ReplyContinuation rc = new SimpleReplyContinuation<Id>(me.getKey(),replies);
				app.sendMessageAwaitReply(new RemoveTuplesMessage(me.getKey(), me.getValue()), rc, ReplySuccess.class);
			}

		} catch (IOException e) {
			throw new DHTException("Error sending RemoveTupleMessage", e);
		} catch (InterruptedException e) {
			return;
		}

		try {
			replies.waitUntilFinished();
		} catch (InterruptedException e) {
			throw new DHTException("Interrupted while trying to await replies to deletions", e);
		}

		for (Map.Entry<Id,List<QpTuple<?>>> me : toDelete.entrySet()) {
			Message reply = replies.getReply(me.getKey());
			if (! (reply instanceof ReplySuccess)) {
				throw new DHTException("Received unexpected reply while deleting tuple(s) " + me.getValue() + " from DHT: " + reply);
			}
		}

	}

	public void finishEpochForRelation(String relName) throws DHTException, InterruptedException {
		int relId = app.store.getSchema(relName).relId;
		SortedSet<byte[]> additions = currentAdditions.get(relId);
		SortedSet<byte[]> deletions = currentDeletions.get(relId);

		try {
			if (currentEpoch == app.getFirstEpochForTable(relId)) {
				app.index.recordTuplesForEpoch(relId, currentEpoch, additions);
			} else {
				app.index.recordChangedTuplesForEpoch(relId, currentEpoch, deletions, additions);
			}
		} catch (IndexServiceException e) {
			throw new DHTException("Error updating index for table " + relName, e);
		}

		currentAdditions.remove(relId);
		currentDeletions.remove(relId);
		relationsFinishedForEpoch.add(relId);
	}

	public QpTuple<M> getTuple(QpTuple<?> key) throws DHTException {
		ArrayList<QpTuple<?>> keys = new ArrayList<QpTuple<?>>(1);
		keys.add(key);
		return getTuples(keys).get(0);
	}

	public List<QpTuple<M>> getTuples(List<QpTuple<?>> keys) throws DHTException {
		final int numTuples = keys.size();
		List<QpTuple<M>> retval = new ArrayList<QpTuple<M>>(numTuples);

		final ReplyHolder<Integer> replies = new ReplyHolder<Integer>(numTuples);
		int pos = 0;
		try {
			for (final QpTuple<?> t : keys) {
				ReplyContinuation rc = new SimpleReplyContinuation<Integer>(pos,replies);

				app.sendMessageAwaitReply(new RetrieveTupleMessage(t), rc, TupleIsMessage.class);
				++pos;
			}
		} catch (IOException e) {
			throw new DHTException("Error sending RetrieveTupleMessage", e);
		} catch (InterruptedException e) {
			return null;
		}

		try {
			replies.waitUntilFinished();
		} catch (InterruptedException e) {
			throw new DHTException("Interrupted while trying to await replies to retrievals", e);
		}

		for (int i = 0; i < numTuples; ++i) {
			Message m = replies.getReply(i);
			if (m instanceof TupleIsMessage) {
				final QpSchema s = keys.get(i).getSchema();
				QpSchema.Source ss = new QpSchema.SingleSource(s);
				retval.set(i, ((TupleIsMessage) m).getTuple(s,ss,mdf));
			} else {
				throw new DHTException("Received unexpected reply to request for tuple " + keys.get(i) + ": " + m);
			}
		}

		return retval;
	}

	BlockingQueue<DHTMessage> msgs = new LinkedBlockingQueue<DHTMessage>();

	void processMessage(DHTMessage m) throws InterruptedException {
		msgs.put(m);
	}

	private class DHTThread extends Thread {

		DHTThread(int num) {
			super(app.tg, app.localAddr + " DHTThread #" + num);
		}

		public void run() {
			while (! isInterrupted()) {
				DHTMessage m;
				try {
					m = msgs.take();
				} catch (InterruptedException ie) {
					return;
				}
				handleMessage(m);
			}
		}
	}

	private void handleMessage(DHTMessage m) {
		try {
			if (m instanceof InsertTuplesMessage) {
				InsertTuplesMessage itm = (InsertTuplesMessage) m;
				List<byte[]> serialized = new ArrayList<byte[]>();
				List<QpTuple<M>> toInsert = itm.getTuples(app.store, mdf, serialized);
				List<QpTuple<M>> errorTuples = new ArrayList<QpTuple<M>>();
				List<ConstraintViolation> errors = new ArrayList<ConstraintViolation>();
				List<ConstraintViolation> cvs = app.store.addTuples(toInsert,serialized);
				final int size = toInsert.size();
				for (int i = 0; i < size; ++i) {
					if (cvs.get(i) != null) {
						errorTuples.add(toInsert.get(i));
						errors.add(cvs.get(i));
					}
				}
				if (errorTuples.isEmpty()) { 
					app.sendReplySuccess(m);
				} else {
					app.sendMessage(new ConstraintViolationMsg(itm, errorTuples, mdf, errors));
				}
			} else if (m instanceof RemoveTuplesMessage) {
				RemoveTuplesMessage rtm = (RemoveTuplesMessage) m;
				app.store.deleteTuples(rtm.getKeys());
				app.sendReplySuccess(m);
			} else if (m instanceof RetrieveTupleMessage) {
				RetrieveTupleMessage rtm = (RetrieveTupleMessage) m;
				QpTuple<M> t = app.store.getTupleByKey(rtm.getKey(app.store));
				if (t == null) {
					app.sendMessage(new ReplyFailure(rtm, "Could not find tuple in tuple store", true));
				} else {
					Filter<? super QpTuple<?>> f = rtm.getFilter(t.getSchema());
					if (f == null || f.eval(t)) {
						if (rtm.desiredCols != null) {
							// Remove undesired columns
							t = new QpTuple<M>(t, rtm.desiredCols);
						}
						app.sendMessage(new TupleIsMessage(rtm,t,mdf));					
					} else {
						app.sendMessage(new TupleFailsFilter(rtm,t));
					}
				}
			} else {
				logger.error("DHT Service doesn't know what to do with message " + m);
			}
		} catch (Exception e) {
			logger.error("Error processing DHT message", e);
			try {
				app.sendMessage(new ReplyException(m,"Error processing DHTMessage", e, false));
			} catch (IOException ioe) {
				logger.error(ioe);
			} catch (InterruptedException ie) {
				return;
			}
		}
	}

	void clear() {
		currentEpoch = Integer.MIN_VALUE;
		currentAdditions.clear();
		currentDeletions.clear();
		relationsFinishedForEpoch.clear();
	}

}

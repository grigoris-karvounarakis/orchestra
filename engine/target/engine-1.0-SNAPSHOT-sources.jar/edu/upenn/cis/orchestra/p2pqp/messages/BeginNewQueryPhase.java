package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import edu.upenn.cis.orchestra.p2pqp.IdRange;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.Router;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class BeginNewQueryPhase extends QpMessage {
	private static final long serialVersionUID = 1L;
	public final int queryId;
	public final int phaseNo;
	public final Router router;
	public final IdRange[] previousPhaseFailedRanges;
	public final Collection<InetSocketAddress> newlyFailedNodes;
	public final Map<Integer,int[]> joinOperatorsToResend;

	public BeginNewQueryPhase(InetSocketAddress dest, int queryId, int phaseNo, Router newRouter,
			IdRange[] previousPhaseFailedRanges, Collection<InetSocketAddress> newlyFailedNodes,
			Map<Integer,int[]> joinOperatorsToResend) {
		super(dest);
		this.queryId = queryId;
		this.phaseNo = phaseNo;
		this.router = newRouter;
		this.previousPhaseFailedRanges = previousPhaseFailedRanges;
		this.newlyFailedNodes = newlyFailedNodes;
		this.joinOperatorsToResend = joinOperatorsToResend;
	}

	public BeginNewQueryPhase(InputBuffer buf, InetSocketAddress origin)
	throws SerializationException {
		super(buf, origin);
		queryId = buf.readInt();
		phaseNo = buf.readInt();
		router = Router.deserialize(buf);
		int numRanges = buf.readInt();
		previousPhaseFailedRanges = new IdRange[numRanges];
		for (int i = 0; i < numRanges; ++i) {
			previousPhaseFailedRanges[i] = IdRange.deserialize(buf);
		}
		int numNodes = buf.readInt();
		newlyFailedNodes = new ArrayList<InetSocketAddress>(numNodes);
		for (int i = 0; i < numNodes; ++i) {
			newlyFailedNodes.add(buf.readInetSocketAddress());
		}
		int numJoinOps = buf.readInt();
		joinOperatorsToResend = new HashMap<Integer,int[]>(numJoinOps);
		for (int i = 0; i < numJoinOps; ++i) {
			int opId = buf.readInt();
			int numCols = buf.readInt();
			int[] cols;
			if (numCols < 0) {
				cols = null;
			} else {
				cols = new int[numCols];
				for (int j = 0; j < numCols; ++j) {
					cols[j] = buf.readInt();
				}
			}
			joinOperatorsToResend.put(opId, cols);
		}
	}

	@Override
	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(queryId);
		buf.writeInt(phaseNo);
		router.serialize(buf);
		buf.writeInt(previousPhaseFailedRanges.length);
		for (IdRange range : previousPhaseFailedRanges) {
			range.serialize(buf);
		}
		buf.writeInt(newlyFailedNodes.size());
		for (InetSocketAddress node : newlyFailedNodes) {
			buf.writeInetSocketAddress(node);
		}
		buf.writeInt(joinOperatorsToResend.size());
		for (Map.Entry<Integer, int[]> me : joinOperatorsToResend.entrySet()) {
			buf.writeInt(me.getKey());
			int[] cols = me.getValue();
			if (cols == null) {
				buf.writeInt(-1);
			} else {
				buf.writeInt(cols.length);
				for (int col : me.getValue()) {
					buf.writeInt(col);
				}
			}
		}
	}
}

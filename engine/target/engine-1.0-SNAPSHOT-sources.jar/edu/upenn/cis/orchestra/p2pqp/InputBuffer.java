package edu.upenn.cis.orchestra.p2pqp;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;


public abstract class InputBuffer {
	public abstract byte[] readBytes(int length);
	
	public final byte[] readBytes() {
		int length = readInt();
		if (length < 0) {
			return null;
		} else {
			return readBytes(length);
		}
	}

	public abstract int readInt();
	
	public abstract short readShort();

	public abstract long readLong();

	public String readString() {
		byte[] bytes = readBytes();
		if (bytes == null) {
			return null;
		} else {
			try {
				return new String(bytes, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	public final Object readObject() {
		byte[] data = readBytes();
		try {
			ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data));
			return ois.readObject();
		} catch (IOException e) {
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	public abstract boolean readBoolean();
	
	public final InetAddress readInetAddress() {
		byte[] addr = readBytes(OutputBuffer.addrLen);
		try {
			return InetAddress.getByAddress(addr);
		} catch (UnknownHostException e) {
			throw new RuntimeException("Shouldn't happen", e);
		}
	}
	
	public final InetSocketAddress readInetSocketAddress() {
		InetAddress addr = readInetAddress();
		// Turn back into an int
		int port = (readShort() & 0xFFFF);
		return new InetSocketAddress(addr,port);
	}
}

abstract class TransactionalInputBuffer extends InputBuffer {
	/**
	 * Record that the current transaction has been read normally.
	 * 
	 * @throws IllegalStateException
	 * 						if there is data from this transaction remaining
	 * 
	 */
	abstract void endReadingTransaction() throws IOException, TransactionSizeException;
	
	/**
	 * Skip the remainder of the current transaction and
	 * proceed to the next transaction
	 */
	abstract void skipTransaction() throws IOException;
	
	static class TransactionSizeException extends Exception {
		private static final long serialVersionUID = 1L;
		final int expected;
		final int read;
		
		TransactionSizeException(int expected, int read) {
			super("Transaction has size " + expected + " but " + read + " bytes were read");
			this.expected = expected;
			this.read = read;
		}
	}

}
package edu.upenn.cis.orchestra.p2pqp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.p2pqp.Filter.FilterException;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public class FilterOperator<M> extends Operator<M> {
	private final List<Filter<? super QpTuple<?>>> fs;

	private final Logger logger = Logger.getLogger(this.getClass());
	
	public FilterOperator(Filter<? super QpTuple<?>> f, Operator<M> dest, WhichChild destInput, int operatorId, MetadataFactory<M> mdf, RecordTuples rt) {
		this(Collections.singleton(f), dest,destInput,operatorId,mdf,rt);
	}

	public FilterOperator(Collection<? extends Filter<? super QpTuple<?>>> fs, Operator<M> dest, WhichChild destInput, int operatorId, MetadataFactory<M> mdf, RecordTuples rt) {
		super(dest,destInput,operatorId,mdf,rt);
		this.fs = new ArrayList<Filter<? super QpTuple<?>>>(fs);
	}

	@Override
	protected void receiveTuples(List<QpTuple<M>> tuples) {
		List<QpTuple<M>> output = new ArrayList<QpTuple<M>>();
		List<ExecutionId> removedIds = new ArrayList<ExecutionId>();
		TUPLE: for (QpTuple<M> t : tuples) {
			for (Filter<? super QpTuple<?>> f : fs) {
				try {
					if (! f.eval(t)) {
						removedIds.add(t.getId());
						continue TUPLE;
					}
				} catch (FilterException e) {
					logger.error("Cannot evaluate filter " + f + " on tuple " + t + ", tuple will be dropped", e);
					removedIds.add(t.getId());
					continue TUPLE;
				}
			}
			output.add(t);
		}
		tuples.clear();
		if (! removedIds.isEmpty()) {
			tuplesRemoved(removedIds);
		}
		if (! output.isEmpty()) {
			sendTuples(output);
		}
	}

}

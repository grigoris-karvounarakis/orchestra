package edu.upenn.cis.orchestra.p2pqp;

import java.util.Collection;

import edu.upenn.cis.orchestra.p2pqp.IndexService.EpochNum;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;

interface KeyReceiver {
	/**
	 * Receive the keys for relation that satisfy a key predicate
	 * and fall into this node's id space
	 * 
	 * @param phaseNo	The sequence number of the set of pages. May be more than zero if
	 * 					recovery happens
	 * @param page		The ID of the page
	 * @param keys		The tuples that satisfy the key predicate and ID space constraint
	 */
	void receiveKeys(int phaseNo, EpochNum page, Collection<ByteArrayWrapper> keys);
}

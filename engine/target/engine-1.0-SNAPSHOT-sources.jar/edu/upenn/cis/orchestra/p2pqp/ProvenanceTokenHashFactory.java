package edu.upenn.cis.orchestra.p2pqp;

import java.util.HashMap;

import edu.upenn.cis.orchestra.p2pqp.bdd.BDDFactory;
import edu.upenn.cis.orchestra.p2pqp.bdd.JFactory;

public class ProvenanceTokenHashFactory {
	static final int NODENUM = 10000000;
	static final int CACHESIZE = 2000000;
	static final int MAXVARNUM = 2000;
	static BDDFactory bddFactory = (BDDFactory)JFactory.init(NODENUM, CACHESIZE);
    static HashMap<Integer,KeyandEpoch> IK = new HashMap<Integer, KeyandEpoch>();
	static HashMap<KeyandEpoch, Integer> KI = new HashMap<KeyandEpoch, Integer>();
	
    private static final ProvenanceTokenHashFactory instance;
	
	static {
		instance = new ProvenanceTokenHashFactory();
	}
	
	public static ProvenanceTokenHashFactory getInstance() {
		return instance;
	}
	
	ProvenanceTokenHashFactory() {
		if (bddFactory != null) {
			if (!bddFactory.isInitialized()) {
				bddFactory = (BDDFactory)JFactory.init(NODENUM, CACHESIZE);
			}
	        bddFactory.setVarNum(MAXVARNUM);
		} else {
			throw new RuntimeException("Inproper use of provenanceTokenHash!");
		}
	}
	
	public static BDDFactory getBDDFactory() {
		if (bddFactory == null || !bddFactory.isInitialized()) {
			throw new RuntimeException("BDDFactory is null!");
		}
		return bddFactory;
	}
	
	public void stop() {
		if (bddFactory != null && bddFactory.isInitialized()) {
			bddFactory.done();
		} else {
			throw new RuntimeException("Cannot stop noninstantiated bddFactory!");
		}
	}
	
	public static int keytoBDD(KeyandEpoch key) {
		//BDD bdd;
		if (!KI.containsKey(key))
		{	
			int lastInt = KI.size();
            lastInt++; 
			if (lastInt >= MAXVARNUM) {
				throw new RuntimeException("Too many BDDs!");
			}
			//bdd = ProvenanceTokenHashFactory.getBDDFactory().ithVar(lastInt);
			KI.put(key, new Integer(lastInt));
			IK.put(new Integer(lastInt), key);
			return lastInt;
		}
		else {
			int index = KI.get(key).intValue();
			//bdd = ProvenanceTokenHashFactory.getBDDFactory().ithVar(index);
			return index;
		}
	}
}

package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;

import rice.p2p.commonapi.NodeHandle;
import edu.upenn.cis.orchestra.p2pqp.PastryMsg;

public class GetNodeInfo extends PastryMsg {
	public final long origMsgId;
	public final InetSocketAddress origFrom;
	
	public GetNodeInfo(NodeHandle dest, InetSocketAddress origin) {
		super(dest);
		this.origFrom = origin;
		this.origMsgId = this.messageId;
	}
	
	public GetNodeInfo(NodeHandle dest, InetSocketAddress origin, long origMsgId) {
		super(dest);
		this.origFrom = origin;
		this.origMsgId = origMsgId;
	}

	private static final long serialVersionUID = 1L;
}

package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;

import rice.p2p.commonapi.Endpoint;
import rice.p2p.commonapi.NodeHandle;

public abstract class PastryMsg extends Message implements rice.p2p.commonapi.Message {
	final NodeHandle dest;
	public NodeHandle fromNH;

	protected PastryMsg(NodeHandle dest) {
		this.dest = dest;
	}
	
	public int getPriority() {
		return MEDIUM_HIGH_PRIORITY;
	}

	@Override
	final void sendImpl(Router r, SocketManager sm, Endpoint e) throws IOException {
		fromNH = e.getLocalNodeHandle();
		e.route(null, this, dest);
	}
}




package edu.upenn.cis.orchestra.p2pqp;
public class Statistics { 
	public static long totalTupleSize = 0;
	public static long totalTupleNum = 0;
	public static long totalShippingTupleNum = 0;
	public static long totalShippingMessages = 0;
	public enum Func { 
		MAX, MIN, COUNT, SUM, AVG, ADD, CONS;
	}
}
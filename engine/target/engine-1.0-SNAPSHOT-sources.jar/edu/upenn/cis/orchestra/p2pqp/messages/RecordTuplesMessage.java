package edu.upenn.cis.orchestra.p2pqp.messages;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.KEY;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.p2pqp.ExecutionId;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpApplication;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;
import edu.upenn.cis.orchestra.p2pqp.RecordTuples.NodeAndOp;
import edu.upenn.cis.orchestra.p2pqp.RecordTuples.TupleAndOp;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;

public class RecordTuplesMessage extends QpMessage implements QueryOwnerMessage {
	private static final long serialVersionUID = 1L;
	public final Collection<ExecutionId> added, removed;
	private final byte[] scanned;
	private final byte[] missing;
	public final Collection<NodeAndOp> finished;
	public final Collection<Exception> exceptions;
	public final Collection<InetSocketAddress> failed;
	private final int queryId;

	public static List<RecordTuplesMessage> build(InetSocketAddress dest, Collection<ExecutionId> added, Collection<ExecutionId> removed,
			Map<OperatorAndPhase,List<QpTuple<?>>> scanned, Collection<NodeAndOp> finished, Collection<Exception> exceptions, Collection<InetSocketAddress> failed,
			Map<OperatorAndPhase,List<QpTuple<?>>> missing, int queryId) {
		List<RecordTuplesMessage> retval = new ArrayList<RecordTuplesMessage>();

		ByteBufferWriter bbw = new ByteBufferWriter();

		Collection<NodeAndOp> ourFinished = finished;
		Collection<Exception> ourExceptions = exceptions;
		Collection<InetSocketAddress> ourFailed = failed;
		Collection<ExecutionId> noIds = Collections.emptyList();
		Collection<ExecutionId> ourAdded = added, ourRemoved = noIds;

		final byte[] empty = new byte[0];
		byte[] scannedBytes = empty, missingBytes = empty;

		final int overhead = 50;
		

		if (overhead + (ourAdded.size() + ourRemoved.size()) * ExecutionId.estimatedSerializedLength  + scannedBytes.length + missingBytes.length + bbw.getCurrentLength() > QpApplication.MAX_MSG_SIZE) {
			retval.add(new RecordTuplesMessage(dest, ourAdded, ourRemoved, scannedBytes, ourFinished, ourExceptions, ourFailed,
					missingBytes, queryId));
			ourExceptions = Collections.emptyList();
			ourFinished = Collections.emptyList();
			ourFailed = Collections.emptyList();
			ourAdded = noIds;
			ourRemoved = noIds;
			scannedBytes = empty;
			missingBytes = empty;
		}

		ourRemoved = removed;

		if (overhead + (ourAdded.size() + ourRemoved.size()) * ExecutionId.estimatedSerializedLength  + scannedBytes.length + missingBytes.length + bbw.getCurrentLength() > QpApplication.MAX_MSG_SIZE) {
			retval.add(new RecordTuplesMessage(dest, ourAdded, ourRemoved, scannedBytes, ourFinished, ourExceptions, ourFailed,
					missingBytes, queryId));
			ourExceptions = Collections.emptyList();
			ourFinished = Collections.emptyList();
			ourFailed = Collections.emptyList();
			ourAdded = noIds;
			ourRemoved = noIds;
			scannedBytes = empty;
			missingBytes = empty;
		}

		for (Map.Entry<OperatorAndPhase, List<QpTuple<?>>> me : scanned.entrySet()) {
			OperatorAndPhase oap = me.getKey();
			List<QpTuple<?>> keys = me.getValue();
			bbw.addToBuffer(oap.operator);
			bbw.addToBuffer(oap.phase);
			bbw.addToBuffer(keys.size());
			bbw.addToBuffer(keys.get(0).getSchema().relId);
			for (QpTuple<?> key : keys) {
				bbw.addToBuffer(key.getKeyBytes());
			}
			if (overhead + (ourAdded.size() + ourRemoved.size()) * ExecutionId.estimatedSerializedLength  + bbw.getCurrentLength() + missingBytes.length > QpApplication.MAX_MSG_SIZE) {
				retval.add(new RecordTuplesMessage(dest, ourAdded, ourRemoved, bbw.getByteArray(), ourFinished, ourExceptions, ourFailed,
						missingBytes, queryId));
				ourExceptions = Collections.emptyList();
				ourFinished = Collections.emptyList();
				ourFailed = Collections.emptyList();
				ourAdded = noIds;
				ourRemoved = noIds;
				scannedBytes = empty;
				missingBytes = empty;
				bbw.clear();
			}
		}
		scannedBytes = bbw.getByteArray();
		bbw.clear();

		for (Map.Entry<OperatorAndPhase, List<QpTuple<?>>> me : missing.entrySet()) {
			OperatorAndPhase oap = me.getKey();
			List<QpTuple<?>> keys = me.getValue();
			bbw.addToBuffer(oap.operator);
			bbw.addToBuffer(oap.phase);
			bbw.addToBuffer(keys.size());
			bbw.addToBuffer(keys.get(0).getSchema().relId);
			for (QpTuple<?> key : keys) {
				bbw.addToBuffer(key.getKeyBytes());
			}
			if (overhead + (ourAdded.size() + ourRemoved.size()) * ExecutionId.estimatedSerializedLength  + scannedBytes.length + bbw.getCurrentLength() > QpApplication.MAX_MSG_SIZE) {
				retval.add(new RecordTuplesMessage(dest, ourAdded, ourRemoved, scannedBytes, ourFinished, ourExceptions, ourFailed,
						bbw.getByteArray(), queryId));
				ourExceptions = Collections.emptyList();
				ourFinished = Collections.emptyList();
				ourFailed = Collections.emptyList();
				ourAdded = noIds;
				ourRemoved = noIds;
				scannedBytes = empty;
				missingBytes = empty;
				bbw.clear();
			}
		}
		missingBytes = bbw.getByteArray();
		bbw.clear();

		retval.add(new RecordTuplesMessage(dest, ourAdded, ourRemoved, scannedBytes, ourFinished, ourExceptions, ourFailed,
				missingBytes, queryId));

		return retval;
	}


	private RecordTuplesMessage(InetSocketAddress dest, Collection<ExecutionId> added, Collection<ExecutionId> removed,
			byte[] scanned, Collection<NodeAndOp> finished, Collection<Exception> exceptions, Collection<InetSocketAddress> failedNodes,
			byte[] missing, int queryId) {
		super(dest);

		this.added = added;
		this.removed = removed;
		this.scanned = scanned;
		this.missing = missing;
		this.queryId = queryId;
		this.failed = failedNodes;
		this.finished = finished;
		this.exceptions = exceptions;
	}

	public static class OperatorAndPhase {
		public final int operator;
		public final int phase;
		
		public OperatorAndPhase(int operator, int phase) {
			this.operator = operator;
			this.phase = phase;
		}
		
		public int hashCode() {
			return operator + 31 * phase;
		}
		
		public boolean equals(Object o) {
			if (o == null || o.getClass() != OperatorAndPhase.class) {
				return false;
			}
			
			OperatorAndPhase oap = (OperatorAndPhase) o;
			return (operator == oap.operator && phase == oap.phase);
		}
	}
	
	public static class ScannedKeys {
		public final int operator;
		public final int phase;
		public final ByteArrayWrapper[] keys;
		
		private ScannedKeys(int operator, int phase, ByteArrayWrapper keys[]) {
			this.operator = operator;
			this.phase = phase;
			this.keys = keys;
		}
	}
	
	public List<ScannedKeys> getScannedKeys() {
		byte[] scanned = this.scanned;
		final int length = scanned.length;
		int pos = 0;
		List<ScannedKeys> retval = new ArrayList<ScannedKeys>();
		while (pos < length) {
			final int operator = IntType.getValFromBytes(scanned, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			final int phase = IntType.getValFromBytes(scanned, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			final int num = IntType.getValFromBytes(scanned, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			ByteArrayWrapper[] tuples = new ByteArrayWrapper[num];
			@SuppressWarnings("unused")
			final int relId = IntType.getValFromBytes(scanned, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			int tupleCount = 0;
			while (tupleCount < num) {
				int keyLength = IntType.getValFromBytes(scanned, pos, IntType.bytesPerInt);
				pos += IntType.bytesPerInt;
				tuples[tupleCount++] = new ByteArrayWrapper(scanned, pos, keyLength);
				pos += keyLength;
			}
			retval.add(new ScannedKeys(operator, phase ,tuples));
		}
		return retval;
	}

	public List<TupleAndOp> getMissingKeys(QpSchema.Source schemas) {
		final int length = missing.length;
		int pos = 0;
		List<TupleAndOp> retval = new ArrayList<TupleAndOp>();
		while (pos < length) {
			final int operator = IntType.getValFromBytes(missing, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			final int phase = IntType.getValFromBytes(missing, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			int num = IntType.getValFromBytes(missing, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			final int relId = IntType.getValFromBytes(missing, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			final QpSchema schema = schemas.getSchema(relId);
			while (num > 0) {
				int keyLength = IntType.getValFromBytes(missing, pos, IntType.bytesPerInt);
				pos += IntType.bytesPerInt;
				QpTuple<?> key = QpTuple.fromBytes(KEY, schema, schemas, null, missing, pos, keyLength, null);
				pos += keyLength;
				retval.add(new TupleAndOp(key, operator, phase));
				--num;
			}
		}
		return retval;
	}

	public String toString() {
		return "RecordTuplesMessage(" + messageId + ")";
	}

	@Override
	protected
	void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(queryId);
		buf.writeInt(added.size());
		buf.writeInt(removed.size());
		
		for (ExecutionId id : added) {
			id.serialize(buf);
		}
		for (ExecutionId id : removed) {
			id.serialize(buf);
		}
		
		buf.writeBytes(scanned);
		buf.writeBytes(missing);
		buf.writeInt(finished.size());
		for (NodeAndOp nao : finished) {
			byte[] addrBytes = nao.node == null ? null : nao.node.getAddress().getAddress();
			buf.writeBytes(addrBytes);
			if (nao.node != null) {
				buf.writeInt(nao.node.getPort());
			}
			buf.writeInt(nao.operatorId);
		}
		if (exceptions.isEmpty()) {
			buf.writeObject(null);
		} else {
			buf.writeObject(exceptions);
		}

		if (failed.isEmpty()) {
			buf.writeInt(0);
		} else {
			buf.writeInt(failed.size());
			for (InetSocketAddress node : failed) {
				buf.writeInetSocketAddress(node);
			}
		}
	}

	@SuppressWarnings("unchecked")
	public RecordTuplesMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		queryId = buf.readInt();
		int numAdded = buf.readInt();
		int numRemoved = buf.readInt();
		
		added = new ArrayList<ExecutionId>(numAdded);
		for (int i = 0; i < numAdded; ++i) {
			added.add(ExecutionId.deserialize(buf));
		}
		removed = new ArrayList<ExecutionId>(numRemoved);
		for (int i = 0; i < numRemoved; ++i) {
			removed.add(ExecutionId.deserialize(buf));
		}
		scanned = buf.readBytes();
		missing = buf.readBytes();
		int numFinished = buf.readInt();
		if (numFinished <= 0) {
			finished = Collections.emptyList();
		} else {
			finished = new ArrayList<NodeAndOp>(numFinished);
			for (int i = 0; i < numFinished; ++i) {
				byte[] addrBytes = buf.readBytes();
				InetSocketAddress node = null;
				if (addrBytes != null) {
					InetAddress addr;
					try {
						addr = InetAddress.getByAddress(addrBytes);
					} catch (UnknownHostException e) {
						throw new IllegalStateException(e);
					}
					node = new InetSocketAddress(addr, buf.readInt());
				}
				int operatorId = buf.readInt();
				finished.add(new NodeAndOp(node, operatorId));
			}
		}
		Object o = buf.readObject();
		if (o == null) {
			exceptions = Collections.emptyList();
		} else {
			exceptions = (List<Exception>) o;
		}
		int numFailedNodes = buf.readInt();
		if (numFailedNodes == 0) {
			failed = Collections.emptyList();
		} else {
			failed = new ArrayList<InetSocketAddress>(numFailedNodes);
			for (int i = 0; i < numFailedNodes; ++i) {
				failed.add(buf.readInetSocketAddress());
			}
		}
	}


	public int getQueryId() {
		return queryId;
	}
}


package edu.upenn.cis.orchestra.p2pqp;

import java.util.Arrays;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;

public class ProvToken {
	private final int operator;
	private final byte[] key;
	
	public ProvToken (QpTuple<UpdateProvenance> tuple) {
		this.operator = tuple.getId().operatorId;
		this.key = tuple.getKeyBytes();
	}

	public ProvToken (byte[] key, int oper) {
		this.operator = oper;
		this.key = key; 
	}
	public ProvToken (ProvToken base, int oper) {
		key = base.key;
		operator = oper;
	}
	public ProvToken (ProvToken left, ProvToken right, int oper) {
		int total = left.key.length + right.key.length;
		
		key = new byte[total];
		int i;
		for (i = 0; i < left.key.length; i++)
			key[i] = left.key[i];
		for (int j = 0; j < right.key.length; j++)
			key[i+j] = right.key[j];
		operator = oper;
		
	}
	public int getOperator() {
		return this.operator;
	}
	
	public byte[] getKey() {
		return this.key;
	}
	
	/**
	 * Serialize ourselves
	 * 
	 * @return
	 */
	public byte[] getBytes() {
		ByteBufferWriter bbw = new ByteBufferWriter();
		
		bbw.addToBuffer(key);
		bbw.addToBuffer(operator);
		
		bbw.addToBuffer(0xbadf00d);
		
		return bbw.getByteArray();
		
		//return getBytes(bbw);
	}
	
	/*
	public byte[] getBytes(ByteBufferWriter bbw) {
		bbw.addToBuffer(key);
		bbw.addToBuffer(operator);
		
		bbw.addToBuffer(0xbadf00d);
		
		return bbw.getByteArray();
	}
    */ 
	/**
	 * Deserialize a new ProvToken from the buffer
	 * 
	 * @param buf
	 * @return
	 */
	public static ProvToken fromBytes(byte[] buf) {
		ByteBufferReader bbr = new ByteBufferReader(null, buf);
		
		byte[] key = bbr.readByteArray();
		int oper = bbr.readInt();
		
		int marker = bbr.readInt();
		if (marker != 0xbadf00d)
			throw new RuntimeException("Misaligned!");
		
		return new ProvToken(key, oper);
		
		//return fromBytes(bbr);
	}
	/*
	public static ProvToken fromBytes(ByteBufferReader bbr) {
		
		byte[] key = bbr.readByteArray();
		int oper = bbr.readInt();
		
		int marker = bbr.readInt();
		if (marker != 0xbadf00d)
			throw new RuntimeException("Misaligned!");
		
		return new ProvToken(key, oper);
	}
	*/
	public int hashCode() { 
		return Arrays.hashCode(this.key); 
	}
	
	public boolean equals(Object o) {
		if ((o == null) || (o.getClass()) != this.getClass()) return false;
		ProvToken t = (ProvToken) o;
		if (t.getOperator() != this.operator) return false;
		return (Arrays.equals(t.getKey(), this.getKey()));
	}
}
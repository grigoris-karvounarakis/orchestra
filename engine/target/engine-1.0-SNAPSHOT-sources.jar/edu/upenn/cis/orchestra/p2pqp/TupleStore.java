package edu.upenn.cis.orchestra.p2pqp;

import java.io.PrintStream;
import java.io.Serializable;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.upenn.cis.orchestra.datamodel.AbstractTuple;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;

public interface TupleStore<M> extends QpSchema.Source {
	QpTupleSet<M> getTuples(int relID, Filter<? super QpTuple<?>> f, int epoch, QpTupleSet<Null> discarded) throws TupleStoreException;
	QpTupleSet<M> getTuples(String relName, Filter<? super QpTuple<?>> f, int epoch, QpTupleSet<Null> discarded) throws TupleStoreException;

	/**
	 * Returns the value of a tuple for a particular epoch
	 * 
	 * @param key				The key of the tuple
	 * @param epoch				The epoch
	 * @return					The most recent value for the key before
	 * 							the supplied epoch, or null if the tuple was
	 * 							deleted or does not exist
	 * @throws TupleStoreException
	 */
	QpTuple<M> getTuple(AbstractTuple<QpSchema> key, int epoch) throws TupleStoreException;
	
	/**
	 * Returns the value of tuples for a particular epoch
	 * 
	 * @param key				The keys of the tuples
	 * @param epoch				The epoch
	 * @return					The most recent value for the keys before
	 * 							the supplied epoch, or null if the tuple was
	 * 							deleted or does not exist
	 * @throws TupleStoreException
	 */
	List<QpTuple<M>> getTuples(List<? extends AbstractTuple<QpSchema>> keys, int epoch) throws TupleStoreException;

	/**
	 * Return the value of a tuple stored for a particular key at a
	 * particular epoch. It does not search previous epochs, use getTuple to do
	 * that.
	 * 
	 * @param key			The key (at the correct epoch)
	 * @return				The associated value, or <code>null</code> if there is none
	 * @throws TupleStoreException
	 */
	QpTuple<M> getTupleByKey(QpTuple<?> key) throws TupleStoreException;
	/**
	 * Return the value of tuples stored for a particular keys at
	 * particular epochs. It does not search previous epochs, use getTuples to do
	 * that.
	 * 
	 * @param key			The keys (at the correct epoch)
	 * @return				The associated values, or <code>null</code> if there is none
	 * @throws TupleStoreException
	 */
	List<QpTuple<M>> getTuplesByKey(List<QpTuple<?>> key) throws TupleStoreException;
	
	interface TupleSink<M> {
		void processException(TupleStoreException tse);
		void deliverTuples(Collection<QpTuple<M>> tuples);
		void tupleNotFound(QpTuple<?> key);
	}
	
	void getTuples(Collection<QpTuple<?>> keys, TupleSink<M> ts);
	void getTuples(int relId, Collection<ByteArrayWrapper> serializedKeys, TupleSink<M> ts);
	
	void deleteTuple(AbstractTuple<QpSchema> t, int epoch) throws TupleStoreException;
	void deleteTuples(Collection<? extends AbstractTuple<QpSchema>> ts, int epoch) throws TupleStoreException;
	
	void deleteTuple(int relId, byte[] key) throws TupleStoreException;
	void deleteTuples(Map<Integer,? extends Collection<byte[]>> keys) throws TupleStoreException;
	
	/**
	 * Add a tuple to the tuple store
	 * 
	 * @param t			The tuple to add
	 * @return			<code>null</code> if the tuple was added successfully, or a
	 * 					<code>ConstraintViolation</code> if one occurred
	 * @throws TupleStoreException
	 * 					In the event of a database error
	 */
	ConstraintViolation addTuple(QpTuple<M> t) throws TupleStoreException;

	/**
	 * @param ts		A list of tuples to add
	 * @return			A list of the same length as ts. The ith element of this list is
	 * 					<code>null</code> if the ith element of <code>ts</code> was added successfully,
	 * 					or is set to a constraint violation if one occurred while added that element of <code>ts</code>.
	 * @throws TupleStoreException
	 * 					In the event of a database error
	 */
	List<ConstraintViolation> addTuples(List<QpTuple<M>> ts) throws TupleStoreException;

	/**
	 * @param ts		A list of tuples to add
	 * @param serialized
	 * 					The serialized versions of the tuples in <code>ts</code>,
	 * 					in the same order
	 * @return			A list of the same length as ts. The ith element of this list is
	 * 					<code>null</code> if the ith element of <code>ts</code> was added successfully,
	 * 					or is set to a constraint violation if one occurred while added that element of <code>ts</code>.
	 * @throws TupleStoreException
	 * 					In the event of a database error
	 */
	List<ConstraintViolation> addTuples(List<QpTuple<M>> ts, List<byte[]> serialized) throws TupleStoreException;

	public static class TupleStoreException extends Exception {
		private static final long serialVersionUID = 1L;

		TupleStoreException(String what) {
			super(what);
		}
		
		TupleStoreException(String what, Throwable why) {
			super(what, why);
		}
	}
	
	public static class ConstraintViolation implements Serializable {
		private static final long serialVersionUID = 1L;
		public final String err;
		ConstraintViolation(String why, QpTuple<?> qt) {
			err = "Error inserting " + qt + " into " + qt.getRelationName() + ": " + why;
		}
		
		public String toString() {
			return "ContraintViolation(" + err + ")";
		}
	}


	
	/**
	 * Start a scan of a table in the TupleStore.
	 * 
	 * @param relation		The name of the table to scan
	 * @param dest			Where to send the results
	 * @param outputDest	Which input to send the results to
	 * @param keyFilter		A filter over the keys columns, or <code>null</code> not to
	 * 						filter based on keys. Tuple that don't match are not
	 * 						reported via RecordTuples
	 * @param fullFilter	A filter over all columns that output tuples must satisfy,
	 * 						or <code>null</code> to output all tuples that pass the key
	 * 						filter
	 * @param lastEpoch		The maximum epoch of tuples to output, or <code>null</code>
	 * 						to continue until the last epoch
	 * @param queryId		The ID of the query performing the scan
	 * @param nodeId		The ID of this node in the DHT
	 * @param operatorId	The ID of the scan node in the query
	 * @param rt			Where to store information about new tuples created
	 * @param enableRecovery
	 * 						Whether to enable support for recovery from node failure
	 * @param phaseNo		
	 * @return				The scan operator
	 */
	PullScanOperator<M> beginScan(String relation, Operator<M> dest, WhichChild outputDest, Filter<? super QpTuple<?>> keyFilter, Filter<? super QpTuple<?>> fullFilter, Integer lastEpoch,
			int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt, boolean enableRecovery, int phaseNo);
	
	/**
	 * Start a scan of a table in the TupleStore.
	 * 
	 * @param relation		The ID of the table to scan
	 * @param dest			Where to send the results
	 * @param outputDest	Which input to send the results to
	 * @param keyFilter		A filter over the keys columns, or <code>null</code> not to
	 * 						filter based on keys. Tuple that don't match are not
	 * 						reported via RecordTuples
	 * @param fullFilter	A filter over all columns that output tuples must satisfy,
	 * 						or <code>null</code> to output all tuples that pass the key
	 * 						filter
	 * @param lastEpoch		The maximum epoch of tuples to output, or <code>null</code>
	 * 						to continue until the last epoch
	 * @param queryId		The ID of the query performing the scan
	 * @param nodeId		The ID of this node in the DHT
	 * @param operatorId	The ID of the scan node in the query
	 * @param rt			Where to store information about new tuples created
	 * @param enableRecovery
	 * 						Whether to enable support for recovery from node failure
	 * @param phaseNo		
	 * @return				The scan operator
	 */
	PullScanOperator<M> beginScan(int relation, Operator<M> dest, WhichChild outputDest, Filter<? super QpTuple<?>> keyFilter, Filter<? super QpTuple<?>> fullFilter, Integer lastEpoch,
			int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt, boolean enableRecovery, int phaseNo);
	
	PullScanOperator<M> beginScan(int relation, Set<ByteArrayWrapper> keys, Filter<? super QpTuple<?>> fullFilter, Operator<M> componentOf, int phaseNo);

	void clear() throws TupleStoreException;
	void close() throws TupleStoreException;
	
	void addTable(QpSchema ns);
	
	void dropTable(String name) throws TupleStoreException;
	void clearTable(String name) throws TupleStoreException;
	
	Map<String, QpSchema> getTables();
	
	void printStats(PrintStream ps) throws TupleStoreException;
}

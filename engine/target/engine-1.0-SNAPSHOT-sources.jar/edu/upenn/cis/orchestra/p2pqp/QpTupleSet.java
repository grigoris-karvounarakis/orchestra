package edu.upenn.cis.orchestra.p2pqp;

import java.util.Collection;

import edu.upenn.cis.orchestra.datamodel.AbstractTupleSet;

public class QpTupleSet<M> extends AbstractTupleSet<QpSchema,QpTuple<M>> {
	private static final long serialVersionUID = 1L;

	public QpTupleSet() {
	}
	
	public QpTupleSet(int initialSize) {
		super(initialSize);
	}

	public QpTupleSet(Collection<QpTuple<M>> tuples) {
		super(tuples);
	}

	@Override
	protected Class<QpSchema> getSchemaClass() {
		return QpSchema.class;
	}

}

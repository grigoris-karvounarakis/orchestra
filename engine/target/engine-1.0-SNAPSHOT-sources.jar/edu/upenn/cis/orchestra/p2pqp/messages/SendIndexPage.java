package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class SendIndexPage extends IndexMessage {
	private static final long serialVersionUID = 1L;
	public final byte[] data;
	public  final int relId, epoch, number;

	public SendIndexPage(InetSocketAddress dest, int relId, int epoch, int number, byte[] data) {
		super(dest);
		this.data = data;
		this.relId = relId;
		this.epoch = epoch;
		this.number = number;
	}

	public String toString() {
		return "SendIndexPage (" + relId + "," + epoch + "," + number + ")";
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeBytes(data);
		buf.writeInt(relId);
		buf.writeInt(epoch);
		buf.writeInt(number);
	}

	public SendIndexPage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		data = buf.readBytes();
		relId = buf.readInt();
		epoch = buf.readInt();
		number = buf.readInt();
	}
}
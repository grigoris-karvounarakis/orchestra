package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.Set;

import rice.p2p.commonapi.Node;
import rice.p2p.commonapi.NodeHandle;

public interface NodeFactory {
	/**
	 * Allocate a node in the P2P network. The node may not be ready when
	 * it is returned.
	 * 
	 * @param nodeId			The node id, or <code>null</code> to generate a new one
	 * 
	 * @return The node itself
	 */
	Node getNode(Id nodeId);

	/**
	 * Deallocate a node in the P2P network
	 * 
	 * @param n	The node to deallocate. It becomes invalid after
	 * this function is called.
	 */
	void shutdownNode(Node n);
	
	/**
	 * Get handles for other known nodes
	 * 
	 * @param nhs	Where to put the other node handles. It will be cleared
	 * @param n		The local node
	 * @return		The socket addresses of the other node handles
	 */
	Set<InetSocketAddress> getOtherNodes(Node n, Collection<NodeHandle> nhs);

	/**
	 * Determine if a node created by this factory is ready to be used
	 * 
	 * @param n			A node created by this factory
	 * @return			<code>true</code> if the node is ready,
	 * 					<code>false</code> if it is not
	 */
	boolean isReady(Node n);
	
	/**
	 * Get the number of nodes created by this factory
	 * 
	 * @return		The number of nodes
	 */
	int getCreatedCount();
	
	/**
	 * Get an IdFactory for the network type created by this NodeFactory. The
	 * IdFactory must have a public zero-argument constructor so that a copy
	 * can be created by the comparator used for the BerkeleyDB database.
	 * 
	 * @return
	 */
	IdFactory getIdFactory();
	
	NodeHandle getRemoteNodeHandle(InetSocketAddress addr);
	
	/**
	 * Deallocate any resources allocated by this node factory
	 */
	void cleanup();
	
	InetSocketAddress getAddress(NodeHandle nh);
}
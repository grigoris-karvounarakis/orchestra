package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;

import edu.upenn.cis.orchestra.datamodel.IntType;

public class ExecutionId {
	public static final int estimatedSerializedLength = 30;
	private static final int addrLen = OutputBuffer.addrLen, nodeIdBytesLen = addrLen + IntType.bytesPerShortInt; // 4 bytes for address, 2 bytes for port
	final int operatorId;
	final InetSocketAddress nodeId;
	final int tupleCount;
	private int hashCode = 0;
	private final byte[] contributingNodes;
	final int phaseNo;
	
	static final int UNKNOWN_PHASE_NO = -1;

	ExecutionId(int operatorId, InetSocketAddress nodeId, int tupleCount, byte[] contributingNodes, int phaseNo) {
		this.operatorId = operatorId;
		this.nodeId = nodeId;
		this.tupleCount = tupleCount;
		if (contributingNodes != null && (contributingNodes.length == 0 || (contributingNodes.length % nodeIdBytesLen != 0))) {
			throw new IllegalArgumentException("Length of contributingNodes must be positive multiple of " + nodeIdBytesLen);
		}
		this.contributingNodes = contributingNodes;
		this.phaseNo = phaseNo;
	}

	public boolean equals(Object o) {
		if (o == null || o.getClass() != this.getClass()) {
			return false;
		}

		ExecutionId ti = (ExecutionId) o;
		return (operatorId == ti.operatorId
				&& tupleCount == ti.tupleCount && nodeId.equals(ti.nodeId));
	}

	public int hashCode() {
		if (hashCode == 0) {
			hashCode =  nodeId.hashCode() + 31 * operatorId + 127 * tupleCount;
		}
		return hashCode;
	}

	public byte[] getBytes() {
		byte[] addressBytes = nodeId.getAddress().getAddress();
		byte[] retval = new byte[3 * IntType.bytesPerInt + IntType.bytesPerShortInt + addrLen + (contributingNodes == null ? 0 : contributingNodes.length)];
		IntType.putBytes(operatorId, retval, 0);
		IntType.putBytes(tupleCount, retval, IntType.bytesPerInt);
		IntType.putBytes(phaseNo, retval, 2 * IntType.bytesPerInt);
		IntType.getShortValBytes(nodeId.getPort(), retval, 3 * IntType.bytesPerInt);
		System.arraycopy(addressBytes, 0, retval, 3 * IntType.bytesPerInt + IntType.bytesPerShortInt, addressBytes.length);
		if (contributingNodes != null) {
			System.arraycopy(contributingNodes, 0, retval, 3 * IntType.bytesPerInt + IntType.bytesPerShortInt + addrLen, contributingNodes.length);
		}
		return retval;
	}

	public static ExecutionId fromBytes(byte[] bytes) {
		if (bytes == null) {
			return null;
		}
		return fromBytes(bytes, 0, bytes.length);
	}

	public static ExecutionId fromBytes(byte[] bytes, int offset, int length) {
		if (bytes == null) {
			return null;
		}
		int operatorId = IntType.getValFromBytes(bytes, offset, IntType.bytesPerInt);
		int tupleCount = IntType.getValFromBytes(bytes, offset + IntType.bytesPerInt, IntType.bytesPerInt);
		int phaseNo = IntType.getValFromBytes(bytes, offset + 2 * IntType.bytesPerInt, IntType.bytesPerInt);		
		int nodeIdPort = IntType.getShortValFromBytes(bytes, offset + 3 * IntType.bytesPerInt, IntType.bytesPerShortInt);
		byte[] nodeIdAddress = new byte[addrLen];
		System.arraycopy(bytes, offset + 3 * IntType.bytesPerInt + IntType.bytesPerShortInt, nodeIdAddress, 0, nodeIdAddress.length);
		byte[] contributingNodes = null;
		int contributingNodesLength = length - (3 * IntType.bytesPerInt + IntType.bytesPerShortInt + addrLen);
		if (contributingNodesLength > 0) {
			contributingNodes = new byte[contributingNodesLength];
			System.arraycopy(bytes, offset + 3 * IntType.bytesPerInt + IntType.bytesPerShortInt + addrLen, contributingNodes, 0, contributingNodesLength);
		}
		try {
			return new ExecutionId(operatorId, new InetSocketAddress(InetAddress.getByAddress(nodeIdAddress), nodeIdPort), tupleCount, contributingNodes, phaseNo);
		} catch (UnknownHostException e) {
			throw new IllegalArgumentException("IP Address has incorrect length", e);
		}
	}

	static class Factory {
		private final int operatorId;
		private int nextTuple;
		private final InetSocketAddress nodeId;
		private final byte[] nodeIdBytes;

		Factory(boolean includeNodeIds, int operatorId, InetSocketAddress nodeId) {
			this(includeNodeIds,operatorId,nodeId,0);
		}

		Factory(boolean includeNodeIds, int operatorId, InetSocketAddress nodeId, int nextTuple) {
			this.operatorId = operatorId;
			this.nextTuple = nextTuple;
			this.nodeId = nodeId;
			if (includeNodeIds) {
				nodeIdBytes = new byte[nodeIdBytesLen];
				System.arraycopy(nodeId.getAddress().getAddress(), 0, nodeIdBytes, 0, addrLen);
				IntType.getShortValBytes(nodeId.getPort(), nodeIdBytes, addrLen);
			} else {
				nodeIdBytes = null;
			}
		}

		ExecutionId next(int phaseNo) {
			int tupleId;
			synchronized (this) {
				tupleId = nextTuple++;
			}
			return new ExecutionId(operatorId, nodeId, tupleId, nodeIdBytes, phaseNo);
		}

		ExecutionId next(ExecutionId inputId) {
			int tupleId;
			synchronized (this) {
				tupleId = nextTuple++;
			}
			if (nodeIdBytes == null) {
				return new ExecutionId(operatorId, nodeId, tupleId, null, inputId.phaseNo);
			} else if (contains(nodeIdBytes, 0, nodeIdBytes.length, inputId.contributingNodes)) {
				return new ExecutionId(operatorId, nodeId, tupleId, inputId.contributingNodes, inputId.phaseNo);
			} else {
				byte[] newContributingNodes = new byte[nodeIdBytes.length + inputId.contributingNodes.length];
				System.arraycopy(nodeIdBytes, 0, newContributingNodes, 0, nodeIdBytes.length);
				System.arraycopy(inputId.contributingNodes, 0, newContributingNodes, nodeIdBytes.length, inputId.contributingNodes.length);
				return new ExecutionId(operatorId, nodeId, tupleId, newContributingNodes, inputId.phaseNo);
			}
		}

		ExecutionId next(ExecutionId inputId, byte[] nodeIdToAdd) {
			byte[] toAdd = new byte[2 * nodeIdBytesLen];
			int toAddPos = 0;
			int tupleId;
			synchronized (this) {
				tupleId = nextTuple++;
			}
			if (nodeIdBytes == null) {
				throw new IllegalStateException();
			}
			if (! contains(nodeIdBytes, 0, nodeIdBytes.length, inputId.contributingNodes)) {
				System.arraycopy(nodeIdBytes, 0, toAdd, toAddPos, nodeIdBytesLen);
				toAddPos += nodeIdBytesLen;
			}
			if (! contains(nodeIdToAdd, 0, nodeIdToAdd.length, inputId.contributingNodes)) {
				System.arraycopy(nodeIdToAdd, 0, toAdd, toAddPos, nodeIdBytesLen);
				toAddPos += nodeIdBytesLen;
			}
			if (toAddPos == 0) {
				return new ExecutionId(operatorId, nodeId, tupleId, inputId.contributingNodes, inputId.phaseNo);
			} else {
				byte[] newContributingNodes = new byte[toAddPos + inputId.contributingNodes.length];
				System.arraycopy(toAdd, 0, newContributingNodes, 0, toAddPos);
				System.arraycopy(inputId.contributingNodes, 0, newContributingNodes, toAddPos, inputId.contributingNodes.length);
				return new ExecutionId(operatorId, nodeId, tupleId, newContributingNodes, inputId.phaseNo);
			}
		}

		ExecutionId next(ExecutionId inputId1, ExecutionId inputId2, int phaseNo) {
			int tupleId;
			synchronized (this) {
				tupleId = nextTuple++;
			}
			if (nodeIdBytes == null) {
				return new ExecutionId(operatorId, nodeId, tupleId, null, phaseNo);
			}
			byte [] newContributingNodes;
			if (contains(nodeIdBytes, 0, nodeIdBytes.length, inputId1.contributingNodes)) {
				newContributingNodes = inputId1.contributingNodes;
			} else {
				newContributingNodes = new byte[nodeIdBytes.length + inputId1.contributingNodes.length];
				System.arraycopy(nodeIdBytes, 0, newContributingNodes, 0, nodeIdBytes.length);
				System.arraycopy(inputId1.contributingNodes, 0, newContributingNodes, nodeIdBytes.length, inputId1.contributingNodes.length);
			}

			byte[] additionalContributingNodes = new byte[inputId2.contributingNodes.length];
			int numAdditionalContributingNodes = 0;
			for (int pos = 0; pos < inputId2.contributingNodes.length; pos += nodeIdBytesLen) {
				if (! contains(inputId2.contributingNodes, pos, nodeIdBytesLen, newContributingNodes)) {
					System.arraycopy(inputId2.contributingNodes, pos, additionalContributingNodes,
							numAdditionalContributingNodes * nodeIdBytesLen, nodeIdBytesLen);
					++numAdditionalContributingNodes;
				}
			}
			byte[] combinedContributingNodes;
			if (numAdditionalContributingNodes == 0) {
				combinedContributingNodes = newContributingNodes;
			} else {
				combinedContributingNodes = new byte[newContributingNodes.length + numAdditionalContributingNodes * nodeIdBytesLen];
				System.arraycopy(newContributingNodes, 0, combinedContributingNodes, 0, newContributingNodes.length);
				System.arraycopy(additionalContributingNodes, 0, combinedContributingNodes, newContributingNodes.length, numAdditionalContributingNodes * nodeIdBytesLen);
			}

			return new ExecutionId(operatorId, nodeId, tupleId, combinedContributingNodes, phaseNo);
		}		
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder("[" + operatorId + ":" + nodeId.toString() + ":" + tupleCount);
		if (contributingNodes != null) {
			sb.append(" {");
			try {
				for (int i = 0; i < contributingNodes.length; i += nodeIdBytesLen) {
					byte[] addrBytes = new byte[addrLen];
					System.arraycopy(contributingNodes, i, addrBytes, 0, addrLen);
					InetAddress addr = InetAddress.getByAddress(addrBytes);
					int port = IntType.getShortValFromBytes(contributingNodes, i + addrLen, IntType.bytesPerShortInt);
					InetSocketAddress isa = new InetSocketAddress(addr, port);
					sb.append(isa);
					if (i + nodeIdBytesLen < contributingNodes.length) {
						sb.append(",");
					}
				}
			} catch (UnknownHostException e) {
				throw new RuntimeException(e);
			}
			sb.append("}");
		}
		sb.append("]");
		return sb.toString();
	}

	private static boolean contains(byte[] arg1, final int arg1offset, final int length, byte[] arg2) {
		POS: for (int arg2offset = 0; arg2offset < arg2.length; arg2offset += length) {
			for (int i = 0; i < length; ++i) {
				if (arg1[arg1offset + i] != arg2[arg2offset+i]) {
					continue POS;
				}
			}
			return true;
		}
	return false;
	}

	public boolean containsNodeId(byte[] nodeId) {
		if (nodeId.length != nodeIdBytesLen){
			throw new IllegalArgumentException("Node ID length must be " + nodeIdBytesLen + " bytes");
		}
		return contains(nodeId, 0, nodeId.length, contributingNodes);
	}
	
	public static byte[] getNodeIdBytes(InetSocketAddress nodeId) {
		byte[] nodeIdBytes = new byte[nodeIdBytesLen];
		System.arraycopy(nodeId.getAddress().getAddress(), 0, nodeIdBytes, 0, addrLen);
		IntType.getShortValBytes(nodeId.getPort(), nodeIdBytes, addrLen);
		return nodeIdBytes;
	}
	
	public void serialize(OutputBuffer buf) {
		buf.writeInt(operatorId);
		buf.writeInetSocketAddress(nodeId);
		buf.writeInt(tupleCount);
		buf.writeInt(phaseNo);
		buf.writeBytes(contributingNodes);
	}
	
	public static ExecutionId deserialize(InputBuffer buf) {
		int operatorId = buf.readInt();
		InetSocketAddress nodeId = buf.readInetSocketAddress();
		int tupleCount = buf.readInt();
		int phaseNo = buf.readInt();
		byte[] contributingNodes = buf.readBytes();
		return new ExecutionId(operatorId, nodeId, tupleCount, contributingNodes, phaseNo);
	}
}

package edu.upenn.cis.orchestra.p2pqp.messages;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetSocketAddress;

import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.Message;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpMessage;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class ReplyException extends QpMessage {
	private static final long serialVersionUID = 1L;

	public final String what;
	public final Exception why;

	public ReplyException(Message origMessage, String what, Exception why, boolean canRetry) {
		super(origMessage, canRetry);
		this.what = what;
		this.why = why;
	}

	public String toString() {
		String start = "ReplyException ("+ what + ")";
		if (why == null) {
			return start;
		} else {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			pw.append(start);
			pw.append(": ");
			why.printStackTrace(pw);
			pw.close();
			return sw.toString();
		}
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeString(what);
		buf.writeObject(why);
	}

	public ReplyException(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);

		what = buf.readString();
		this.why = (Exception) buf.readObject();
	}
}
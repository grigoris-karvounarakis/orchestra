package edu.upenn.cis.orchestra.p2pqp.messages;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.STORE;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.upenn.cis.orchestra.datamodel.ByteBufferReader;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.MetadataFactory;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class InsertTuplesMessage extends DHTMessage {
	private static final long serialVersionUID = 1L;
	private final byte[] tuples;

	public <M> InsertTuplesMessage(InetSocketAddress dest, Collection<QpTuple<M>> tuples, MetadataFactory<M> mdf) {
		super(dest);

		if (tuples.isEmpty()) {
			throw new IllegalArgumentException("Should not try to insert no tuples");
		}

		Map<Integer,List<QpTuple<M>>> toInsert = new HashMap<Integer,List<QpTuple<M>>>();
		for (QpTuple<M> t : tuples) {
			int relId = t.getSchema().relId;
			List<QpTuple<M>> forRel = toInsert.get(relId);
			if (forRel == null) {
				forRel = new ArrayList<QpTuple<M>>();
				toInsert.put(relId, forRel);
			}
			forRel.add(t);
		}
		
		ByteBufferWriter bbw = new ByteBufferWriter();
		for (Map.Entry<Integer, List<QpTuple<M>>> me : toInsert.entrySet()) {
			bbw.addToBuffer(me.getKey());
			bbw.addToBuffer(me.getValue().size());
			for (QpTuple<M> t : me.getValue()) {
				bbw.addToBuffer(t.getBytes(STORE, mdf));
			}
		}
		
		this.tuples = bbw.getByteArray();
	}

	public <M> List<QpTuple<M>> getTuples(QpSchema.Source schemas, MetadataFactory<M> mdf, List<byte[]> serialized) {
		if (! serialized.isEmpty()) {
			throw new IllegalArgumentException("serialized shoud be empty");
		}
		List<QpTuple<M>> retval = new ArrayList<QpTuple<M>>();
		ByteBufferReader bbr = new ByteBufferReader(tuples);

		while (! bbr.hasFinished()) {
			int relId = bbr.readInt();
			int num = bbr.readInt();
			QpSchema schema = schemas.getSchema(relId);
			while (num > 0) {
				byte[] bytes = bbr.readByteArray();
				retval.add(QpTuple.fromBytes(STORE, schema, schemas, mdf, bytes, null));
				serialized.add(bytes);
				--num;
			}
		}
		return retval;
	}

	public String toString() {
		return "InsertTuples";
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeBytes(tuples);
	}

	public InsertTuplesMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		tuples = buf.readBytes();
	}
}


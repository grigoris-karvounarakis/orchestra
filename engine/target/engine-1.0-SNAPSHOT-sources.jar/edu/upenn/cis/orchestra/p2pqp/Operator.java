package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.Collections;
import java.util.List;

import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public abstract class Operator<M> {
	public static class OperatorCreationException extends Exception {
		private static final long serialVersionUID = 1L;
	
		public OperatorCreationException(String what, Throwable why) {
			super(what,why);
		}
		
		public OperatorCreationException(String what) {
			super(what);
		}
		
		public OperatorCreationException(Throwable why) {
			super(why);
		}
	}

	final int operatorId;
	protected final boolean enableRecovery;
	private final RecordTuples rt;
	private final Operator<M> dest;
	private final WhichChild destInput;
	
	protected WhichChild getDestInput() {
		return destInput;
	}
	
	public Operator<M> getDest() {
		return dest;
	}

	private final ExecutionId.Factory idFactory;
	
	protected final MetadataFactory<M> mdf;
	
	protected Operator(int operatorId, MetadataFactory<M> mdf, RecordTuples rt) {
		this(null,null,operatorId, mdf, rt);
	}

	protected Operator(int queryId, InetSocketAddress nodeId, int operatorId, MetadataFactory<M> mdf, RecordTuples rt, boolean enableRecovery) {
		this(null, null, queryId, nodeId, operatorId, mdf, rt, enableRecovery);
	}
	
	protected Operator(Operator<M> dest, WhichChild destInput, int operatorId, MetadataFactory<M> mdf, RecordTuples rt) {
		this(dest, destInput, -1, null, operatorId, mdf, rt, false);
	}

	protected Operator(Operator<M> dest, WhichChild destInput, int queryId,
			InetSocketAddress nodeId, int operatorId, MetadataFactory<M> mdf, RecordTuples rt, boolean enableRecovery) {
		if (nodeId == null) {
			idFactory = null;
		} else {
			idFactory = new ExecutionId.Factory(enableRecovery, operatorId, nodeId);			
		}
		this.rt = rt;
		this.operatorId = operatorId;
		this.dest = dest;
		this.destInput = destInput;
		if (mdf == null || mdf instanceof NullMetadataFactory) {
			this.mdf = null;
		} else {
			this.mdf = mdf;
		}
		this.enableRecovery = enableRecovery;
	}

	protected Operator(Operator<M> componentOf) {
		this.dest = componentOf.dest;
		this.destInput = componentOf.destInput;
		this.rt = componentOf.rt;
		this.operatorId = componentOf.operatorId;
		this.idFactory = componentOf.idFactory;
		this.mdf = componentOf.mdf;
		this.enableRecovery = componentOf.enableRecovery;
	}
	
	protected final ExecutionId getFreshId(ExecutionId derivedFrom, byte[] nodeIdToAdd) {
		if (idFactory == null) {
			throw new RuntimeException("Cannot call getFreshId on an Operator that cannot create new tuples");
		}

		return idFactory.next(derivedFrom, nodeIdToAdd);
	}
	
	/**
	 * Get a tuple ID. The ID must be reported using tuplesAdded()
	 * 
	 * @param	The phase number to assign to the ID
	 * @return	A fresh tuple ID
	 */
	protected final ExecutionId getFreshId(int phaseNo) {
		if (idFactory == null) {
			throw new RuntimeException("Cannot call getFreshId on an Operator that cannot create new tuples");
		}

		return idFactory.next(phaseNo);
	}
	
	/**
	 * Get a tuple ID. The ID must be reported using tuplesAdded()
	 * 
	 * @param derivedFrom			An execution ID to copy the set of contributing nodes from
	 * @return	A fresh tuple ID
	 */
	protected final ExecutionId getFreshId(ExecutionId derivedFrom) {
		if (idFactory == null) {
			throw new RuntimeException("Cannot call getFreshId on an Operator that cannot create new tuples");
		}

		return idFactory.next(derivedFrom);
	}
	
	/**
	 * Get a tuple ID. The ID must be reported using tuplesAdded()
	 * 
	 * @param derivedFrom1			An execution ID to copy the set of contributing nodes from
	 * @param derivedFrom2			Another execution ID to copy the set of contributing nodes from
	 * @param phaseNo				The phase in which the derived tuple exists
	 * @return	A fresh tuple ID
	 */
	protected final ExecutionId getFreshId(ExecutionId derivedFrom1, ExecutionId derivedFrom2, int phaseNo) {
		if (idFactory == null) {
			throw new RuntimeException("Cannot call getFreshId on an Operator that cannot create new tuples");
		}

		return idFactory.next(derivedFrom1, derivedFrom2, phaseNo);
	}

	protected void keysScanned(List<QpTuple<?>> keys, int phaseNo) {
		rt.keysScanned(operatorId, keys, phaseNo);
	}

	/**
	 * Deliver tuples to an operator.
	 * 
	 * @param tuples			The tuples to deliver. The tuples list will not be modified by the caller
	 * 							until after this method returns, but it may be modified after that time.
	 * 							The callee may modify the array (i.e. to clear tuples that have been processed)
	 */
	protected abstract void receiveTuples(List<QpTuple<M>> tuples);

	protected void close() {
		
	}
	
	void waitUntilFinished() throws InterruptedException {
		
	}
	
	protected final void tuplesAdded(List<ExecutionId> tids) {
		if (rt == null) {
			throw new RuntimeException("Cannot call tupleRemoved on an Operator that cannot record removed tuples");
		}
		rt.tuplesAdded(tids);
	}

	protected final void tuplesRemoved(List<ExecutionId> tids) {
		if (rt == null) {
			throw new RuntimeException("Cannot call tupleRemoved on an Operator that cannot record removed tuples");
		}
		rt.tuplesRemoved(tids);
	}

	protected void sendTuples(List<QpTuple<M>> tuples) {
		for (QpTuple<M> t : tuples) {
			t.setDest(destInput);
		}
		dest.receiveTuples(tuples);
	}
	
	protected void reportException(Exception e) {
		if (rt == null) {
			throw new RuntimeException("Cannot report exception without RecordTuples");
		}
		rt.reportException(e);
	}
	
	protected void reportMissing(List<QpTuple<?>> keys, int phaseNo) {
		rt.keysNotFound(operatorId, keys, phaseNo);
	}
	
	protected void disposeOfFailedTuples(int newPhaseNo, byte[][] failedNodeIds) {
		
	}
	
	protected void reportNodeFailure(InetSocketAddress node) {
		rt.nodesHaveFailed(Collections.singleton(node));
	}
}

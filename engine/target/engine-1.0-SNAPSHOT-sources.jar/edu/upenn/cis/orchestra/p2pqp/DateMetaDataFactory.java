package edu.upenn.cis.orchestra.p2pqp;
import java.util.Collection;
import java.util.Date;

import edu.upenn.cis.orchestra.datamodel.TimestampType;
import edu.upenn.cis.orchestra.p2pqp.QpSchema.Source;

public class DateMetaDataFactory implements MetadataFactory<Date> {

	private static final DateMetaDataFactory instance;
	

	static {
		instance = new DateMetaDataFactory();
	}
	
	public static DateMetaDataFactory getInstance() {
		return instance;
	}
	
	public Date agg(Operator<Date> o, Collection<Date> inputs) {
		// TODO Auto-generated method stub
		return null;
	}

	public Date applyFunctions(Operator<Date> o, Date m) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public long funcEval(Statistics.Func conFunc, Statistics.Func aggFunc, Date m) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public String printMetadata(Date m) {
		return m.toString();
	}

	public Date fromBytes(Source findSchema, IdFactory idf, MetadataFactory<Date> mdf, byte[] bytes, ExecutionId tupleId) {
		return TimestampType.getValFromBytes(bytes);
	}

	public Date derive(Operator<Date> o, Date metadata) {
		// For now, deriving a tuple from another date returns the same date.
		
		return (Date)metadata.clone();
	}
	
	public Date join(Operator<Date> o, Date leftMetadata, Date rightMetadata) {
		// For now, joining two dates returns the date midway between the two.
		
		return new Date((leftMetadata.getTime() + rightMetadata.getTime())/2);
	}

	public Date scan(Operator<Date> o, Date inStorage) {
		// TODO Auto-generated method stub
		return null;
	}

	public byte[] toBytes(Date m) {
		return TimestampType.getBytes(m);
		
	}

	public Date combineMetadata(Date origMetadata, Date addedMetadata) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean shouldDelete(Date m) {
		// TODO Auto-generated method stub
		return false;
	}

    public Date differenceMetadata(Date newMetadata, Date oldMetadata) {
    	// TODO Auto-generated method stub
	    return null;
    }
    
    public Date duplicate(Date m) {
    	return (Date) m.clone();
    }
 
}

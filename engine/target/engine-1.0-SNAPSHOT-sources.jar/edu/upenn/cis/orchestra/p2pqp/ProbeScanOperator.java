package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.upenn.cis.orchestra.p2pqp.Filter.FilterException;
import edu.upenn.cis.orchestra.p2pqp.IndexService.EpochNum;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.p2pqp.TupleStore.TupleSink;
import edu.upenn.cis.orchestra.p2pqp.TupleStore.TupleStoreException;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;

public class ProbeScanOperator<M> extends Operator<M> implements KeyReceiver {

	private final Filter<? super QpTuple<?>> filter;
	private final TupleStore<M> ts;
	final QpSchema probeSchema;
	private final List<Set<EpochNum>> alreadyScanned;
	
	public ProbeScanOperator(QpSchema probeSchema, Filter<? super QpTuple<?>> filter, TupleStore<M> ts, Operator<M> dest,
			WhichChild destInput, int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt,
			MetadataFactory<M> mdf, boolean enableRecovery) {
		super(dest, destInput, queryId, nodeId, operatorId, mdf, rt, enableRecovery);
		this.filter = filter;
		this.ts = ts;
		this.probeSchema = probeSchema;
		alreadyScanned = new ArrayList<Set<EpochNum>>();
	}

	protected void receiveTuples(List<QpTuple<M>> tuples) {
		throw new UnsupportedOperationException("Should never send tuples to a scan operator");
	}

	public void receiveKeys(final int phaseNo, EpochNum page, Collection<ByteArrayWrapper> keys) {
		synchronized (alreadyScanned) {
			while (alreadyScanned.size() <= phaseNo) {
				alreadyScanned.add(new HashSet<EpochNum>());
			}
			// Don't scan a page multiple times
			if (! alreadyScanned.get(phaseNo).add(page)) {
				return;
			}
		}
		if (keys.isEmpty()) {
			return;
		}
		ts.getTuples(probeSchema.relId, keys, new TupleSink<M>() {
			public void deliverTuples(Collection<QpTuple<M>> tuples) {
				List<QpTuple<?>> keysScanned = new ArrayList<QpTuple<?>>(tuples.size());
				List<ExecutionId> tuplesAdded = new ArrayList<ExecutionId>(tuples.size());
				List<QpTuple<M>> results = new ArrayList<QpTuple<M>>(tuples.size());
				try {
					for (QpTuple<M> retrieved : tuples) {
						QpTuple<?> key = retrieved.getKeyTuple();
						keysScanned.add(key);
						if (filter == null || filter.eval(retrieved)) {
							QpTuple<M> added = retrieved.changeId(getFreshId(phaseNo));
							results.add(added);
							tuplesAdded.add(added.getId());
						}
					}
				} catch (FilterException fe) {
					reportException(fe);
				}
				tuplesAdded(tuplesAdded);
				keysScanned(keysScanned, phaseNo);
				sendTuples(results);
			}

			public void processException(TupleStoreException tse) {
				reportException(tse);
			}

			public void tupleNotFound(QpTuple<?> key) {
				List<QpTuple<?>> missing = new ArrayList<QpTuple<?>>(1);
				missing.add(key);
				reportMissing(missing, phaseNo);
			}
		});		
	}

}

package edu.upenn.cis.orchestra.p2pqp.plan;

import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.p2pqp.UnionOperator;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.Operator;
import edu.upenn.cis.orchestra.p2pqp.QueryExecution;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class UnionNode extends TwoInputQueryPlan {
	private static final long serialVersionUID = 1L;

	public UnionNode(QpSchema outputSchema, Location loc, QueryPlan left, QueryPlan right, int operatorId) {
		super(outputSchema.getRelationName(), loc, left, right, operatorId); 
	}
	
	@Override
	<M> Operator<M> createOperator(QueryExecution<M> exec, Operator<M> parent, WhichChild dest, boolean allowRecovery)
	throws Operator.OperatorCreationException {
	
		QpSchema outputSchema = exec.getSchema(this.outputSchema);
		
		return new UnionOperator<M>(exec.app, left.outputSchema, right.outputSchema, 
				  outputSchema, parent, dest, operatorId, exec.getRecordTuples(), exec.app.getMetadataFactory());
		
	}
	@Override
	protected boolean subclassEquals(TwoInputQueryPlan jqp) {
		if (jqp instanceof UnionNode) {
			return true;
		} else {
			return false;
		}
	}
	@Override
	void serialize(Document doc, Element el, Map<String, QpSchema> schemas) {
		serializeHelper(doc, el, schemas);
	}

	
	public static UnionNode deserialize(Element el, Map<String,QpSchema> schemas, Set<Integer> alreadyIds) throws XMLParseException {
		QueryPlanData qpd = deserializeHelper(el);
		QueryPlan leftInput = getLeftInput(el, schemas, alreadyIds);
		QueryPlan rightInput = getRightInput(el, schemas, alreadyIds);
		
		UnionNode ret = new UnionNode(schemas.get(qpd.outputSchema), qpd.loc,
				 leftInput, rightInput, qpd.operatorId);
		return ret;
	}

}

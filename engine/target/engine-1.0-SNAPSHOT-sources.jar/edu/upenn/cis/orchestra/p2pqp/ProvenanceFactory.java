package edu.upenn.cis.orchestra.p2pqp;


public class ProvenanceFactory {
	public enum PROV_TYPE {
		COUNT_PROVENANCE,
		ABSORP_PROVENANCE,
		RELATIVE_PROVENANCE
	};
	
	public static PROV_TYPE defaultProvenance = PROV_TYPE.ABSORP_PROVENANCE;
	
	public static <M> TupleProvenance getProvenanceFor(int opid, KeyandEpoch key) {
		return getProvenanceFor(opid, key, defaultProvenance);
	}
		
	public static <M> TupleProvenance getProvenanceFor(int opid, KeyandEpoch key, PROV_TYPE typ) {
		if (typ == PROV_TYPE.ABSORP_PROVENANCE)
			return new AbsorptionProvenance(key);
		else if (typ == PROV_TYPE.COUNT_PROVENANCE)
			return new CountProvenance();
		else if (typ == PROV_TYPE.RELATIVE_PROVENANCE)
			return new RelativeProvenance(key, opid);
		
		return null;
		
	}
	
	public static TupleProvenance fromBytes(byte[] bytes) {
		return fromBytes(bytes, defaultProvenance);
	}
	
	public static TupleProvenance fromBytes(byte[] bytes, PROV_TYPE typ) {
		if (typ == PROV_TYPE.ABSORP_PROVENANCE)
			return AbsorptionProvenance.fromBytes(bytes);
		else if (typ == PROV_TYPE.COUNT_PROVENANCE)
			return CountProvenance.fromBytes(bytes);
		else if (typ == PROV_TYPE.RELATIVE_PROVENANCE)
			return RelativeProvenance.fromBytes(bytes);
		
		return null;
	}	
}

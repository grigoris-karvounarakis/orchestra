package edu.upenn.cis.orchestra.p2pqp;

import java.net.InetSocketAddress;
import java.util.List;

import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

abstract class PullScanOperator<M> extends Operator<M> {
	PullScanOperator(Operator<M> dest, WhichChild outputDest, int queryId, InetSocketAddress nodeId, int operatorId, RecordTuples rt, MetadataFactory<M> mdf, boolean enableRecovery) {
		super(dest, outputDest, queryId, nodeId, operatorId, mdf, rt, enableRecovery);
	}
	PullScanOperator(Operator<M> dest, WhichChild outputDest, int operatorId) {
		super(dest,outputDest,operatorId,null,null);
	}
	PullScanOperator(Operator<M> componentOf) {
		super(componentOf);
	}
	
	public abstract void scan(int blockSize, int phaseNo);
	public abstract void scanAll(int blockSize, int phaseNo);	
	public abstract boolean isFinished(int phaseNo);
	protected final void receiveTuples(List<QpTuple<M>> tuples) {
		throw new UnsupportedOperationException("Cannot deliver tuples to a scan operator (" + this.getClass().getName() + ")");
	}
	
	public abstract void interrupt(int phaseNo);
	
	boolean canRescan() {
		return false;
	}
}
package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.Arrays;

import rice.p2p.commonapi.Endpoint;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public abstract class QpMessage extends Message {
	static final int initialNumIds = 10;
	private static final long serialVersionUID = 1L;
	private final long[] inReplyTo;
	private InetSocketAddress dest;
	private final Id destId;
	private final boolean canRetry;

	/**
	 * Construct a message that will be routed to the node that owns
	 * a particular Id in the network
	 * 
	 * @param destId		The Id to route to
	 */
	protected QpMessage(Id destId) {
		this.inReplyTo = null;
		this.destId = destId;
		this.dest = null;
		canRetry = false;
	}

	/**
	 * Construct a message that is a reply to another message. It will
	 * be send back directly to the node that send the original message.
	 * canRetry is set to false.
	 * 
	 * @param inReplyTo		The message to reply to
	 */
	protected QpMessage(Message inReplyTo) {
		this(inReplyTo,false);
	}

	/**
	 * Construct a message that is a reply to another message. It will
	 * be send back directly to the node that send the original message
	 * 
	 * @param inReplyTo		The message to reply to
	 * @param canRetry		If this message indicates a failure, whether
	 * 						retrying may give a success
	 */
	protected QpMessage(Message inReplyTo, boolean canRetry) {
		if (inReplyTo.getOrigin() == null) {
			throw new IllegalArgumentException("Cannot construct a reply to a message without an origin");
		}
		this.inReplyTo = new long[] {inReplyTo.messageId};
		this.dest = inReplyTo.getOrigin();
		this.destId = null;
		this.canRetry = canRetry;
	}

	protected QpMessage(InetSocketAddress dest, long[] msgIds) {
		if (dest == null) {
			throw new IllegalArgumentException("Cannot have a reply to no destination");
		}
		if (msgIds.length == 0) {
			throw new IllegalArgumentException("Cannot have reply to no messages");
		}
		this.inReplyTo = msgIds;
		this.dest = dest;
		this.destId = null;
		this.canRetry = false;
	}

	/**
	 * Construct a message that will be sent directly to another node
	 * 
	 * @param destNH
	 */
	protected QpMessage(InetSocketAddress dest) {
		this.inReplyTo = null;
		this.dest = dest;
		this.destId = null;
		canRetry = false;
	}

	public final boolean isReply() {
		return inReplyTo != null;
	}

	protected long[] getOrigIds() {
		if (inReplyTo == null) {
			return null;
		}
		long[] retval = new long[inReplyTo.length];
		System.arraycopy(inReplyTo, 0, retval, 0, retval.length);
		return retval;
	}

	protected String getOrigIdsString() {
		if (inReplyTo == null) {
			return "";
		}

		if (inReplyTo.length < 5) {
			return Arrays.toString(inReplyTo);
		} else {
			return "...";
		}
	}

	int getNumOrigIds() {
		if (inReplyTo == null) {
			return 0;
		} else {
			return inReplyTo.length;
		}
	}

	public Id getDestId() {
		return destId;
	}


	protected InetSocketAddress getDest() {
		return dest;
	}

	public void serialize(OutputBuffer buf) {
		buf.writeLong(messageId);
		if (inReplyTo == null) {
			buf.writeInt(-1);
		} else {
			buf.writeInt(inReplyTo.length);
			for (int i = 0; i < inReplyTo.length; ++i) {
				buf.writeLong(inReplyTo[i]);
			}
		}

		if (destId == null) {
			buf.writeBoolean(false);
		} else {
			buf.writeBoolean(true);
			destId.serialize(buf);
		}

		buf.writeBoolean(canRetry);
		subclassSerialize(buf);
	}

	protected QpMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf.readLong(), origin);
		int numInReplyTo = buf.readInt();
		if (numInReplyTo < 0) {
			inReplyTo = null;
		} else {
			inReplyTo = new long[numInReplyTo];
			for (int i = 0; i < numInReplyTo; ++i) {
				inReplyTo[i] = buf.readLong();
			}
		}

		boolean hasDestId = buf.readBoolean();
		if (hasDestId) {
			destId = Id.deserialize(buf);
		} else {
			destId = null;
		}

		canRetry = buf.readBoolean();
	}


	protected abstract void subclassSerialize(OutputBuffer buf);

	static InetSocketAddress readAddress(InputBuffer buf) throws SerializationException {
		try {
			return new InetSocketAddress(InetAddress.getByAddress(buf.readBytes()),
					buf.readInt());
		} catch (UnknownHostException e) {
			throw new SerializationException("Error decoding message origin", e);
		}
	}

	@Override
	final void sendImpl(Router r, SocketManager sm, Endpoint e) throws IOException, InterruptedException {
		if (destId != null) {
			dest = r.getDest(destId);
		}
		sm.sendMessage(this);
	}

	protected boolean canRetry() {
		return canRetry;
	}

	public boolean hasDestId() {
		return destId != null;
	}
}
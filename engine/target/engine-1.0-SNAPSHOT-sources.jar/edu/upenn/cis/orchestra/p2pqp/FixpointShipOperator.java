package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.datamodel.Subtuple;
import edu.upenn.cis.orchestra.datamodel.Type;
import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.datamodel.exceptions.NotNumericalException;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.optimization.Aggregate.AggFunc;
import edu.upenn.cis.orchestra.p2pqp.messages.RehashTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplySuccess;
import edu.upenn.cis.orchestra.p2pqp.messages.ShippedTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.plan.AggregateNode.OutputColumn;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public class FixpointShipOperator<M> extends BlockingOperator<M> {
	public static final int defaultBufferSize = 10000;
	public static boolean defaultBufferingChoice = true;
	private int[] groupingColumns = null;
	private OutputColumn[] outputColumns = null;
	//TODO: need to reconsider aggregateTable
	private final HashMap<Subtuple,Collection<QpTuple<Null>>> aggregateTable;
	private final HashMap<Subtuple,List<QpTuple<Null>>> aggregateTuples;
	private final HashMap<QpTuple<Null>,M> aggregateMetadata;
	private final HashMap<QpTuple<Null>,M> insertMetadata;
	private final HashMap<QpTuple<Null>,M> deleteMetadata;
	private final HashMap<QpTuple<Null>,M> sentMetadata;
	final private FixpointShipThread sendThread;
	//boolean finished;
	final private QpApplication<M> app;
	final private InetSocketAddress destAddress;
	final private int queryId;
	private List<QpTuple<M>> pendingToShip;
	final private QpSchema newSchema;
	final private Map<Integer,Integer> newSchemaMapping;
	final private String namedDest;

	private final Logger logger = Logger.getLogger(this.getClass());

	private Set<Long> outstandingMessages = Collections.synchronizedSet(new HashSet<Long>());


	public FixpointShipOperator(QpApplication<M> app, List<Integer> groupingColumns, List<OutputColumn> outputColumns, Operator<M> destOperator, WhichChild dest, InetSocketAddress destAddress, String namedDest, InetSocketAddress nodeId, int queryId, int operatorId, MetadataFactory<M> mdf, RecordTuples rt) {
		this(app, null, null, groupingColumns, outputColumns, destOperator, dest, ShipOperator.defaultShipIntervalMs, destAddress, namedDest, nodeId, queryId, operatorId, mdf, rt);
	}


	public FixpointShipOperator(QpApplication<M> app, QpSchema newSchema, Map<Integer,Integer> newSchemaMapping, List<Integer> groupingColumns, List<OutputColumn> outputColumns, Operator<M> destOperator, WhichChild dest, InetSocketAddress destAddress, String namedDest, InetSocketAddress nodeId, int queryId, int operatorId, MetadataFactory<M> mdf, RecordTuples rt) {
		this(app, newSchema, newSchemaMapping, groupingColumns, outputColumns, destOperator, dest, ShipOperator.defaultShipIntervalMs, destAddress, namedDest, nodeId, queryId, operatorId, mdf, rt);
	}

	public FixpointShipOperator(QpApplication<M> app, QpSchema newSchema, Map<Integer,Integer> newSchemaMapping, List<Integer> groupingColumns, List<OutputColumn> outputColumns, Operator<M> destOperator, WhichChild dest, int shipIntervalMs,  InetSocketAddress destAddress, String namedDest, InetSocketAddress nodeId, int queryId, int operatorId, MetadataFactory<M> mdf, RecordTuples rt) {
		super(destOperator, dest, queryId, nodeId, operatorId, rt, mdf, false);
		this.destAddress = destAddress;
		this.queryId = queryId;
		this.app = app;
		pendingToShip = new ArrayList<QpTuple<M>>();
		sendThread = new FixpointShipThread(shipIntervalMs);
		this.newSchema = newSchema;
		if (newSchema == null) {
			this.newSchemaMapping = null;
		} else {
			if (newSchemaMapping == null) {
				throw new IllegalArgumentException("Need new schema mapping");
			}
			for (Map.Entry<?,?> me : newSchemaMapping.entrySet()) {
				if (me.getKey() == null || me.getValue() == null) {
					throw new NullPointerException("Cannot have null entry in schema mapping");
				}
			}
			this.newSchemaMapping = new HashMap<Integer,Integer>(newSchemaMapping);
		}

		this.namedDest = namedDest;
		if (mdf == null || mdf instanceof NullMetadataFactory) {
			sentMetadata = null;
			insertMetadata = null; 
			deleteMetadata = null;
			aggregateTable = null;
			aggregateTuples = null;
			aggregateMetadata = null;
		} else {
			sentMetadata = new HashMap<QpTuple<Null>,M>();
			insertMetadata = new HashMap<QpTuple<Null>,M>();
			deleteMetadata = new HashMap<QpTuple<Null>,M>();
			aggregateTable = new HashMap<Subtuple, Collection<QpTuple<Null>>>();
			aggregateTuples = new HashMap<Subtuple, List<QpTuple<Null>>>();
			aggregateMetadata = new HashMap<QpTuple<Null>,M>();
		}

		if (groupingColumns != null && outputColumns != null) {
			FixpointOperator.aggregateMode = true;
			this.groupingColumns = new int[groupingColumns.size()];
			int pos = 0;
			for (int col : groupingColumns) {
				this.groupingColumns[pos] = col;
				++pos;
			}
			this.outputColumns = new OutputColumn[outputColumns.size()];
			pos = 0;
			for (OutputColumn oc: outputColumns) {
				this.outputColumns[pos] = oc;
				++pos;
			}
		}
		sendThread.start();
	}

	@Override
	protected void receiveTuples(List<QpTuple<M>> tuples) {
		// TODO: Reimplement FixpointShipOperator to work with changes merged in from Nick's branch
		throw new UnsupportedOperationException("Need to re-implement based on version in subversion revision 7592");
	}

	public void finish(int blockSize) {
		// TODO: Reimplement FixpointShipOperator to work with changes merged in from Nick's branch
		throw new UnsupportedOperationException("Need to re-implement based on version in subversion revision 7592");
	}

	protected void close() {
		if (!pendingToShip.isEmpty()) {
			throw new RuntimeException("Not all shipped");
		}

		pendingToShip.clear();
		insertMetadata.clear();
		deleteMetadata.clear();
		sentMetadata.clear();
		try {
			sendThread.interrupt();
			sendThread.join();
		} catch (InterruptedException ie) {
			return;
		}
	}

	private class FixpointShipThread extends Thread {
		private final int sendIntervalMs;
		FixpointShipThread(int sendIntervalMs) {
			super(app.tg, "ShipOperator(" + queryId + "," + operatorId + "," + app.endpoint.getId() + ")");
			this.sendIntervalMs = sendIntervalMs;
		}

		public void run() {
			// TODO: Reimplement FixpointShipOperator to work with changes merged in from Nick's branch
			throw new UnsupportedOperationException("Need to re-implement based on version in subversion revision 7592");
		}
	}

	int getOutstandingMessages() {
		return outstandingMessages.size();
	}
}

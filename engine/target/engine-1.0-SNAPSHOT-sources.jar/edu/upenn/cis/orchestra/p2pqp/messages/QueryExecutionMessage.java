package edu.upenn.cis.orchestra.p2pqp.messages;

public interface QueryExecutionMessage {
	int getQueryId();
}

package edu.upenn.cis.orchestra.p2pqp.messages;

import static edu.upenn.cis.orchestra.p2pqp.QpTuple.SerializationMode.KEY;

import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.Collection;

import edu.upenn.cis.orchestra.p2pqp.Filter;
import edu.upenn.cis.orchestra.p2pqp.FilterSerialization;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpSchema;
import edu.upenn.cis.orchestra.p2pqp.QpTuple;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class RetrieveTupleMessage extends DHTMessage {
	private static final long serialVersionUID = 1L;
	private final byte[] t;
	public final byte[] filter;
	public final int[] desiredCols;
	public final int relId;

	public RetrieveTupleMessage(QpTuple<?> key) {
		this(key,null,null);
	}

	public RetrieveTupleMessage(QpTuple<?> key, Collection<Integer> desiredCols) {
		this(key,null,desiredCols);
	}

	public RetrieveTupleMessage(QpTuple<?> key, Filter<? super QpTuple<?>> f) {
		this(key,f,null);
	}

	public RetrieveTupleMessage(QpTuple<?> key, Filter<? super QpTuple<?>> f,
			Collection<Integer> desiredCols) {
		super(key.getQPid());
		relId = key.getSchema().relId;
		this.t = key.getKeyBytes();
		if (f == null) {
			filter = null;
		} else {
			filter = FilterSerialization.getBytes(f, key.getSchema());
		}
		if (desiredCols == null) {
			this.desiredCols = null;
		} else {
			this.desiredCols = new int[desiredCols.size()];
			int pos = 0;
			for (int col : desiredCols) {
				this.desiredCols[pos++] = col;
			}
			Arrays.sort(this.desiredCols);
		}
	}

	public QpTuple<?> getKey(QpSchema.Source schemas) {
		QpSchema schema = schemas.getSchema(relId);
		return QpTuple.fromBytes(KEY, schema, schemas, t, null);
	}

	public Filter<? super QpTuple<?>> getFilter(QpSchema schema) {
		if (filter == null) {
			return null;
		} else {
			return FilterSerialization.fromBytes(schema, filter);
		}
	}

	public byte[] getKeyBytes() {
		return t;
	}

	public String toString() {
		return "RetrieveTupleMessage";
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(relId);
		buf.writeBytes(t);
		buf.writeBytes(filter);
		if (desiredCols == null) {
			buf.writeInt(-1);
		} else {
			buf.writeInt(desiredCols.length);
			for (int col : desiredCols) {
				buf.writeInt(col);
			}
		}
	}

	public RetrieveTupleMessage(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		relId = buf.readInt();
		t = buf.readBytes();
		filter = buf.readBytes();
		int length = buf.readInt();
		if (length >= 0) {
			desiredCols = new int[length];
			for (int pos = 0; pos < desiredCols.length; ++pos) {
				desiredCols[pos] = buf.readInt();
			}
		} else {
			desiredCols = null;
		}
	}
}


package edu.upenn.cis.orchestra.p2pqp.messages;

import java.net.InetSocketAddress;
import java.util.List;

import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.p2pqp.InputBuffer;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.IndexService.EpochNum;
import edu.upenn.cis.orchestra.p2pqp.QpMessageSerialization.SerializationException;

public class SendIndexPages extends IndexMessage {
	private static final long serialVersionUID = 1L;
	public final int relId, epoch;
	public final byte[] data;

	public SendIndexPages(InetSocketAddress dest, int relId, int epoch, List<EpochNum> pages, int numTuples, int treeNum) {
		super(dest);
		this.relId = relId;
		this.epoch = epoch;
		ByteBufferWriter bbw = new ByteBufferWriter();
		bbw.addToBuffer(numTuples);
		bbw.addToBuffer(treeNum);
		for (EpochNum page : pages) {
			bbw.addToBuffer(page.epoch);
			bbw.addToBuffer(page.num);
		}
		data = bbw.getByteArray();
	}

	public String toString() {
		return "SendIndexPages (" + relId + "," + epoch + ")";
	}

	protected void subclassSerialize(OutputBuffer buf) {
		buf.writeInt(relId);
		buf.writeInt(epoch);
		buf.writeBytes(data);
	}

	public SendIndexPages(InputBuffer buf, InetSocketAddress origin) throws SerializationException {
		super(buf, origin);
		relId = buf.readInt();
		epoch = buf.readInt();
		data = buf.readBytes();
	}
}

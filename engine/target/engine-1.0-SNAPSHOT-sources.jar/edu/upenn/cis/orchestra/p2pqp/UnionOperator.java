package edu.upenn.cis.orchestra.p2pqp;

import java.util.ArrayList;
import java.util.List;

import edu.upenn.cis.orchestra.datamodel.AbstractImmutableTuple.FieldSource;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.p2pqp.QpTuple.WhichChild;

public class UnionOperator<M> extends Operator<M> {
	private final String leftSchema, rightSchema;
	private final QpSchema outputSchema;
	private final FieldSource[] fs;


	public UnionOperator(QpApplication<M> app, String leftSchema, String rightSchema, QpSchema outputSchema, 
			Operator<M> dest, WhichChild outputDest, int operatorId, RecordTuples rt, MetadataFactory<M> mdf) {

		super(dest,outputDest,operatorId, mdf,rt);

		this.leftSchema = leftSchema;
		this.rightSchema = rightSchema;
		this.outputSchema = outputSchema;
		fs = new FieldSource[outputSchema.getNumCols()];
		for (int i = 0; i < outputSchema.getNumCols(); ++i) {
			fs[i] = new FieldSource(i, true);
		}
	}


	@Override
	protected synchronized void receiveTuples(List<QpTuple<M>> tuples) {
		List<QpTuple<M>> tuplesProduced = new ArrayList<QpTuple<M>>();

		try {
			synchronized(this) {
				for (QpTuple<M> t : tuples) {
					if (t.isLeft() && t.getRelationName().equals(leftSchema)) {
					} else if (t.isRight() && t.getRelationName().equals(rightSchema)) {
					} else {
						this.reportException(new RuntimeException("Received unexpected " + (t.getDest() == null ? "unlabeled" : t.getDest().toString()) + " tuple " + t + " in fixpoint operator"));
					}

					tuplesProduced.add(new QpTuple<M>(outputSchema, fs, t, null));
				}
			}
		} catch (ValueMismatchException vme) {
			this.reportException(vme);
		}

		if (! tuplesProduced.isEmpty()) {
			sendTuples(tuplesProduced);
		}  

	}
}

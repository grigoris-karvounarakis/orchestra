package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import edu.upenn.cis.orchestra.p2pqp.IndexService.EpochNum;
import edu.upenn.cis.orchestra.p2pqp.IndexService.IndexServiceException;
import edu.upenn.cis.orchestra.p2pqp.QueryCoordinator.QueryFailure;
import edu.upenn.cis.orchestra.p2pqp.messages.BeginNewQueryPhase;
import edu.upenn.cis.orchestra.p2pqp.messages.BlockingOperatorsCanExecute;
import edu.upenn.cis.orchestra.p2pqp.messages.JoinInputHasFinished;
import edu.upenn.cis.orchestra.p2pqp.messages.QueryOwnerMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.RecordTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyFailure;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplySuccess;
import edu.upenn.cis.orchestra.p2pqp.messages.RecordTuplesMessage.ScannedKeys;
import edu.upenn.cis.orchestra.p2pqp.plan.QueryPlan;
import edu.upenn.cis.orchestra.util.Pair;

class QueryOwner<M> {
	final QpApplication<M> app;
	final int queryId;
	private final QueryCoordinator qc;
	private final QueryExecution<M> qe;
	private final Logger logger = Logger.getLogger(this.getClass());

	QueryOwner(Router queryRouter, int queryId, QpApplication<M> app, Map<Integer,Collection<EpochNum>> distributedScanPages, int epoch, QueryPlan qp, final Collection<QpSchema> schemas, Collection<QpTuple<M>> tupleDest, Set<InetSocketAddress> participants, boolean attemptRecovery) throws Operator.OperatorCreationException, IndexServiceException, InterruptedException, IOException {
		this.queryId = queryId;

		// This base and query schemas
		QpSchema.Source ss = new QpSchema.CollectionSource(schemas);

		this.app = app;
		this.qc = new QueryCoordinator(queryRouter, this, epoch, queryId, qp, ss, attemptRecovery);

		qe = new QueryExecution<M>(queryRouter, distributedScanPages, epoch, queryId, schemas, app, qc, tupleDest, attemptRecovery);
		qp.createCentralExecution(qe, null, null, attemptRecovery);

	}
	
	void process(QueryOwnerMessage m) throws IOException, InterruptedException {
		if (m.getQueryId() != queryId) {
			throw new IllegalArgumentException("Message query ID (" + m.getQueryId() + ") does not match expected query id (" + queryId + ")");
		}
		final InetSocketAddress from = ((Message) m).getOrigin(); 
		if (qc.nodeHasFailed(from)) {
			return;
		}
		
		if (m instanceof RecordTuplesMessage) {
			RecordTuplesMessage rtm = (RecordTuplesMessage) m;
			qc.tuplesAdded(rtm.added);
			qc.tuplesRemoved(rtm.removed);
			List<ScannedKeys> scanned = rtm.getScannedKeys();
			for (ScannedKeys sk : scanned) {
				qc.keysScanned(sk.operator, sk.keys, sk.phase, from);
			}
			qc.operatorsHaveFinished(rtm.finished);
			qc.keysNotFound(rtm.getMissingKeys(qe));
			for (Exception e : rtm.exceptions) {
				qc.reportException(from, e);
			}
			qc.messageReceived(rtm.getOrigin(), rtm.messageId);
			app.sendReplySuccess(rtm);
		} else {
			logger.error("Don't know what to do with QueryOwnerMessage " + m);
			app.sendMessage(new ReplyFailure((Message) m, "Unexpected type of QueryOwnerMessage", false));
		}
	}

	void start() throws IndexServiceException, InterruptedException {
		qc.start();
		qe.start();
	}

	void waitUntilDone() throws InterruptedException, QueryFailure {
		qc.waitUntilEmpty();
	}


	void close() throws InterruptedException {
		qe.close();
	}

	void finishLocalBlockingOperators(Collection<Integer> localOps) {
		for (int op : localOps) {
			qe.finishOperator(op);
		}
	}

	void finishRemoteBlockingOperators(Map<InetSocketAddress,Set<Integer>> operators) {
		for (Map.Entry<InetSocketAddress, Set<Integer>> me : operators.entrySet()) {
			if (! me.getValue().isEmpty()) {
				try {
					app.sendMessage(new BlockingOperatorsCanExecute(me.getKey(), queryId, me.getValue()));
				} catch (IOException e) {
					logger.error(e);
				} catch (InterruptedException ie) {
					return;
				}
			}
		}
	}

	void localJoinInputHasFinished(Collection<Integer> leftLocalOps, Collection<Integer> rightLocalOps) {
		for (int op : leftLocalOps) {
			qe.joinInputHasFinished(op, true);
		}

		for (int op : rightLocalOps) {
			qe.joinInputHasFinished(op, false);
		}
	}

	void distributedJoinInputHasFinished(Collection<Integer> leftRemoteOps, Collection<Integer> rightRemoteOps) {
		if (leftRemoteOps.isEmpty() && rightRemoteOps.isEmpty()) {
			return;
		}
		try {
			for (final InetSocketAddress dest : qe.getMostRecentRouter().getParticipants()) {
				app.sendMessageAwaitReply(new JoinInputHasFinished(dest, queryId, leftRemoteOps, rightRemoteOps), new ReplyContinuation() {
					boolean finished = false;
					public synchronized boolean isFinished() {
						return finished;
					}

					public synchronized void processReply(Message m) {
						finished = true;
						if (! (m instanceof ReplySuccess)) {
							logger.error("Received unexpected reply to JoinInputHasFinished from " + dest + ": " + m);
						}
					}
					
				}, ReplySuccess.class);
			}
		} catch (IOException e) {
			logger.error("Error sending JoinInputHasFinished", e);
		} catch (InterruptedException ie) {
			return;
		}
	}

	void namedJoinInputHasFinished(Map<InetSocketAddress,Pair<Collection<Integer>,Collection<Integer>>> ops) {
		try {
			for (Map.Entry<InetSocketAddress, Pair<Collection<Integer>,Collection<Integer>>> me : ops.entrySet()) {
				final InetSocketAddress dest = me.getKey();
				final Collection<Integer> leftNamedOps = me.getValue().getFirst(), rightNamedOps = me.getValue().getSecond();
				app.sendMessageAwaitReply(new JoinInputHasFinished(dest, queryId, leftNamedOps, rightNamedOps), new ReplyContinuation() {
					boolean finished = false;
					public synchronized boolean isFinished() {
						return finished;
					}

					public synchronized void processReply(Message m) {
						finished = true;
						if (! (m instanceof ReplySuccess)) {
							logger.error("Received unexpected reply to JoinInputHasFinished from " + dest + ": " + m);
						}
					}
					
				}, ReplySuccess.class);
			}
		} catch (IOException e) {
			logger.error("Error sending JoinInputHasFinished", e);
		} catch (InterruptedException ie) {
			return;
		}
		
	}
	
	QueryExecution<M> getOwnedExecution() {
		return qe;
	}

	void reportException(Exception e) {
		qc.reportException(e);
	}

	void nodesHaveFailed(Collection<InetSocketAddress> failedNodes) {
		qc.nodesHaveFailed(failedNodes);
	}

	int getCurrentPhase() {
		return qc.getCurrentPhase();
	}
	
	Set<InetSocketAddress> beginNewQueryPhase(int phaseNo, Router newRouter,
			IdRange[] previousPhaseFailedRanges, Collection<InetSocketAddress> newlyFailedNodes,
			Map<Integer,int[]> joinOperatorsToResend) throws InterruptedException, IOException {
		qe.beginNewQueryPhase(new BeginNewQueryPhase(app.localAddr,queryId,phaseNo,newRouter,previousPhaseFailedRanges,newlyFailedNodes,joinOperatorsToResend));
		
		final Set<InetSocketAddress> remaining = new HashSet<InetSocketAddress>(newRouter.getParticipants());
		final Set<InetSocketAddress> failed = new HashSet<InetSocketAddress>();
		
		for (final InetSocketAddress node : newRouter.getParticipants()) {
			app.sendMessageAwaitReply(new BeginNewQueryPhase(node,queryId,phaseNo,newRouter,previousPhaseFailedRanges,newlyFailedNodes,joinOperatorsToResend),
					new ReplyContinuation() {
						private boolean finished = false;
						
						public synchronized boolean isFinished() {
							return finished;
						}

						public synchronized void processReply(Message m) {
							finished = true;
							synchronized (remaining) {
								remaining.remove(node);
								if (! (m instanceof ReplySuccess)) {
									failed.add(node);
								}
								if (remaining.isEmpty()) {
									remaining.notify();
								}
							}
							
						}
			}, ReplySuccess.class);
		}
		
		synchronized (remaining) {
			while (! remaining.isEmpty()) {
				remaining.wait();
			}
		}

		return failed;
	}
}

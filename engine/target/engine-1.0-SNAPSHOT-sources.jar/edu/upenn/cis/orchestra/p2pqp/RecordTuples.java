package edu.upenn.cis.orchestra.p2pqp;

import java.io.Serializable;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.List;

public interface RecordTuples {
	static class TupleAndOp implements Serializable {
		private static final long serialVersionUID = 1L;
		final QpTuple<?> t;
		final int operatorId;
		final int phaseNo;
		
		public TupleAndOp(QpTuple<?> t, int operatorId, int phaseNo) {
			this.t = t;
			this.operatorId = operatorId;
			this.phaseNo = phaseNo;
		}
		
		public boolean equals(Object o) {
			if (o == null || o.getClass() != this.getClass()) {
				return false;
			}
			
			TupleAndOp tao = (TupleAndOp) o;
			return operatorId == tao.operatorId && phaseNo == tao.phaseNo && t.equals(tao.t);
		}
		
		public int hashCode() {
			return operatorId + 37 * t.hashCode() + 97 * phaseNo;
		}
		
		public String toString() {
			return "<" + t + "," + operatorId + "," + phaseNo + ">";
		}
	}
	
	static class NodeAndOp implements Serializable {
		private static final long serialVersionUID = 1L;
		public final InetSocketAddress node;
		public final int operatorId;
		
		public NodeAndOp(InetSocketAddress node, int operatorId) {
			this.node = node;
			this.operatorId = operatorId;
		}
		
		public boolean equals(Object o) {
			if (o == null || o.getClass() != this.getClass()) {
				return false;
			}
			
			NodeAndOp nao = (NodeAndOp) o;
			return (nao.operatorId == operatorId && (node == null ? nao.node == null : nao.node.equals(node)));
		}
		
		public int hashCode() {
			return (node == null ? 0 : node.hashCode()) + 37 * operatorId;
		}
		
		public String toString() {
			return "<" + node + "," + operatorId + ">";
		}
	}
	
	public void tuplesRemoved(Collection<ExecutionId> tupleIds);
	public void tuplesAdded(Collection<ExecutionId> tupleIds);
	public void keysScanned(int operatorId, List<QpTuple<?>> keys, int phaseNo);
	public void keysNotFound(int operatorId, List<QpTuple<?>> keys, int phaseNo);
	public void operatorHasFinished(int operatorId, InetSocketAddress node);
	public void reportException(Exception e);
	public void nodesHaveFailed(Collection<InetSocketAddress> node);
	
	public void close();
}

package edu.upenn.cis.orchestra.p2pqp;

import edu.upenn.cis.orchestra.datamodel.AbstractImmutableTuple;
import edu.upenn.cis.orchestra.datamodel.AbstractTuple;
import edu.upenn.cis.orchestra.datamodel.ByteBufferWriter;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;

public class QpTuple<M> extends AbstractImmutableTuple<QpSchema> implements Comparable<QpTuple<?>> {
	public static final int FIRST_EPOCH = 0;
	private static final long serialVersionUID = 1L;
	private final int epoch;
	private final ExecutionId tupleId;
	private final M metadata;

	private WhichChild dest;

	public enum WhichChild {
		LEFT,
		RIGHT
	}

	public enum SerializationMode {
		KEY,
		STORE,
		EXECUTION
	}
	
	public QpTuple(AbstractTuple<QpSchema> t, int epoch, boolean onlyKey) {
		super(t,onlyKey);
		tupleId = null;
		this.epoch = epoch;
		this.metadata = null;
	}
	
	public QpTuple(QpMutableTuple<M> t, int epoch, boolean onlyKey) {
		super(t,onlyKey);
		tupleId = null;
		this.epoch = epoch;
		if (onlyKey) {
			metadata = null;
		} else {
			metadata = t.metadata;
		}
	}
	
	public QpTuple(QpSchema schema, boolean onlyKey, int epoch, ExecutionId tupleId, M metadata, Object[] fields) throws ValueMismatchException {
		super(schema,onlyKey,fields);
		this.tupleId = tupleId;
		if (onlyKey) {
			this.metadata = null;
		} else {
			this.metadata = metadata;
		}
		this.epoch = epoch;
	}
	
	public QpTuple(QpSchema schema, boolean onlyKey, int epoch, Object[] fields) throws ValueMismatchException {
		this(schema, onlyKey, epoch, null, null, fields);
	}

	public QpTuple(QpSchema schema, FieldSource[] fss, QpTuple<M> t, Object[] otherFields) throws ValueMismatchException {
		super(schema,fss,t,otherFields);
		this.epoch = t.epoch;
		this.tupleId = t.tupleId;
		this.metadata = t.metadata;
	}

	public QpTuple(QpSchema schema, FieldSource[] fss, QpTuple<?> t, M metadata, Object[] otherFields) throws ValueMismatchException {
		super(schema,fss,t,otherFields);
		this.epoch = t.epoch;
		this.tupleId = t.tupleId;
		this.metadata = metadata;
	}
	
	public QpTuple(QpSchema schema, FieldSource[] fss, QpTuple<?> t, int epoch, M metadata, Object[] otherFields) throws ValueMismatchException {
		super(schema,fss,t,otherFields);
		this.epoch = epoch;
		this.tupleId = t.tupleId;
		this.metadata = metadata;
	}

	public QpTuple(QpSchema schema, FieldSource[] fss, QpTuple<?> t, int epoch, ExecutionId tupleId, M metadata, Object[] otherFields) throws ValueMismatchException {
		super(schema,fss,t,otherFields);
		this.epoch = epoch;
		this.tupleId = tupleId;
		this.metadata = metadata;
	}

	public QpTuple(QpTuple<?> tuple, boolean onlyKey, int[] retainCols, int epoch, ExecutionId tupleId, M metadata) {
		super(tuple, onlyKey, retainCols);
		this.epoch = epoch;
		this.tupleId = tupleId;
		this.metadata = metadata;
	}

	public QpTuple(QpTuple<?> tuple, int[] retainCols, int epoch, ExecutionId tupleId, M metadata) {
		super(tuple, tuple.isKeyTuple(), retainCols);
		this.epoch = epoch;
		this.tupleId = tupleId;
		this.metadata = metadata;
	}
	
	public QpTuple(QpTuple<M> tuple, int[] retainCols) {
		super(tuple, tuple.isKeyTuple(), retainCols);
		this.epoch = tuple.epoch;
		this.tupleId = tuple.tupleId;
		this.metadata = tuple.metadata;
	}
	
	public QpTuple(QpSchema schema, JoinFieldSource[] jfss, QpTuple<?> first, QpTuple<?> second, int epoch, ExecutionId tupleId, M metadata) throws ValueMismatchException {
		super(schema, jfss, first,second);
		this.epoch = epoch;
		this.tupleId = tupleId;
		this.metadata = metadata;
	}
	
	private QpTuple(QpSchema schema, boolean onlyKey, byte[] data, int offset, int epoch, ExecutionId tid, M metadata) {
		super(schema,onlyKey,data,offset);
		this.epoch = epoch;
		this.tupleId = tid;
		this.metadata = metadata;
	}
	
	private QpTuple(QpTuple<?> tuple, boolean onlyKey, int newEpoch, ExecutionId newTupleId, M newMetadata) {
		super(tuple, onlyKey);
		this.epoch = newEpoch;
		this.tupleId = newTupleId;
		this.metadata = newMetadata;
	}

	@Override
	public boolean sameSchemaAs(AbstractTuple<QpSchema> t) {
		return t.getSchema().relId == getSchema().relId;
	}

	public int getEpoch() {
		return epoch;
	}

	public byte[] getKeyBytes() {
		return getBytes(SerializationMode.KEY, null);
	}

	public byte[] getExecutionBytes(MetadataFactory<M> mdf) {
		return getBytes(SerializationMode.EXECUTION, mdf);
	}

	public byte[] getStoreBytes(MetadataFactory<M> mdf) {
		return getBytes(SerializationMode.STORE, mdf);
	}

	private byte[] getBytesForId(int[] cols, byte[] scratch) {
		final int length = cols.length * IntType.bytesPerInt;
		byte[] retval;
		if (scratch != null && scratch.length == length) {
			retval = scratch;
		} else {
			retval = new byte[length];
		}
		int pos = 0;
		for (int col : cols) {
			int code = getColHashCode(col);
			IntType.putBytes(code, retval, pos);
			pos += IntType.bytesPerInt;
		}
		return retval;
	}

	/*
	 * Serialization format:
	 * Epoch #
	 *
	 * if EXECUTION:
	 * 		execution ID length
	 * 		execution ID bytes
	 * 
	 * if EXECUTION or STORE:
	 * 		metadata length
	 * 		metadata bytes
	 * 
	 * BitSet showing which relevant columns are non-null
	 * BitSet showing which relevant columns are labeled nulls
	 * 
	 * For each relevant column:
	 * 		If a labeled null, the integer label
	 * 		If a type with variable serialized length
	 * 			The field length
	 * 			The field bytes
	 *		If a type with fixed serialized length
	 *			The field bytes
	 */



	public byte[] getBytes(SerializationMode sm, MetadataFactory<M> mdf) {
		ByteBufferWriter bbw = new ByteBufferWriter();
		bbw.addToBuffer(epoch);
		boolean full = (sm != SerializationMode.KEY);
		if (full && this.isKeyTuple()) {
			throw new IllegalStateException("Cannot do a full serialization of a key tuple");
		}
		if (sm == SerializationMode.EXECUTION) {
			if (tupleId == null) {
				bbw.addToBuffer((byte[]) null);
			} else {
				bbw.addToBuffer(tupleId.getBytes());
			}
		}
		if (full) {
			if (mdf == null || metadata == null) {
				bbw.addToBuffer((byte []) null);
			} else {
				bbw.addToBuffer(mdf.toBytes(metadata));
			}
		}
		if ((! full) && (! this.isKeyTuple())) {
			bbw.addToBufferNoLength(this.getKeyTuple().serialize());
		} else {
			bbw.addToBufferNoLength(this.serialize());
		}
		return bbw.getByteArray();
	}

	public static QpTuple<Null> fromBytes(SerializationMode sm, QpSchema schema, QpSchema.Source findSchema, byte[] bytes, ExecutionId tupleId) {
		return fromBytes(sm,schema,findSchema, NullMetadataFactory.getInstance(), bytes,0,bytes.length,tupleId);
	}

	public static <M> QpTuple<M> fromBytes(SerializationMode sm, QpSchema schema, QpSchema.Source findSchema, MetadataFactory<M> mdf, byte[] bytes, ExecutionId tupleId) {
		return fromBytes(sm,schema,findSchema,mdf,bytes,0,bytes.length,tupleId);
	}

	public static <M> QpTuple<M> fromBytes(SerializationMode sm, QpSchema schema, QpSchema.Source findSchema, MetadataFactory<M> mdf, byte[] bytes, int offset, int length, ExecutionId tupleId) {
		int pos = offset;
		int epoch = IntType.getValFromBytes(bytes, pos, IntType.bytesPerInt);
		pos += IntType.bytesPerInt;
		
		ExecutionId storedId = null;
		M storedMetadata = null;
		if (sm == SerializationMode.EXECUTION) {
			int tidLen = IntType.getValFromBytes(bytes, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			if (pos >= 0) {
				storedId = ExecutionId.fromBytes(bytes, pos, tidLen);
				pos += tidLen;
			}
		}
		boolean full = (sm != SerializationMode.KEY);
		if (full) {
			int mdLength = IntType.getValFromBytes(bytes, pos, IntType.bytesPerInt);
			pos += IntType.bytesPerInt;
			if (mdLength >= 0) {
				byte[] mdBytes = new byte[mdLength];
				System.arraycopy(bytes, pos, mdBytes, 0, mdLength);
				storedMetadata = mdf.fromBytes(findSchema, null, mdf, mdBytes, tupleId);
				pos += mdLength;
			}
		}
		// Override stored Id if one is supplied
		ExecutionId newId = (tupleId == null) ? storedId : tupleId;

		QpTuple<M> qt = new QpTuple<M>(schema, sm == SerializationMode.KEY, bytes, pos, epoch, newId, storedMetadata); 

		return qt;
	}


	public M getMetadata() {
		return metadata;
	}

	public ExecutionId getId() {
		return tupleId;
	}

	public void setDest(WhichChild dest) {
		this.dest = dest;
	}

	public boolean isLeft() {
		return (dest == WhichChild.LEFT);
	}

	public boolean isRight() {
		return (dest == WhichChild.RIGHT);
	}

	public WhichChild getDest() {
		return dest;
	}

	public QpTuple<?> getKeyTuple() {
		if (this.isKeyTuple()) {
			throw new IllegalStateException("This is already a key tuple");
		}
		return new QpTuple<Null>(this, true, this.epoch, null, null);
	}
	
	public <MM> QpTuple<MM> getNonKeyTuple(ExecutionId tid, MM metadata) {
		if (! this.isKeyTuple()) {
			throw new IllegalStateException("This is already a non-key tuple");
		}
		return new QpTuple<MM>(this, false, this.epoch, tid, metadata);
	}
	
	public QpTuple<?> getKeyTuple(int newEpoch) {
		return new QpTuple<Null>(this, true, newEpoch, null, null);
	}

	Id getQPid(int[] cols) {
		return Id.fromContent(getBytesForId(cols,null));
	}
	
	Id getQPid(int[] cols, byte[] scratch) {
		return Id.fromContent(getBytesForId(cols,scratch));
	}

	Id getQPid(byte[] scratch) {
		return Id.fromContent(getBytesForId(schema.getHashColsNoCopy(),scratch));
	}

	public Id getQPid() {
		return Id.fromContent(getBytesForId(schema.getHashColsNoCopy(),null));
	}

	public int compareTo(QpTuple<?> t) {
		/*
		 * Go through fields in order
		 * null precedes non-null
		 * labeled null precedes normal null
		 */
		if (getSchema().relId != t.getSchema().relId) {
			throw new IllegalArgumentException("Should only compare tuples from same relation");
		}
		final QpSchema s = getSchema();
		final int numCols = s.getNumCols();
		for (int i = 0; i < numCols; ++i) {
			if (this.isLabeledNull(i)) {
				if (t.isLabeledNull(i)) {
					int diff = this.getLabeledNull(i) - t.getLabeledNull(i);
					if (diff != 0) {
						return diff;
					}
				} else {
					return -1;
				}
			} else if (t.isLabeledNull(i)) {
				return 1;
			}
			Object o1 = this.get(i), o2 = t.get(i);
			if (o1 == null) {
				if (o2 != null) {
					return -1;
				}
			} else if (o2 == null) {
				if (o1 != null) {
					return 1;
				}
			} else {
				int diff;
				try {
					diff = s.getColType(i).compareTwo(o1, o2);
				} catch (CompareMismatch e) {
					throw new RuntimeException(e);
				}
				if (diff != 0) {
					return diff;
				}
			}
		}
		return 0;
	}
		
	QpTuple<M> changeEpoch(int newEpoch) {
		return new QpTuple<M>(this, this.isKeyTuple(), newEpoch, this.tupleId, this.metadata);
	}
	
	QpTuple<M> changeId(ExecutionId newId) {
		if (this.isKeyTuple()) {
			throw new IllegalStateException("Key tuples do not have IDs");
		}
		return new QpTuple<M>(this, false, this.epoch, newId, this.metadata);
	}
	
	<MM> QpTuple<MM> changeIdAndMetadata(ExecutionId newId, MM metadata) {
		if (this.isKeyTuple()) {
			throw new IllegalStateException("Key tuples do not have IDs or metadata");
		}
		return new QpTuple<MM>(this, false, this.epoch, newId, metadata);
	}
	
	<MM> QpTuple<MM> changeMetadata(MM metadata) {
		if (this.isKeyTuple()) {
			throw new IllegalStateException("Key tuples do not have metadata");
		}
		return new QpTuple<MM>(this, false, this.epoch, this.tupleId, metadata);
	}
}

package edu.upenn.cis.orchestra.p2pqp.messages;

import java.io.IOException;

import edu.upenn.cis.orchestra.p2pqp.Message;
import edu.upenn.cis.orchestra.p2pqp.OutputBuffer;
import edu.upenn.cis.orchestra.p2pqp.QpApplication;

public class ReplyTimeout extends Message {
	private static final long serialVersionUID = 1L;

	public final Message m;
	public ReplyTimeout(Message origMessage) {
		this.m = origMessage;
	}

	public String toString() {
		return "ReplyTimeout" + "(" + QpApplication.removePackageName(m.getClass().getName()) + ")";
	}

	protected void subclassSerialize(OutputBuffer buf) throws IOException {
		throw new RuntimeException("Should never try to serialize a ReplyTimeout");
	}
	
	public boolean isReply() {
		return true;
	}
	
	protected long[] getOrigIds() {
		return new long[] { m.messageId };
	}
	
	protected boolean canRetry() {
		return true;
	}
}



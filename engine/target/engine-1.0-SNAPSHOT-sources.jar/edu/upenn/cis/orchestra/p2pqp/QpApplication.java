package edu.upenn.cis.orchestra.p2pqp;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.StringWriter;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import rice.p2p.commonapi.Application;
import rice.p2p.commonapi.Endpoint;
import rice.p2p.commonapi.Node;
import rice.p2p.commonapi.NodeHandle;
import rice.p2p.commonapi.RouteMessage;

import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;

import edu.upenn.cis.orchestra.p2pqp.IndexService.EpochNum;
import edu.upenn.cis.orchestra.p2pqp.IndexService.IndexServiceException;
import edu.upenn.cis.orchestra.p2pqp.IndexService.TupleSink;
import edu.upenn.cis.orchestra.p2pqp.MsgStatusCache.MsgStatus;
import edu.upenn.cis.orchestra.p2pqp.QueryCoordinator.QueryFailure;
import edu.upenn.cis.orchestra.p2pqp.Router.NodeInfo;
import edu.upenn.cis.orchestra.p2pqp.TupleStore.TupleStoreException;
import edu.upenn.cis.orchestra.p2pqp.messages.BeginNewQueryPhase;
import edu.upenn.cis.orchestra.p2pqp.messages.CheckRelation;
import edu.upenn.cis.orchestra.p2pqp.messages.DHTMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.DistributeQueryMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.DoesNotHaveQuery;
import edu.upenn.cis.orchestra.p2pqp.messages.DummyMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.GetNodeInfo;
import edu.upenn.cis.orchestra.p2pqp.messages.IndexMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.LocalRelationIs;
import edu.upenn.cis.orchestra.p2pqp.messages.MessageDestHasDied;
import edu.upenn.cis.orchestra.p2pqp.messages.MissingTuplesAre;
import edu.upenn.cis.orchestra.p2pqp.messages.NodeInfoIs;
import edu.upenn.cis.orchestra.p2pqp.messages.QueryExecutionMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.QueryOwnerMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyException;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyFailure;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplySendingFailed;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplySuccess;
import edu.upenn.cis.orchestra.p2pqp.messages.ReplyTimeout;
import edu.upenn.cis.orchestra.p2pqp.messages.ShipConfig;
import edu.upenn.cis.orchestra.p2pqp.messages.ShippedTuplesMessage;
import edu.upenn.cis.orchestra.p2pqp.messages.TearDownQueryMessage;
import edu.upenn.cis.orchestra.p2pqp.plan.DistributedScanNode;
import edu.upenn.cis.orchestra.p2pqp.plan.QueryPlan;
import edu.upenn.cis.orchestra.p2pqp.plan.QueryPlanWithSchemas;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.Holder;
import edu.upenn.cis.orchestra.util.LongList;
import edu.upenn.cis.orchestra.util.Pair;

public class QpApplication<M> implements Application, SocketManagerClient {
	// Number of times to retry an operation that fails
	static final int DEFAULT_NUM_RETRIES = 5;
	// Delay between failure and retry, in milliseconds
	static final int DEFAULT_RETRY_DELAY = 1000;

	// Time to wait for query dissemination before timing out
	public static int QUERY_DISSEMINATION_TIME_MS = 5000;

	// Maximum amount of time to wait between responses to a flood before giving up
	public static int FLOODING_MAX_WAIT_INTERVAL_MS = 5000;

	// Time to wait after receiving notification that a node joined or left before updating
	// the known nodes set
	public static final int NODE_NOTIFICATION_WAIT_MS = 2000;


	// Time to retain information about a received message, in milliseconds
	static final int MSG_RETAIN_MS = 600000;

	// Maximum size of a message, 128 KB
	public static final int MAX_MSG_SIZE = 128 * 1024;

	final Logger logger = Logger.getLogger(this.getClass());

	final public static String instanceName = "Orchestra QP";
	final public static String scribeInstanceName = "Orchestra QP Multicasting";
	final public static String allNodesName = "All Nodes";

	final static int numMessageProcessingThreads = 5;
	private final IdFactory idf;
	private NodeFactory nf;
	private Node node;
	Id nodeId;
	protected Endpoint endpoint;

	final ThreadGroup tg;
	private List<MessageProcessingThread> messageProcessingThreads;
	// Table to store reply data, is synchronized
	private Map<Long,ReplyData> replyData;
	// Record of which messages were sent where, is not synchronized
	private Map<InetSocketAddress,Set<Long>> messageDests;

	private final Set<InetSocketAddress> knownNodes = new HashSet<InetSocketAddress>();
	private final List<NodeHandle> knownNodesHandles = new ArrayList<NodeHandle>();

	TupleStore<M> store;
	DHTService<M> dht; 
	IndexService index;
	private Map<Integer,Integer> firstEpochsForTables;

	private BootNodeThread bootThread;
	private ShowStatusThread showQueueThread;

	private Map<Integer,QueryOwner<M>> ownedQueries;
	private Map<Integer,QueryExecution<M>> distributedQueries;
	private Map<Pair<Integer,String>,QueryExecution<M>> namedNodeQueries;

	private Map<String,Record> messageCounts;

	private Set<String> localNames;
	private Map<String,InetSocketAddress> allNames;

	final MetadataFactory<M> mdf;

	private final DocumentBuilder docBuilder;

	private MsgStatusCache msgStatus;

	private QpMessageSerialization messageSerialization;

	private Timer timer;

	// This QpApplication has complete control over all files that begin with
	// scratchPrefix in scratchDir.
	@SuppressWarnings("unused")
	private File scratchDir;
	@SuppressWarnings("unused")
	private String scratchPrefix;

	private volatile Router router = null;
	// Mapping from QP address to node handle
	private final Map<InetSocketAddress,NodeHandle> routerNodeHandles = Collections.synchronizedMap(new HashMap<InetSocketAddress,NodeHandle>());

	final InetSocketAddress localAddr;
	private InetSocketAddress pastryAddr;
	final SocketManager socketManager;
	final int replicationFactor;

	private final Map<InetSocketAddress,InetSocketAddress> getPastryAddress = Collections.synchronizedMap(new HashMap<InetSocketAddress,InetSocketAddress>());

	public QpApplication(InetSocketAddress localAddr, NodeFactory nf, File scratchDir, String scratchPrefix, Environment e, String storeTableName, String indexTableName) throws IOException, DatabaseException {
		this(localAddr, nf,scratchDir,scratchPrefix,e,storeTableName,indexTableName,null,null);
	}

	public QpApplication(InetSocketAddress localAddr, NodeFactory nf, File scratchDir, String scratchPrefix, Environment env, String storeTableName, String indexTableName, MetadataFactory<M> mdf, Map<String,InetSocketAddress> allNames) throws IOException, DatabaseException {
		this(localAddr,null,nf,scratchDir,scratchPrefix,env,storeTableName,indexTableName,mdf,allNames);
	}
	public QpApplication(InetSocketAddress localAddr, Id nodeId, NodeFactory nf, File scratchDir, String scratchPrefix, Environment env, String storeTableName, String indexTableName, MetadataFactory<M> mdf, Map<String,InetSocketAddress> allNames) throws IOException, DatabaseException {
		this(localAddr,nodeId,nf,scratchDir,scratchPrefix,env,storeTableName,indexTableName,mdf,allNames,1);
	}

	public QpApplication(InetSocketAddress localAddr, Id nodeId, NodeFactory nf, File scratchDir, String scratchPrefix, Environment env, String storeTableName, String indexTableName, MetadataFactory<M> mdf, Map<String,InetSocketAddress> allNames, int replicationFactor) throws IOException, DatabaseException {
		if (replicationFactor % 2 != 1) {
			throw new IllegalArgumentException("Replication factor must be odd");
		}
		this.replicationFactor = replicationFactor;
		this.nf = nf;
		this.mdf = mdf;
		this.nodeId = nodeId;

		idf = nf.getIdFactory();
		if (allNames != null) {
			this.allNames = new HashMap<String,InetSocketAddress>(allNames);
		} else {
			this.allNames = Collections.emptyMap();
		}
		localNames = Collections.synchronizedSet(new HashSet<String>());
		tg = new ThreadGroup("Orchestra QP #" + nf.getCreatedCount() + " Threads");
		try {
			docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e);
		}

		messageCounts = new HashMap<String,Record>();

		messageDests = new HashMap<InetSocketAddress,Set<Long>>();

		this.scratchDir = scratchDir;
		this.scratchPrefix = scratchPrefix;
		msgStatus = new MsgStatusCache(MSG_RETAIN_MS);

		this.localAddr = localAddr; 
		messageSerialization = new QpMessageSerialization();
		socketManager = new SocketManager(messageSerialization, scratchDir, scratchPrefix, this, tg, localAddr);

		timer = new Timer(localAddr + " timer");
		timer.schedule(new TimerTask() {

			@Override
			public void run() {
				timer.purge();
			}

		}, 5000, 5000);
		ownedQueries = Collections.synchronizedMap(new HashMap<Integer,QueryOwner<M>>());
		distributedQueries = new HashMap<Integer,QueryExecution<M>>();
		namedNodeQueries = Collections.synchronizedMap(new HashMap<Pair<Integer,String>,QueryExecution<M>>());

		firstEpochsForTables = new HashMap<Integer,Integer>();

		messageProcessingThreads = new ArrayList<MessageProcessingThread>(numMessageProcessingThreads);
		for (int i = 0; i < numMessageProcessingThreads; ++i) {
			MessageProcessingThread mpt = new MessageProcessingThread(i + 1);
			mpt.start();
			messageProcessingThreads.add(mpt);
		}

		replyData = Collections.synchronizedMap(new HashMap<Long,ReplyData>());

		showQueueThread = new ShowStatusThread();
		showQueueThread.start();

		updateKnownNodes = new TimerTask() {

			@Override
			public void run() {
				updateKnownNodes();
			}
		};
		timer.schedule(updateKnownNodes, 5000, 5000);

		store = new BDbTupleStore<M>(env, storeTableName, tg, mdf);
		dht = new DHTService<M>(this);
		index = new IndexService(this, env, indexTableName);


		bootThread = new BootNodeThread();
		bootThread.start();
	}

	private class BootNodeThread extends Thread {
		BootNodeThread() {
			super(tg,"Boot node thread");
		}

		public void run() {
			Node n = nf.getNode(nodeId);
			try {
				while (! nf.isReady(n)) {
					Thread.sleep(5);
				}
			} catch (InterruptedException ie) {
				logger.error("Interrupted while booting node", ie);
				return;
			}
			synchronized (QpApplication.this) {
				node = n;
				nodeId = idf.toP2PQP(n.getId());
				endpoint = node.buildEndpoint(QpApplication.this, instanceName);
				endpoint.register();
				pastryAddr = nf.getAddress(n.getLocalNodeHandle());
				router = new Router(Collections.singletonList(new Router.NodeInfo(nodeId, pastryAddr, localAddr)));
				logger.info("Finished creating new node (ID " + nodeId + ", Pastry address " + pastryAddr + ", QP address " + localAddr);
			}
		}
	}

	private List<String> sentMessages = new ArrayList<String>();

	private static class Record implements Comparable<Record> {
		String className;
		int count;

		Record(String className) {
			this.className = className;
			count = 1;
		}

		Record(String className, int count) {
			this.className = className;
			this.count = count;
		}

		// Sort in decreasing order by count
		public int compareTo(Record r) {
			return r.count - count;
		}

		void increment() {
			++count;
		}
	}

	private class ShowStatusThread extends Thread {

		ShowStatusThread() {
			super(tg, "Show Status Thread");
		}


		public void run() {
			long lastTime = System.currentTimeMillis();
			while (! isInterrupted()) {
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					return;
				}
				if (logger.isInfoEnabled()) {
					Map<String,Record> counts = new HashMap<String,Record>();
					List<Record> records = new ArrayList<Record>(counts.values());

					List<String> sent;
					synchronized (QpApplication.this) {
						if (sentMessages.isEmpty()) {
							sent = null;
						} else {
							sent = sentMessages;
							sentMessages = new ArrayList<String>(sent.size());
						}
					}
					if (sent != null) {
						for (String s : sent) {
							Record r = counts.get(s);
							if (r == null) {
								counts.put(s, new Record(s));
							} else {
								r.increment();
							}	
						}
						records = new ArrayList<Record>(counts.values());
						if (! records.isEmpty()) {
							StringBuilder sb = new StringBuilder("Node " + endpoint.getId() + " sent through Pastry ");
							Collections.sort(records);
							Iterator<Record> it = records.iterator();

							while (it.hasNext()) {
								Record r = it.next();
								sb.append(r.count + " " + r.className);
								if (it.hasNext()) {
									sb.append(", ");
								}
							}
							logger.info(sb);
						}
					}

					Collection<InetSocketAddress> throttling = socketManager.getThrottledNodes();
					Collection<InetSocketAddress> throttledBy = socketManager.getThrottledByNodes();
					if (! throttling.isEmpty()) {
						logger.info("Node " + localAddr + " is throttling " + throttling);
					}

					if (! throttledBy.isEmpty()) {
						logger.info("Node " + localAddr + " is throttled by " + throttledBy);
					}
					if (logger.isInfoEnabled()) {
						long currTime = System.currentTimeMillis();
						ArrayList<Record> recs;
						synchronized (messageCounts) {
							recs = new ArrayList<Record>(messageCounts.values());
							messageCounts.clear();
						}
						Collections.sort(recs);
						Iterator<Record> it = recs.iterator();
						StringBuilder sb = new StringBuilder("Messages processed at " + localAddr + " in last " + (currTime - lastTime) +" msec: ");
						while (it.hasNext()) {
							Record r = it.next();
							sb.append(r.count + " " + r.className);
							if (it.hasNext()) {
								sb.append(", ");
							}
						}
						logger.info(sb);
						lastTime = currTime;
					}
				}
			}
		}
	}

	public boolean isReady() {
		return router != null;
	}

	public void waitUntilReady() throws InterruptedException {
		bootThread.join();
	}

	public void stop() throws IndexServiceException, TupleStoreException {
		try {
			socketManager.close();
			logger.info("Closed " + localAddr + " socket manager");
		} catch (IOException ioe) {
			logger.error("Error shutting down socket manager", ioe);
		} catch (InterruptedException ie) {
			return;
		}

		if (timer != null) {
			timer.cancel();
			timer = null;
		}
		logger.info("Stopped " + localAddr + " timer");

		try {
			if (msgStatus != null) {
				msgStatus.close();
			}

			if (showQueueThread != null) {
				showQueueThread.interrupt();
				showQueueThread.join();
				showQueueThread = null;
			}

			if (messageProcessingThreads != null) {
				for (int i = 0; i < messageProcessingThreads.size(); ++i) {
					MessageProcessingThread mpt = messageProcessingThreads.get(i);
					mpt.interrupt();
					mpt.join();
				}
				messageProcessingThreads = null;
			}
			logger.info("Stopped " + localAddr + " message processing threads");

			synchronized (ownedQueries) {
				for (QueryOwner<M> qo : ownedQueries.values()) {
					qo.close();
				}
				ownedQueries.clear();
			}
			logger.info("Stopped " + localAddr + " owned queries");

			synchronized (distributedQueries) {
				for (QueryExecution<M> qe : distributedQueries.values()) {
					qe.close();
				}
				distributedQueries.clear();
			}
			logger.info("Stopped " + localAddr + " distributed queries");

			synchronized (namedNodeQueries) {
				for (QueryExecution<M> qe : namedNodeQueries.values()) {
					qe.close();
				}
				namedNodeQueries.clear();
			}
			logger.info("Stopped " + localAddr + " named node queries");



			if (store != null) {
				store.close();
				store = null;
			}
			logger.info("Stopped " + localAddr + " store");


			if (dht != null) {
				dht.close();
				dht = null;
			}
			logger.info("Stopped " + localAddr + " DHT service");

			if (index != null) {
				index.close();
				index = null;
			}
			logger.info("Stopped " + localAddr + " index service");
		} catch (Exception e) {
			logger.error("Error stopping " + localAddr, e);
		}

		if (node != null) {
			nf.shutdownNode(node);
			node = null;
		}
		logger.info("Stopped " + localAddr + " DHT node");
	}

	synchronized rice.environment.Environment getNodeEnv() {
		return node.getEnvironment();
	}

	/*
	 *  Application methods
	 */

	public void deliver(rice.p2p.commonapi.Id id, rice.p2p.commonapi.Message message) {
		if (message instanceof Message) {
			Message m = (Message) message;
			socketManager.deliverMessage(m);
		} else {
			logger.warn("Received unexpected Pastry message " + message);
		}
	}

	public boolean forward(RouteMessage message) {
		return true;
	}

	private TimerTask updateKnownNodes;
	private final Object updateRoutingTableLock = new Object();
	private UpdateRoutingTable updateRoutingTable;

	public void scheduleRoutingTableUpdate() throws IOException, InterruptedException {
		boolean created = false;
		synchronized (updateRoutingTableLock) {
			if (updateRoutingTable == null && timer != null) {
				created = true;
				updateRoutingTable = new UpdateRoutingTable();
			}
		}
		if (created) {
			getNodeInfo(updateRoutingTable);
		}
	}

	public void performRoutingTableUpdate() throws Exception {
		boolean created = false;
		UpdateRoutingTable toWaitFor;
		synchronized (updateRoutingTableLock) {
			if (updateRoutingTable == null && timer != null) {
				created = true;
				updateRoutingTable = new UpdateRoutingTable();
			}
			toWaitFor = updateRoutingTable;
		}
		if (created) {
			getNodeInfo(updateRoutingTable);
		}
		synchronized (updateRoutingTableLock) {
			while (! toWaitFor.done) {
				updateRoutingTableLock.wait();
			}
			if (toWaitFor.err != null) {
				throw new Exception("Error updating routing table", toWaitFor.err);
			}
		}
	}

	private class UpdateRoutingTable implements NodeInfoSink {
		private boolean done = false;
		Exception err = null;

		public void deliver(List<NodeInfo> result) {
			Router r;
			try {
				r = new Router(result);
			} catch (Exception e) {
				logger.error("Error constructing routing table for node " + localAddr, e);
				return;
			}
			synchronized (updateRoutingTableLock) {
				if (done) {
					return;
				}
				router = r;
				updateRoutingTable = null;
				done = true;
				updateRoutingTableLock.notifyAll();
			}
			synchronized (getPastryAddress) {
				getPastryAddress.putAll(r.getPastryAddressMap());
			}
			synchronized (routerNodeHandles) {
				Iterator<Map.Entry<InetSocketAddress, NodeHandle>> it = routerNodeHandles.entrySet().iterator();
				while (it.hasNext()) {
					if (! r.getParticipants().contains(it.next().getKey())) {
						it.remove();
					}
				}
			}
			for (InetSocketAddress node : r.getParticipants()) {
				if (! routerNodeHandles.containsKey(node)) {
					routerNodeHandles.put(node, nf.getRemoteNodeHandle(r.getPastryAddress(node)));
				}
			}
		}

		public void exception(Exception e) {
			logger.info("Error retrieving range info, routing table unchanged", e);
			synchronized (updateRoutingTableLock) {
				updateRoutingTable = null;
				done = true;
				err = e;
				updateRoutingTableLock.notifyAll();
			}
		}
	}


	private void updateKnownNodes() {
		List<NodeHandle> currNodeHandles = new ArrayList<NodeHandle>();
		Node n;
		synchronized (QpApplication.this) {
			n = node;
		}
		if (n == null) {
			return;
		}
		Set<InetSocketAddress> otherNodes = QpApplication.this.nf.getOtherNodes(n, currNodeHandles);
		synchronized (knownNodes) {
			if (! knownNodes.equals(otherNodes)) {
				knownNodes.clear();
				knownNodes.addAll(otherNodes);
				knownNodesHandles.clear();
				knownNodesHandles.addAll(currNodeHandles);
			}
		}
	}

	public void update(NodeHandle handle, boolean joined) {
		if (logger.isInfoEnabled()) {
			logger.info("Node " + handle + " " + (joined ? "joined" : "left") + ", scheduling recomputation of known nodes");
		}
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				updateKnownNodes();
			}
		}, NODE_NOTIFICATION_WAIT_MS);
	}

	private void processMessage(Message m) {
		try {
			if (m.isReply()) {
				for (long id : m.getOrigIds()) {
					// Dispatch through reply table
					ReplyData rd = replyData.get(id);
					if (rd == null) {
						// Silently ignore replies we're not interested in
						if (logger.isTraceEnabled()) {
							logger.trace("Ignoring reply " + m + " to " + id + " since its reply continuation has finished");
						}
						continue;
					}
					synchronized (rd) {
						// Avoid race condition when two replies arrive simultaneously,
						// and one causes success or failure
						if (rd.hasFinished()) {
							continue;
						}

						rd.cancelPendingAction();

						boolean isSuccess = false;
						for (Class<?> c : rd.successReplies) {
							if (c.isInstance(m)) {
								isSuccess = true;
								break;
							}
						}
						synchronized (messageDests) {
							Set<Long> msgIds = messageDests.get(rd.sentTo);
							if (msgIds != null) {
								msgIds.remove(id);
								if (msgIds.isEmpty()) {
									messageDests.remove(rd.sentTo);
								}
							}
						}
						if ((! rd.retriesLeft()) || isSuccess || (! m.canRetry())) {
							rd.rc.processReply(m);
							if (rd.rc.isFinished() || ((! isSuccess) && ((! rd.retriesLeft()) || (! m.canRetry())))) {
								rd.setFinished();
								replyData.remove(id);
							} else {
								rd.startPendingAction(this);
							}
						} else {
							rd.recordFailure();
							rd.startPendingAction(this);
						}
					}
				}
				return;
			}
			if (m.getOrigin() != null) {
				MsgStatus ms = msgStatus.getStatus(m.getOrigin(), m.messageId);
				if (ms == MsgStatus.UNKNOWN || ms == MsgStatus.CAN_RETRY) {
					msgStatus.recordMessageReceived(m.getOrigin(), m.messageId);
				} else if (ms == MsgStatus.SUCCEEDED) {
					sendReplySuccess(m);
					return;
				} else if (ms == MsgStatus.FAILED) {
					sendMessage(new ReplyFailure(m, "Message has already failed", false));
					return;
				} else if (ms == MsgStatus.CANNOT_RETRY) {
					sendMessage(new ReplyFailure(m, "Message has been processed and cannot be retried", false));
					return;
				} else if (ms == MsgStatus.RECEIVED) {
					return;
				} else {
					throw new RuntimeException("Don't know how to handle " + ms);
				}
			}
			if (m instanceof DHTMessage) {
				dht.processMessage((DHTMessage) m);
			} else if (m instanceof IndexMessage) {
				index.processMessage((IndexMessage) m);
			} else if (m instanceof ShippedTuplesMessage) {
				ShippedTuplesMessage stm = (ShippedTuplesMessage) m;
				QueryExecution<M> qe;
				if (stm.namedNodeDest == null) {
					QueryOwner<M> qo = ownedQueries.get(stm.queryId);
					if (qo == null) {
						sendMessage(new DoesNotHaveQuery(stm, stm.queryId));
						qe = null;
					} else {
						qe = qo.getOwnedExecution();
					}
				} else {
					qe = namedNodeQueries.get(new Pair<Integer,String>(stm.queryId,stm.namedNodeDest));
					if (qe == null) {
						sendMessage(new DoesNotHaveQuery(stm, stm.queryId));
					}
				}
				if (qe != null) {
					qe.process(stm);
				}
			} else if (m instanceof QueryOwnerMessage) {
				QueryOwnerMessage qom = (QueryOwnerMessage) m;
				QueryOwner<M> qo = ownedQueries.get(qom.getQueryId());
				if (qo == null) {
					sendMessage(new DoesNotHaveQuery(m, qom.getQueryId()));
				} else {
					qo.process(qom);
				}
			} else if (m instanceof QueryExecutionMessage) {
				QueryExecutionMessage qem = (QueryExecutionMessage) m;
				QueryExecution<M> qe;
				final int queryId = qem.getQueryId(); 
				synchronized (distributedQueries) {
					qe = distributedQueries.get(queryId);
				}
				if (qe == null) {
					sendMessage(new DoesNotHaveQuery(m, queryId));
				} else {
					qe.process(qem);
				}
			} else if (m instanceof DistributeQueryMessage) {
				DistributeQueryMessage dqm = (DistributeQueryMessage) m;
				QueryPlanWithSchemas qpws;

				Map<String,QpSchema> tableSchemas = store.getTables();

				final int dieDelayMs = this.dieDelayMs;

				try {
					Document doc = docBuilder.parse(dqm.getQPWSInputSource());
					qpws = QueryPlanWithSchemas.deserialize(doc.getDocumentElement(), tableSchemas);
				} catch (Exception e) {
					logger.error("Error parsing query plan", e);
					sendMessage(new ReplyException(m,"Error parsing query plan", e, false));
					return;
				}

				synchronized (getPastryAddress) {
					getPastryAddress.putAll(dqm.queryRouter.getPastryAddressMap());
				}

				try {
					List<QpSchema> schemas = new ArrayList<QpSchema>(tableSchemas.values());
					schemas.addAll(qpws.querySchemas.values());
					QueryExecution<M> qe = new QueryExecution<M>(dqm.queryRouter, dqm.distributedScanOperatorPages, dqm.epoch, dqm.queryId,
							schemas, this, dqm.getOrigin(), true, dqm.attemptRecovery);

					synchronized (distributedQueries) {
						qpws.qp.createDistributedExecution(qe, null, null, dqm.attemptRecovery);
						distributedQueries.put(dqm.queryId, qe);
					}
					if (logger.isInfoEnabled()) {
						logger.info("Participant " + localAddr + " created distributed execution for query " + dqm.queryId);
					}

					for (String name : localNames) {
						QueryExecution<M> namedQE = new QueryExecution<M>(dqm.queryRouter, dqm.distributedScanOperatorPages, dqm.epoch, dqm.queryId,
								schemas, this, dqm.getOrigin(), name, dqm.attemptRecovery);
						qpws.qp.createNamedExecution(name, namedQE, null, null, dqm.attemptRecovery);
						namedNodeQueries.put(new Pair<Integer,String>(dqm.queryId,name), namedQE);
						namedQE.start();
						if (logger.isInfoEnabled()) {
							logger.info("Participant " + localAddr + " created named node " + name + " query " + dqm.queryId);
						}
					}
					qe.start();
					sendReplySuccess(dqm);

					if (logger.isInfoEnabled()) {
						logger.info("Participant " + localAddr + " created distributed query " + dqm.queryId);
					}

					if (dieDelayMs >= 0) {
						timer.schedule(new TimerTask() {

							@Override
							public void run() {
								logger.warn("Stopping participant " + localAddr);
								try {
									stop();
								} catch (Exception e) {
									logger.error("Error stopping participant " + localAddr, e);
									return;
								}
								logger.warn("Stopped participant " + localAddr);
							}

						}, dieDelayMs);

						logger.warn("Participant " + localAddr + " will die in " + dieDelayMs + " ms");
					}
				} catch (Operator.OperatorCreationException e) {
					logger.error("Error instantiating query plan", e);
					sendMessage(new ReplyException(dqm, "Error instantiating query plan", e, false));
				}
			} else if (m instanceof BeginNewQueryPhase) {
				BeginNewQueryPhase bnqp = (BeginNewQueryPhase) m;
				boolean failed = false;
				synchronized (distributedQueries) {
					QueryExecution<?> qe = distributedQueries.get(bnqp.queryId);
					if (qe == null) {
						failed = true;
					} else {
						qe.beginNewQueryPhase(bnqp);
					}
				}
				for (String name : localNames) {
					QueryExecution<?> qe = namedNodeQueries.get(new Pair<Integer,String>(bnqp.queryId,name));
					if (qe != null) {
						qe.beginNewQueryPhase(bnqp);
					}
				}
				if (failed) {
					sendMessage(new DoesNotHaveQuery(m, bnqp.queryId));
				} else {
					sendReplySuccess(m);
				}
			} else if (m instanceof TearDownQueryMessage) {
				TearDownQueryMessage tdqm = (TearDownQueryMessage) m;
				QueryExecution<M> qe = distributedQueries.remove(tdqm.queryId);
				qe.close();
				for (String name : localNames) {
					qe = namedNodeQueries.remove(new Pair<Integer,String>(tdqm.queryId,name));
					if (qe != null) {
						qe.close();
					}
				}
			} else if (m instanceof LocalRelationIs) {
				QpMessage reply;
				try {
					LocalRelationIs rri = (LocalRelationIs) m;
					String relName = store.getSchema(rri.relationId).getName();
					store.clearTable(relName);
					store.addTuples(rri.getTuples(store, mdf));
					reply = new ReplySuccess(m);
				} catch (Exception e) {
					logger.error("Error storing replicated relation", e);
					reply = new ReplyException(m,"Error storing replicated relation", e,false);
				}
				sendMessage(reply);
			} else if (m instanceof CheckRelation) {
				CheckRelation cr = (CheckRelation) m;
				Set<QpTuple<?>> missing = findMissingLocalTuples(cr.relId, cr.epoch, cr.router.getOwnedRange(localAddr));
				QpMessage mta = new MissingTuplesAre(cr,missing);
				sendMessage(mta);
			} else if (m instanceof GetNodeInfo) {
				GetNodeInfo gni = (GetNodeInfo) m;
				// Make sure we don't process the same request more than once
				final MsgStatus status = msgStatus.getStatus(gni.origFrom, gni.origMsgId); 
				if (status == MsgStatus.UNKNOWN || status == MsgStatus.RECEIVED) {
					// Send local info back to the requester
					QpMessage reply = new NodeInfoIs(gni, nodeId, pastryAddr, localAddr);
					if (logger.isTraceEnabled()) {
						logger.trace(localAddr + " sent node info " + reply.messageId + " to " + gni.origFrom + "(" + gni.origMsgId + ")");
					}
					sendMessage(reply);

					// Send on to other nodes
					Collection<NodeHandle> handles;
					synchronized (knownNodesHandles) {
						handles = new ArrayList<NodeHandle>(knownNodesHandles);
					}
					for (NodeHandle handle : handles) {
						this.sendMessage(new GetNodeInfo(handle, gni.origFrom, gni.origMsgId));
					}
				}
			} else if (m instanceof ShipConfig) {
				ShipConfig sc = (ShipConfig) m;
				ShipOperator.batchShips = sc.batchShips;
				sendReplySuccess(sc);
			} else if (m instanceof DummyMessage) {
				if (((DummyMessage) m).wantReply) {
					sendMessage(new ReplySuccess(m));
				}
			} else {
				logger.error("QpApplication doesn't know what to do with message " + m);
			}
		} catch (Exception e) {
			logger.error("Error in message processing thread", e);
			try {
				sendMessage(new ReplyException(m,"Error processing message",e,true));
			} catch (IOException ioe) {
				logger.error("Error sending ReplyException", ioe);
			} catch (InterruptedException ie) {
				return;
			}
		}
	}

	public void startedThrottling(InetSocketAddress node) {
		if (! router.getParticipants().contains(node)) {
			return;
		}

		List<ReplyData> toStop;
		synchronized (messageDests) {
			Set<Long> messageIds = messageDests.get(node);
			if (messageIds == null) {
				return;
			}
			toStop = new ArrayList<ReplyData>(messageIds.size());
			for (Long id : messageIds) {
				ReplyData rd = replyData.get(id);
				if (rd != null) {
					toStop.add(rd);
				}
			}
		}

		for (ReplyData rd : toStop) {
			rd.cancelPendingAction();
		}

		logger.info(localAddr + " started throttling " + node);
	}

	public void stoppedThrottling(InetSocketAddress node) {
		List<ReplyData> toStart;
		synchronized (messageDests) {
			Set<Long> messageIds = messageDests.get(node);
			if (messageIds == null) {
				return;
			}
			toStart = new ArrayList<ReplyData>(messageIds.size());
			for (Long id : messageIds) {
				ReplyData rd = replyData.get(id);
				if (rd != null) {
					toStart.add(rd);
				}
			}
		}
		for (ReplyData rd : toStart) {
				rd.startPendingAction(this);
		}

		logger.info(localAddr + " stopped throttling " + node);
	}

	private class MessageProcessingThread extends Thread {
		Message m;
		private boolean interruptable = true;
		private boolean interrupted = false;
		private MessageProcessingThread(int count) {
			super(tg, "Message Processing Thread #" + count + " (" + localAddr + ")");
		}

		public synchronized boolean isInterrupted() {
			return interrupted;
		}

		public synchronized void interrupt() {
			interrupted = true;
			if (interruptable) {
				super.interrupt();
			}
		}

		public void run() {
			try {
				while (! isInterrupted()) {
					final Message currMsg = socketManager.readMessage();
					synchronized (this) {
						m = currMsg;
						interruptable = false;
					}

					try {
						processMessage(currMsg);
						if (logger.isInfoEnabled()) {
							String msgClass = removePackageName(m.getClass().getName());
							synchronized (messageCounts) {
								Record rec = messageCounts.get(msgClass);
								if (rec == null) {
									messageCounts.put(msgClass, new Record(msgClass));
								} else {
									rec.increment();
								}
							}
						}
					} catch (Exception e) {
						logger.error("Error processing " + currMsg, e);
					} finally {
						synchronized (this) {
							m = null;
							interruptable = true;
						}
					}
				}
			} catch (InterruptedException ie) {
				return;
			}
		}

		synchronized boolean isBusy() {
			return (m != null);
		}
	}


	/**
	 * Send a message, after updating the reply status cache.
	 * After this method returns, the message destination, if known,
	 * will be set.
	 * 
	 * @param m			The message to send
	 * @throws IOException
	 * @throws InterruptedException
	 */
	void sendMessage(Message m) throws IOException, InterruptedException {
		if (m.isReply()) {
			QpMessage qm = (QpMessage) m;
			if (qm.isReply()) {
				final InetSocketAddress isa = qm.getDest();
				if (m instanceof ReplyException || m instanceof ReplyFailure) {
					for (long msgId : qm.getOrigIds()) {
						msgStatus.recordMessageFailure(isa, msgId, qm.canRetry());
					}
				} else if (m instanceof ReplySuccess) {
					for (long msgId : qm.getOrigIds()) {
						msgStatus.recordMessageSuccess(isa, msgId);
					}
				} else {
					for (long msgId : qm.getOrigIds()) {
						msgStatus.recordMessageFinished(isa, msgId, qm.canRetry());
					}
				}
			}
		}
		send(m);
	}

	/**
	 * Send a message. After this method returns, the message destination, if known,
	 * will be set.
	 * 
	 * @param m			The message to send
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void send(Message m) throws IOException, InterruptedException {
		m.send(localAddr, router, socketManager, endpoint);
	}

	void sendReplySuccess(Message received) throws IOException, InterruptedException {
		msgStatus.recordMessageSuccess(received.getOrigin(), received.messageId);
		QpMessage m = new ReplySuccess(received);
		send(m);
	}

	TimerTask scheduleDeliverMessage(final Message m, int delayMs) {
		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				socketManager.deliverMessage(m);
			}

		};
		timer.schedule(task, delayMs);
		return task;
	}

	TimerTask scheduleResendMessage(final ReplyData rd, int delayMs) {
		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				try {
					rd.resend(QpApplication.this);
				} catch (IOException e) {
					logger.error("Error sending message " + rd.m, e);
				} catch (InterruptedException e) {
					return;
				}
			}

			public boolean cancel() {
				if (super.cancel()) {
					logger.info("Cancelling resend of " + rd.m);
					return true;
				} else {
					return false;
				}
			}
		};
		timer.schedule(task, delayMs);
		return task;
	}

	void sendMessageAwaitReply(Message m, ReplyContinuation rc, int retryDelay, int numRetries, int replyTimeout, Class<?>... successReplies) throws IOException, InterruptedException {

		ReplyData rd = new ReplyData(rc, m, retryDelay, numRetries, replyTimeout, successReplies);
		synchronized (replyData) {
			replyData.put(m.messageId, rd);
		}
		sendMessageAwaitReply(rd);
	}
	void sendMessageAwaitReply(ReplyData rd) throws IOException, InterruptedException {
		Message m = rd.m;
		sendMessage(m);
		if (m instanceof QpMessage) {
			InetSocketAddress dest = ((QpMessage) m).getDest();
			if (dest != null) {
				synchronized (rd) {
					rd.setSentTo(dest);
					synchronized (messageDests) {
						Set<Long> msgs = messageDests.get(dest);
						if (msgs == null) {
							msgs = new HashSet<Long>();
							messageDests.put(dest, msgs);
						}
						msgs.add(m.messageId);
					}
				}
			}
		} else {
			rd.setSent();
			rd.startPendingAction(this);
		}
	}

	void sendMessageAwaitReply(Message m, ReplyContinuation rc,
			Class<?>... successReplies) throws IOException, InterruptedException {
		sendMessageAwaitReply(m, rc, DEFAULT_RETRY_DELAY, DEFAULT_NUM_RETRIES, 0, successReplies);
	}

	public MetadataFactory<M> getMetadataFactory() {
		return mdf;
	}

	public void addTable(QpSchema schema, int epoch) throws IllegalArgumentException {
		QpSchema.Location l = schema.getLocation();
		if (l != QpSchema.Location.REPLICATED && l != QpSchema.Location.STRIPED) {
			throw new IllegalArgumentException("Schema " + schema.getName() + " is neither replicated nor striped");
		}
		store.addTable(schema);

		if (l == QpSchema.Location.REPLICATED) {
			return;
		}

		Set<Integer> keyCols = schema.getKeyColsSet();

		for (int col : schema.getHashColsNoCopy()) {
			if (! keyCols.contains(col)) {
				throw new IllegalArgumentException("Table must have only key columns as hash columns");
			}
		}

		final int table = schema.relId;
		synchronized (firstEpochsForTables) {
			Integer e = firstEpochsForTables.get(table);
			if (e != null) {
				throw new IllegalArgumentException("Already have first epoch (" + e + ") for table " + table + " when trying to add new first epoch (" + epoch + ")");
			}
			firstEpochsForTables.put(table, epoch);
		}
	}

	public void addViewSchema(QpSchema schema) throws IllegalArgumentException {
		store.addTable(schema);
	}

	int getFirstEpochForTable(int table) {
		synchronized (firstEpochsForTables) {
			Integer epoch = firstEpochsForTables.get(table);
			if (epoch == null) {
				throw new IllegalArgumentException("Don't have a first epoch for table " + table);
			}
			return epoch;
		}
	}

	void clear() throws TupleStoreException, IndexServiceException, InterruptedException, IOException {
		if (msgStatus != null) {
			msgStatus.clear();	
		}
		store.clear();
		index.clear();
		dht.clear();

		firstEpochsForTables.clear();
		replyData.clear();
		socketManager.reset();
	}

	public Id getNodeId() {
		return nodeId;
	}

	public void beginQuery(int queryId, int epoch, QueryPlan qp, Collection<? extends QpSchema> schemas, Collection<QpTuple<M>> tupleDest)
	throws InterruptedException, QueryInstantiationException {
		beginQuery(queryId, epoch, new QueryPlanWithSchemas(qp,schemas), tupleDest, false);
	}

	public void beginQuery(int queryId, int epoch, QueryPlan qp, Collection<? extends QpSchema> schemas, Collection<QpTuple<M>> tupleDest, boolean attemptRecovery)
	throws InterruptedException, QueryInstantiationException {
		beginQuery(queryId, epoch, new QueryPlanWithSchemas(qp,schemas), tupleDest, attemptRecovery);
	}

	public void beginQuery(final int queryId, int epoch, QueryPlanWithSchemas qpws, Collection<QpTuple<M>> tupleDest, boolean attemptRecovery)
	throws InterruptedException, QueryInstantiationException {
		try {
			Router queryRouter = router;

			logger.info("Starting query " + queryId);

			Map<String,QpSchema> baseTables = store.getTables();
			Map<Integer,Collection<EpochNum>> distScanPages = new HashMap<Integer,Collection<EpochNum>>();
			List<QueryPlan> scans = new ArrayList<QueryPlan>();
			qpws.qp.getOperatorsOfType(scans, DistributedScanNode.class);
			for (QueryPlan qp : scans) {
				DistributedScanNode dsn = (DistributedScanNode) qp;
				distScanPages.put(dsn.operatorId, Collections.unmodifiableCollection(index.getPagesForRelation(baseTables.get(dsn.outputSchema).relId, epoch)));
			}


			List<QpSchema> schemas = new ArrayList<QpSchema>(baseTables.values());
			schemas.addAll(qpws.querySchemas.values());

			final QueryOwner<M> qo = new QueryOwner<M>(queryRouter, queryId, this, distScanPages, epoch, qpws.qp, schemas, tupleDest, getParticipants(), attemptRecovery);

			synchronized (ownedQueries) {
				ownedQueries.put(queryId, qo);
			}

			Document doc = docBuilder.newDocument();
			Element el = doc.createElement("queryPlanAndSchema");
			doc.appendChild(el);
			qpws.serialize(doc, el, baseTables);
			StringWriter sw = new StringWriter();
			DomUtils.write(doc, sw);

			final Router r = router;
			final Set<InetSocketAddress> remaining = new HashSet<InetSocketAddress>(r.getParticipants());
			final Map<InetSocketAddress,Message> errors = new HashMap<InetSocketAddress,Message>();

			DistributeQueryMessage dqm = null;

			for (final InetSocketAddress dest : r.getParticipants()) {
				if (dqm == null) {
					dqm = new DistributeQueryMessage(dest, sw.toString(), epoch, queryId, queryRouter, attemptRecovery, distScanPages);
				} else {
					dqm = dqm.retarget(dest);
				}
				sendMessageAwaitReply(dqm, new ReplyContinuation() {
					private boolean finished = false;
					public synchronized boolean isFinished() {
						return finished;
					}

					public synchronized void processReply(Message m) {
						finished = true;
						synchronized (remaining) {
							remaining.remove(dest);
							if (! (m instanceof ReplySuccess)) {
								errors.put(dest, m);
							}
							if (remaining.isEmpty()) {
								remaining.notify();
							}
						}
					}

				}, 0, 0, QUERY_DISSEMINATION_TIME_MS, Message.class);
			}

			synchronized (remaining) {
				while (! remaining.isEmpty()) {
					remaining.wait();
				}
			}

			if (! errors.isEmpty()) {
				throw new QueryInstantiationException(errors.toString());
			}
			logger.info("Starting query owner for query " + queryId);
			qo.start();
		} catch (InterruptedException ie) {
			throw ie;
		} catch (QueryInstantiationException qie) {
			throw qie;
		} catch (Exception e) {
			throw new QueryInstantiationException(e);
		}
	}
	
	public void continueQuery(int queryId, int epoch) throws InterruptedException, IndexServiceException{
		QueryOwner<?> qo;
		synchronized (ownedQueries) {
			qo = ownedQueries.get(queryId);
		}
		if (qo == null) {
			throw new IllegalArgumentException("Don't have owner query with id " + queryId);
		}		
		//qo.continueQueryOwner(epoch);
	}

	public void endQuery(int queryId) throws InterruptedException, IOException {
		QueryOwner<?> qo;
		synchronized (ownedQueries) {
			qo = ownedQueries.remove(queryId);
		}
		if (qo != null) {
			qo.close();
		}

		Router r = qo.getOwnedExecution().getRouter(qo.getCurrentPhase());

		for (InetSocketAddress dest : r.getParticipants()) {
			send(new TearDownQueryMessage(dest,queryId));
		}
	}

	public void waitUntilDone(int queryId) throws InterruptedException, QueryFailure, IOException {
		QueryOwner<?> qo;
		synchronized (ownedQueries) {
			qo = ownedQueries.get(queryId);
		}
		if (qo == null) {
			throw new IllegalArgumentException("Don't have owner query with id " + queryId);
		}
		try {
			qo.waitUntilDone();
		} catch (QueryFailure qf) {
			endQuery(queryId);
			throw qf;
		} catch (Exception e) {
			QueryFailure qf = new QueryFailure("Caught unexpected exception", e);
			endQuery(queryId);
			throw qf;
		}
	}

	public TupleStore<M> getStore() {
		return this.store;
	}

	public void addLocalName(String name) {
		this.localNames.add(name);
	}

	public void removeLocalName(String name) {
		this.localNames.remove(name);
	}

	public void clearLocalNames() {
		this.localNames.clear();
	}

	InetSocketAddress getNamedNodehandle(String name) {
		InetSocketAddress isa = allNames.get(name);
		if (isa == null) {
			throw new IllegalArgumentException("Don't know location of named node " + name);
		}
		return isa;
	}

	public DHTService<M> getDHT() {
		return this.dht;
	}

	public IndexService getIndex() {
		return this.index;
	}

	public void printStoreStats(PrintStream ps) throws Exception {
		store.printStats(ps);
	}

	public void publishReplicatedRelation(int relationId, Collection<QpTuple<M>> tuples) throws IOException, InterruptedException {
		final Set<InetSocketAddress> remaining = new HashSet<InetSocketAddress>(router.getParticipants());
		final Map<InetSocketAddress,Message> errors = new HashMap<InetSocketAddress,Message>();
		LocalRelationIs msg = null;
		for (final InetSocketAddress dest : router.getParticipants()) {
			if (msg == null) {
				msg = new LocalRelationIs(dest, relationId, tuples, mdf);
			} else {
				msg = msg.retarget(dest);
			}
			sendMessageAwaitReply(msg, new ReplyContinuation() {
				private boolean finished = false;
				public synchronized boolean isFinished() {
					synchronized (remaining) {
						return finished;
					}
				}

				public void processReply(Message m) {
					synchronized (this) {
						finished = true;
					}
					synchronized (remaining) {
						if (! (m instanceof ReplySuccess)) {
							errors.put(dest,m);
						}
						remaining.remove(dest);
						if (remaining.isEmpty()) {
							remaining.notify();
						}
					}
				}
			}, ReplySuccess.class);
		}

		synchronized (remaining) {
			while (! remaining.isEmpty()) {
				remaining.wait();
			}
		}

		if (! errors.isEmpty()) {
			logger.error("Received errors in reply to LocalRelationIs: " + errors);
		}
	}

	public Map<InetSocketAddress,Set<QpTuple<?>>> findMissingTuples(String relation, int epoch) throws InterruptedException, IOException {
		final Map<InetSocketAddress,Set<QpTuple<?>>> retval = new HashMap<InetSocketAddress,Set<QpTuple<?>>>();
		final QpSchema schema = store.getSchema(relation);

		final Router r = router;
		final Set<InetSocketAddress> remaining = new HashSet<InetSocketAddress>(r.getParticipants());
		final Map<InetSocketAddress,Message> errors = new HashMap<InetSocketAddress,Message>();

		for (final InetSocketAddress node : r.getParticipants()) {
			QpMessage m = new CheckRelation(node,router,schema.relId,epoch);

			ReplyContinuation rc = new ReplyContinuation() {
				private boolean finished = false;
				public synchronized boolean isFinished() {
					return finished;
				}

				public void processReply(Message m) {
					synchronized (this) {
						finished = true;
					}
					synchronized (remaining) {
						if (m instanceof MissingTuplesAre) {
							remaining.remove(node);
							if (remaining.isEmpty()) {
								remaining.notify();
							}
							InetSocketAddress addr = m.getOrigin();
							Set<QpTuple<?>> missing = ((MissingTuplesAre) m).getData(schema, store);
							if (! missing.isEmpty()) {
								retval.put(addr, missing);
							}
						} else {
							errors.put(node, m);
						}
					}
				}

			};
			sendMessageAwaitReply(m, rc, 0, 0, 240000, Message.class);
		}


		synchronized (remaining) {
			while (! remaining.isEmpty()) {
				remaining.wait();
			}
		}

		if (! errors.isEmpty()) {
			logger.error("Received errors in reply to LocalRelationIs: " + errors);
		}


		return retval;
	}

	private Set<QpTuple<?>> findMissingLocalTuples(int relId, int epoch, final IdRange ownedRange) throws InterruptedException {
		final HashSet<QpTuple<?>> missing = new HashSet<QpTuple<?>>();
		final Holder<Boolean> done = new Holder<Boolean>(false);

		index.getTuplesInRelation(relId, epoch, new TupleSink() {
			int count = 0;
			Set<Integer> remaining = new HashSet<Integer>();
			boolean deliveredAll = false;
			int numPagesRemaining = -1;
			public void deliverTuples(QpTuple<?>[] contents) {
				final ArrayList<QpTuple<?>> toFind = new ArrayList<QpTuple<?>>(contents.length);
				for (QpTuple<?> t : contents) {
					if (t == null) {
						break;
					}
					if (ownedRange.contains(t.getQPid())) {
						toFind.add(t);
					}
				}
				final int thisCount;
				synchronized (missing) {
					if (numPagesRemaining < 0) {
						processException(new RuntimeException("numPagesRemaining < 0, is totalNumTuplesIs not being called?"));
						return;
					}
					--numPagesRemaining;
					if (numPagesRemaining < 0) {
						processException(new RuntimeException("numPagesRemaining < 0, pages are being delivered multiple times"));
						return;
					}					
					if (numPagesRemaining == 0) {
						deliveredAll = true;
					}
					if (toFind.isEmpty()) {
						if (deliveredAll) {
							done.value = true;
							missing.notify();
						}
						return;
					} else {
						thisCount = count++;
						remaining.add(thisCount);
					}
				}
				store.getTuples(toFind, new TupleStore.TupleSink<M>() {
					int numRemaining = toFind.size();
					public synchronized void deliverTuples(
							Collection<QpTuple<M>> tuples) {
						numRemaining -= tuples.size();
						if (numRemaining == 0) {
							synchronized (missing) {
								remaining.remove(thisCount);
								if (deliveredAll && remaining.isEmpty()) {
									done.value = true;
									missing.notify();
								}
							}
						}
					}

					public void processException(TupleStoreException tse) {
						tse.printStackTrace();
					}

					public synchronized void tupleNotFound(QpTuple<?> key) {
						numRemaining -= 1;
						synchronized (missing) {
							missing.add(key);
							if (numRemaining == 0) {
								remaining.remove(thisCount);
								if (deliveredAll && remaining.isEmpty()) {
									done.value = true;
									missing.notify();
								}
							}
						}
					}

				});
			}

			public void processException(Exception e) {
				e.printStackTrace();
			}

			public void totalNumTuplesIs(int numTuples, int numPages) {
				synchronized (missing) {
					numPagesRemaining = numPages;
				}
			}
		});

		synchronized (missing) {
			while (! done.value) {
				missing.wait();
			}
		}

		if (logger.isInfoEnabled()) {
			logger.info("Finished checking relation " + store.getSchema(relId).getName() + ", found " + missing.size() + " missing tuples");
		}
		return missing;
	}

	public static String removePackageName(String fullyQualified) {
		return fullyQualified.substring(fullyQualified.lastIndexOf('.') + 1);
	}

	public void startForcedThrottling() {
		socketManager.startForcedThrottling();
	}

	public void stopForcedThrottling() {
		socketManager.stopForcedThrottling();
	}

	private interface NodeInfoSink {
		void deliver(List<NodeInfo> result);
		void exception(Exception e);
	}

	private void getNodeInfo(final NodeInfoSink ris) throws IOException, InterruptedException {
		final GetNodeInfo gni = new GetNodeInfo(endpoint.getLocalNodeHandle(), localAddr);

		logger.info("Node " + localAddr + " is sending GetNodeInfo(" + gni.messageId + ")");

		ReplyContinuation rc = new ReplyContinuation() {
			List<NodeInfo> retval = new ArrayList<NodeInfo>();
			Set<InetSocketAddress> processed = new HashSet<InetSocketAddress>();
			{
				// Include local info
				retval.add(new NodeInfo(nodeId, pastryAddr, localAddr));
				processed.add(localAddr);
			}

			boolean finished = false;
			public synchronized boolean isFinished() {
				return finished;
			}

			public synchronized void processReply(Message m) {
				if (m instanceof ReplyTimeout) {
					finished = true;
					ris.deliver(retval);
				} else if (m instanceof NodeInfoIs) {
					if (logger.isTraceEnabled()) {
						logger.trace("GetNodeInfo(" + gni.messageId + ") at " + localAddr + " received NodeInfoIs " + m.messageId + " from " + m.getOrigin());
					}
					NodeInfoIs nii = (NodeInfoIs) m;
					if (processed.add(nii.getOrigin())) {
						retval.add(nii.ni);
					}
				} else {
					logger.warn("Received unexpected reply to GetNodeInfo: " + m);
				}
			}

		};

		this.sendMessageAwaitReply(gni, rc, 0, 0, FLOODING_MAX_WAIT_INTERVAL_MS, ReplyTimeout.class, NodeInfoIs.class);
	}

	public synchronized boolean throttlingOccurring() {
		return socketManager.throttlesNodes() || socketManager.isThrottledByNodes();
	}

	public Router getRouter() {
		return router;
	}

	public void sentMessagesReceived(InetSocketAddress sentTo, LongList msgIds) {
		if (logger.isTraceEnabled()) {
			logger.trace("Messages sent from " + localAddr + " to " + sentTo + " have been received: " + msgIds);
		}
	}

	public Set<InetSocketAddress> getParticipants() {
		return router.getParticipants();
	}

	void removeReplyContinuation(long msgId) {
		ReplyData rd = replyData.remove(msgId);
		if (rd == null) {
			return;
		}
		rd.cancelPendingAction();
	}

	public void messageSendingFailed(LongList msgIds) {
		try {
			for (long msgId : msgIds.getList()) {
				ReplyData rd = replyData.get(msgId);
				if (rd == null) {
					continue;
				}
				Message m = new ReplySendingFailed((QpMessage) rd.m);
				processMessage(m);
			}
		} catch (Exception e) {
			logger.error("Error enqueing notification that sending failed", e);
		}
	}

	public void messagesSent(LongList msgIds) {
		for (long msgId : msgIds.getList()) {
			ReplyData rd = replyData.get(msgId);
			if (rd != null) {
				synchronized (rd) {
					rd.setSent();
					rd.startPendingAction(this);
				}
			}
		}
		if (logger.isTraceEnabled()) {
			logger.trace("Node " + localAddr + " sent messages " + msgIds);
		}
	}

	public void setShipBatching(boolean batch) throws IOException, InterruptedException {
		final Set<InetSocketAddress> remaining = new HashSet<InetSocketAddress>(router.getParticipants());
		final Set<InetSocketAddress> timedOut = new HashSet<InetSocketAddress>();
		for (final InetSocketAddress dest : router.getParticipants()) {
			ShipConfig sc = new ShipConfig(dest,batch);
			sendMessageAwaitReply(sc, new ReplyContinuation() {
				private boolean finished = false;
				public synchronized boolean isFinished() {
					synchronized (remaining) {
						return finished;
					}
				}

				public void processReply(Message m) {
					synchronized (this) {
						finished = true;
					}
					synchronized (remaining) {
						if (m instanceof ReplyTimeout) {
							timedOut.add(dest);
						}
						remaining.remove(dest);
						if (remaining.isEmpty()) {
							remaining.notify();
						}
					}
				}
			}, ReplySuccess.class);
		}

		synchronized (remaining) {
			while (! remaining.isEmpty()) {
				remaining.wait();
			}
		}

		if (timedOut.isEmpty()) {
			logger.info("Set ship batching to " + batch);
		} else {
			logger.error("Received no reply to ShipConfig from " + timedOut);
		}
	}

	Router getRouterForQuery(int queryId, int phaseNo) {
		synchronized (distributedQueries) {
			QueryExecution<?> qe = distributedQueries.get(queryId);
			if (qe == null) {
				return null;
			} else {
				return qe.getRouter(phaseNo);
			}
		}
	}

	Set<InetSocketAddress> getFailedNodesForQuery(int queryId) {
		synchronized (distributedQueries) {
			QueryExecution<?> qe = distributedQueries.get(queryId);
			if (qe == null) {
				return null;
			} else {
				return qe.getFailedNodes();
			}
		}
	}

	public void peerIsDead(InetSocketAddress peer) {
		List<QueryOwner<M>> qos = new ArrayList<QueryOwner<M>>();
		synchronized (ownedQueries) {
			qos.addAll(ownedQueries.values());
		}
		for (QueryOwner<M> qo : qos) {
			qo.nodesHaveFailed(Collections.singleton(peer));
		}
		List<QueryExecution<M>> qes = new ArrayList<QueryExecution<M>>();
		synchronized (distributedQueries) {
			qes.addAll(distributedQueries.values());
		}
		synchronized (namedNodeQueries) {
			qes.addAll(namedNodeQueries.values());
		}
		for (QueryExecution<?> qe : qes) {
			qe.getRecordTuples().nodesHaveFailed(Collections.singleton(peer));
		}

		Set<Long> msgIds;
		synchronized (messageDests) {
			msgIds = messageDests.remove(peer);
		}
		if (msgIds == null) {
			return;
		}
		List<Long> canRetry = new ArrayList<Long>(), cannotRetry = new ArrayList<Long>();
		for (Long id : msgIds) {
			ReplyData rd = replyData.get(id);
			if (rd == null) {
				continue;
			}
			if (((QpMessage) rd.m).hasDestId()) {
				canRetry.add(id);
			} else {
				cannotRetry.add(id);
			}
		}

		try {
			if (! canRetry.isEmpty()) {
				processMessage(new MessageDestHasDied(peer,canRetry,true));
			}
			if (! cannotRetry.isEmpty()) {
				processMessage(new MessageDestHasDied(peer,cannotRetry,false));
			}
		} catch (Exception e) {
			logger.error("Error notifying of node death", e);
		}
	}

	void nodesHaveFailed(Set<InetSocketAddress> failedNodes) {
		router = this.router.getRouterWithout(failedNodes);
	}

	private volatile int dieDelayMs = -1;

	public void dieAfterNextQuery(int msDelay) {
		dieDelayMs = msDelay;
	}


	public void setMaxSendRate(int maxKBperSecond) {
		socketManager.setMaxKBPerSecond(maxKBperSecond);
	}

}

package edu.upenn.cis.orchestra.p2pqp;

import java.io.IOException;
import java.io.Serializable;
import java.net.InetSocketAddress;

import rice.p2p.commonapi.Endpoint;

public abstract class Message implements Serializable {
	private static long nextMessageId = 0;

	public final long messageId;
	private InetSocketAddress from;

	public Message() {
		messageId = getNextMessageId();
	}
	
	Message(long msgId, InetSocketAddress from) {
		this.messageId = msgId;
		this.from = from;
	}
	
	private static synchronized long getNextMessageId() {
		return nextMessageId++;
	}
	
	final void send(InetSocketAddress from, Router r, SocketManager sm,
			Endpoint e) throws IOException, InterruptedException {
		this.from = from;
		sendImpl(r,sm, e);
	}

	void sendImpl(Router r, SocketManager sm,
			Endpoint e) throws IOException, InterruptedException {
		throw new UnsupportedOperationException("Messages of this type cannot be sent");
	}

	public InetSocketAddress getOrigin() {
		return from;
	}

	public boolean isReply() {
		return false;
	}
	
	protected long[] getOrigIds() {
		return null;
	}
	
	protected boolean canRetry() {
		return false;
	}
}

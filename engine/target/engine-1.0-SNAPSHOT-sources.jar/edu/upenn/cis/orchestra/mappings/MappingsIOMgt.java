package edu.upenn.cis.orchestra.mappings;

import java.util.ArrayList;
import java.util.List;

import edu.upenn.cis.orchestra.Config;
import edu.upenn.cis.orchestra.Debug;
import edu.upenn.cis.orchestra.datamodel.AtomConst;
import edu.upenn.cis.orchestra.datamodel.IntType;
import edu.upenn.cis.orchestra.datamodel.OrchestraSystem;
import edu.upenn.cis.orchestra.datamodel.Peer;
import edu.upenn.cis.orchestra.datamodel.Relation;
import edu.upenn.cis.orchestra.datamodel.RelationContext;
import edu.upenn.cis.orchestra.datamodel.RelationField;
import edu.upenn.cis.orchestra.datamodel.Mapping;
import edu.upenn.cis.orchestra.datamodel.Atom;
import edu.upenn.cis.orchestra.datamodel.AtomArgument;
import edu.upenn.cis.orchestra.datamodel.AtomVariable;
import edu.upenn.cis.orchestra.datamodel.Schema;
import edu.upenn.cis.orchestra.datamodel.exceptions.RelationNotFoundException;

/**
 * 
 * @author gkarvoun
 *
 */
public class MappingsIOMgt 
{

	public static List<Rule> inOutTranslationR(OrchestraSystem system, List<Rule> rules, boolean ins){	
		List<Rule> ret = new ArrayList<Rule>();

		for(Rule r: rules){
			try{
				Atom head = r.getHead();
				Schema s = head.getSchema();
				Peer p = head.getPeer();

//				TableSchema rl = s.getRelation(head.getRelation().getDbRelName() + "_L");
				Relation rr = s.getRelation(head.getRelation().getLocalRejDbName());//.getDbRelName() + "_R");

//				RelationContext rlc = new RelationContext(rl, s, p);
				RelationContext rrc = new RelationContext(rr, s, p, false);


//				Add \neg R_R in the body of every mapping with R in the head
				Atom notrra = new Atom(rrc, head.getValues());
				notrra.negate();

				Rule mappR = r.deepCopy();
				if(ins){
					mappR.getBody().add(notrra);	
				}
				ret.add(mappR);
			}catch(RelationNotFoundException e){
				Debug.println("Relation not found! " + e.getMessage());
				e.printStackTrace();
			}
		}
		return ret;
	}	

	public static List<Rule> inOutTranslationL(OrchestraSystem system, List<RelationContext> rels) throws RelationNotFoundException {	
		List<Rule> ret = new ArrayList<Rule>();

//		Create a new mapping from R_L to R			
//		ScMappingAtom rla = new ScMappingAtom(rlc, head.getValues());

		for(RelationContext r : rels){
			Relation rl = null;
			try {
				//rl = r.getSchema().getRelation(r.getRelation().getDbRelName() + "_L");
				rl = r.getSchema().getRelation(r.getRelation().getLocalInsDbName());//.getDbRelName() + "_L");
			} catch (RelationNotFoundException rnf) {
				// Skip if there's no _L relation
				continue;
			}

			RelationContext rlc = new RelationContext(rl, r.getSchema(), r.getPeer(), false);

			List<AtomArgument> l = new ArrayList<AtomArgument>();
			List<AtomArgument> hl = new ArrayList<AtomArgument>();

			for(int k = 0; k < r.getRelation().getFields().size(); k++){
				String v = Mapping.getFreshAutogenVariableName();
				l.add(new AtomVariable(v));
				if(Config.getEdbbits() && k == r.getRelation().getFields().size()-1){
					AtomConst c = new AtomConst("1");
					c.setType(new IntType(false));
					hl.add(c);
				}else{
					hl.add(new AtomVariable(v));
				}
			}

			
			Atom ra = new Atom(r, hl);
			Atom rla = new Atom(rlc, l);
//			List<ScMappingAtom> h = new ArrayList<ScMappingAtom>();
			List<Atom> b = new ArrayList<Atom>();
//			h.add(ra);
//			b.add(rla);

//			ScMapping copyL = new ScMapping("COPY" + r.getRelation().getDbRelName() + "_L",  "COPY" + r.getRelation().getDbRelName() + "_L", true, 1, h, b);

			b.add(rla);
			Rule copyL = new Rule(ra, b, null, system.getMappingDb());
			copyL.setFakeMapping(true);
			copyL.setId("BASE" + ra.getRelation().getName());
			ret.add(copyL);
		}
		return ret;
	}
}

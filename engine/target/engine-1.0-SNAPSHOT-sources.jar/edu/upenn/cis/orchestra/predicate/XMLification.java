package edu.upenn.cis.orchestra.predicate;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.datamodel.AbstractRelation;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class XMLification {
	private static class TagDatum {
		String tagName;
		Class<? extends Predicate> tagClass;
		
		TagDatum(String tagName, Class<? extends Predicate> tagClass) {
			this.tagName = tagName;
			this.tagClass = tagClass;
		}
	}
	
	private static List<TagDatum> tagData = new ArrayList<TagDatum>();
	
	private static String getTag(Predicate p) {
		for (TagDatum td : tagData) {
			if (td.tagClass.isInstance(p)) {
				return td.tagName;
			}
		}
		return null;
	}
	
	private static Class<? extends Predicate> getClass(String tag) {
		for (TagDatum td : tagData) {
			if (td.tagName.equals(tag)) {
				return td.tagClass;
			}
		}
		return null;
	}
	
	private static void registerType(String tagName, Class<? extends Predicate> tagClass) {
		tagData.add(new TagDatum(tagName, tagClass));
	}
	
	static {
		registerType("and", AndPred.class);
		registerType("compare", ComparePredicate.class);
		registerType("not", NotPred.class);
		registerType("or", OrPred.class);
	}
	
	public static Element serialize(Predicate p, Document d, AbstractRelation ts) {
		String tag = getTag(p);
		if (tag == null) {
			throw new IllegalArgumentException("Don't have tag registered for predicate of type " + p.getClass().getName());
		}
		Element el = d.createElement(tag);
		p.serialize(d, el, ts);
		return el;
	}
	
	public static Predicate deserialize(Element el, AbstractRelation ts) throws XMLParseException {
		Class<? extends Predicate> c = getClass(el.getTagName());
		if (c == null) {
			throw new XMLParseException("Cannot find class to deserialize predicate", el);
		}
		try {
			Method m = c.getDeclaredMethod("deserialize", Element.class, AbstractRelation.class);
			Object o = m.invoke(null, el, ts);
			return (Predicate) o;
		} catch (NoSuchMethodException e) {
			throw new XMLParseException("Could not find deserialize method for class " + c.getName(), el);
		} catch (IllegalAccessException e) {
			throw new XMLParseException("Error invoking deserialize method on class " + c.getName(), el);
		} catch (InvocationTargetException e) {
			if (e.getCause() instanceof XMLParseException) {
				throw (XMLParseException) e.getCause();
			} else {
				throw new XMLParseException("Error invoking deserialize method on class " + c.getName(), e.getCause());
			}
		}
		
	}
}

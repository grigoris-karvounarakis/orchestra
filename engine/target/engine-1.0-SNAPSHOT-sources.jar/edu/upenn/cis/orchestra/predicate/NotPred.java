package edu.upenn.cis.orchestra.predicate;

import java.util.List;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.datamodel.AbstractRelation;
import edu.upenn.cis.orchestra.datamodel.AbstractTuple;
import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;

/**
 * Class to represent the negation of a predicate
 * 
 * @author Nick Taylor
 */
public class NotPred implements Predicate  {
	private static final long serialVersionUID = 1L;
	Predicate p;
	/**
	 * Create a new predicate that returns the negation
	 * of another predicate
	 * 
	 * @param p		The predicate to negate
	 */
	public NotPred(Predicate p) {
		this.p = p;
	}
	public boolean eval(AbstractTuple<?> t) throws CompareMismatch {
		return (! p.eval(t));
	}
	public String toString() {
		return "!(" + p.toString() + ")";
	}
	public String getSqlCondition(AbstractRelation ts, String prefix, String suffix) {
		return "NOT " + p.getSqlCondition(ts, prefix, suffix);
	}
	public boolean equals(Object o) {
		if (o == null || o.getClass() != this.getClass()) {
			return false;
		}
		NotPred np = (NotPred) o;
		return p.equals(np.p);
	}
	public void serialize(Document d, Element el, AbstractRelation ts) {
		el.appendChild(XMLification.serialize(p, d, ts));
	}
	static Predicate deserialize(Element el, AbstractRelation ts) throws XMLParseException {
		List<Element> children = DomUtils.getChildElements(el);
		if (children.size() != 1) {
			throw new XMLParseException("Not predicate must contain exactly two other predicates", el);
		}
		return new NotPred(XMLification.deserialize(children.get(0), ts));
	}
	public Set<Integer> getColumns() {
		return p.getColumns();
	}

}
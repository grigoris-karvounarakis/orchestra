package edu.upenn.cis.orchestra.datamodel;

import java.io.Serializable;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.datamodel.exceptions.UnsupportedTypeException;
import edu.upenn.cis.orchestra.repository.model.beans.ScFieldBean;
import edu.upenn.cis.orchestra.util.XMLParseException;

/*******************************************************************************
 * Class used to describe a relation field (equivalent to a table column for
 * relational). Types are used as JDBC types.
 * 
 * @author Olivier Biton
 * @see java.sql.Types
 *      ****************************************************************
 */
public class RelationField implements Serializable {
	public static final long serialVersionUID = 1L;

	/** Field name */
	private String _name;
	/** Field description */
	private String _description;
	/** Orchestra type */
	private Type _type;

	private AbstractRelation _rel;

	/**
	 * The extension used for labeled null columns.
	 */
	public static String LABELED_NULL_EXT = "_LN";

	/**
	 * Creates a new field
	 * 
	 * @param name
	 *            Field's name
	 * @param description
	 *            Field's description
	 * @param isNullable
	 *            True if the field can contain null values
	 * @param dbType
	 *            Database type (RDBMS specific)
	 * @throws UnsupportedTypeException
	 */
	public RelationField(String name, String description, boolean isNullable,
			String dbType) throws UnsupportedTypeException {
		_name = name;
		_description = description;
		_type = Type.deserialize(dbType, isNullable);
		// assert(_type != null);
	}

	public RelationField(String name, String description, Type type) {
		_name = name;
		_description = description;
		_type = type;
		assert (_type != null);
	}

	/**
	 * Deep copy of a given field. <BR>
	 * Use the method deepCopy to benefit from polymorphism
	 * 
	 * @param field
	 *            Field to copy
	 * @roseuid 449AEADF00BB
	 * @see RelationField#deepCopy()
	 */
	protected RelationField(RelationField field) {
		_name = field.getName();
		_description = field.getDescription();
		_type = field.getType();
		assert (_type != null);
	}

	public RelationField(ScFieldBean fieldB) throws UnsupportedTypeException {
		_name = fieldB.getName();
		_description = fieldB.getDescription();
		_type = Type.deserialize(fieldB.getDbType(), fieldB.isNullable());
		assert (_type != null);
	}

	public Type getType() {
		return _type;
	}

	/**
	 * Get the field's name
	 * 
	 * @return Field's name
	 * @roseuid 44AD2CE8006D
	 */
	public String getName() {
		return _name;
	}

	/**
	 * Get the field's description
	 * 
	 * @return Field's description
	 * @roseuid 44AD2CF101A5
	 */
	public String getDescription() {
		return _description;
	}

	/**
	 * Get the field's type, as defined in the JDBC API
	 * 
	 * @return Fields type
	 * @roseuid 44AD2D00007D
	 * @see java.sql.Types
	 */
	public int getSqlTypeCode() {
		return _type.getSqlTypeCode();
	}

	/**
	 * Is this field nullable?
	 * 
	 * @return True if the field can contain null values
	 */
	public boolean isNullable() {
		return _type.isNullable();
	}

	/**
	 * Get a deep copy of the field
	 * 
	 * @return Deep copy of this field
	 * @see RelationField#ScField(RelationField)
	 */
	public RelationField deepCopy() {
		return new RelationField(this);
	}

	/**
	 * Returns a description of the field, conforms to the flat file format
	 * defined in <code>RepositoryDAO</code>
	 * 
	 * @return Field's description
	 */
	public String toString() {
		return getName() + " " + _type.getSQLType() + " " + _type.toString();
	}

	/**
	 * Convert this object to its bean representation
	 * 
	 * @return Bean describing the object
	 */
	public ScFieldBean toBean() {
		ScFieldBean res = new ScFieldBean();

		res.setName(getName());
		res.setDbType(getSQLTypeName());
		res.setType(_type.getSqlTypeCode());
		res.setDescription(_description);
		res.setNullable(_type.isNullable());

		// String[] ignore = {"_type"};
		// Copy the bean properties
		// BeanUtils.copyProperties(this, res, ignore);

		return res;
	}

	/**
	 * Get the database type (RDMBS specific)
	 * 
	 * @return Database type
	 */
	public String getSQLType() {
		return _type.getSQLType();
	}

	/**
	 * Get the database type (DON'T APPEND "NOT NULL")
	 * 
	 * @return
	 */
	public String getSQLTypeName() {
		return _type.getSQLTypeName();
	}

	public void serialize(Document doc, Element field) {
		field.setAttribute("name", _name);
		field.setAttribute("description", _description);
		_type.serialize(doc, field);
	}

	public static RelationField deserialize(Element field)
			throws XMLParseException, UnsupportedTypeException {
		String name = field.getAttribute("name");
		String description = field.getAttribute("description");
		Type type = Type.deserialize(field);
		return new RelationField(name, description, type);
	}

	public boolean equals(RelationField other) {
//		return (_name.equals(other._name) && _type.equals(other._type) && _description
//		.equals(other._description));

		if(_name.equals(other._name) && _type.equals(other._type) && _description
				.equals(other._description)){
			if((_rel == null && other._rel == null) || 
				(_rel != null && other._rel != null && _rel.equals(other._rel))){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public boolean equals(Object oth) {
		if (oth instanceof RelationField) {
			return equals((RelationField) oth);
		} else {
			return false;
		}
	}

	public int hashCode() {
		return _name.hashCode();
	}

	/**
	 * Return <code>true</code> if <code>columnName</code> follows the
	 * labeled null naming convention, <code>false</code> otherwise.
	 * 
	 * @param columnName
	 *            name to test.
	 * @return see description.
	 */
	public static boolean isLabeledNull(String columnName) {
		return columnName.endsWith(LABELED_NULL_EXT);
	}

	public void setRelation(AbstractRelation rel) {
		_rel = rel;
	}

	public AbstractRelation getRelation() {
		return _rel;
	}

}

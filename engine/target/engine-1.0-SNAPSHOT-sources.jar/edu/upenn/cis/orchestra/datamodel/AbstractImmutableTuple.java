package edu.upenn.cis.orchestra.datamodel;

import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.util.BitSet;
import edu.upenn.cis.orchestra.util.ByteArrayWrapper;


public abstract class AbstractImmutableTuple<S extends AbstractRelation> extends AbstractTuple<S> {
	private static final long serialVersionUID = 1L;

	private final boolean onlyKey;
	private final byte[] data;
	private final int[] offsets;
	private final int bitSetSize;

	/**
	 * Construct a new tuple
	 * 
	 * @param t				A tuple to copy the values from
	 * @param onlyKey		<code>true</code> to copy all fields,
	 * 						<code>false</code> to copy only the key fields
	 */
	public AbstractImmutableTuple(final AbstractTuple<S> t, boolean onlyKey) {
		super(t.schema);
		this.onlyKey = onlyKey;
		offsets = new int[onlyKey ? schema.keyColsArray.length : schema.allColsArray.length];
		bitSetSize = BitSet.numBytes(offsets.length);
		try {
			data = init(t.schema, onlyKey, offsets, new GetField() {
				public ByteArrayWrapper getField(int col) {
					if (t.isLabeledNull(col)) {
						return new ByteArrayWrapper(IntType.getBytes(t.getLabeledNull(col)));
					} else {
						return new ByteArrayWrapper(schema._columnTypes[col].getBytes(t.get(col)));
					}
				}

				public boolean isLabeledNull(int col) {
					return t.isLabeledNull(col);
				}

				public boolean isNull(int col) {
					return t.isNull(col);
				}

				public void checkValidForType(Type t, int col) {
					// Since the schema isn't changing we don't need to check
				}

			}, null);
		} catch (ValueMismatchException e) {
			throw new IllegalStateException(e);
		}
	}

	/**
	 * Construct a new tuple
	 * 
	 * @param schema			The schema
	 * @param onlyKey			<code>true</code> to set only key fields,
	 * 							<code>false</code> to set only key fields
	 * @param fields			An array of <code>schema.getNumCols()</code> fields
	 * 							representing the values to be stored in this tuple
	 * @throws ValueMismatchException
	 */
	public AbstractImmutableTuple(final S schema, boolean onlyKey, final Object[] fields) throws ValueMismatchException {
		super(schema);
		this.onlyKey = onlyKey;
		offsets = new int[onlyKey ? schema.keyColsArray.length : schema.allColsArray.length];
		bitSetSize = BitSet.numBytes(offsets.length);
		data = init(schema, onlyKey, offsets, new GetField() {
			public ByteArrayWrapper getField(int col) {
				if (fields[col] instanceof LabeledNull) {
					return new ByteArrayWrapper(IntType.getBytes(((LabeledNull) fields[col]).getLabel()));
				} else {
					return new ByteArrayWrapper(schema._columnTypes[col].getBytes(fields[col]));
				}
			}

			public boolean isLabeledNull(int col) {
				return (fields[col] instanceof LabeledNull);
			}

			public boolean isNull(int col) {
				return (fields[col] == null || fields[col] instanceof LabeledNull);
			}

			public void checkValidForType(Type t, int col) throws ValueMismatchException {
				if (fields[col] == null || fields[col] instanceof LabeledNull) {
					return;
				}
				if (! t.isValidForColumn(fields[col])) {
					throw new ValueMismatchException(fields[col], t);
				}
			}
		}, null);
	}

	public static class FieldSource {
		public final int pos;
		public final boolean fromTuple;
		public FieldSource(int pos, boolean fromTuple) {
			this.pos = pos;
			this.fromTuple = fromTuple;
		}
	}

	public static class JoinFieldSource {
		public final int pos;
		public final boolean fromFirstTuple;
		public JoinFieldSource(int pos, boolean fromFirstTuple) {
			this.pos = pos;
			this.fromFirstTuple = fromFirstTuple;
		}
	}

	/**
	 * Copy a tuple
	 * 
	 * @param t			A tuple
	 * @param onlyKey	If the new tuple should be a key-only tuple
	 */
	public AbstractImmutableTuple(final AbstractImmutableTuple<S> t, boolean onlyKey) {
		super(t.schema);
		if ((! onlyKey) && t.onlyKey) {
			this.onlyKey = false;
			offsets = new int[schema.allColsArray.length];
			bitSetSize = BitSet.numBytes(offsets.length);
			int keyBitSetSize = BitSet.numBytes(t.offsets.length);
			data = new byte[2 * bitSetSize + t.data.length - 2 * keyBitSetSize];
			System.arraycopy(t.data, 2 * keyBitSetSize, data, 2 * bitSetSize, data.length - 2 * bitSetSize);
			// Set all fields to null
			for (int i = 0; i < bitSetSize; ++i) {
				data[i] = (byte) 0xFF;
			}
			for (int i = 0; i < schema.keyColsArray.length; ++i) {
				// Clear the fields that are non-null
				if (! BitSet.getField(i, t.data, 0)) {
					BitSet.clearField(schema.keyColsArray[i], data, 0);
				}
				// Set the fields that are labeled nulls
				if (BitSet.getField(i, t.data, keyBitSetSize)) {
					BitSet.setField(schema.keyColsArray[i], data, bitSetSize);
				}
				offsets[schema.keyColsArray[i]] = t.offsets[i] - keyBitSetSize + bitSetSize;
			}
		} else if (onlyKey && (! t.onlyKey)) {
			this.onlyKey = onlyKey;
			offsets = new int[schema.keyColsArray.length];
			bitSetSize = BitSet.numBytes(offsets.length);
			try {
				data = init(schema, onlyKey, offsets, new GetFieldFromTuple(t), null);
			} catch (ValueMismatchException e) {
				throw new IllegalStateException(e);
			}
		} else {
			this.bitSetSize = t.bitSetSize;
			this.data = t.data;
			this.offsets = t.offsets;
			this.onlyKey = t.onlyKey;
		}
	}

	/**
	 * Construct a new tuple using a mixture of data from two existing tuples
	 * 
	 * @param schema			The schema of the new tuple
	 * @param jfss				Data telling where to take each field from (in order)
	 * @param first				The first input tuple
	 * @param second			The second input tuple
	 * @throws ValueMismatchException
	 */
	public AbstractImmutableTuple(final S schema, final JoinFieldSource[] jfss, final AbstractImmutableTuple<?> first,
			final AbstractImmutableTuple<?> second) throws ValueMismatchException {
		super(schema);
		this.onlyKey = false;
		offsets = new int[schema.getNumCols()];
		bitSetSize = BitSet.numBytes(offsets.length);
		data = init(schema, onlyKey, offsets, new GetField() {
			public void checkValidForType(Type t, int col)
			throws ValueMismatchException {
				JoinFieldSource jfs = jfss[col];
				AbstractImmutableTuple<?> tuple = jfs.fromFirstTuple ? first : second;
				Type fromType = tuple.getSchema()._columnTypes[jfs.pos];
				if (! t.canReadFrom(fromType)) {
					throw new ValueMismatchException(fromType, t);
				}
			}

			public ByteArrayWrapper getField(int col) {
				JoinFieldSource jfs = jfss[col];
				AbstractImmutableTuple<?> inputTuple = jfs.fromFirstTuple ? first : second;
				int offset = inputTuple.offsets[jfs.pos];
				int length = schema._columnLengths[col];
				if (length < 0) {
					length = IntType.getValFromBytes(inputTuple.data, offset, IntType.bytesPerInt);
					offset += IntType.bytesPerInt;
				}
				return new ByteArrayWrapper(inputTuple.data, offset, length);
			}

			public boolean isLabeledNull(int col) {
				JoinFieldSource jfs = jfss[col];
				AbstractImmutableTuple<?> t = jfs.fromFirstTuple ? first : second;
				return t.isLabeledNull(jfs.pos);
			}

			public boolean isNull(int col) {
				JoinFieldSource jfs = jfss[col];
				AbstractImmutableTuple<?> t = jfs.fromFirstTuple ? first : second;
				return t.isNull(jfs.pos);
			}
		}, null);
	}

	/**
	 * Construct a new tuple using a mixture of new data
	 * and data from an existing tuple
	 * 
	 * @param schema			The schema of the new tuple
	 * @param fss				Data telling where to take each field from (in order)
	 * @param inputTuple					The tuple to copy data from
	 * @param otherFields		The other data to use to create the new tuple
	 * @throws ValueMismatchException
	 */
	public AbstractImmutableTuple(final S schema, final FieldSource[] fss, final AbstractImmutableTuple<?> inputTuple, final Object[] otherFields) throws ValueMismatchException {
		super(schema);
		this.onlyKey = false;
		offsets = new int[schema.getNumCols()];
		bitSetSize = BitSet.numBytes(offsets.length);
		data = init(schema, onlyKey, offsets, new GetField() {
			public ByteArrayWrapper getField(int col) {
				FieldSource fs = fss[col];
				if (fs.fromTuple) {
					int offset = inputTuple.offsets[fs.pos];
					int length = schema._columnLengths[col];
					if (length < 0) {
						length = IntType.getValFromBytes(inputTuple.data, offset, IntType.bytesPerInt);
						offset += IntType.bytesPerInt;
					}
					return new ByteArrayWrapper(inputTuple.data, offset, length);
				} else {
					Object o = otherFields[fs.pos];
					if (o instanceof LabeledNull) {
						return new ByteArrayWrapper(IntType.getBytes(((LabeledNull) o).getLabel()));
					} else {
						return new ByteArrayWrapper(schema._columnTypes[col].getBytes(o));
					}
				}

			}

			public boolean isLabeledNull(int col) {
				FieldSource fs = fss[col];
				if (fs.fromTuple) {
					return inputTuple.isLabeledNull(fs.pos);
				} else {
					return (otherFields[fs.pos] instanceof LabeledNull);
				}
			}

			public boolean isNull(int col) {
				FieldSource fs = fss[col];
				if (fs.fromTuple) {
					return inputTuple.isNull(fs.pos);
				} else {
					return (otherFields[fs.pos] == null);
				}
			}

			public void checkValidForType(Type t, int col) throws ValueMismatchException {
				FieldSource fs = fss[col];
				if (fs.fromTuple) {
					if (! t.canReadFrom(inputTuple.getSchema()._columnTypes[fs.pos])) {
						throw new ValueMismatchException(t, inputTuple.getSchema()._columnTypes[fs.pos]);
					}
				} else {
					if (otherFields[fs.pos] == null || otherFields[fs.pos] instanceof LabeledNull) {
						return;
					}
					if (! t.isValidForColumn(otherFields[fs.pos])) {
						throw new ValueMismatchException(otherFields[fs.pos], t);
					}
				}
			}

		}, null);
	}

	/**
	 * Deserialize an AbstractImmutableTuple
	 * 
	 * @param schema			The schema
	 * @param onlyKey			<code>true</code> if the serialized data contains only key columns, false otherwise
	 * @param data				The data array
	 * @param offset			The offset in the data array
	 */
	public AbstractImmutableTuple(S schema, boolean onlyKey, byte[] data, int offset) {
		super(schema);
		this.onlyKey = onlyKey;
		offsets = new int[onlyKey ? schema.keyColsArray.length : schema.allColsArray.length];
		bitSetSize = BitSet.numBytes(offsets.length);
		int[] cols = onlyKey ? schema.keyColsArray : schema.allColsArray;
		int length = offset + 2 * bitSetSize;
		for (int i = 0; i < cols.length; ++i) {
			int col = cols[i];
			offsets[i] = length - offset;
			if (BitSet.getField(i, data, offset)) {
				// is null
			} else if (BitSet.getField(i, data, offset + bitSetSize)) {
				// is labeled null
				length += IntType.bytesPerInt;
			} else if (schema._columnLengths[col] < 0) {
				int fieldLen = IntType.getValFromBytes(data, length, IntType.bytesPerInt);
				length += IntType.bytesPerInt;
				length += fieldLen;
			} else {
				length += schema._columnLengths[col];
			}
		}
		this.data = new byte[length - offset];
		System.arraycopy(data, offset, this.data, 0, this.data.length);
	}

	public AbstractImmutableTuple(AbstractImmutableTuple<S> tuple, boolean onlyKey, int[] retainCols) {
		super(tuple.schema);
		this.onlyKey = onlyKey;
		offsets = new int[onlyKey ? schema.keyColsArray.length : schema.allColsArray.length];
		bitSetSize = BitSet.numBytes(offsets.length);
		try {
			data = init(schema, onlyKey, offsets, new GetFieldFromTuple(tuple), retainCols);
		} catch (ValueMismatchException e) {
			throw new IllegalStateException(e);
		}
	}

	private interface GetField {
		boolean isNull(int col);
		boolean isLabeledNull(int col);
		ByteArrayWrapper getField(int col);
		void checkValidForType(Type t, int col) throws ValueMismatchException;
	}

	private class GetFieldFromTuple implements GetField {
		private final AbstractImmutableTuple<?> t;

		GetFieldFromTuple(AbstractImmutableTuple<?> tuple) {
			t = tuple;
		}
		public ByteArrayWrapper getField(int col) {
			int offset = t.offsets[t.getCol(col)];
			int length = schema._columnLengths[col];
			if (length < 0) {
				length = IntType.getValFromBytes(t.data, offset, IntType.bytesPerInt);
				offset += IntType.bytesPerInt;
			}
			return new ByteArrayWrapper(t.data, offset, length);
		}

		public boolean isLabeledNull(int col) {
			return t.isLabeledNull(col);
		}

		public boolean isNull(int col) {
			return t.isNull(col);
		}

		public void checkValidForType(Type t, int col) {
			// Since the schema isn't changing we don't need to do anything
		}	
	}

	private static byte[] init(AbstractRelation schema, boolean onlyKey, int[] offsets, GetField gf, int[] retainCols) throws ValueMismatchException {
		int[] cols = onlyKey ? schema.keyColsArray : schema.allColsArray;
		if (retainCols == null) {
			retainCols = cols;
		}
		int bitSetSize = BitSet.numBytes(cols.length);
		int length = 2 * bitSetSize;
		ByteArrayWrapper[] fields = new ByteArrayWrapper[cols.length];
		int retainColsPos = 0;
		for (int i = 0; i < cols.length; ++i) {
			int col = cols[i];
			Type type = schema._columnTypes[col];
			offsets[i] = length;
			gf.checkValidForType(type, col);
			if (retainColsPos >= retainCols.length) {
				break;
			}
			if (retainCols[retainColsPos] > col) {
				continue;
			} else if (retainCols[retainColsPos] == col) {
				++retainColsPos;
			} else {
				throw new IllegalArgumentException("retainCols is not sorted");
			}
			if (gf.isLabeledNull(col)) {
				length += IntType.bytesPerInt;
				fields[i] = gf.getField(col);
			} else if (! gf.isNull(col)) {
				fields[i] = gf.getField(col);
				length += fields[i].length;
				if (schema._columnLengths[col] < 0) {
					length += IntType.bytesPerInt;
				}
			}
		}
		// Non-null fields are in first bit set, labeled null fields are in second bit set
		byte[] data = new byte[length];
		retainColsPos = 0;
		int pos = 2 * bitSetSize;
		for (int i = 0; i < cols.length; ++i) {
			int col = cols[i];
			boolean isNull = false;
			if (retainColsPos >= retainCols.length || retainCols[retainColsPos] > col) {
				isNull = true;
			} else if (retainCols[retainColsPos] == col) {
				++retainColsPos;
			} else {
				throw new IllegalArgumentException("retainCols is not sorted");
			}
			if ((! isNull) && gf.isLabeledNull(col)) {
				BitSet.setField(i, data, bitSetSize);
				System.arraycopy(fields[i].array, fields[i].offset, data, pos, fields[i].length);
				pos += fields[i].length;
			} else if (isNull || gf.isNull(col)) {
				BitSet.setField(i, data, 0);				
			} else {
				if (schema._columnLengths[col] < 0) {
					System.arraycopy(IntType.getBytes(fields[i].length), 0, data, pos, IntType.bytesPerInt);
					pos += IntType.bytesPerInt;
				}
				System.arraycopy(fields[i].array, fields[i].offset, data, pos, fields[i].length);
				pos += fields[i].length;
			}
		}

		if (pos != length) {
			throw new IllegalStateException("Pos and length should match");
		}

		return data;
	}

	private int getCol(int i) {
		if (onlyKey) {
			return schema.allColsToKeys[i];
		} else {
			return i;
		}
	}

	@Override
	public Object get(int i) {
		int col = getCol(i);
		if (col < 0) {
			return null;
		}
		if (BitSet.getField(col, data, 0) || BitSet.getField(col, data, bitSetSize)) {
			// Is null or labeled null
			return null;
		}
		Type t = schema._columnTypes[i];
		int offset = offsets[col];
		int length = schema._columnLengths[i];
		if (length < 0) {
			length = IntType.getValFromBytes(data, offset, IntType.bytesPerInt);
			offset += IntType.bytesPerInt;
		}
		return t.fromBytes(data, offset, length);
	}

	@Override
	public int getLabeledNull(int index) throws IsNotLabeledNull {
		int col = getCol(index);
		if (col < 0) {
			throw new IsNotLabeledNull();
		}
		if (BitSet.getField(col, data, bitSetSize)) {
			return IntType.getValFromBytes(data, offsets[col], IntType.bytesPerInt);
		} else {
			throw new IsNotLabeledNull();
		}
	}

	@Override
	public Object getNoCopy(int i) {
		return get(i);
	}

	@Override
	public Object getValueOrLabeledNull(int i) {
		int col = getCol(i);
		if (col < 0) {
			return null;
		}
		if (BitSet.getField(col, data, bitSetSize)) {
			return new LabeledNull(IntType.getValFromBytes(data, offsets[col], IntType.bytesPerInt));
		} else {
			return get(i);
		}
	}

	@Override
	public boolean isLabeledNull(int index) {
		int col = getCol(index);
		if (col < 0) {
			return false;
		}
		return BitSet.getField(col, data, bitSetSize);
	}

	@Override
	public boolean isNull(int index) {
		int col = getCol(index);
		if (col < 0) {
			return true;
		}
		return (BitSet.getField(col, data, 0) || BitSet.getField(col, data, bitSetSize));
	}

	@Override
	public boolean isReadOnly() {
		return true;
	}

	/**
	 * Get the serialized representation of this AbstractImmutableTuple.
	 * Do <b>NOT</b> modify the return value
	 * 
	 * @return		The serialized representation of the tuple,
	 * 				which should not be modified 
	 */
	protected byte[] serialize() {
		return data;
	}

	public boolean isKeyTuple() {
		return onlyKey;
	}

	@SuppressWarnings("unchecked")
	public boolean equalsOnColumns(int[] cols, AbstractTuple<S> t) {
		if (! (t instanceof AbstractImmutableTuple)) {
			return super.equalsOnColumns(cols, t);
		}
		
		if (! sameSchemaAs(t)) {
			return false;
		}
		
		AbstractImmutableTuple<S> tt = (AbstractImmutableTuple<S>) t;

		if (cols == null) {
			cols = schema.allColsArray;
		}

		for (int col : cols) {
			if (isLabeledNull(col)) {
				if (tt.isLabeledNull(col)) {
					if (getLabeledNull(col) != tt.getLabeledNull(col)) {
						return false;
					} else{
						continue;
					}
				} else {
					return false;
				}
			} else if (isNull(col)) {
				if (tt.isLabeledNull(col)) {
					return false;
				} else if (! tt.isNull(col)) {
					return false;
				} else {
					continue;
				}
			}
			
			int offset = offsets[getCol(col)];
			int ttOffset = tt.offsets[tt.getCol(col)];
			int length, ttLength;
			Type type = schema._columnTypes[col];
			int knownLength = schema._columnLengths[col];
			if (knownLength < 0) {
				length = IntType.getValFromBytes(data, offset, IntType.bytesPerInt);
				offset += IntType.bytesPerInt;
				ttLength = IntType.getValFromBytes(tt.data, ttOffset, IntType.bytesPerInt);
				ttOffset += IntType.bytesPerInt;
			} else {
				length = knownLength;
				ttLength = knownLength;
			}
			if (type.canCompareSerialized()) {
				if (length != ttLength) {
					return false;
				}
				for (int i = 0; i < length; ++i) {
					if (data[offset + i] != tt.data[ttOffset + i]) {
						return false;
					}
				}
			} else {
				Object o1 = type.fromBytes(data, offset, length);
				Object o2 = type.fromBytes(tt.data, ttOffset, ttLength);
				try {
					if (type.compareTwo(o1, o2) != 0) {
						return false;
					}
				} catch (CompareMismatch e) {
					throw new IllegalStateException("Should not get a CompareMismatch when comparing two tuples of the same schema", e);
				}
			}
		}
		
		return true;
	}

	private int hashCode = 0;
	
	public int hashCode() {
		if (hashCode == 0) {
			hashCode = hashCode(true, null);
		}
		return hashCode;
	}
	
	int hashCode(boolean first, int[] cols) {
		int hashval = 0;
		int multPos = 0;
		int[] mults = first ? hashMultipliers1 : hashMultipliers2;

		if (cols == null) {
			cols = schema.allColsArray;
		}
		final int numCols = cols.length;
		for (int i = 0; i < numCols; ++i) {
			int col = cols[i];
			int thisColCode;
			if (isLabeledNull(col)) {
				thisColCode = getLabeledNull(col);
			} else if (isNull(col)) {
				continue;
			} else {
				int offset = offsets[getCol(col)];
				Type t = schema._columnTypes[col];
				int length = schema._columnLengths[col];
				if (length < 0) {
					length = IntType.getValFromBytes(data, offset, IntType.bytesPerInt);
					offset += IntType.bytesPerInt;
				}
				thisColCode = t.getHashCodeFromBytes(data, offset, length);
			}
			if (multPos >= mults.length) {
				hashval = thisColCode + 37 * hashval;
			} else {
				hashval += thisColCode * mults[multPos];
				++multPos;
			}
		}
		return hashval;
	}
	
	public int getColHashCode(int col) {
		if (isLabeledNull(col)) {
			return getLabeledNull(col);
		} else if (isNull(col)) {
			return 0;
		}
		Type t = schema._columnTypes[col];
		int offset = offsets[getCol(col)];
		int length = schema._columnLengths[col];
		if (length < 0) {
			length = IntType.getValFromBytes(data, offset, IntType.bytesPerInt);
			offset += IntType.bytesPerInt;
		}
		return t.getHashCodeFromBytes(data, offset, length);		
	}
}

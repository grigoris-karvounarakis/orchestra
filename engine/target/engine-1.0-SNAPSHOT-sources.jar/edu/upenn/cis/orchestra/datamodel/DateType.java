package edu.upenn.cis.orchestra.datamodel;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.datamodel.exceptions.NotNumericalException;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.util.XMLParseException;

public class DateType extends Type {
	private static final long serialVersionUID = 1L;

	public static final DateType DATE = new DateType(true);

	public DateType(boolean nullable) {
		super(nullable, Date.class);
	}

	public String getXSDType() {
		return "xsd:date";
	}

	@Override
	public Integer compareTwo(Object o1, Object o2) throws CompareMismatch {
		if (o1 == null || o2 == null) {
			return null;
		}
		if (o1.getClass() != Date.class || o2.getClass() != Date.class) {
			throw new CompareMismatch(o1,o2,Date.class);
		}
		Date d1 = (Date) o1;
		Date d2 = (Date) o2;
		return d1.compareTo(d2);
	}

	@Override
	public Date duplicateValue(Object o) {
		return (Date) o;
	}

	@Override
	public Date fromBytes(byte[] bytes, int offset, int length) {
		return getValFromBytes(bytes, offset, length);
	}

	@Override
	public byte[] getBytes(Object o) {
		return getBytes((Date) o);
	}

	public static byte[] getBytes(Date d) {
		return d.getBytes();
	}

	public static Date getValFromBytes(byte[] bytes) {
		return Date.getValFromBytes(bytes);
	}

	public static Date getValFromBytes(byte[] bytes, int offset, int length) {
		return Date.getValFromBytes(bytes, offset, length);
	}

	@Override
	public Date getFromResultSet(ResultSet rs, int colno) throws SQLException {
		return Date.fromSQL(rs.getDate(colno));
	}

	@Override
	public Date getFromResultSet(ResultSet rs, String colname) throws SQLException {
		return Date.fromSQL(rs.getDate(colname));
	}

	@Override
	public String getSQLLit(Object o) {
		Date d = (Date) o;
		return d.toString();
	}

	@Override
	public String getSQLTypeName() {
		return "DATE";
	}

	@Override
	public int getSqlTypeCode() {
		return Types.DATE;
	}

	@Override
	public boolean typeEquals(Type t) {
		return (this.getClass() == t.getClass());
	}

	@Override
	public Object add(Object o1, Object o2) throws NotNumericalException {
		throw new NotNumericalException(this);
	}

	@Override
	public Object divide(Object o, int divisor) throws NotNumericalException {
		throw new NotNumericalException(this);
	}

	public void serialize(Document doc, Element field) {
		field.setAttribute("type", "date");
		field.setAttribute("nullable", Boolean.toString(isNullable()));
	}

	public static Type deserialize(String type, boolean nullable) {
		if (type != null && type.compareToIgnoreCase("date") == 0) {
			return new DateType(nullable);
		}
		return null;
	}

	@Override
	public Date fromStringRep(String rep) throws XMLParseException {
		try {
			return Date.fromString(rep);
		} catch (IllegalArgumentException e) {
			throw new XMLParseException("Could not parse date string '" + rep + "'");
		}
	}

	@Override
	public String getStringRep(Object o) throws NullPointerException, ValueMismatchException {
		if (o == null) {
			throw new NullPointerException();
		}
		if (! this.isValidForColumn(o)) {
			throw new ValueMismatchException(o,this);
		}

		return ((Date) o).toString();
	}

	@Override
	public edu.upenn.cis.orchestra.optimization.Type getOptimizerType() {
		return new edu.upenn.cis.orchestra.optimization.DateType();
	}

	@Override
	public void setInPreparedStatement(Object o, PreparedStatement ps, int no)
	throws SQLException {
		if (o == null) {
			ps.setNull(no, this.getSqlTypeCode());
		} else {
			ps.setDate(no, ((Date) o).getSQL());
		}
	}

	@Override
	public int bytesLength() {
		return Date.bytesPerDate;
	}

	@Override
	public int getHashCodeFromBytes(byte[] data, int offset, int length) {
		// From Date.getBytes and Date.hashCode
		int year = ((int) (data[offset] & 0xFF)) << 8;
		year |= ((int) (data[offset + 1] & 0xFF));
		byte month = data[offset + 2];
		byte day = data[offset + 3];
		
		return year + 37 * month + 1201 * day;
	}
}


package edu.upenn.cis.orchestra.datamodel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.datamodel.exceptions.InvalidBeanException;
import edu.upenn.cis.orchestra.datamodel.exceptions.UnknownRefFieldException;
import edu.upenn.cis.orchestra.datamodel.exceptions.UnsupportedTypeException;
import edu.upenn.cis.orchestra.repository.model.beans.ScConstraintBean;
import edu.upenn.cis.orchestra.repository.model.beans.ScFieldBean;
import edu.upenn.cis.orchestra.repository.model.beans.ScRelationBean;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.ReadOnlyList;
import edu.upenn.cis.orchestra.util.XMLParseException;

public abstract class AbstractRelation implements Serializable {

	public static class BadColumnName extends Exception {
		private static final long serialVersionUID = 1L;

		BadColumnName(String name) {
			super("Column name '" + name + "' is not valid");
		}
	}

	public static class NameNotFound extends Exception {
		private static final long serialVersionUID = 1L;

		public NameNotFound(String name, AbstractRelation schema) {
			super("Attribute '" + name + "' not found in tuple schema " + schema);
		}
	}

	public class SchemaMismatch extends Exception {
		private static final long serialVersionUID = 1L;

		SchemaMismatch(Relation tupleSchema) {
			super("Attempt to perform operation between tuple with schema " + AbstractRelation.this +
					" and tuple with schema " + tupleSchema);
		}
	}

	/** Relation name */	
	protected String _name;
	/** Relation description */
	protected String _description;
	/** Relation fields */
	private List<RelationField> _fields;
	// An unmodifiable copy of _fields, created when relation is
	// finished
	private List<RelationField> _publicFields = null;

	/** Map fields name to the field object to avoid scanning _fields for access by name, which will be frequent */
	protected Map<String, RelationField> _fieldsByName;


	/*** Constraints. 
	 * Note that constraints are not stored as a list of ScConstraint to avoid scanning the list for Pk, 
	 * casting too often... 
	 * If check constraint ... are to be added, they will be stored as a list of ScConstraint or a new abstract subclass
	 * to avoid adding Pk... to this list
	 */
	/** Relation's primary key, can stay null */
	protected PrimaryKey _pk=null;
	/** Relation foreign keys */
	protected List<ForeignKey> _foreignKeys = new ArrayList<ForeignKey> ();
	/** Relation unique indexes */
	protected List<RelationIndexUnique> _uniqueIndexes = new ArrayList<RelationIndexUnique> ();
	/** Non unique indexes */
	protected List<RelationIndexNonUnique> _nonUniqueIndexes = new ArrayList<RelationIndexNonUnique> ();

	// columnTypes[i] contains the type of the ith attribute
	Type[] _columnTypes;
	// columnLength[i] gives the length of the serialization of the ith column,
	// from _columnTypes[i].bytesLength()
	int[] _columnLengths;
	// getColumnNum[name] =	gives the index of the type of the column
	//							with called name

	private HashMap<String,Integer> _columnNum;

	/** True if we've finished creating this schema and it won't be modified in the future. */
	protected boolean finished;

	private ReadOnlyList<Integer> _keyColumnList;

	public AbstractRelation() {
		this((String) null);
	}
	
	int[] keyColsArray, allColsArray, allColsToKeys;

	public AbstractRelation(String name) {
		_name = name; 
		_columnNum = new HashMap<String,Integer>();
		finished = false;
		_fields = new ArrayList<RelationField> ();
		_columnTypes = new Type[_fields.size()];

		// TODO: raise exception if fields.size=0
		initFieldsByNamesMap ();
	}

	/**
	 * Creates a new relation
	 * @param name Relation name
	 * @param description Relation description
	 * @param fields Relation fields
	 */
	public AbstractRelation (String name, 
			String description, List<RelationField> fields) 
	{
		_columnNum = new HashMap<String,Integer>();
		finished = false;

		// TODO: raise exception if fields.size=0
		_name = name;
		_description = description;
		_fields = new ArrayList<RelationField> ();
		_fields.addAll(fields);
		_columnTypes = new Type[_fields.size()];

		setFieldsRelRef();
		initFieldsByNamesMap ();
	}

	/**
	 * Creates a new relation
	 * @param name Relation name
	 * @param description Relation description
	 * @param pkName The primary key constraint name
	 * @param pkFieldNames The names of the fields in the primary key
	 * @throws UnknownRefFieldException 
	 */
	public AbstractRelation(String name, String description,
			List<RelationField> fields, String pkName,
			Collection<String> pkFieldNames) throws UnknownRefFieldException {
		_columnNum = new HashMap<String,Integer>();
		finished = false;

		// TODO: raise exception if fields.size=0
		_name = name;
		_description = description;
		_fields = new ArrayList<RelationField> ();
		_fields.addAll(fields);
		_columnTypes = new Type[_fields.size()];

		setFieldsRelRef();
		initFieldsByNamesMap ();

		if (pkName != null && pkFieldNames != null) {
			_pk = new PrimaryKey(pkName,this,pkFieldNames);
		}

		markFinished();

	}

	/**
	 * Creates a new relation from its bean description. <BR>
	 * Foreign keys not loaded there because the referenced relation 
	 * might not exist yet 
	 * @param relBean Relation bean 
	 * @throws InvalidBeanException If the fields list is empty,
	 *    or a direct constraint implies a field not known in the 
	 *    relation , or a mandatory field is missing
	 * @throws UnsupportedTypeException 
	 */
	public AbstractRelation (ScRelationBean relBean)
	throws InvalidBeanException, UnsupportedTypeException
	{
		_columnNum = new HashMap<String,Integer>();
		_name = relBean.getName();
		if (_name == null)
			throw new InvalidBeanException (relBean, "A name is mandatory for each relation");
		_description = relBean.getDescription();
		if (_description==null)
			_description = _name;
		_fields = new ArrayList<RelationField> ();
		if (relBean.getFields().size()==0)
			throw new InvalidBeanException (relBean, "A relation must have at least one field");

		int i = 0;
		for (ScFieldBean fldB : relBean.getFields())
		{
			RelationField fld = new RelationField(fldB);
			_fields.add(fld);
			_columnNum.put(fld.getName(), i++);
		}
		_columnTypes = new Type[_fields.size()];

		setFieldsRelRef();
		initFieldsByNamesMap();
		/** Load constraints */
		//	TODO: error if two pks...
		for (ScConstraintBean cstBean : relBean.getDirectConstraints()) {
			if (cstBean.getType().equals("P")) {
				_pk = new PrimaryKey (cstBean, this);
			} else {
				if (cstBean.getType().equals("U")) {
					_uniqueIndexes.add (new RelationIndexUnique(cstBean, this));
				} else {
					if (cstBean.getType().equals("I")) {
						_nonUniqueIndexes.add (new RelationIndexNonUnique(cstBean, this));
					} else {
						if (!cstBean.getType().equals("F")) {
							throw new InvalidBeanException (relBean, "Unknown constraint type: " + cstBean.getType());
						}
					}
				}
			}
		}
		markFinished();
	}

	/**
	 * Deep copy of the relation
	 * Use the method deepCopy to benefit from polymorphism
	 * @param relation Relation to copy
	 * @roseuid 449AEA650271
	 * @see AbstractRelation#deepCopy()
	 */
	protected AbstractRelation(AbstractRelation relation) 
	{
		_name = relation.getName();
		_description = relation.getDescription();
		_fields = new ArrayList<RelationField> ();
		_columnNum = new HashMap<String,Integer>();
		int i = 0;
		for (RelationField fld : relation._fields){
			_fields.add(fld.deepCopy ());
			_columnNum.put(fld.getName(), i++);
		}
		
		setFieldsRelRef();
		initFieldsByNamesMap ();
	}   

	/**
	 * Gets the number of columns in the schema.
	 * 
	 * @return			The number of columns
	 */
	public int getNumCols() {
		return _fields.size();
	}

	/**
	 * Get the name of a column.
	 * 
	 * @param whichCol			The index of the column of interest
	 * @return					The name of the column, or <code>null</code>
	 * 							if it does not exist
	 */
	public String getColName(int whichCol) {
		try {
			return _fields.get(whichCol).getName();
		} catch (IndexOutOfBoundsException ioobe) {
			return null;
		}
	}

	/**
	 * Get the number of a column
	 * 
	 * @param whichCol			The name of the column of interest
	 * @return					The index of the column, or <code>null</code>
	 * 							if it does not exist
	 */
	public Integer getColNum(String whichCol) {
		return _columnNum.get(whichCol);
	}

	/**
	 * Get the type of a column
	 * 
	 * @param whichCol			The index of the column of interest
	 * @return					The <CODE>Type</CODE> of the column
	 */
	public Type getColType(int whichCol) {
		if (_columnTypes[whichCol] != null)
			return _columnTypes[whichCol];
		else {
			return _fields.get(whichCol).getType();
		}
	}

	/**
	 * Get the type of a column
	 * 
	 * @param whichCol			The name of the column of interest
	 * @return					The <CODE>Type</CODE> of the column
	 */
	public Type getColType(String whichCol) {
		int inx = _columnNum.get(whichCol);
		if (_columnTypes[inx] != null)
			return _columnTypes[inx];
		else
			return _fields.get(inx).getType();
	}

	public void markFinished() {
		if (_pk == null) {
			List<String> cols = new ArrayList<String>(_fields.size());
			for (RelationField f : _fields) {
				cols.add(f.getName());
			}
			PrimaryKey pk;
			try {
				pk = new PrimaryKey("pk", this, cols);
			} catch (UnknownRefFieldException e) {
				throw new RuntimeException("Should not happen", e);
			}
			setPrimaryKey(pk);
		}
		finished = true;

		ArrayList<Integer> keyColumnIndices = new ArrayList<Integer>();
		_keyColumnList = ReadOnlyList.create(keyColumnIndices);
		for (RelationField f : (_pk == null ? _fields : _pk.getFields())) {
			keyColumnIndices.add(_columnNum.get(f.getName()));				
		}
		_publicFields = Collections.unmodifiableList(_fields);
		
		_columnTypes = new Type[_fields.size()];
		_columnLengths = new int[_fields.size()];
		for (int i = 0; i < _columnTypes.length; ++i) {
			_columnTypes[i] = _fields.get(i).getType();
			_columnLengths[i] = _columnTypes[i].bytesLength();
		}
		
		keyColsArray = new int[_keyColumnList.size()];
		allColsToKeys = new int[_fields.size()];
		allColsArray = new int[_fields.size()];
		for (int i = 0; i < allColsArray.length; ++i) {
			allColsArray[i] = i;
			allColsToKeys[i] = -1;
		}
		int pos = 0;
		for (int col : _keyColumnList) {
			allColsToKeys[col] = pos;
			keyColsArray[pos++] = col;
		}
	}

	/**
	 * Get the column numbers of the key columns, in ascending order
	 * 
	 * @return			A list of the numbers, which is immutable
	 */
	public List<Integer> getKeyCols() {
		return _keyColumnList;
	}

	public boolean isFinished() {
		return finished;
	}


	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		if (o == null || o.getClass() != this.getClass()) {
			return false;
		}
		AbstractRelation ts = (AbstractRelation) o;

		return equals(ts, true);

	}

	public boolean equalsOnColumns(AbstractRelation ts) {
		return equals(ts, false);
	}

	private boolean equals(AbstractRelation ts, boolean includeName) {
		if (includeName && (! getRelationName().equals(ts.getRelationName()))) {
			return false;
		}

		final int numCols = getNumCols();

		if (ts._fields.size() != numCols) {
			return false;
		}

		for (int i = 0; i < numCols; ++i) {
			Type t1 = _fields.get(i).getType();
			Type t2 = ts._fields.get(i).getType();
			if (! _fields.get(i).getName().equals(ts._fields.get(i).getName())) {
				return false;
			}
			if (! t1.equals(t2)) {
				return false;
			}
		}

		return true;
	}

	/////////////////////////////////////

	/**
	 * Init the map used to access fields by name
	 */
	private void initFieldsByNamesMap ()
	{
		_fieldsByName = new Hashtable<String, RelationField> ();
		int i = 0;
		for (RelationField fld : _fields) {
			_fieldsByName.put(fld.getName(), fld);
			_columnNum.put(fld.getName(), i++);
		}
	}

	private void setFieldsRelRef(){
		for(RelationField field : _fields)
			field.setRelation(this);
	}


	/**
	 * Add a new column to the current schema
	 * 
	 * @param name		The name of the column to add
	 * @param se		The column to add
	 * @throws Exception	If the column name is reserved
	 */
	public void addCol(String name, Type se) throws BadColumnName {
		addCol(name, "column", se);
	}

	/**
	 * Add a new column to the current schema
	 * 
	 * @param name		The name of the column to add
	 * @param desc		The column description
	 * @param se		The column to add
	 * @throws Exception	If the column name is reserved
	 */
	public void addCol(String name, String desc, Type se) throws BadColumnName {
		if (finished) {
			throw new RuntimeException("Attempt to modify finished schema");
		}
		// TODO: move these checks into reconciliation code
		if (name.equals("peer") || name.equals("recno") || name.equals("tid") ||
				name.equals("conflict") || name.equals("option") ||
				name.equals("tid1") || name.equals("tid2") ||
				name.equals("serialno") || name.equals("txn") ||
				name.equals("truster") ||  name.equals("trusted") ||
				name.endsWith("_old") || name.endsWith("_new")) {
			throw new BadColumnName(name);
		}
		addField(new RelationField(name, desc, se));
	}

	/**
	 * Add a new field to this relation, inserted at a given index (to respect the 
	 * source database order)
	 * @param f Field to be added
	 * @param index Index at which the field is to be inserted
	 * @roseuid 449AE4D401A5
	 */
	public void addField(RelationField f, int index) throws BadColumnName 
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify finished schema");
		}
		//	TODO: LOW Error if index KO
		_fields.add (index, f);
		_columnNum.put(f.getName(), index);
		_fieldsByName.put(f.getName(), f);
	}

	/**
	 * Add a new field at the end of the relation
	 * @param f New field
	 */
	public void addField(RelationField f) throws BadColumnName
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify finished schema");
		}
		_fields.add (f);
		_columnNum.put(f.getName(), _fields.size() - 1);
		_fieldsByName.put(f.getName(), f);
	}

	/**
	 * Get the fields contained in this relation.
	 * To optimize performance this is not a deep copy. DO NOT MODIFY.
	 * @return List
	 * @roseuid 449AE61A001F
	 */
	public List<RelationField> getFields() 
	{
		if (_publicFields != null) {
			return _publicFields;
		} else {
			return Collections.unmodifiableList(_fields);
		}
	}

	/**
	 * Get a field by index
	 * @param index Index of the field to retrieve
	 * @return Field if found TODO : LOW Exception if not found
	 */
	public RelationField getField (int index)
	{
		//	TODO:LOW error if ind KO
		return _fields.get(index);
	}

	/**
	 * Get a field by name
	 * @param name Name of the field to retrieve
	 * @return Field if found, null if it does not exist
	 */
	public RelationField getField (String name)
	{
		return _fieldsByName.get(name);

	}

	/**
	 * Get the name of this relation
	 * @return java.lang.String Relation name
	 * @roseuid 44AD2CC800AB
	 */
	public String getName() 
	{
		return _name;
	}

	/**
	 * Get the description of this relation
	 * @return java.lang.String Relation description
	 * @roseuid 44AD2CCF037A
	 */
	public String getDescription() 
	{
		return _description;
	}

	/**
	 * Change the relation description
	 * @param description New description
	 */
	public void setDescription (String description)
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
		_description = description;
	}


	/**
	 * Set the primary key for this relation. The primary key cannot
	 * be changed once set
	 * @param pk primary key, fields must exist in the relation
	 */
	public void setPrimaryKey (PrimaryKey pk)
	{
		if (_pk != null) {
			throw new IllegalStateException("Cannot change the primary key once it is set");
		}
		if (pk == null) {
			throw new NullPointerException();
		}
		for (RelationField f : pk.getFields()) {
			RelationField found = getField(f.getName());
			if (found == null || (! found.equals(f))) {
				throw new IllegalArgumentException("Fields in primary key must match those in relation");
			}
		}
		_pk = pk;
	}

	/**
	 * Set the primary key for this relation. The primary key cannot
	 * be changed once set
	 * @param pkName		The primary key name
	 * @param keyColNames	A collection of fields in this relation
	 * @throws UnknownRefFieldException
	 */
	public void setPrimaryKey(String pkName, Collection<String> keyColNames) throws UnknownRefFieldException {
		this.setPrimaryKey(new PrimaryKey(pkName, this, keyColNames));
	}

	/**
	 * Set the primary key for this relation. The primary key cannot
	 * be changed once set
	 * @param keyColNames	A collection of fields in this relation
	 * @throws UnknownRefFieldException
	 */
	public void setPrimaryKey(Collection<String> keyColNames) throws UnknownRefFieldException {
		this.setPrimaryKey(new PrimaryKey("pk", this, keyColNames));
	}

	/**
	 * Add a foreign key to this relation
	 * Referenced table fields / pk coherency is not checked
	 * @param fk New foreign key, fields must exist in the relation.
	 */
	public void addForeignKey (ForeignKey fk)
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
		if (! fk.getRelation().equals(_name)) {
			throw new IllegalArgumentException("Foreign key is not for this relation");
		}
		// Check that fields exist and have the same type etc.
		for (RelationField sf : fk._fields) {
			RelationField inRel = _fieldsByName.get(sf.getName());
			if (inRel == null) {
				throw new IllegalArgumentException("Relation does not contain fields " + sf.getName());
			} else if (! sf.equals(inRel)) {
				throw new IllegalArgumentException("Field in relation is not the same as field in foreign key");
			}
		}
		_foreignKeys.add(fk);
	}

	/**
	 * Remove a given foreign key from the relation.
	 * Will not raise an exception if the foreign key is not found
	 * @param fk Foreign key to remove
	 */
	public void removeForeignKey (ForeignKey fk)
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
		_foreignKeys.remove(fk);
	}

	/**
	 * Remove all foreign keys
	 *
	 */
	public void clearForeignKeys ()
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
		_foreignKeys.clear();
	}

	/**
	 * Add a non unique index to this relation
	 * @param idx New "non unique" index, fields must exist in the relation
	 */
	public void addNonUniqueIndex (RelationIndexNonUnique idx)
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
		//	TODO:MID Check that fields exist
		_nonUniqueIndexes.add (idx);
	}

	/**
	 * Remove a given non unique index
	 * @param idx Non unique index to remove
	 */
	public void removeNonUniqueIndex (RelationIndexNonUnique idx)
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
		_nonUniqueIndexes.remove (idx);
	}

	/**
	 * Remove all non unique indexes from the relation
	 *
	 */
	public void clearNonUniqueIndexes ()
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
		_nonUniqueIndexes.clear();
	}

	/**
	 * Add a unique index to this relation
	 * @param idx New unique index, fields must exist in the relation
	 */
	public void addUniqueIndex (RelationIndexUnique idx)
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
		//	TODO:MID Check that fields exist
		_uniqueIndexes.add (idx);
	}

	/**
	 * Remove a given unique index
	 * @param idx Unique index to remove
	 */
	public void removeUniqueIndex (RelationIndexUnique idx)
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
		_uniqueIndexes.remove (idx);
	}

	/**
	 * Remove all unique indexes from the relation
	 *
	 */
	public void clearUniqueIndexes ()
	{
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
		_uniqueIndexes.clear();
	}	

	/**
	 * Returns the primary key
	 * @return Primary key, null if none
	 */
	public PrimaryKey getPrimaryKey ()
	{
		return _pk;
	}

	/**
	 * Returns the list of unique indexes.
	 * @return Unique indexes
	 */
	public List<RelationIndexUnique> getUniqueIndexes ()
	{
		return Collections.unmodifiableList(_uniqueIndexes);
	}

	/**
	 * Returns the list of NON unique indexes.
	 * @return Non unique indexes
	 */
	public List<RelationIndexNonUnique> getNonUniqueIndexes ()
	{
		return Collections.unmodifiableList(_nonUniqueIndexes);
	}	

	/**
	 * Returns the list of foreign keys (from this relation to another ot to itself)
	 * @return Foreign keys
	 */
	public List<ForeignKey> getForeignKeys ()
	{
		return Collections.unmodifiableList(_foreignKeys);
	}

	// Alias to TableSchema version
	public String getRelationName() {
		return getName();
	}

	/// Original TableSchema version
	public String toStringText() {
		StringBuffer retval = new StringBuffer(getRelationName() + "(\n");

		int size = _fields.size();
		for (int i = 0; i < size; ++i) {
			String name = _fields.get(i).getName();
			retval.append(name + "\t" + _fields.get(i).getType().getSQLType());
			if (i != (size - 1)) {
				retval.append(",");
			}
			retval.append("\n");
		}
		retval.append(", PRIMARY KEY (");
		Iterator<Integer> colIt = _keyColumnList.iterator();
		while (colIt.hasNext()) {
			retval.append(_fields.get(colIt.next()).getName());
			if (colIt.hasNext()) {
				retval.append(",");
			}
		}
		retval.append(")\n");

		retval.append(")\n");
		return retval.toString();
	}

	public void serialize(Document doc, Element schema) {
		schema.setAttribute("name", _name);
		if (_description != null) {
			schema.setAttribute("description", _description);
		}
		for (RelationField f : getFields()) {
			Element field = DomUtils.addChild(doc, schema, "field");
			f.serialize(doc, field);
		}
		if (_pk != null) {
			Element pk = DomUtils.addChild(doc, schema, "primaryKey");
			pk.setAttribute("name", _pk.getName());
			for (RelationField f : _pk.getFields()) {
				Element fieldEl = DomUtils.addChild(doc, pk, "fieldName");
				fieldEl.setAttribute("name", f.getName());
			}
		}
		for (ForeignKey fk : _foreignKeys) {
			Element foreignkey = DomUtils.addChild(doc, schema, "foreignKey");
			foreignkey.setAttribute("name", fk.getName());
			foreignkey.setAttribute("refRel", fk._refRelation._name);
			Iterator<RelationField> refFields = fk._refFields.iterator();
			Iterator<RelationField> fields = fk._fields.iterator();
			
			while (refFields.hasNext()) {
				String refField = refFields.next().getName();
				String thisField = fields.next().getName();
				
				Element entry = DomUtils.addChild(doc, foreignkey, "fkEntry");
				entry.setAttribute("refField", refField);
				entry.setAttribute("field", thisField);
			}
		}

	}

	protected static class AbstractRelationInfo {
		public final String name;
		private final String descr;
		private final List<RelationField> fields;
		private final String pkName;
		private final Collection<String> pkFieldNames;
		private final Collection<FkInfo> fks;
		
		AbstractRelationInfo(String name, String descr, List<RelationField> fields,
				String pkName, Collection<String> pkFieldNames, Collection<FkInfo> fks) {
			this.name = name;
			this.descr = descr;
			this.fields = fields;
			this.pkName = pkName;
			this.pkFieldNames = pkFieldNames;
			this.fks = fks;
		}
		
		public void decode(AbstractRelation ar, GetSchema<?> gs) throws UnknownRefFieldException, BadColumnName {
			ar.setDescription(descr);
			for (RelationField f : fields) {
				ar.addField(f);
			}
			if (pkName != null) {
				ar.setPrimaryKey(pkName, pkFieldNames);
			}
			for (FkInfo fki : fks) {
				fki.decode(ar,gs);
			}
		}
	}
	
	public interface GetSchema<S extends AbstractRelation> {
		S getSchema(String name);
	}
	
	private static class FkInfo {
		private final String fkName;
		private final String refRelName;
		private final List<String> refFieldNames;
		private final List<String> thisFieldNames;
		
		FkInfo(String fkName, String refRelName, List<String> refFieldNames, List<String> thisFieldNames) {
			this.fkName = fkName;
			this.refRelName = refRelName;
			this.refFieldNames = refFieldNames;
			this.thisFieldNames = thisFieldNames;
		}
		
		void decode(AbstractRelation ar, GetSchema<?> gs) throws UnknownRefFieldException {
			AbstractRelation ref = gs.getSchema(refRelName);
			if (ref == null) {
				throw new IllegalArgumentException("No relation found for " + refRelName);
			}
			ForeignKey fk = new ForeignKey(fkName, ar, thisFieldNames, ref, refFieldNames);
			ar.addForeignKey(fk);
		}
	}

	public static AbstractRelationInfo deserializeAbstractRelation(Element relElt) throws XMLParseException, UnknownRefFieldException, UnsupportedTypeException {
		String name = relElt.getAttribute("name");
		if (name.length() == 0) {
			throw new XMLParseException("Missing relation name", relElt);
		}
		String descr = relElt.getAttribute("description");
		if (descr.length() == 0) {
			descr = null;
		}

		ArrayList<RelationField> fields = new ArrayList<RelationField>();
		for (Element field : DomUtils.getChildElementsByName(relElt, "field")) {
			RelationField f = RelationField.deserialize(field);
			fields.add(f);
		}
		Element primaryKey = DomUtils.getChildElementByName(relElt, "primaryKey");
		String pkName = null;
		List<String> pkFieldNames = null;
		if (primaryKey != null) {
			pkName = primaryKey.getAttribute("name");
			pkFieldNames = new ArrayList<String>();
			if (pkName.length() == 0) {
				throw new XMLParseException("Missing primary key name", primaryKey);
			}
			for (Element fieldEl : DomUtils.getChildElementsByName(primaryKey, "fieldName")) {
				String fieldName = fieldEl.getAttribute("name");
				if (fieldName.length() == 0) {
					throw new XMLParseException("Missing name for field", fieldEl);
				}
				pkFieldNames.add(fieldName);
			}
		}
		
		List<FkInfo> fkInfo = new ArrayList<FkInfo>();
		List<Element> fks = DomUtils.getChildElementsByName(relElt, "foreignKey");
		for (Element fk : fks) {
			String fkName = fk.getAttribute("name");
			if (fkName.length() == 0) {
				throw new XMLParseException("Missing foreign key name", fk);
			}
			String refRel = fk.getAttribute("refRel");
			if (refRel.length() == 0) {
				throw new XMLParseException("Missing referenced relation name", fk);
			}
			List<String> refFields = new ArrayList<String>();
			List<String> thisFields = new ArrayList<String>();
			List<Element> fkEntries = DomUtils.getChildElementsByName(fk, "fkEntry");
			for (Element fkEntry : fkEntries) {
				String refField = fkEntry.getAttribute("refField");
				if (refField.length() == 0) {
					throw new XMLParseException("Missing referenced field name", fkEntry);
				}
				String thisField = fkEntry.getAttribute("field");
				if (thisField.length() == 0) {
					throw new XMLParseException("Missing field name", fkEntry);
				}
			}
			fkInfo.add(new FkInfo(fkName, refRel, refFields, thisFields));
		}
		
		return new AbstractRelationInfo(name, descr, fields, pkName,
				pkFieldNames, fkInfo);
	}	
}

package edu.upenn.cis.orchestra.datamodel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.Config;
import edu.upenn.cis.orchestra.datamodel.Atom.AtomType;
import edu.upenn.cis.orchestra.datamodel.exceptions.DuplicateRelationIdException;
import edu.upenn.cis.orchestra.datamodel.exceptions.InvalidBeanException;
import edu.upenn.cis.orchestra.datamodel.exceptions.UnknownRefFieldException;
import edu.upenn.cis.orchestra.datamodel.exceptions.UnsupportedTypeException;
import edu.upenn.cis.orchestra.mappings.MappingsTranslationMgt;
import edu.upenn.cis.orchestra.repository.model.beans.ScConstraintBean;
import edu.upenn.cis.orchestra.repository.model.beans.ScFieldBean;
import edu.upenn.cis.orchestra.repository.model.beans.ScForeignKeyBean;
import edu.upenn.cis.orchestra.repository.model.beans.ScRelationBean;
import edu.upenn.cis.orchestra.util.DomUtils;
import edu.upenn.cis.orchestra.util.XMLParseException;



/**
 * A class to represent a relation that exists inside a schema
 * for a collection of relations.
 * 
 * @author netaylor
 *
 */
public class Relation extends AbstractRelation {
	
	public static final int NO_ID = -1;
	private static final long serialVersionUID = 1L;

	private /*final */ Schema _schema;
	private /*final */ int _relationID = NO_ID;
	private boolean _hasLNs = true;
	
	public static final String LOCAL = "_L";
	public static final String REJECT = "_R";
	
	public static final String INSERT = "_INS";
	public static final String DELETE = "_DEL";

	public static String valueAttrName = "VALUE";

	/**
	 * What mapping tables' names start with.
	 */
	public static final String MAPPING_PREFIX = "M";

	/** Fields of this relation that appear in some skolem term */
	protected List<RelationField> _skolemizedFields = new ArrayList<RelationField> ();

	/** Catalog used for the relation in the source database, might be null */
	protected String _dbCatalog;
	/** Schema used for the relation in the source database, might be null */
	protected String _dbSchema;
	/** Relation physical name in the database. Can be equal to the 
	 * "Orchestra name" (_name) but the Orchestra name has to be 
	 * unique for a given Orchestra schema
	 */
	protected String _dbRelName;

	/** A relation can be virtual or materialized **/
	protected boolean _materialized;

	
	/**
	 * Create a new schema 
	 */
	public Relation(Schema schema, int relationID) {
		super();
		_relationID = relationID;
		_schema = schema;
		if (schema != null)
			_name = schema.getNameForID(relationID);
	}
	
	public Relation(Schema schema, int relationID, AbstractRelation tab, boolean materialized) {
		super(tab);
		if (tab instanceof Relation)
			_hasLNs = ((Relation)tab)._hasLNs;
		_relationID = relationID;
		_schema = schema;
		if (schema != null && _name == null)
			_name = schema.getNameForID(relationID);
		if (relationID != Relation.NO_ID && this._schema != null && 
				!schema.getNameForID(relationID).equals(getName()))
			throw new IllegalStateException("Relation's internal name and schema name differ!  " +
					schema.getNameForID(relationID) + " / " + getName());
		
		if (tab._pk != null){
			List<String> keyFields = new ArrayList<String>();
			for (RelationField fld : tab._pk.getFields()){
				keyFields.add(fld.getName());
			}
			try{
				_pk = new PrimaryKey(tab._pk.getName(), this, keyFields);
			}catch(UnknownRefFieldException e){
//				Should never happen
				e.printStackTrace();
			}
//			_pk = tab._pk;
		}

		for (RelationIndexUnique idx : tab.getUniqueIndexes())
			_uniqueIndexes.add(idx);
		for (RelationIndexNonUnique idx : tab.getNonUniqueIndexes())
			_nonUniqueIndexes.add(idx);
		
		_materialized = materialized;
		finished = tab.finished;
	}

	public Relation(Schema schema, AbstractRelation tab,
			String nam, String dbName, String dbSchema, boolean materialized) {
		super(tab);
		
		_materialized = materialized;
		
		if (tab instanceof Relation)
			_hasLNs = ((Relation)tab)._hasLNs;
		_name = nam;
		_dbRelName = dbName;
		this._schema = schema;
		this._dbSchema = dbSchema;
		
		try {
			this._relationID = schema.addRelation(this);
		} catch (DuplicateRelationIdException dne) {
			
		}
		
		if (tab._pk != null){
			List<String> keyFields = new ArrayList<String>();
			for (RelationField fld : tab._pk.getFields()){
				keyFields.add(fld.getName());
			}
			try{
				_pk = new PrimaryKey(tab._pk.getName(), this, keyFields);
			}catch(UnknownRefFieldException e){
//				Should never happen
				e.printStackTrace();
			}
//			_pk = tab._pk;
		}
		
		for (RelationIndexUnique idx : tab.getUniqueIndexes())
			_uniqueIndexes.add(idx);
		for (RelationIndexNonUnique idx : tab.getNonUniqueIndexes())
			_nonUniqueIndexes.add(idx);
		finished = tab.finished;
	}
	
	/**
	 * Creates a new relation
	 * @param dbCatalog Catalog used for the relation in the source database, can be null
	 * @param dbSchema Schema used for the relation in the source database, can be null
	 * @param dbRelName Relation name in the actual database
	 * @param name Relation name
	 * @param description Relation description
	 * @param fields Relation fields
	 */
	public Relation (String dbCatalog, String dbSchema, String dbRelName, String name, 
							String description, boolean materialized, List<RelationField> fields) 
	{
		super(name, description, fields);
		for(RelationField field : fields)
			field.setRelation(this);
		_dbCatalog = dbCatalog;
		_dbSchema = dbSchema;
		_dbRelName = dbRelName;
		_materialized = materialized;
	}	
   
	/**
	 * Creates a new relation
	 * @param dbCatalog Catalog used for the relation in the source database, can be null
	 * @param dbSchema Schema used for the relation in the source database, can be null
	 * @param dbRelName Relation name in the actual database
	 * @param name Relation name
	 * @param description Relation description
	 * @param fields Relation fields
	 * @throws UnknownRefFieldException 
	 */
	public Relation (String dbCatalog, String dbSchema, String dbRelName, String name, 
							String description, boolean materialized, List<RelationField> fields, String pkName,
							List<String> pkFieldNames) throws UnknownRefFieldException 
	{
		super (name, description, fields, pkName, pkFieldNames);
		
		_dbCatalog = dbCatalog;
		_dbSchema = dbSchema;
		_dbRelName = dbRelName;
		_materialized = materialized;
	}	
	/**
	 * Creates a new relation from its bean description. <BR>
	 * Foreign keys not loaded there because the referenced relation 
	 * might not exist yet 
	 * @param relBean Relation bean 
	 * @throws InvalidBeanException If the fields list is empty,
	 *    or a direct constraint implies a field not known in the 
	 *    relation , or a mandatory field is missing
	 * @throws UnsupportedTypeException 
	 */
	public Relation (ScRelationBean relBean)
							throws InvalidBeanException, UnsupportedTypeException
	{
		super(relBean);
		_dbCatalog = relBean.getDbCatalog();		
		_dbSchema = relBean.getDbSchema();
		_dbRelName = relBean.getDbRelName();
		if (_dbRelName == null)
			throw new InvalidBeanException (relBean, "A database relation name is mandatory for " + relBean.getName());
		_materialized = relBean.isMaterialized();
	}

	/**
	 * Deep copy of the relation
	 * Use the method deepCopy to benefit from polymorphism
	 * @param relation Relation to copy
	 * @roseuid 449AEA650271
	 * @see AbstractRelation#deepCopy()
	 */
	protected Relation(Relation relation) 
	{
		this(relation._schema, relation._relationID, relation, relation.isMaterialized());
		_hasLNs = relation._hasLNs;
		
		_dbCatalog = relation.getDbCatalog();
		_dbSchema = relation.getDbSchema();
		_dbRelName = relation.getDbRelName();
//		_materialized = relation.isMaterialized();

		//this.relationID = relation.relationID;
		//this.schema = relation.schema;
	}   
	
	protected void setNewID(int relID) {
		_relationID = relID;
	}
	
	/**
	 * Set the schema / relation ID
	 * 
	 * @param s
	 * @param relID
	 */
	public void setSchema(Schema s, int relID) {
		this._relationID = relID;
		this._schema = s;
	}

	/**
	 * Add a relation to a schema
	 * 
	 * @param s
	 */
	public void addToSchema(Schema s) throws IllegalStateException, DuplicateRelationIdException {
		if (finished) {
			throw new IllegalStateException("Cannot add relation to finished schema");
		} else if (this._schema != null && this._schema != s) {
			throw new IllegalStateException("Cannot move relation from one schema to another");
		}
		
		this._relationID = s.addRelation(this);
		this._schema = s;
		_name = _schema.getNameForID(_relationID);
	}
	
	
	public String getRelationName() throws IllegalStateException {
		if (this._schema != null && !_schema.getNameForID(_relationID).equals(getName()))
			throw new IllegalStateException("Relation's internal name and schema name differ!  " +
					_schema.getNameForID(_relationID) + " / " + getName());
		return getName();//schema.getNameForID(relationID);
	}
	
	public int getRelationID() throws IllegalStateException {
		if (this._schema == null)
			throw new IllegalStateException("Cannot get relation ID from a relation that has no associated schema!");

		return _relationID;
	}
	
	public void setRelationID(int id) {
		_relationID = id;
	}

	/**
	 * Get a deep copy of this relation. <BR>
	 * Deep copy won't copy the foreign keys
	 * @return Deep copy
	 * @see AbstractRelation#TableSchema(AbstractRelation)
	 * @see AbstractRelation#deepCopyFks(Schema)
	 */
	/*protected*/
	public synchronized Relation deepCopy ()
	{
		return new Relation(_schema, _relationID, this, _materialized);
	}   

	public synchronized Relation deepCopy (String newName, String newDbName, String newDbSchema)
	{
		return new Relation(_schema, this, newName, newDbName, newDbSchema, _materialized);

	}   
	
	public synchronized void deepCopyFks (AbstractRelation relation, Schema schema)
	{
		for (ForeignKey cst : relation.getForeignKeys())
			_foreignKeys.add(cst);

	}

   public boolean hasLabeledNulls() {
	   return _hasLNs;
   }
   
   public void setLabeledNulls() {
		if (finished) {
			throw new RuntimeException("Attempt to modify a finished schema");
		}
	   _hasLNs = true;
   }
   
   public void setLabeledNulls(boolean b) {
	   _hasLNs = b;
   }
   
	
	public synchronized void serialize(Document doc, Element schema) {
		// TODO: rewrite to use AbstractRelation.serialize
		schema.setAttribute("name", _name);
		schema.setAttribute("description", _description);
		schema.setAttribute("materialized", _materialized ? "true" : "false");
 	    schema.setAttribute("noNulls", hasLabeledNulls() ? "false" : "true");
		Element dbinfo = DomUtils.addChild(doc, schema, "dbinfo");
		dbinfo.setAttribute("catalog", _dbCatalog);
		dbinfo.setAttribute("schema", _dbSchema);
		dbinfo.setAttribute("table", _dbRelName);
		super.serialize(doc, schema);
	}
	
//	public TableSchema (String dbCatalog, String dbSchema, String dbRelName, String name, 
//	String description, boolean materialized, List<ScField> fields,
//	int statNbRows) 
	public static Relation deserialize(Element relElt, boolean builtinFunction) throws XMLParseException, UnknownRefFieldException, UnsupportedTypeException {
		// TODO: rewrite to use AbstractRelation.deserializeAbstractRelation
		String noNulls = relElt.getAttribute("noNulls");
		   
		String name = relElt.getAttribute("name");
		String descr = relElt.getAttribute("description");
		boolean mat = Boolean.parseBoolean(relElt.getAttribute("materialized"));
		Element dbinfo = DomUtils.getChildElementByName(relElt, "dbinfo");
		if (dbinfo == null) {
			throw new XMLParseException("Missing dbinfo element under relation element", relElt);
		}
		String dbcatalog = dbinfo.getAttribute("catalog");
		if (dbcatalog.length() == 0) {
			dbcatalog = null;
		}
		String dbschema = dbinfo.getAttribute("schema");
		String dbtable = dbinfo.getAttribute("table");
		ArrayList<RelationField> fields = new ArrayList<RelationField>();
		List<String> keyFields = new ArrayList<String>();
		for (Element field : DomUtils.getChildElementsByName(relElt, "field")) {
			RelationField f = RelationField.deserialize(field);
			fields.add(f);
			if("true".equals(field.getAttribute("key"))){
				keyFields.add(field.getAttribute("name"));
			}
		}
			
		Element primaryKey = DomUtils.getChildElementByName(relElt, "primaryKey");
		String pkName = null;
		List<String> pkFieldNames = new ArrayList<String>();
		if (primaryKey != null) {
			pkName = primaryKey.getAttribute("name");
			if (pkName.length() == 0) {
				throw new XMLParseException("Missing primary key name", primaryKey);
			}
			for (Element fieldEl : DomUtils.getChildElementsByName(primaryKey, "fieldName")) {
				String fieldName = fieldEl.getAttribute("name");
				if (fieldName.length() == 0) {
					throw new XMLParseException("Missing name for field", fieldEl);
				}
				pkFieldNames.add(fieldName);
			}
		}else{
			pkName = "pk";
			pkFieldNames.addAll(keyFields);
		}
		
//		greg: hack to add edb bit to peer relations
		if(Config.getEdbbits() && !builtinFunction){
			RelationField f = MappingsTranslationMgt.edbBitField();
			fields.add(f);
			pkFieldNames.add(f.getName());
		}
		
		Relation rel;
		if (pkName != null) {
			rel = new Relation(dbcatalog, dbschema, dbtable, name, descr, mat, fields, pkName, pkFieldNames);
		} else {
			rel = new Relation(dbcatalog, dbschema, dbtable, name, descr, mat, fields);
		}
		if (noNulls.equals("true"))
		   rel._hasLNs = false;
	   else
		   rel._hasLNs = true;
		rel.markFinished();		
		
		return rel;
	}

	/**
	 * Load foreign keys from a bean definition (not loaded in the constructor since some referred 
	 * relation might not exist yet in the schema
	 * @param relBean Relation bean description
	 * @param schema Schema containing the relation (must contain referenced relations)
	 * @throws InvalidBeanException If a relation of field does not exist
	 */
	public synchronized void loadForeignKeys (ScRelationBean relBean, Schema schema)
					throws InvalidBeanException
	{
		for (ScForeignKeyBean fkBean : relBean.getForeignKeys())
			_foreignKeys.add (new ForeignKey(fkBean, this, schema));	   
	}
   
	public boolean isInternalRelation() {
		return getName().endsWith(LOCAL) || getName().endsWith(REJECT);
	}
	
	public static boolean isInternalRelationName(String fn) {
		return fn.endsWith(LOCAL) || fn.endsWith(REJECT);
	}
	
	/**
	 * Return <code>true</code> if <code>s</code> follows the naming convention
	 * for mapping tables, <code>false</code> otherwise.
	 * 
	 * @param s that which is being tested.
	 * @return see description.
	 */
	public static boolean isMappingTableName(String s) {
		return s.matches(MAPPING_PREFIX + "\\d+");
	}
	
	public String getLocalName() {
		return getName() + LOCAL;
	}

	public String getRejectName() {
		return getName() + REJECT;
	}

	public String getLocalInsDbName() {
		return getDbRelName() + LOCAL;
	}

	public String getLocalRejDbName() {
		return getDbRelName() + REJECT;
	}
	
	/**
	 * Set the skolemized fields for this relation
	 * @param the fields of this relation that appear in some skolem term
	 * @deprecated
	 */
	public synchronized void setSkolemizedFields (List<RelationField> skolemizedFields){
		_skolemizedFields = skolemizedFields;
	}

	/**
	 * @return List of fields of this relation that 
	 * appear in some skolem term 
	 * @deprecated
	 */
	public synchronized List<RelationField> getSkolemizedFields ()
	{
		return Collections.unmodifiableList(_skolemizedFields);
	}

	/**
	 * Get the database catalog for this relation
	 * @return Database catalog 
	 */
	public String getDbCatalog ()
	{
		return _dbCatalog;	   
	}

	/**
	 * Get the database schema for this relation
	 * @return Database schema
	 */
	public String getDbSchema ()
	{
		return _dbSchema;
	}

	/** 
	 * Get the database relation name for this relation
	 * (can be different from Orchestra relation name which 
	 * must be unique for a given Orchestra schema) 
	 * @return Database table name
	 */
	public String getDbRelName ()
	{
		return _dbRelName;
	}
	/**
	 * Get the fully qualified id of this relation over the underlying database.<BR>
	 * The id is computed based on the DbCatalog, the DbSchema and the DbName. Thus this id 
	 * is supposed to be unique for a given database.
	 * @return The relation id
	 * @see Schema
	 */  
	public String getFullQualifiedDbId ()
	{
		//	 TODO:LOW Could a schema be defined over multiple dbs? Sounds not likely to occur with orchestra for 
		//	 materialized schemas but what about coming virtual schemas? 
		return getFullQualifiedDbId(getDbCatalog(), getDbSchema(), getName());
	}

	public String getFullQualifiedOUProvDbId ()
	{
		//	 TODO:LOW Could a schema be defined over multiple dbs? Sounds not likely to occur with orchestra for 
		//	 materialized schemas but what about coming virtual schemas? 
		return getFullQualifiedDbId(getDbCatalog(), getDbSchema(), "p" + getName());
	}

	/**
	 * Compute a relation fully qualified db name based on the DbCatalog, 
	 * the DbSchema and the DbName
	 * @param catalog DbCatalog for the relation id to compute
	 * @param schema  DbSchema for the relation id to compute
	 * @param name  Relation's name
	 * @return Relation id
	 * @see Schema
	 */
	public static String getFullQualifiedDbId (String catalog, String schema, String name)
	{
		String id="";
		if (catalog != null)
			id = catalog + ".";
		if (schema != null)
			id += schema + ".";
//		else
//			id += "ORCHESTRA" + ".";
		id += name;
		return id;
	}

	/**
	 * Returns a description of the relation, conforms to the 
	 * flat file format defined in <code>RepositoryDAO</code>
	 * @return Relation description
	 */   
	public String toString ()
	{
		return toString (0);
	}

	/**
	 * Returns a description of the relation, conforms to the 
	 * flat file format defined in <code>RepositoryDAO</code>
	 * Description is indented with <code>nbTabs</code> tabs
	 * @param nbTabs Nb of tabulations
	 * @return Relation description
	 */   
	protected synchronized String toString (int nbTabs)
	{
		StringBuffer buff = new StringBuffer (); 

		for (int i = 0 ; i < nbTabs ; i++)
			buff.append("\t");
		buff.append("RELATION ");
		buff.append(getName());
		buff.append(" \"" + getDescription() + "\"");
		if (isMaterialized())
			buff.append(" MATERIALIZED");
		else
			buff.append(" VIRTUAL");
		buff.append("\n");

		for (int i = 0 ; i < nbTabs ; i++)
			buff.append("\t");
		buff.append("\tDBINFO ");
		buff.append((getDbCatalog()!=null?getDbCatalog():"") + ", ");
		buff.append((getDbSchema()!=null?getDbSchema():"") + ", ");
		buff.append(getDbRelName() + "\n");

		for (int i = 0 ; i < nbTabs ; i++)
			buff.append("\t");
		buff.append("\tFIELDS ");
		boolean firstField = true;
		for (RelationField fld : getFields())
		{
			buff.append ((firstField?"":", ") + fld.toString());
			firstField = false;
		}
		buff.append("\n");


		if (_pk != null)
		{
			for (int i = 0 ; i < nbTabs ; i++)
				buff.append("\t");
			buff.append("\t");		
			buff.append (_pk.toString());
			buff.append("\n");

		}



		for (RelationIndexUnique ux : _uniqueIndexes)
		{
			for (int i = 0 ; i < nbTabs ; i++)
				buff.append("\t");
			buff.append ("\t");
			buff.append (ux.toString() + "\n");
		}

		for (RelationIndexNonUnique ux : _nonUniqueIndexes)
		{
			for (int i = 0 ; i < nbTabs ; i++)
				buff.append("\t");
			buff.append ("\t");
			buff.append (ux.toString() + "\n");
		}

		for (ForeignKey fk : _foreignKeys)
		{
			for (int i = 0 ; i < nbTabs ; i++)
				buff.append("\t");
			buff.append ("\t");
			buff.append (fk.toString() + "\n");
		}		

		return buff.toString();

	}

	public synchronized String toAtomString(AtomType type) {
		// returns a string of form: R(A,B,C,D)
		StringBuffer buf = new StringBuffer();
		//Olivier: fix to work with multiple schemas
		//buf.append(getName());
		buf.append(getFullQualifiedDbId());
		buf.append(Atom.typeToSuffix(type));
		buf.append("(");
		List<RelationField> fields = getFields();
		for (int i = 0; i < fields.size(); i++) {
			if (i != 0) {
				buf.append(",");
			}
			buf.append(fields.get(i).getName());
		}
		buf.append(")");
		return buf.toString();
	}

	/**
	 * Creates a bean from this relation. Used to communicate with the 
	 * DAO layer (and with web services?)
	 * @return The relation bean
	 */
	public synchronized ScRelationBean toBean ()
	{
		// Create the relation bean
		ScRelationBean bean = new ScRelationBean ();

		/*
		bean.setDbCatalog(getDbCatalog());
		bean.setDbSchema(getDbSchema());
		bean.setDbRelName(getDbRelName());
		bean.setName(getName());
		bean.setDescription(getDescription());
		 */

		// Copy the bean simple properties
		BeanUtils.copyProperties(this, bean, new String[] {"fields", "directConstraints", "foreignKeys"});

		//	 Create the list of fields beans 
		List<ScFieldBean> fieldsBeans = new ArrayList<ScFieldBean> ();
		for (RelationField fld : getFields())
			fieldsBeans.add (fld.toBean ());
		bean.setFields(fieldsBeans);

		//	 Create the list of direct constraints beans
		List<ScConstraintBean> directConstraints = new ArrayList<ScConstraintBean> ();
		if (getPrimaryKey()!= null)	
			directConstraints.add(getPrimaryKey().toBean());
		for (RelationIndexUnique uniqueIdx : getUniqueIndexes())
			directConstraints.add (uniqueIdx.toBean());	  
		for (RelationIndexNonUnique idx : getNonUniqueIndexes())
			directConstraints.add (idx.toBean());		
		bean.setDirectConstraints(directConstraints);

		//	 Create the list of foreign keys beans 
		List<ScForeignKeyBean> foreignKeys = new ArrayList<ScForeignKeyBean> ();
		for (ForeignKey fk : getForeignKeys())
			foreignKeys.add((ScForeignKeyBean) fk.toBean());
		bean.setForeignKeys(foreignKeys);

		return bean;

	}

	/**
	 * Is this relation materialized or virtual
	 * @return
	 */
	public boolean isMaterialized ()
	{
		return _materialized;
	}

	/** 
	 * Get next revision for the current relation
	 * _VER1 if now previous revision exists 
	 * @return Database table name
	 */
	public String getNextRevisionName ()
	{
		String relName = _dbRelName;
		String nextRevision = "_VER";
		int intVersionIndex = _dbRelName.indexOf("_VER");
		if (intVersionIndex != -1)
		{
			relName = _dbRelName.substring(0,intVersionIndex);
			String currRevision = _dbRelName.substring(intVersionIndex+4,
													_dbRelName.length());
			nextRevision += (new Integer
								(Integer.parseInt(currRevision)+1)).toString();
			System.out.println("nextRevision-->"+nextRevision);
		}
		else
		{
			System.out.println("First revision");
			nextRevision += "1";
		}
		return relName + nextRevision;
	}
}
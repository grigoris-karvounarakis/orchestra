/**
 * 
 */
package edu.upenn.cis.orchestra.datamodel;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.util.XMLParseException;


public class LongType extends Type {
	public static final int bytesPerLong = Long.SIZE / Byte.SIZE;
	private static final long serialVersionUID = 1L;

	public static final LongType LONG = new LongType(true);

	public LongType(boolean nullable) {
		super(nullable, Long.class);
	}

	public String getXSDType() {
		return "xsd:long";
	}

	@Override
	public Integer compareTwo(Object o1, Object o2) throws CompareMismatch {
		if (o1 == null || o2 == null) {
			return null;
		}
		if (o1.getClass() != Long.class || o2.getClass() != Long.class) {
			throw new CompareMismatch(o1,o2,Long.class);
		}
		Long l1 = (Long) o1;
		Long l2 = (Long) o2;
		return l1.compareTo(l2);
	}

	@Override
	public Object duplicateValue(Object o) {
		// Longs are immutable
		return o;
	}

	public static long getValFromBytes(byte[] bytes) {
		return getValFromBytes(bytes,0,bytes.length);
	}

	public static long getValFromBytes(byte[] bytes, int offset, int length) {
		if (length != bytesPerLong) {
			throw new RuntimeException("Byteified long must have length " + bytesPerLong);
		}
		long value = 0;
		value |= ((long) (bytes[offset] & 0xFF)) << 56;		
		value |= ((long) (bytes[offset + 1] & 0xFF)) << 48;		
		value |= ((long) (bytes[offset + 2] & 0xFF)) << 40;		
		value |= ((long) (bytes[offset + 3] & 0xFF)) << 32;		
		value |= ((long) (bytes[offset + 4] & 0xFF)) << 24;		
		value |= ((long) (bytes[offset + 5] & 0xFF)) << 16;		
		value |= ((long) (bytes[offset + 6] & 0xFF)) << 8;		
		value |= ((long) (bytes[offset + 7] & 0xFF));

		return value;
	}

	/**
	 * Convert a long into a byte array. This outputs the integer in big-endian format
	 * 
	 * @param l		The value to convert
	 * @return		The corresponding byte array
	 */
	public static byte[] getBytes(long l) {
		byte[] retval = new byte[bytesPerLong];

		retval[0] = (byte) (l >>> 56);
		retval[1] = (byte) (l >>> 48);
		retval[2] = (byte) (l >>> 40);
		retval[3] = (byte) (l >>> 32);
		retval[4] = (byte) (l >>> 24);
		retval[5] = (byte) (l >>> 16);
		retval[6] = (byte) (l >>> 8);
		retval[7] = (byte) l;

		return retval;
	}

	@Override
	public Long fromBytes(byte[] bytes, int offset, int length) {
		return getValFromBytes(bytes, offset, length);
	}

	@Override
	public byte[] getBytes(Object o) {
		return getBytes((long) (Long) o);
	}

	@Override
	public Long getFromResultSet(ResultSet rs, int colno) throws SQLException {
		Long l = rs.getLong(colno);
		if (rs.wasNull()) {
			return null;
		} else {
			return l;
		}
	}

	@Override
	public Long getFromResultSet(ResultSet rs, String colname) throws SQLException {
		Long l = rs.getLong(colname);
		if (rs.wasNull()) {
			return null;
		} else {
			return l;
		}
	}

	@Override
	public String getSQLLit(Object o) {
		return o.toString();
	}

	@Override
	public String getSQLTypeName() {
		return "BIGINT";
	}

	@Override
	public int getSqlTypeCode() {
		return Types.BIGINT;
	}

	@Override
	public boolean typeEquals(Type t) {
		return (this.getClass() == t.getClass());
	}

	@Override
	public Object add(Object o1, Object o2) throws ValueMismatchException {
		if (o1 == null && o2 == null) {
			return null;
		}
		if (o1 == null) {
			o1 = 0l;
		}
		if (o2 == null) {
			o2 = 0l;
		}
		if (! (o1 instanceof Long)) {
			throw new ValueMismatchException(o1, this);
		}
		if (! (o2 instanceof Long)) {
			throw new ValueMismatchException(o2, this);
		}
		long l1 = (Long) o1;
		long l2 = (Long) o2;

		return l1 + l2;
	}

	@Override
	public Object divide(Object o, int divisor) throws ValueMismatchException {
		if (o == null) {
			return null;
		}
		if (! (o instanceof Long)) {
			throw new ValueMismatchException(o, this);
		}

		if (divisor == 0) {
			return null;
		}

		long l = (Long) o;
		return l / ((long) divisor);
	}

	public void serialize(Document doc, Element field) {
		field.setAttribute("type", "long");
		field.setAttribute("nullable", Boolean.toString(isNullable()));
	}

	public static Type deserialize(String type, boolean nullable) {
		if (type != null && (type.compareToIgnoreCase("long") == 0 || 
				type.compareToIgnoreCase("bigint") == 0)) {
			return new LongType(nullable);
		}
		return null;
	}

	@Override
	public Long fromStringRep(String rep) throws XMLParseException {
		try {
			return Long.parseLong(rep);
		} catch (NumberFormatException e) {
			throw new XMLParseException("Could not decode long value " + rep, e);
		}
	}

	@Override
	public String getStringRep(Object o) throws NullPointerException, ValueMismatchException {
		if (o == null) {
			throw new NullPointerException();
		}
		if (! this.isValidForColumn(o)) {
			throw new ValueMismatchException(o,this);
		}
		return Long.toString((Long) o);
	}

	@Override
	public edu.upenn.cis.orchestra.optimization.Type getOptimizerType() {
		throw new UnsupportedOperationException("Need to implement type in optimizer");
	}

	@Override
	public void setInPreparedStatement(Object o, PreparedStatement ps, int no)
	throws SQLException {
		if (o == null) {
			ps.setNull(no, this.getSqlTypeCode());
		} else {
			ps.setLong(no, (Long) o);
		}
	}

	@Override
	public int bytesLength() {
		return bytesPerLong;
	}
	
	@Override
	public int getHashCodeFromBytes(byte[] data, int offset, int length) {
		// Should give same hashCode as getHashCode
		// per javadoc
		long l = getValFromBytes(data, offset, length);
		return (int)(l^(l>>>32));
	}
}
/**
 * 
 */
package edu.upenn.cis.orchestra.datamodel.exceptions;

import edu.upenn.cis.orchestra.datamodel.AbstractRelation;
import edu.upenn.cis.orchestra.datamodel.Type;


public class ValueMismatchException extends Exception {
	private static final long serialVersionUID = 1L;
	public ValueMismatchException(Object o, Type t) {
		super("Attempt to use object '" + o + "' of type " + (o == null ? "null" : o.getClass().getName()) + 
				" as type " + t);
	}
	public ValueMismatchException(Object o, AbstractRelation schema, int col) {
		super("Attempt to use object '" + o + "' of type " + (o == null ? "null" : o.getClass().getName()) + 
				" as type " + schema.getColType(col) + "(" + schema.getColName(col) + " of " + schema.getName() + ")");
	}
	public ValueMismatchException(Type tActual, Type tExpected) {
		super("Attempt to use object of type " + tActual + 
				" as type " + tExpected);
	}
}
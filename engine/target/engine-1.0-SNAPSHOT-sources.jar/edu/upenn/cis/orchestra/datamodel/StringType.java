package edu.upenn.cis.orchestra.datamodel;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import edu.upenn.cis.orchestra.datamodel.exceptions.CompareMismatch;
import edu.upenn.cis.orchestra.datamodel.exceptions.NotNumericalException;
import edu.upenn.cis.orchestra.datamodel.exceptions.ValueMismatchException;
import edu.upenn.cis.orchestra.optimization.CharType;
import edu.upenn.cis.orchestra.optimization.VarCharType;

/**
 * @author Nick Taylor
 *
 * Class to represent a string (i.e. CHAR or VARCHAR) element in a schema.
 */
public class StringType extends Type {
	private static final long serialVersionUID = 1L;
	private final boolean isVariable;
	private final int length;

	/**
	 * Create a new string element to be used in a table schema.
	 * 
	 * @param nullable		Whether this column can be set to null
	 * @param isVariable	Whether the string has variable length
	 * @param length		(Maximum) length of the string
	 */
	public StringType(boolean nullable, boolean isVariable,
			int length) {
		super(nullable, String.class);
		this.isVariable = isVariable;
		this.length = length;
	}

	public String getXSDType() {
		return "xsd:string";
	}

	public String getSQLTypeName() {
		String retval = "CHAR(" + Integer.toString(length) + ")";
		if (isVariable) {
			retval = "VAR" + retval;
		}
		return retval;
	}

	public Object duplicateValue(Object o) {
		// Strings are immutable, no need to duplicate
		return o;
	}

	public Integer compareTwo(Object o1, Object o2) throws CompareMismatch {
		if (o1 == null || o2 == null) {
			return null;
		}

		if (o1.getClass() != String.class || o2.getClass() != String.class) {
			throw new CompareMismatch(o1, o2, String.class);
		}

		String s1 = (String) o1;
		String s2 = (String) o2;
		return s1.compareTo(s2);
	}

	public int getSqlTypeCode() {
		if (isVariable)
			return Types.VARCHAR;
		else
			return Types.CHAR;
	}

	public String getFromResultSet(ResultSet rs, int colno) throws SQLException {
		String s = rs.getString(colno);
		if (rs.wasNull()) {
			return null;
		} else {
			if (isVariable) {
				return s;
			} else {
				int pos = s.length();
				while (pos > 0 && Character.isWhitespace(s.charAt(pos - 1))) {
					--pos;
				}
				return s.substring(0, pos);
			}
		}
	}

	public String getFromResultSet(ResultSet rs, String colname) throws SQLException {
		String s = rs.getString(colname);
		if (rs.wasNull()) {
			return null;
		} else {
			if (isVariable) {
				return s;
			} else {
				int pos = s.length();
				while (pos > 0 && Character.isWhitespace(s.charAt(pos - 1))) {
					--pos;
				}
				return s.substring(0, pos);
			}
		}
	}

	public boolean typeEquals(Type t) {
		if (t == null || t.getClass() != this.getClass()) {
			return false;
		}
		StringType st = (StringType) t;
		return (st.isVariable == isVariable && st.length == length);
	}

	public String getSQLLit(Object o) {
		String val = (String) o;
		StringBuilder sb = new StringBuilder("'");

		final int length = val.length();
		for (int i = 0; i < length; ++i) {
			char c = val.charAt(i);
			if (c == '\'') {
				sb.append("''");
			} else {
				sb.append(c);
			}
		}

		sb.append("'");

		return sb.toString();
	}

	public @Override
	byte[] getBytes(Object o) 
	{
		if (o == null) {
			return null;
		}
		String s = (String) o;
		try {
			return s.getBytes("UTF-8");
		} catch (java.io.UnsupportedEncodingException uee) {
			throw new RuntimeException("Can't convert string to bytes using UTF-8");
		}
	}

	public @Override
	String fromBytes(byte[] bytes, int offset, int length) {
		try {
			return new String(bytes, offset, length, "UTF-8");
		} catch (UnsupportedEncodingException uee) {
			throw new RuntimeException("Can't convert bytes to string using UTF-8");
		}
	}

	@Override
	public Object add(Object o1, Object o2) throws NotNumericalException {
		throw new NotNumericalException(this);
	}

	@Override
	public Object divide(Object o, int divisor) throws NotNumericalException {
		throw new NotNumericalException(this);
	}

	@Override
	public boolean canPutInto(Type t) {
		if (t == null || t.getClass() != this.getClass()) {
			return false;
		}
		StringType st = (StringType) t;
		return (st.length >= length);
	}

	@Override
	public boolean canReadFrom(Type t) {
		if (t == null || this.getClass() != t.getClass()) {
			return false;
		}
		StringType st = (StringType) t;
		return (st.length <= length);
	}

	public boolean isVariableLength() {
		return isVariable;
	}

	public int getLength() {
		return length;
	}

	public boolean isValidForColumn(Object o) {
		if (o == null) {
			return isNullable();
		}
		if (!(o instanceof String)) {
			return false;
		}
		String s = (String) o;
		return s.length() <= length;
	}

	public void serialize(Document doc, Element field) {
		field.setAttribute("type", (isVariable ? "varchar(" : "char(" ) + length + ")");
		field.setAttribute("nullable", isNullable() ? "true" : "false");
	}

	public static Type deserialize(String type, boolean nullable) {
		if (type == null)
			return null;

		int left = type.indexOf("(");
		int right = type.indexOf(")");
		if (left != -1 && right != -1 && left > 0 && right == type.length()-1 && left < right) {
			String name = type.substring(0, left);
			String length = type.substring(left+1, right);
			try {
				int len = Integer.parseInt(length);
				if (name.equalsIgnoreCase("varchar")) {
					return new StringType(nullable, true, len);
				} else if (name.equalsIgnoreCase("char")) {
					return new StringType(nullable, false, len);
				}
			} catch (NumberFormatException e) {
				return null;
			}
		}
		return null;
	}

	@Override
	public String fromStringRep(String rep) {
		// pos = index of last character to include
		int pos = rep.length() - 1;
		// Trim to length of datatype
		if (pos >= length) {
			pos = length - 1;
		}
		// Strip out trailing whitespace
		while (pos >= 0) {
			char c = rep.charAt(pos);
			if (! Character.isWhitespace(c)) {
				break;
			}
			--pos;
		}
		if (pos == rep.length() - 1) {
			return rep;
		} else {
			return rep.substring(0, pos + 1);
		}
	}

	@Override
	public String getStringRep(Object o) throws NullPointerException, ValueMismatchException {
		if (o == null) {
			throw new NullPointerException();
		}
		if (! this.isValidForColumn(o)) {
			throw new ValueMismatchException(o,this);
		}
		return (String) o;
	}

	@Override
	public edu.upenn.cis.orchestra.optimization.Type getOptimizerType() {
		if (isVariable) {
			return new VarCharType(length, length / 2);
		} else {
			return new CharType(length);
		}
	}

	@Override
	public void setInPreparedStatement(Object o, PreparedStatement ps, int no)
	throws SQLException {
		if (o == null) {
			ps.setNull(no, this.getSqlTypeCode());
		} else {
			ps.setString(no, (String) o);
		}
	}

	@Override
	public int bytesLength() {
		return -1;
	}

	// Only use the first 10 bytes to create the hash
	private final int hashCodeLength = 10;
	
	static final Charset cs = Charset.forName("UTF-8");
	
	@Override
	public int getHashCode(Object o) throws ValueMismatchException {
		if (o == null) {
			return 0;
		}
		try {
			String s = (String) o;
			byte[] bytes = s.substring(0, s.length() > hashCodeLength ? hashCodeLength : s.length()).getBytes(cs);
			return hashCode(bytes, 0, bytes.length > hashCodeLength ? hashCodeLength : bytes.length);
		} catch (ClassCastException cce) {
			throw new ValueMismatchException(o,this);
		}
	}
		
	private static int hashCode(byte[] data, int offset, int length) {
		int hashCode = 0;
		final int end = offset + length;
		for (int i = offset; i < end; ++i) {
			hashCode = 31 * hashCode + data[i];
		}
		return hashCode;
	}
	
	@Override
	public int getHashCodeFromBytes(byte[] data, int offset, int length) {
		if (length > hashCodeLength) {
			return hashCode(data, offset, hashCodeLength);
		} else {
			return hashCode(data, offset, length);
		}
	}
}

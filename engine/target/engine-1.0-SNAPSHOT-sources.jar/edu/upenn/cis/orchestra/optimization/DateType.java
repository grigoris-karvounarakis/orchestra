package edu.upenn.cis.orchestra.optimization;

import edu.upenn.cis.orchestra.datamodel.Date;

public class DateType extends Type {
	public DateType() {
	}
	
	public DateType(Date constantValue) {
		super(constantValue);
	}

	@Override
	int getExpectedSize() {
		return Date.bytesPerDate;
	}

	@Override
	int getMaximumSize() {
		return Date.bytesPerDate;
	}
	
	public String toString() {
		return "DATE";
	}

	public int compareTo(Type t) {
		return getClass().getSimpleName().compareTo(t.getClass().getSimpleName());
	}

	@Override
	Object convertLit(Object lit, Type to) throws TypeError {
		if (!(lit instanceof Date)) {
			throw new IllegalArgumentException("Expected date literal");
		}
		if (to.equals(this)) {
			return lit;
		}
		throw new TypeError("Cannot convert from " + this + " to " + to);			
	}
	
	public edu.upenn.cis.orchestra.datamodel.DateType getExecutionType() {
		return edu.upenn.cis.orchestra.datamodel.DateType.DATE;
	}

	DateType setConstantValue(Type t) throws TypeError {
		if (! t.valueKnown()) {
			throw new IllegalArgumentException("Supplied type must have a constant value");
		}
		Object newVal = t.convertLit(t.getConstantValue(), this);
		return new DateType((Date) newVal);
	}
}

package edu.upenn.cis.orchestra.optimization;



public class IntType extends Type {
	public IntType() {
	}
	
	public IntType(int constantValue) {
		super(constantValue);
	}
	
	@Override
	int getExpectedSize() {
		return Integer.SIZE / Byte.SIZE;
	}

	@Override
	int getMaximumSize() {
		return Integer.SIZE / Byte.SIZE;
	}

	public String toString() {
		return "INT";
	}

	public int compareTo(Type t) {
		return getClass().getSimpleName().compareTo(t.getClass().getSimpleName());
	}

	@Override
	Object convertLit(Object lit, Type to) throws TypeError {
		if (!(lit instanceof Integer)) {
			throw new IllegalArgumentException("Expected integer literal");
		}
		if (to.equals(this)) {
			return lit;
		} else if (to.equals(Type.DOUBLE)) {
			int value = (Integer) lit;
			return new Double(value);
		} else {
			throw new TypeError("Cannot convert from " + this + " to " + to);
		}
	}

	@Override
	public edu.upenn.cis.orchestra.datamodel.IntType getExecutionType() {
		return edu.upenn.cis.orchestra.datamodel.IntType.INT;
	}
	
	IntType setConstantValue(Type t) throws TypeError {
		if (! t.valueKnown()) {
			throw new IllegalArgumentException("Supplied type must have a constant value");
		}
		Object newVal = t.convertLit(t.getConstantValue(), this);
		return new IntType((Integer) newVal);
	}
}


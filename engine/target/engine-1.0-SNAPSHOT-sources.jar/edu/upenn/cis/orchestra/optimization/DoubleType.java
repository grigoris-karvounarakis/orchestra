package edu.upenn.cis.orchestra.optimization;

public class DoubleType extends Type {
	public DoubleType() {
	}
	
	public DoubleType(double constantValue) {
		super(constantValue);
	}

	@Override
	int getExpectedSize() {
		return Double.SIZE / Byte.SIZE;
	}

	@Override
	int getMaximumSize() {
		return Double.SIZE / Byte.SIZE;
	}
	
	public String toString() {
		return "DOUBLE";
	}

	public int compareTo(Type t) {
		return getClass().getSimpleName().compareTo(t.getClass().getSimpleName());
	}

	@Override
	Object convertLit(Object lit, Type to) throws TypeError {
		if (!(lit instanceof Double)) {
			throw new IllegalArgumentException("Expected double literal");
		}
		if (to.equals(this)) {
			return lit;
		} else if (to.equals(Type.INTEGER)) {
			double value = (Double) lit;
			return new Integer((int) value);
		} else {
			throw new TypeError("Cannot convert from " + this + " to " + to);			
		}
	}
	
	public edu.upenn.cis.orchestra.datamodel.DoubleType getExecutionType() {
		return edu.upenn.cis.orchestra.datamodel.DoubleType.DOUBLE;
	}

	DoubleType setConstantValue(Type t) throws TypeError {
		if (! t.valueKnown()) {
			throw new IllegalArgumentException("Supplied type must have a constant value");
		}
		Object newVal = t.convertLit(t.getConstantValue(), this);
		return new DoubleType((Double) newVal);
	}
}


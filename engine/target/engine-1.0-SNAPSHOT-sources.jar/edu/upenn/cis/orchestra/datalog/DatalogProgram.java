package edu.upenn.cis.orchestra.datalog;

import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;

import edu.upenn.cis.orchestra.Config;
import edu.upenn.cis.orchestra.Debug;
import edu.upenn.cis.orchestra.exchange.RuleQuery;
import edu.upenn.cis.orchestra.mappings.Rule;

/**
 * 
 * @author gkarvoun
 *
 */
public class DatalogProgram extends Datalog {
	protected RuleQuery _stmts;
	String _queryString;
	boolean preparedFlag = false;

	public List<Rule> _rules;
//	public boolean _c4f;
//	public boolean _measureExecTime;
	
	public DatalogProgram(List<Rule> r, boolean c4f){
		_rules = r;
		_c4f = c4f;
		_measureExecTime = false;
	}

	public DatalogProgram(List<Rule> r, boolean c4f, boolean t){
		_rules = r;
		_c4f = c4f;
		_measureExecTime = t;
	}
	
	public DatalogProgram(List<Rule> r){
		_rules = r;
		_c4f = true;
	}
	
	public List<Rule> getRules(){
		return _rules;
	}

	public void setMeasureExecTime(boolean s){
		_measureExecTime = s;
	}

	public boolean measureExecTime(){
		return _measureExecTime;
	}
	
	public boolean count4fixpoint(){
		return _c4f;
	}
	
	public void omitFromCount() {
		_c4f = false;
	}

//	public String toString(){
//		StringBuffer buf = new StringBuffer();
//		if(this instanceof RecursiveDatalogProgram){
//			buf.append("Recursive: ");
//		}else{
//			buf.append("Non-Recursive: ");
//		}
//		int count = 0;
//		for (Rule r : getRules()){
//			if (count++ > 0)
//				buf.append("\n");
//			
//			buf.append(r.toString());
//		}
//		return(buf.toString());
//	}
	
	public String toQueryString ()
	{
		if(_queryString != null){
			return _queryString;
		}else{
			StringBuffer buffer = new StringBuffer ();
			for (Rule r : getRules()) {
				for(String query : r.toUpdate(0)){
					buffer.append("\n" + query);
				}
				buffer.append("\n");
			}
			
			return buffer.toString();
		}
	}
	
	@Override
	public String toString ()
	{
		StringBuffer buffer = new StringBuffer ();
		for (Rule r : getRules()) {
			buffer.append("\n" + r.toString() + "\n");
		}

		return buffer.toString();
	}
	
	public void printString() {
		if(this instanceof RecursiveDatalogProgram){
			Debug.println("Recursive{ ");
		}else{
			Debug.println("Non-Recursive{ ");
		}
//		int count = 0;
		for (Rule r : getRules()){
//			if (count++ > 0)
//				Debug.print("\n");
			
			r.printString();
		}
		if(this instanceof RecursiveDatalogProgram){
			edu.upenn.cis.orchestra.Debug.println("} END Recursive");
		}else{
			Debug.println("} END Non-Recursive");
		}
	}


	public void initialize(RuleQuery q, int curIterCnt) {
//		For (unprepared) stratified we need to generate 
//		different SQL queries for every fixpoint iteration
		if(!Config.getRecomputeQueries()){
			if (_stmts != null)
				return;
		}
		
		StringBuffer qString = new StringBuffer();
		List<List<Integer>> params = new ArrayList<List<Integer>>();
		
		List<String> qs = getQuery(curIterCnt, params);
		
		if(qs.size() != params.size()){
			System.out.println("DIFFERENT NUM QUERIES VS. NUM PARAMS");
		}
		
		for(int i = 0; i < qs.size(); i++){
			String query = qs.get(i);
			List<Integer> qparams = params.get(i);
//		for (String query : qs){

			if(Config.getStratified())
				q.addPrepared(query, qparams);
			else
				q.add(query);
//			q.add(query);
//			q.setPreparedParams(qparams);
			
			qString.append("\n");
			qString.append(query);
		}

		_queryString = new String(qString);
		_stmts = q;
	}
	
	public int evaluate(int curIterCnt) {
		Debug.println("QQQQQ: " + _queryString);
		return _stmts.evaluateSelf(_queryString, curIterCnt);
	}
	
//	public List<PreparedStatement> statements(){
	public RuleQuery statements() {
		return _stmts;
	}
	public List<String> getQuery(int curIterCnt, List<List<Integer>> params) {
		List<String> queries = new ArrayList<String>();

//		Debug.println("Query...");
//		Rule last = null;
		HashSet<Rule> done = new HashSet<Rule>();
//		List<Integer> preparedParams = new ArrayList<Integer>();
		
		for (Rule rule : getRules()) {
			/*if (done.contains(rule))
				continue;
			else
				Debug.println("R: " + rule);*/
			
//			if (rule.deleteFromHead() && !rule.clearNcopy()) {
//				// TODO: See if we can merge with the previous query
//				queries = rule.toUpdate();
//			} else {
//				queries = rule.toUpdate(queries, curIterCnt, preparedParams);
				queries = rule.toUpdate(queries, curIterCnt, params);
//			}
//			last = rule;
//			params.add(preparedParams);
			done.add(rule);
		}
		
//		for (String q: queries)
//			Debug.println(q);
		
		return queries;//new String(qString);
	}
	
	public void prepare() {
		preparedFlag = true;
		try {
			_stmts.prepare();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Unable to prepare:\n" + e.getStackTrace());
		}
	}
	
	public boolean isPrepared(){
//		return(_stmts != null);
		return preparedFlag;
	}

}

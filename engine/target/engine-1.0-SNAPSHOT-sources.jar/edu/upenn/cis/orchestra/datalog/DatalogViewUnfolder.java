package edu.upenn.cis.orchestra.datalog;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.upenn.cis.orchestra.Config;
import edu.upenn.cis.orchestra.Debug;
import edu.upenn.cis.orchestra.datamodel.Atom;
import edu.upenn.cis.orchestra.datamodel.AtomArgument;
import edu.upenn.cis.orchestra.datamodel.AtomVariable;
import edu.upenn.cis.orchestra.datamodel.Mapping;
import edu.upenn.cis.orchestra.datamodel.StringType;
import edu.upenn.cis.orchestra.mappings.Rule;
import edu.upenn.cis.orchestra.mappings.exceptions.RecursionException;
import edu.upenn.cis.orchestra.provenance.ProvEdbNode;
import edu.upenn.cis.orchestra.provenance.ProvIdbNode;
import edu.upenn.cis.orchestra.provenance.ProvenanceNode;

/**
 * View unfolding class for nonrecursive datalog rules.  Maintains a provenance tree
 * for each of these rules, which then gets converted into the appropriate datalog
 * interpreted predicates.
 * 
 * @author zives
 *
 */
public class DatalogViewUnfolder {
	/**
	 * Given a set of rules, make the named atom the distinguished atom
	 * for a query result.  Unfold the rules and create a single expression.
	 * 
	 * @param rules
	 * @param queryAtom
	 */
	public static List<Rule> unfoldQuery(Collection<Rule> rules, String queryAtom,
			Map<Atom,ProvenanceNode> prov, Set<String> provenanceRelations) throws RecursionException {
		HashMap<String,List<Rule>> ruleMap = new HashMap<String,List<Rule>>();
		
		// Index each rule or set of rules by its atom name
		for (Rule r: rules) {
			List<Rule> rs = ruleMap.get(r.getHead().getRelationContext().toString());
			if (rs == null) {
				rs = new ArrayList<Rule>();
				ruleMap.put(r.getHead().getRelationContext().toString(), rs);				
			}
			if (!rs.contains(r))
				rs.add(r);
		}
		
		// The set of atoms we've already expanded -- we don't want to
		// try to expand a recursive / cyclic query into a single SQL
		// statement, and instead require the use of runMaterializedQuery.
		Set<String> visited = new HashSet<String>();
		
		List<Rule> currentQuery = new ArrayList<Rule>();
		currentQuery.addAll(ruleMap.get(queryAtom));
		
		visited.add(queryAtom);
		// See if unfolding this rule gives us a recursive query
		Map<Rule,Boolean> cache = new HashMap<Rule,Boolean>();
		for (Rule r: ruleMap.get(queryAtom))
			if (isRecursive(r, visited, ruleMap, cache))
				throw new RecursionException("Recursive rule " + r.toString());
		

		// Create the initial provenance node
		for (Rule r: currentQuery) {
			List<ProvenanceNode> children = new ArrayList<ProvenanceNode>();
			prov.put(r.getHead(), new ProvIdbNode(r.getHead().getRelationContext().toString(), children));
		}

		Map<Rule,List<Atom>> extraAtoms = new HashMap<Rule,List<Atom>>();
		expandQuery(currentQuery, ruleMap, prov, provenanceRelations, extraAtoms);
		
		for (Rule r: currentQuery)
			if (extraAtoms.containsKey(r))
				r.getBody().addAll(extraAtoms.get(r));
		
		return currentQuery;
	}
	
	/**
	 * Returns true if the current rule, when unfolded one step, contains recursion
	 * 
	 * @param r
	 * @param visited
	 * @param ruleMap
	 * @return
	 */
	private static boolean isRecursive(Rule r, Set<String> visited, Map<String,List<Rule>> ruleMap, Map<Rule,Boolean> cache) {
		if (cache.containsKey(r))
			return cache.get(r);
		for (Atom a : r.getBody()) {
			List<Rule> refs = ruleMap.get(a.getRelationContext().toString());
			
			if (refs != null && refs.size() > 0) {
				for (Rule rul : refs)
					// Self-recursive rule
					for (Atom b : r.getBody()) {
						if (rul.getHead().getRelationContext().equals(b.getRelationContext().toString())) {
							cache.put(r, true);
							return true;
						}
						
						if (visited.contains(b.getRelationContext().toString())) {
							cache.put(r, true);
							return true;
						}

						Set<String> visited2 = new HashSet<String>();
						visited2.addAll(visited);
						if (ruleMap.get(b.getRelationContext().toString()) != null) {
							for (Rule r2: ruleMap.get(b.getRelationContext().toString()))
								if (isRecursive(r2, visited2, ruleMap, cache)) {
									cache.put(r, true);
									return true;
								}
						} //else
//							System.err.println("WARNING: DON'T KNOW ABOUT " + b.getRelationContext().toString());
					}
			}
		}
		cache.put(r, false);
		return false;
	}
	
	/**
	 * Simple test to determine that a rule's atoms all have provenance nodes
	 * 
	 * @param r
	 * @param prov
	 */
	public static void testProvenance(Rule r, Map<Atom,ProvenanceNode> prov) {
		if (prov.get(r.getHead()) == null)
			System.err.println("Head not bound to provenance: " + r.toString());
		
		Set<Atom> existingAtoms = new HashSet<Atom>();
		for (Atom a : r.getBody()) {
			
			if (prov.get(a) == null)
				System.err.println("Body atom " + a.toString() + " not bound to provenance: " + r.toString());
		}
	}
	
	/**
	 * Copy the provenance from Rule 0 to all of the other rules.  ASSUMES THE PREVIOUS VERSION
	 * OF THE RULE ONLY DIFFERS AT THE IDB.
	 * 
	 * @param ruleSet
	 * @param atomPos
	 * @param numAtoms
	 * @param prov
	 */
	public static void copyProvenanceToMoreRules(List<Rule> ruleSet, int atomPos, int numAtoms,
			Map<String,List<Rule>> ruleMap,
			Map<Atom,ProvenanceNode> prov, ProvIdbNode baseNode, Rule base) {
		int offset = numAtoms - atomPos;

		// For the item at the earliest position, we need to do something else:
		// that IDB got mapped into something different for each rule
		Atom atomOfInterest = base.getBody().get(atomPos);

		testProvenance(base, prov);
		for (int i = 0; i < ruleSet.size(); i++) {
			Rule r = ruleSet.get(i);
			// Copy the first rule's provenance tree
			ProvenanceNode n = baseNode.deepCopy();
			
			// Now bind each atom "after" our IDB to the appropriate position
			for (int a = r.getBody().size() - offset + 1; a < r.getBody().size(); a++) {
				ProvenanceNode correspondingNode = baseNode.getCorresponding(prov.get(base.getBody().get(a + 
						base.getBody().size() - r.getBody().size())), n);
					
				if (prov.get(r.getBody().get(a)) != null)
					System.err.println("WARNING: " + r.getBody().get(a) + " already has provenance to be replaced!");
				prov.put(r.getBody().get(a), correspondingNode);
			}

			// Expand the current IDB according to the rule
			ProvenanceNode recentlyExpandedIdb = 
				baseNode.getCorresponding(prov.get(atomOfInterest), n);
			
			expandProvenanceForIdb(r, atomPos, r.getBody().size() - offset, ruleMap, prov, (ProvIdbNode)recentlyExpandedIdb);
			
			// Copy the bindings for the other (unexpanded) IDBs
			for (int a = 0; a < atomPos; a++) {
				// For the item at the earliest position, we need to do something else:
				// that IDB got mapped into something different for each rule
				ProvenanceNode correspondingNode = 
					baseNode.getCorresponding(prov.get(base.getBody().get(a)), n);
				
				prov.put(r.getBody().get(a), correspondingNode);
			}
			
			prov.put(r.getHead(), n);
			testProvenance(r, prov);
		}
	}
	
	/**
	 * When an IDB is being expanded, we want to add provenance nodes for
	 * each of its subnodes into the provenance tree corresponding to the IDB.
	 * 
	 * @param r
	 * @param atomPos
	 * @param endPos
	 * @param ruleMap
	 * @param prov
	 * @param oldIdbProv
	 */
	public static void expandProvenanceForIdb(Rule r, int atomPos, int endPos,
			Map<String,List<Rule>> ruleMap,
			Map<Atom,ProvenanceNode> prov, ProvIdbNode oldIdbProv) {
		
		// We need to add children the IdbNode for oldIdbProv for all of the
		// expanded atoms
		ProvenanceNode p2;
		Atom at;
		for (int a = endPos; a >= atomPos; a--) {
			at = r.getBody().get(a);
			
			if (ruleMap.containsKey(at.getRelationContext().toString())) {
				p2 = new ProvIdbNode(at.getRelationContext().toString());
			} else {
				List<Integer> keys = at.getRelation().getKeyCols();
				List<AtomArgument> args = new ArrayList<AtomArgument>();
				if(keys!=null){
//					for (Integer inx : keys)
//						args.add(at.getValues().get(inx.intValue()));
					for(int j = 0; j < at.getValues().size(); j++){
						if(keys.contains(j)){
							args.add(at.getValues().get(j));
						}else{
							args.add(at.getValues().get(j));
//							args.add(new AtomVariable(Mapping.getFreshAutogenVariableName()));
						}
						
					}
				}
				p2 = new ProvEdbNode(at.getRelationContext().toString(), args);
			}
			prov.put(at, p2);
			if (oldIdbProv != null)
				oldIdbProv.prependChild(p2);
		}
	}
	
	/**
	 * Takes a rule and unfolds each atom at most once
	 * 
	 * @param query
	 * @param atomName
	 * @param ruleMap
	 * @return
	 */
	private static List<Rule> expandRuleOneLevel(Rule query, String atomName, 
			Map<String,List<Rule>> ruleMap,
			Map<Atom,ProvenanceNode> prov, Set<String> provenanceRelations, 
			Map<Rule,List<Atom>> extraAtoms) {
		List<Rule> results = new ArrayList<Rule>();
		
		results.add(query);
		
		boolean didSomething = false;
		
		// Go through the atoms in the original rule and expand one atom
		// at a time, from right to left
		int maxI = query.getBody().size();
		Set<Rule> alreadyExpanded = new HashSet<Rule>();
		for (int i = maxI - 1; i >= 0; i--) {
			for (int j = 0; j < results.size(); j++) {
				Rule r = results.get(j);
				ProvenanceNode p2 = prov.get(r.getHead());
				Atom a = r.getBody().get(i);
				
				// Do a substitution -- from this, we get a rule SET
				if (!alreadyExpanded.contains(r) &&
						a.getRelationContext().toString().equals(atomName) && ruleMap.get(atomName) != null) {
					
					List<Rule> newRules;
					if (ruleMap.get(atomName) != null)
						newRules = r.substituteAtom(i, ruleMap.get(atomName), false);
					else
						newRules = new ArrayList<Rule>();

					for (Rule r2: newRules)
						alreadyExpanded.add(r2);

					// Copy extra atoms associated with original rule to the new rules
					if (extraAtoms.containsKey(r))
						for (Rule r2: newRules) {
							extraAtoms.put(r2, new ArrayList<Atom>());
							extraAtoms.get(r2).addAll(extraAtoms.get(r));
						}
					
					// If it's a provenance relation, we add it back to the end
					// and save the fact that it's been used by these rules
					if (provenanceRelations.contains(atomName)) {
						for (Rule rul : newRules) {
							if (!extraAtoms.containsKey(rul)) {
								extraAtoms.put(rul, new ArrayList<Atom>());
							}
							extraAtoms.get(rul).add(a);
						}
					}
					
					if (newRules.size() > 0) {
						didSomething = true;
						// Replace the current rule
						copyProvenanceToMoreRules(newRules, i, maxI, ruleMap, prov, (ProvIdbNode)p2, r);
						results.set(j, newRules.get(0));
						r = results.get(j);
						
						// Insert in any additional rules into our working set
						if (newRules.size() > 1) {
							for (int k = 1; k < newRules.size(); k++)
								results.add(j + k - 1, newRules.get(k));
						}
						j = j + newRules.size() - 1;
					}
				}
//				System.out.println("> " + r.toString() + "| " + prov.get(r.getHead()));
			}
		}
		if (didSomething)
			return results;
		else
			return null;
	}
	
	/**
	 * Takes a union of conjunctive expressions representing a query, plus
	 * a named map of edbs/idb definitions, and expands it recursively
	 * while adding provenance annotations
	 * 
	 * Uses a DFS traversal
	 * 
	 * @param query
	 * @param ruleInx -- rule to expand from (we've expanded all previous)
	 * @param atomInx -- atom to expand from in this rule (we've expanded all prev)
	 * @param ruleMap
	 * @param provMap
	 * @param visited
	 * @throws RecursionException
	 */
	private static String expandQuery(List<Rule> query, Map<String,List<Rule>> ruleMap,
			Map<Atom,ProvenanceNode> prov, Set<String> provenanceRelations, Map<Rule,List<Atom>> used) 
	throws RecursionException
	{
		// Build the initial provenance mapping for the rule: IDB with a bunch of EDB/IDB children
		for (int j = 0; j < query.size(); j++) {
			Rule r = query.get(j);

			ProvenanceNode rootIdb = prov.get(r.getHead());
			
			expandProvenanceForIdb(r, 0, r.getBody().size() - 1, ruleMap, prov, (ProvIdbNode)rootIdb);
		}
		
//		Config.setDebug(true);
		// Take the rule and expand each atom
		boolean changed;
		do {
			changed = false;
			for (int j = 0; j < query.size(); j++) {
				Rule r = query.get(j);
	
				Debug.println("Before expansion of Rule " + j + ": ");
				if (prov.get(r.getHead()) != null)
					Debug.println(r.toString() + " | " + prov.get(r.getHead()).toString());
				else
					Debug.println(r.toString() + " | ? ");
	
				boolean didSomething = false;
				for (int i = r.getBody().size() - 1; i >= 0; i--) {
					Atom a = r.getBody().get(i);
					String nam = a.getRelationContext().toString();
	
					List<Rule> res = expandRuleOneLevel(r, nam, ruleMap, prov, provenanceRelations, used);
					//while 
					if (res != null) {
						if (!didSomething)
							Debug.println("After expansion: ");
						for (Rule r2 : res) {
							if (prov.get(r2.getHead()) != null)
								Debug.println(r2.toString() + " | " + prov.get(r2.getHead()).toString());
							else
								Debug.println(r2.toString() + " | ? ");
						}
	
						query.set(j, res.get(0));
						r = query.get(j);
						
						// Insert in any additional rules into our working set
						if (res.size() > 1) {
							for (int k = 1; k < res.size(); k++)
								query.add(j + k - 1, res.get(k));
						}
						didSomething = true;
	
//						nam = r.getBody().get(i).getRelationContext().toString();
//						res = expandRuleOneLevel(r, nam, ruleMap, prov);
						if (i > 0)
							Debug.println("...");
					}
				}
				if (didSomething)
					changed = true;;
			}
		} while (changed);
		
		/* Print the rules and their provenance annotations */
//		Debug.println(prov.toString());
		StringType sType = new StringType(true,true,255);
		for (Rule r: query) {
			ProvenanceNode ruleProv = prov.get(r.getHead());
			r.setProvenance(ruleProv);
			
			/*
			ScMappingAtomVariable pType = new ScMappingAtomVariable("__PROV");
			pType.setType(sType);
			
			r.getHead().getValues().add(pType);
			try {
				r.getHead().getRelation().addColVirtual("__PROV", "column", sType);
			} catch (BadColumnName b) {
				b.printStackTrace();
			}*/
			
			Debug.println(r.toString());
			/*
			if (prov.get(r.getHead()) != null)
				System.out.println(r.toString() + " | " + prov.get(r.getHead()).toString());
			else
				System.out.println(r.toString() + " | ? ");
			*/
		}
		
		return null;
	}

}

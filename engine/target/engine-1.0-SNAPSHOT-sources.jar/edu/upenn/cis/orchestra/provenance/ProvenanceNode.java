package edu.upenn.cis.orchestra.provenance;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import edu.upenn.cis.orchestra.datamodel.AtomVariable;
import edu.upenn.cis.orchestra.datamodel.StringType;
import edu.upenn.cis.orchestra.datamodel.Type;
import edu.upenn.cis.orchestra.mappings.Rule;

public abstract class ProvenanceNode {
	private List<ProvenanceNode> _children;
	private ProvenanceNode _parent = null;
	
	public ProvenanceNode() {
		_children = new ArrayList<ProvenanceNode>();
	}
	
	public ProvenanceNode(Collection<ProvenanceNode> children) {
		_children = new ArrayList<ProvenanceNode>();
		
		_children.addAll(children);
	}
	
	public List<ProvenanceNode> getChildren() {
		return _children;
	}
	
	public void addChild(ProvenanceNode child) {
		_children.add(child);
		child._parent = this;
	}
	
	public void prependChild(ProvenanceNode child) {
		_children.add(0, child);
		child._parent = this;
	}
	
	public ProvenanceNode getChildAt(int i) {
		return _children.get(i);
	}
	
	public int getNumChildren() {
		return _children.size();
	}
	
	public ProvenanceNode getParent() {
		return _parent;
	}
	
	public int size() {
		return getNumChildren();
	}
	
	public abstract ProvenanceNode copySelf();

	public ProvenanceNode deepCopy() {
		ProvenanceNode n = copySelf();
		for (ProvenanceNode p : getChildren())
			n.addChild(p.deepCopy());
		
		return n;
	}

	/**
	 * Given the root of an identical subtree, returns the node in
	 * that tree that is identical to the findThis node in our tree
	 * 
	 * @param findThis
	 * @param twinTree
	 * @return
	 */
	public ProvenanceNode getCorresponding(ProvenanceNode findThis,
			ProvenanceNode twinTree) {
		if (this == findThis)
			return twinTree;
		else {
			for (int i = 0; i < getNumChildren(); i++) {
				ProvenanceNode ret = getChildAt(i).getCorresponding(findThis, 
						twinTree.getChildAt(i));
				
				if (ret != null)
					return ret;
			}
		}
		return null;
	}
	
	/**
	 * Coalesces consecutive string elements in the list
	 * 
	 * @param list
	 */
	public void simplify(List<Object> list) {
		int i = 0;
		
		while (i < list.size() - 1) {
			if (list.get(i) instanceof String &&
				list.get(i+1) instanceof String) {
				String str = (String)list.get(i) + (String)list.get(i+1);
				
				list.set(i, str);
				list.remove(i+1);
			} else
				i++;
		}
	}
	
	/**
	 * Returns the SQL expression from our provenance expression.
	 * Assumes '' quotes for string, || operator for concatenation.
	 * Assumes that all variables can be concatenated regardless of
	 * datatype.  (Not sure what happens when an int get strcat'ed.)
	 * 
	 * @param map Variable mapping to SQL name
	 * @param typemap Variable mapping to Orchestra datatype
	 * @return
	 */
	public String getSqlExpression(Map<String,String> map, Map<String,Type> typemap,
			String castTo) {
		List<Object> result = getStringExpr();
		
		StringBuffer ret = new StringBuffer();
		ret.append("(");
		
		boolean first = true;
		for (Object o : result) {
			if (!first)
				ret.append(" || ");
			if (o instanceof String)
				ret.append("'" + o.toString() + "'");
			else if (o instanceof AtomVariable) {
				if (typemap.get(o.toString()) instanceof StringType)
					ret.append("'\"' || " + map.get(o.toString()) + "|| '\"'");
				else
					ret.append("CAST(" + map.get(o.toString()) + " AS " + castTo + ")");
			} else
				ret.append(o.toString());
			
			first = false;
		}
		
		ret.append(")");
		
		return new String(ret);
	}
	
	public String getSqlValueExpression(Map<String,String> map, Map<String,Type> typemap,
			Rule rule) {
		List<Object> result = getValueExpr(rule);
		
		StringBuffer ret = new StringBuffer();
		ret.append("(");
		
		for (Object o : result) {
			if (o instanceof String)
				ret.append(o.toString());
			else if (o instanceof AtomVariable) {
				ret.append(map.get(o.toString()));
			} else
				ret.append(o.toString());
		}
		
		ret.append(")");
		
		return new String(ret);
	}

	
	public abstract List<Object> getStringExpr();
	
	public abstract List<Object> getValueExpr(Rule rule);
}

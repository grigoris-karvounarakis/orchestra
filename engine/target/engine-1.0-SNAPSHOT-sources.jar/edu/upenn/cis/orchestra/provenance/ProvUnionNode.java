package edu.upenn.cis.orchestra.provenance;

import java.util.ArrayList;
import java.util.List;

import edu.upenn.cis.orchestra.mappings.Rule;

public class ProvUnionNode extends ProvenanceNode {

	public String toString() {
		StringBuffer str = new StringBuffer();
		
		boolean first = true;
		for (ProvenanceNode p : getChildren()) {
			if (!first)
				str.append("+");
			str.append(p.toString());
			first = false;
		}
		
		return new String(str);
	}
	
	public ProvUnionNode copySelf() {
		return new ProvUnionNode();
	}

	public List<Object> getStringExpr() {
		List<Object> results = new ArrayList<Object>();
		
		boolean first = true;
		for (ProvenanceNode p : getChildren()) {
			if (!first)
				results.add("+");
			results.addAll(p.getStringExpr());
			first = false;
		}
		
		simplify(results);
		
		return results;
	}
	
	public List<Object> getValueExpr(Rule rule) {
		List<Object> results = new ArrayList<Object>();
		
		boolean first = true;
		for (ProvenanceNode p : getChildren()) {
			if (!first)
				results.add("+");
			results.addAll(p.getValueExpr(rule));
			first = false;
		}
		
		simplify(results);
		
		return results;
	}

}

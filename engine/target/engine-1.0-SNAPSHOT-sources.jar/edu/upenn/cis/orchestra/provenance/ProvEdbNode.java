package edu.upenn.cis.orchestra.provenance;

import java.util.ArrayList;
import java.util.List;

import edu.upenn.cis.orchestra.Debug;
import edu.upenn.cis.orchestra.datamodel.AtomArgument;
import edu.upenn.cis.orchestra.datamodel.Relation;
import edu.upenn.cis.orchestra.mappings.Rule;

public class ProvEdbNode extends ProvenanceNode {
	List<AtomArgument> _varNames;
	String _label;

	public ProvEdbNode(String label, List<AtomArgument> varNames) {
		super();
		_label = label;
		_varNames = new ArrayList<AtomArgument>();
		
		_varNames.addAll(varNames);
//		for (ScMappingAtomArgument arg : varNames)
//			_varNames.add(arg.deepCopy());
	}
	
	public String getLabel() {
		return _label;
	}
	
	public List<AtomArgument> getVarNames() {
		return _varNames;
	}
	
	public ProvEdbNode copySelf() {
		return new ProvEdbNode(_label, _varNames);
	}
	
	public String toString() {
		String ret = _label + "(";
		
		boolean first = true;
		for (AtomArgument a: _varNames) {
			if (!first)
				ret = ret + ",";
			first = false;
			ret = ret + a.toString();
		}
		
		return ret + ")";
	}

	public List<Object> getStringExpr() {
		List<Object> results = new ArrayList<Object>();
		
		results.add(_label + "(");
		
		//results.addAll(_varNames);
		boolean first = true;
		for (AtomArgument a: _varNames) {
			if (!first)
				results.add(",");
			first = false;
			results.add(a);
		}
		
		results.add(")");
		
		return results;
	}
	
	public List<Object> getValueExpr(Rule rule) {
		List<Object> results = new ArrayList<Object>();
		
//		results.add(_label + "(");
		//results.addAll(_varNames);
		boolean first = true;
//		results.add("value");
		boolean found = false;
		for(int i = 0; i < rule.getBody().size(); i++){
			if(!found && _label.equals(rule.getBody().get(i).getRelationContext().toString())){
				found = true;
				results.add("R"+i+"." + Relation.valueAttrName);
			}
		}
		if(!found){
			Debug.println("WHAT IS THIS?");
		}
		return results;
	}

}

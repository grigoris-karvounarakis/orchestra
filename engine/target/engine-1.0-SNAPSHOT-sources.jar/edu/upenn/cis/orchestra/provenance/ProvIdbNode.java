package edu.upenn.cis.orchestra.provenance;

import java.util.ArrayList;
import java.util.List;

import edu.upenn.cis.orchestra.Debug;
import edu.upenn.cis.orchestra.mappings.Rule;

public class ProvIdbNode extends ProvenanceNode {
	String _label;
	Integer _labelValue = 1;
	
	public ProvIdbNode(String label) {
		super();
		_label = label;
	}
	
	public ProvIdbNode(String label, List<ProvenanceNode> children) {
		super(children);
		_label = label;
	}
	
	public String getLabel() {
		return _label;
	}

	public String toString() {
		StringBuffer str = new StringBuffer(_label + "(");
		
		boolean first = true;
		for (ProvenanceNode p : getChildren()) {
			if (!first)
				str.append("*");
			str.append(p.toString());
			first = false;
		}
		str.append(")");
		
		return new String(str);
	}
	
	public ProvIdbNode copySelf() {
		return new ProvIdbNode(_label);
	}

	public List<Object> getStringExpr() {
		List<Object> results = new ArrayList<Object>();
		
		results.add(_label + "(");

		boolean first = true;
		for (ProvenanceNode p : getChildren()) {
			if (!first)
				results.add("*");
			results.addAll(p.getStringExpr());
			first = false;
		}
		results.add(")");
		
		simplify(results);
		
		return results;
	}
	
	public List<Object> getValueExpr(Rule rule) {
		List<Object> results = new ArrayList<Object>();
		
		results.add(_labelValue + "*(");

		boolean first = true;
		for (ProvenanceNode p : getChildren()) {
			if (!first)
				results.add("*");
			results.addAll(p.getValueExpr(rule));
			first = false;
		}
		results.add(")");
		if(first){
			Debug.println("NO CHILDREN?!");
		}
//		simplify(results);
		
		return results;
	}
	
}
